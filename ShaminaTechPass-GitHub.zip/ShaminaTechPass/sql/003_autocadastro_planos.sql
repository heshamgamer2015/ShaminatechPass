-- Autocadastro de estabelecimentos e planos (somente ADITIVO; não altera nem apaga nada existente).
-- Local: criada automaticamente pelo Hibernate (perfil local, ddl-auto=update) ao reiniciar o backend.
-- Produção (ddl-auto=validate): aplicar este script ANTES de subir a versão nova, com backup recente.
--
-- Um registro por estabelecimento que escolheu um plano (autocadastro). Guarda separadamente o plano, o preço
-- comercial previsto (centavos, só informativo), a condição gratuita da fase de testes e o estado de acesso.
-- NÃO é assinatura financeira: não há cobrança, meio de pagamento nem data de fim da fase de testes.
-- Estabelecimentos já existentes não recebem registro e continuam com os limites da sua política.

CREATE TABLE IF NOT EXISTS establishment_plan (
    id                BIGSERIAL PRIMARY KEY,
    establishment_id  BIGINT       NOT NULL,
    plan_code         VARCHAR(20)  NOT NULL,
    list_price_cents  INTEGER      NOT NULL,
    trial_free        BOOLEAN      NOT NULL,
    access_status     VARCHAR(20)  NOT NULL,
    origin            VARCHAR(20)  NOT NULL,
    terms_accepted_at TIMESTAMP WITH TIME ZONE,
    terms_version     VARCHAR(40),
    created_at        TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at        TIMESTAMP WITH TIME ZONE NOT NULL,
    version           BIGINT       NOT NULL,
    CONSTRAINT uk_establishment_plan_establishment UNIQUE (establishment_id),
    CONSTRAINT fk_establishment_plan_establishment FOREIGN KEY (establishment_id) REFERENCES establishment (id)
);
