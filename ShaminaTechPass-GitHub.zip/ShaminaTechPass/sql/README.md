# Scripts SQL — ShaminaTech Pass

Scripts executados **manualmente** pelo responsável. Nada aqui roda automaticamente.

| Script | Conteúdo | Executar como | Situação |
|---|---|---|---|
| `000_create_database.sql` | Cria a role `shaminatech_pass_app` e o banco `shaminatech_pass` | superusuário, banco `postgres` | ✅ executado no ambiente local |
| `001_etapa2_remove_enum_checks.sql` | Remove as 23 CHECKs de listas de enum geradas pelo Hibernate (inclui `audit_event.action`, que bloqueia os eventos da Etapa 2). Não altera dados. | dono do banco, banco `shaminatech_pass` | ⏳ aguardando aprovação/execução pelo responsável |

## Tabelas

- **Desenvolvimento local:** as tabelas são criadas e atualizadas pelo Hibernate a partir das entidades
  (perfil `local`, `ddl-auto=update`). Não há scripts manuais por tabela.
- **Produção:** o perfil `prod` usa `ddl-auto=validate`. Antes do primeiro deploy será preciso gerar e revisar
  um script de criação do schema (a partir das entidades) e executá-lo manualmente.

## Mudanças que o Hibernate não faz com segurança

O `update` **não** remove nem renomeia tabelas/colunas, **não** muda tipos e **não** cria coluna `NOT NULL`
em tabela que já tem dados. Nesses casos a mudança será apresentada como script SQL nesta pasta,
para revisão e execução manual, antes de alterar a entidade.

## Enums e restrições CHECK

O Hibernate 7 gera `CHECK (coluna IN (...))` para todo atributo enum — **inclusive com `AttributeConverter`**, porque deriva
a lista do tipo Java do atributo. Essas listas ficam congeladas: o `update` não as altera e qualquer valor novo é recusado.

Desde a Etapa 2 a aplicação registra `EnumWithoutCheckJavaType` para todo enum persistido via `EnumNameConverter`
(descoberta automática em `EnumCheckFreeTypeContributor`). Tabelas e colunas novas já nascem sem essas CHECKs; as
existentes são removidas pelo script `001`. Os valores continuam gravados como texto legível e validados pela aplicação.
Restrições de outra natureza (NOT NULL, UNIQUE, FK, PK, `@Check` explícito) não são afetadas.

## Etapa 5 — cadastro público por QR Code

Somente acréscimos, criados pelo Hibernate no perfil local (verificado no PostgreSQL local, sem CHECKs):

- **`public_signup_link`**: um link/QR Code público por programa (`token` aleatório de 128 bits, único; `active`;
  `token_created_at`; `status_changed_at`; `created_by`). Únicas: `uk_public_signup_link_token`, `uk_public_signup_link_program`.
- **`public_signup`**: um registro por autocadastro concluído (ids de estabelecimento, link, programa, consumidor e cartão;
  `request_key_hash` único = SHA-256 do identificador do envio; `signed_up_at`). Nenhum dado pessoal.
- Valores novos de enum gravados como texto: `card_transaction.channel = PUBLIC_SIGNUP`; `audit_event.action` =
  `SIGNUP_LINK_CREATED`, `SIGNUP_LINK_STATUS_CHANGED`, `SIGNUP_LINK_REGENERATED`, `CONSUMER_SELF_REGISTERED`;
  `consumer.source = PUBLIC_QR` (já previsto desde a Etapa 2). Em bancos que ainda tenham as CHECKs antigas, o script `001`
  é necessário antes de usar o cadastro público.
- Nenhuma coluna nova em tabela existente; nenhum dado alterado.

## Etapa 6 — notificações e proximidade

Somente acréscimos, criados pelo Hibernate no perfil local (verificado no PostgreSQL local, sem CHECKs; `PostgresSchemaIT`
com `ddl-auto=validate` aprovado):

- **`notification_settings`**: uma linha por estabelecimento (única), criada na primeira abertura da página. Categorias
  desligadas por padrão; critérios (carimbos/percentual, dias antes do vencimento, dias de inatividade, intervalo mínimo);
  `proximity_enabled`, `proximity_published` e `proximity_text`.
- **`establishment_location`**: até 10 endereços da loja (nome, endereço, cidade, UF, CEP, latitude, longitude). Nenhum
  dado de localização de consumidores é gravado.
- **`wallet_reminder`**: um pedido de aviso por situação (`dedup_key` única), com estado, texto enviado, tentativas,
  datas de aceite/retirada e último erro. Sem dados pessoais além das referências ao cartão.
- Valores novos de enum gravados como texto: `audit_event.action` = `NOTIFICATION_SETTINGS_CHANGED`,
  `ESTABLISHMENT_LOCATION_SAVED`, `ESTABLISHMENT_LOCATION_REMOVED`.
- Nenhuma coluna nova em tabela existente; nenhum dado alterado.

## Etapa 8 — recuperação de senha

- Tabela nova `password_reset_token` (script aditivo `002_etapa8_password_reset_token.sql`). Guarda só o hash SHA-256
  do token, validade e uso; chave estrangeira para `app_user`.
- Local: criada pelo Hibernate ao reiniciar o backend no perfil `local`. Produção: aplicar o script antes do deploy.
- Backup, restauração e verificação de integridade: `docs/seguranca-operacao.md`.

## Autocadastro de estabelecimentos e planos

- Tabela nova `establishment_plan` (script aditivo `003_autocadastro_planos.sql`): plano escolhido, preço comercial
  previsto (centavos, informativo), condição gratuita da fase de testes, estado de acesso, origem (autocadastro ou
  administrador) e aceite dos termos (data e versão). Um registro por estabelecimento (`establishment_id` único).
- Não é assinatura financeira: não há cobrança, meio de pagamento nem data de término da fase de testes.
- Valor novo de enum gravado como texto: `audit_event.action` = `ESTABLISHMENT_SELF_REGISTERED`.
- Estabelecimentos existentes não recebem registro (continuam com os limites da política); nenhum dado alterado.
