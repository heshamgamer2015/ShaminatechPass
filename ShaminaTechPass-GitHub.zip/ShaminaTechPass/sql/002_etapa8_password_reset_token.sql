-- Etapa 8 — tabela da recuperação de senha (somente ADITIVO; não altera nem apaga nada existente).
-- Local: criada automaticamente pelo Hibernate (perfil local, ddl-auto=update) ao reiniciar o backend.
-- Produção (ddl-auto=validate): aplicar este script ANTES de subir a versão nova, com backup recente.
-- Só o hash SHA-256 (hex, 64 caracteres) do token é gravado; o token em si nunca vai para o banco.

CREATE TABLE IF NOT EXISTS password_reset_token (
    id          BIGSERIAL PRIMARY KEY,
    user_id     BIGINT      NOT NULL,
    token_hash  VARCHAR(64) NOT NULL,
    created_at  TIMESTAMP WITH TIME ZONE NOT NULL,
    expires_at  TIMESTAMP WITH TIME ZONE NOT NULL,
    used_at     TIMESTAMP WITH TIME ZONE,
    CONSTRAINT uk_password_reset_token_hash UNIQUE (token_hash),
    CONSTRAINT fk_password_reset_token_user FOREIGN KEY (user_id) REFERENCES app_user (id)
);

CREATE INDEX IF NOT EXISTS ix_password_reset_token_user ON password_reset_token (user_id);
