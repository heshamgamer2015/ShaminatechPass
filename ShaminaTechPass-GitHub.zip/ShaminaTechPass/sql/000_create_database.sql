-- ShaminaTech Pass - Etapa 0
-- Execução MANUAL pelo responsável, conectado como superusuário (ex.: postgres) no banco "postgres".
-- Troque a senha abaixo ANTES de executar e NÃO versione a senha real.
--
--   psql -h localhost -U postgres -d postgres -f sql/000_create_database.sql

CREATE ROLE shaminatech_pass_app WITH LOGIN PASSWORD 'TROQUE_AQUI';

CREATE DATABASE shaminatech_pass
    WITH OWNER = shaminatech_pass_app
         ENCODING = 'UTF8'
         TEMPLATE = template0;
