-- ============================================================================
-- ShaminaTech Pass — Etapa 2
-- Remove as restrições CHECK de LISTAS DE ENUM geradas automaticamente pelo Hibernate 7.
--
-- Por quê: o Hibernate gera "CHECK (coluna IN (...))" para todo atributo enum, mesmo com
-- AttributeConverter. Essas listas ficam congeladas no banco (o ddl-auto=update não as altera)
-- e bloqueiam qualquer valor novo — foi o que aconteceu com audit_event.action.
-- A aplicação passou a não gerar mais essas CHECKs (EnumWithoutCheckJavaType); a validação dos
-- valores continua na aplicação (só grava constantes do enum e recusa valores desconhecidos ao ler).
--
-- O que este script faz:
--   * remove SOMENTE as 23 restrições abaixo, todas do tipo "coluna IN (lista de enum)";
--   * NÃO altera, move ou apaga registros; NÃO remove tabelas, colunas, NOT NULL, UNIQUE, FK nem PK;
--   * é idempotente (IF EXISTS) e roda em uma única transação (tudo ou nada).
--
-- Executar conectado ao banco shaminatech_pass com o dono do banco:
--   psql -U shaminatech_pass_app -d shaminatech_pass -f sql/001_etapa2_remove_enum_checks.sql
-- ============================================================================

BEGIN;

-- Etapa 1 -------------------------------------------------------------------
ALTER TABLE audit_event      DROP CONSTRAINT IF EXISTS audit_event_action_check;          -- bloqueia hoje os eventos da Etapa 2
ALTER TABLE app_user         DROP CONSTRAINT IF EXISTS app_user_platform_role_check;
ALTER TABLE app_user         DROP CONSTRAINT IF EXISTS app_user_status_check;
ALTER TABLE establishment    DROP CONSTRAINT IF EXISTS establishment_status_check;
ALTER TABLE membership       DROP CONSTRAINT IF EXISTS membership_role_check;
ALTER TABLE membership       DROP CONSTRAINT IF EXISTS membership_status_check;
ALTER TABLE role_permission  DROP CONSTRAINT IF EXISTS role_permission_role_check;

-- Etapa 2 -------------------------------------------------------------------
ALTER TABLE consumer         DROP CONSTRAINT IF EXISTS consumer_status_check;
ALTER TABLE consumer         DROP CONSTRAINT IF EXISTS consumer_source_check;
ALTER TABLE loyalty_program  DROP CONSTRAINT IF EXISTS loyalty_program_type_check;
ALTER TABLE loyalty_program  DROP CONSTRAINT IF EXISTS loyalty_program_status_check;
ALTER TABLE loyalty_program  DROP CONSTRAINT IF EXISTS loyalty_program_validity_mode_check;
ALTER TABLE loyalty_program  DROP CONSTRAINT IF EXISTS loyalty_program_expired_balance_policy_check;
ALTER TABLE loyalty_program  DROP CONSTRAINT IF EXISTS loyalty_program_reversal_policy_check;
ALTER TABLE loyalty_program  DROP CONSTRAINT IF EXISTS loyalty_program_rounding_check;
ALTER TABLE loyalty_program  DROP CONSTRAINT IF EXISTS loyalty_program_stamp_criterion_check;
ALTER TABLE loyalty_card     DROP CONSTRAINT IF EXISTS loyalty_card_status_check;
ALTER TABLE card_transaction DROP CONSTRAINT IF EXISTS card_transaction_type_check;
ALTER TABLE card_transaction DROP CONSTRAINT IF EXISTS card_transaction_channel_check;
ALTER TABLE card_transaction DROP CONSTRAINT IF EXISTS card_transaction_card_status_after_check;
ALTER TABLE benefit_lot      DROP CONSTRAINT IF EXISTS benefit_lot_status_check;
ALTER TABLE wallet_pass      DROP CONSTRAINT IF EXISTS wallet_pass_provider_check;
ALTER TABLE wallet_pass      DROP CONSTRAINT IF EXISTS wallet_pass_sync_status_check;

COMMIT;

-- Conferência (somente leitura): deve retornar 0 linhas.
SELECT c.conrelid::regclass AS tabela, c.conname AS restricao, pg_get_constraintdef(c.oid) AS definicao
FROM pg_constraint c
JOIN pg_namespace n ON n.oid = c.connamespace
WHERE c.contype = 'c' AND n.nspname = 'public'
ORDER BY 1, 2;
