# ShaminaTech Pass — segurança e operação (Etapa 8)

Documento de referência para colocar o Pass em produção com segurança. Tudo aqui foi verificado no código e, quando
indicado, por testes automatizados.

## 1. Sessões e cookies

| Item | Comportamento | Evidência |
|---|---|---|
| Sessão | No servidor (cookie `STPASS_SESSION`), `HttpOnly`, `SameSite=Lax`, validade 8 h | `application.yml` |
| `Secure` | `false` só no ambiente local HTTP; perfil `prod` força `true` e a aplicação **não sobe** sem ele | `application-prod.yml`, `ProductionSafetyCheck` |
| Cookie CSRF `XSRF-TOKEN` | Legível pelo Angular (necessário), `Secure` igual ao da sessão, `SameSite=Lax` | `SecurityConfig` |
| Fixação de sessão | Novo identificador a cada login e troca de senha | `SessionSecurityTest.loginIssuesANewSessionIdentifier` |
| Troca de senha | Encerra **todas as outras** sessões do usuário (a sessão atual continua) | `SessionSecurityTest` |
| Nova senha temporária (admin) / recuperação | Encerra todas as sessões abertas do usuário | `SessionSecurityTest`, `PasswordResetTest` |
| Usuário desativado ou com papel alterado | Sessão encerrada na requisição seguinte (401 `SESSION_REVOKED`) | `AuthFlowTest` |
| Estabelecimento suspenso/cancelado | Acesso ao painel bloqueado na requisição seguinte (403 `ESTABLISHMENT_INACTIVE`) | `TenantIsolationTest`, `AdminPanelTest` |
| Hash da senha na sessão | Não é guardado: a sessão guarda só uma marca SHA-256 do hash | `SessionSecurityTest` |

Como funciona a revogação por troca de senha: no login, a sessão recebe `credentialStamp = SHA-256(hash da senha)`.
A cada requisição, `SessionUserRevalidationFilter` compara com o hash atual do banco; se a senha mudou em qualquer
lugar, a sessão é encerrada.

## 2. IP real atrás de proxy (limite de tentativas)

| Configuração | Efeito |
|---|---|
| Padrão (`FORWARD_HEADERS_STRATEGY=none`) | `X-Forwarded-For` é **ignorado**; o IP é o da conexão TCP. Seguro sem proxy. |
| Produção atrás de proxy: `FORWARD_HEADERS_STRATEGY=native` + `TRUSTED_PROXIES=<regex exata do IP do proxy>` | O IP real vem do `X-Forwarded-For`, **somente** quando a conexão vem do proxy confiável. Vale o último IP não confiável da cadeia (o cliente não consegue inserir um IP falso à esquerda). O esquema HTTPS do proxy também passa a ser reconhecido. |
| `native` sem `TRUSTED_PROXIES` | Nenhum proxy é confiável (o padrão do Tomcat confiaria em qualquer IP privado — por isso foi anulado). Aviso no log de produção. |

Testes com servidor HTTP real: `ProxyWithoutConfigTest`, `ProxyUntrustedSourceTest`, `ProxyTrustedTest`.

**Limites em memória**: os contadores (`PublicRateLimitFilter`, `SignupGuard`, recuperação de senha, bloqueio de
login fica no banco) vivem na memória de cada instância. Consequências: zeram ao reiniciar; com N instâncias, o limite
efetivo é N vezes maior. Com uma instância (cenário inicial) é adequado. Para várias instâncias será preciso um
armazenamento compartilhado (Redis ou tabela no PostgreSQL) — **decisão pendente de aprovação** (infraestrutura nova).

## 3. Frontend em produção (cabeçalhos e CSP)

Configuração pronta em `deploy/nginx/shaminatech-pass.conf`. Pontos-chave:

- CSP sem `unsafe-inline`: `script-src 'self' 'nonce-…'; style-src 'self' 'nonce-…'; img-src 'self' data: blob:;
  connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'`.
- O build não tem mais script nem estilo embutidos (`inlineCritical: false`). O Angular aplica o nonce do atributo
  `ngCspNonce` aos estilos que injeta; o servidor troca `__CSP_NONCE__` por um valor aleatório **a cada resposta**.
- `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`,
  `Permissions-Policy: camera=(self), geolocation=()…` (câmera só para a leitura do QR no balcão), `X-Frame-Options: DENY`,
  HSTS, `index.html` com `Cache-Control: no-store`.
- Validação local: `python -I deploy/csp-test-server.py` (mesmos cabeçalhos) — 20 rotas do painel e o cadastro
  público percorridos sem nenhuma violação de CSP.
- Regra para o código: **não usar atributo `style="..."` em templates** (a CSP bloqueia); usar classes ou
  `[style.x]` (que o Angular aplica via CSSOM, permitido).
- Se o servidor de hospedagem não puder trocar o nonce por resposta, a alternativa é `style-src 'self' 'unsafe-inline'`
  (scripts continuam rígidos) — só com aprovação, pois enfraquece a proteção contra injeção de CSS.

## 4. Recuperação de acesso empresarial

Fundação implementada (`auth/reset`), **canal de entrega desativado** (nenhum provedor de e-mail contratado):

- `POST /api/auth/password-reset/request` — resposta 202 sempre igual; limite 3/h por e-mail e 20/h por IP; um
  pedido novo invalida os anteriores; token de 256 bits; banco guarda só o SHA-256; validade 30 min.
- `POST /api/auth/password-reset/confirm` — uso único (linha bloqueada), política de senha forte, desbloqueia a conta,
  encerra todas as sessões, auditoria `PASSWORD_RESET_COMPLETED` (sem token nem senha).
- Sem provedor: o pedido é auditado como "não configurado" e **nenhum token é emitido**.
- Para ativar: implementar `PasswordResetSender` (SMTP ou serviço transacional), criar a tela `/redefinir-senha` no
  Angular e o link "Esqueci a senha". Até lá, o caminho continua: o administrador ShaminaTech gera uma senha
  temporária (troca obrigatória no próximo acesso), que também encerra as sessões antigas.

## 5. Recuperação de cartão do consumidor

Auditado: o cadastro público **nunca** mostra o cartão de quem já existe (telefone/e-mail repetido → resposta genérica
"peça no balcão"); o link da carteira só é gerado pelo estabelecimento logado, depois de identificar o cliente
pessoalmente. Recuperação remota segura exigiria comprovar a posse do telefone ou e-mail (código de uso único por SMS ou
e-mail) — depende de provedor externo; **permanece presencial** nesta versão.

## 6. Tokens do QR Code de cadastro

Modelo de ameaça: o token do QR é **público por natureza** (impresso no balcão); conhecê-lo só permite fazer o
cadastro no programa, exatamente como escanear o cartaz. Ele não dá acesso a cartões, saldos ou dados pessoais. Quem
lê o banco já tem acesso a todos os dados pessoais, então o hash do token não reduziria esse risco — e impediria o
painel de mostrar e baixar o QR de novo. Controles existentes: 128 bits aleatórios, "Desativar" e "Gerar novo código"
(invalida o anterior), limite por IP, campo isca, formulário assinado com tempo mínimo de preenchimento, limite de
clientes com bloqueio de linha. **Decisão: manter o armazenamento atual.** (Tokens de link da carteira e de
recuperação de senha, que dão acesso a algo, são guardados só como hash.)

## 7. Google Wallet — `addMessage` HTTP 409

A documentação oficial não define o significado de 409 nesse método. Antes: 409 era tratado como "aceito". Agora:
o Pass lê o objeto no Google; só marca **Aceito** se a mensagem com o mesmo id estiver gravada no cartão (pedido
anterior cuja resposta se perdeu). Mensagem ausente → **Recusado** (sem reenvio). Falha ao consultar → **Falha**, com
nova tentativa (que verifica de novo). Testes: `NotificationRemindersTest.conflict409*`.

## 8. Backup e restauração (PostgreSQL)

**Backup diário** (no servidor do banco, usuário só com leitura é suficiente):

```bash
pg_dump --format=custom --no-owner --file=/backup/pass-$(date +%F).dump "$DATABASE_URL"
```

- Retenção sugerida: 7 diários + 4 semanais + 3 mensais; cópia cifrada fora do servidor.
- Para recuperação a um ponto no tempo (mais robusto), habilitar arquivamento de WAL (`archive_mode`) ou usar o
  backup gerenciado do provedor do PostgreSQL.

**Restauração — sempre num banco NOVO, nunca sobre o principal:**

```bash
createdb pass_restore_teste
pg_restore --no-owner --dbname=pass_restore_teste /backup/pass-AAAA-MM-DD.dump
```

**Verificação de integridade após restaurar** (ou a qualquer momento, somente leitura): as consultas de
`backend/src/test/java/com/shaminatech/pass/PostgresIntegrityIT.java` — saldo = lotes = último saldo registrado,
ausência de saldo negativo, de vínculos entre empresas diferentes e de estornos duplicados. No banco local (Etapa 8):
0 inconsistências em 11 verificações.

**Teste de restauração**: mensal, restaurar o último backup num banco temporário, rodar a verificação de integridade e
apagar o banco temporário.

**Atualização de schema em produção** (sem Flyway/Liquibase, por decisão do projeto):

1. Backup imediatamente antes.
2. Aplicar os scripts aditivos de `sql/` na ordem (ex.: `002_etapa8_password_reset_token.sql`).
3. Subir a versão nova com `ddl-auto=validate` — se o schema não bater, a aplicação **não sobe** (nada é alterado).
4. Em falha: voltar a versão anterior da aplicação (os scripts são aditivos e compatíveis com ela).

## 9. Logs e erros

- Respostas de erro sem stack trace nem mensagem interna (`server.error.include-*: never`).
- Logs não contêm senhas, tokens de sessão, de recuperação ou de carteira, nem a chave do Google. A falha de entrega da
  recuperação registra só o id interno da conta.
- Na inicialização, um ajuste de dados aditivo e idempotente (`LoyaltyStartupInitializer`) preenche
  `membership.account_slot` quando falta — não apaga nem altera vínculos existentes.
