package com.shaminatech.pass.tenant;

import java.util.Set;

import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.membership.Membership;
import com.shaminatech.pass.membership.Permission;

/** Resultado de uma verificação de acesso bem-sucedida a um estabelecimento. */
public record TenantAccess(Establishment establishment, Membership membership, Set<Permission> permissions) {

    public Long establishmentId() {
        return establishment.getId();
    }

    public boolean has(Permission permission) {
        return permissions.contains(permission);
    }
}
