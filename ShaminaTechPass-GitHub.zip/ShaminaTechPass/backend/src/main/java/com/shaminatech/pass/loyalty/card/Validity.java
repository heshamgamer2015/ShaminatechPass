package com.shaminatech.pass.loyalty.card;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;

import com.shaminatech.pass.loyalty.program.ProgramEnums.ValidityMode;

/**
 * Cálculo de validade. O resultado é um instante <b>exclusivo</b>: vale enquanto {@code agora < resultado}.
 * <ul>
 *   <li>END_OF_DAY: data local (fuso do estabelecimento) da movimentação + N dias; vale até 23:59:59 desse dia.
 *       Ex.: compra em 15/11 às 14h10, 30 dias → vale até 15/12 23:59:59 (vence às 00:00 de 16/12).</li>
 *   <li>EXACT_TIME: mesmo horário local, N dias depois (respeita mudanças de horário de verão).
 *       Ex.: 15/11 14h10 → vence 15/12 14h10.</li>
 * </ul>
 */
public final class Validity {

    private Validity() {
    }

    public static Instant expiresAt(Instant from, int days, ValidityMode mode, ZoneId zone) {
        LocalDateTime local = LocalDateTime.ofInstant(from, zone);
        if (mode == ValidityMode.EXACT_TIME) {
            return local.plusDays(days).atZone(zone).toInstant();
        }
        LocalDate lastDay = local.toLocalDate().plusDays(days);
        return lastDay.plusDays(1).atStartOfDay(zone).toInstant();
    }

    /** Último instante em que ainda vale (para exibição): um segundo antes do vencimento exclusivo. */
    public static LocalDateTime validUntilLocal(Instant expiresAt, ZoneId zone) {
        return LocalDateTime.ofInstant(expiresAt.minusSeconds(1), zone);
    }
}
