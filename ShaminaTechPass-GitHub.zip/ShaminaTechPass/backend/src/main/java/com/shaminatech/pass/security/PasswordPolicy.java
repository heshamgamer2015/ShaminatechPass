package com.shaminatech.pass.security;

import java.nio.charset.StandardCharsets;
import java.util.Optional;

/** Regras mínimas de senha. BCrypt considera no máximo 72 bytes, por isso o limite. */
public final class PasswordPolicy {

    public static final int MIN_LENGTH = 10;
    public static final int MAX_BYTES = 72;

    private PasswordPolicy() {
    }

    /** @return a mensagem da regra violada, ou vazio se a senha é aceitável. */
    public static Optional<String> violation(String password) {
        if (password == null || password.isBlank()) {
            return Optional.of("Informe a senha.");
        }
        if (password.length() < MIN_LENGTH) {
            return Optional.of("A senha deve ter pelo menos " + MIN_LENGTH + " caracteres.");
        }
        if (password.getBytes(StandardCharsets.UTF_8).length > MAX_BYTES) {
            return Optional.of("A senha é longa demais.");
        }
        boolean hasLetter = password.chars().anyMatch(Character::isLetter);
        boolean hasDigit = password.chars().anyMatch(Character::isDigit);
        if (!hasLetter || !hasDigit) {
            return Optional.of("A senha deve conter letras e números.");
        }
        return Optional.empty();
    }
}
