package com.shaminatech.pass.loyalty.wallet.apple;

import java.security.SecureRandom;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.Comparator;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Links temporários de instalação do passe de homologação (perfil {@code local}). Tudo fica <b>só em memória</b>:
 * nada é gravado em disco e tudo some ao reiniciar o backend.
 * <ul>
 *   <li>token de 32 bytes do {@link SecureRandom} (base64url, 43 caracteres), associado a um único arquivo gerado;</li>
 *   <li>válido por 15 minutos e <b>não</b> consumido no primeiro acesso (o iPhone pode baixar mais de uma vez),
 *       mas limitado a {@value #MAX_DOWNLOADS} downloads;</li>
 *   <li>no máximo {@value #MAX_ACTIVE} links ativos (o mais antigo sai);</li>
 *   <li>links vencidos perdem o arquivo na hora e ficam só como registro por 1 hora, para responder "expirado".</li>
 * </ul>
 */
@Component
@Profile("local")
public class AppleHomologationLinks {

    public static final Duration TTL = Duration.ofMinutes(15);
    static final int MAX_ACTIVE = 5;
    static final int MAX_DOWNLOADS = 30;
    private static final Duration TOMBSTONE = Duration.ofHours(1);
    private static final java.util.regex.Pattern TOKEN = java.util.regex.Pattern.compile("^[A-Za-z0-9_-]{43}$");

    /** Link criado (sem o arquivo). */
    public record Link(String token, String serialNumber, String sha256, int sizeBytes, Instant createdAt, Instant expiresAt) {
    }

    /** Resultado da consulta pelo token. */
    public sealed interface Lookup {
        record Found(String serialNumber, byte[] data) implements Lookup {
        }

        record Expired() implements Lookup {
        }

        record NotFound() implements Lookup {
        }
    }

    private static final class Entry {
        final Link link;
        final long sequence;
        volatile byte[] data;
        int downloads;

        Entry(Link link, long sequence, byte[] data) {
            this.link = link;
            this.sequence = sequence;
            this.data = data;
        }
    }

    private final Map<String, Entry> entries = new ConcurrentHashMap<>();
    private final SecureRandom random = new SecureRandom();
    private long sequence;
    private final Clock clock;

    public AppleHomologationLinks(Clock clock) {
        this.clock = clock;
    }

    public synchronized Link create(AppleOfflineHomologation.Generated pass) {
        cleanup();
        Instant now = clock.instant();
        byte[] bytes = new byte[32];
        random.nextBytes(bytes);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        Link link = new Link(token, pass.serialNumber(), pass.sha256(), pass.data().length, now, now.plus(TTL));
        entries.put(token, new Entry(link, ++sequence, pass.data()));
        while (entries.values().stream().filter(e -> e.data != null).count() > MAX_ACTIVE) {
            entries.values().stream().filter(e -> e.data != null).min(Comparator.comparingLong(e -> e.sequence))
                    .ifPresent(e -> e.data = null); // o mais antigo deixa de ser baixável
        }
        return link;
    }

    /** Arquivo do token, se válido. Não consome o token (o iPhone pode repetir a requisição). */
    public synchronized Lookup find(String token) {
        if (token == null || !TOKEN.matcher(token).matches()) {
            return new Lookup.NotFound();
        }
        Entry entry = entries.get(token);
        if (entry == null) {
            return new Lookup.NotFound();
        }
        if (!clock.instant().isBefore(entry.link.expiresAt()) || entry.data == null || entry.downloads >= MAX_DOWNLOADS) {
            entry.data = null;
            return new Lookup.Expired();
        }
        entry.downloads++;
        return new Lookup.Found(entry.link.serialNumber(), entry.data);
    }

    /** Link ainda ativo (para o painel validar o endereço do QR Code). */
    public synchronized Optional<Link> active(String token) {
        Entry entry = token == null ? null : entries.get(token);
        return entry == null || entry.data == null || !clock.instant().isBefore(entry.link.expiresAt())
                ? Optional.empty() : Optional.of(entry.link);
    }

    /** Remove arquivos vencidos e registros antigos. Roda também a cada minuto. */
    @Scheduled(fixedDelay = 60_000, initialDelay = 60_000)
    public synchronized void cleanup() {
        Instant now = clock.instant();
        entries.values().forEach(e -> {
            if (!now.isBefore(e.link.expiresAt())) {
                e.data = null;
            }
        });
        entries.values().removeIf(e -> now.isAfter(e.link.expiresAt().plus(TOMBSTONE)));
    }

    synchronized int stored() {
        return (int) entries.values().stream().filter(e -> e.data != null).count();
    }
}
