package com.shaminatech.pass.loyalty.signup;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.EnumMap;
import java.util.Map;

import javax.imageio.ImageIO;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

/** Gera QR Codes em SVG (impressão nítida em qualquer tamanho) e PNG. Correção de erro M e margem de 4 módulos. */
public final class QrCodes {

    private QrCodes() {
    }

    private static BitMatrix matrix(String text) {
        Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        hints.put(EncodeHintType.MARGIN, 4);
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        try {
            // Tamanho 0: um pixel por módulo; a escala é feita na saída.
            return new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, hints);
        } catch (WriterException e) {
            throw new IllegalArgumentException("Conteúdo não cabe em um QR Code.", e);
        }
    }

    public static String svg(String text) {
        BitMatrix m = matrix(text);
        int w = m.getWidth();
        int h = m.getHeight();
        StringBuilder path = new StringBuilder();
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if (m.get(x, y)) {
                    int run = 1;
                    while (x + run < w && m.get(x + run, y)) {
                        run++;
                    }
                    path.append('M').append(x).append(',').append(y).append('h').append(run).append("v1h-").append(run).append('z');
                    x += run - 1;
                }
            }
        }
        return "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 " + w + " " + h + "\" shape-rendering=\"crispEdges\">"
                + "<rect width=\"100%\" height=\"100%\" fill=\"#fff\"/><path fill=\"#000\" d=\"" + path + "\"/></svg>";
    }

    public static byte[] png(String text, int targetSize) {
        BitMatrix m = matrix(text);
        int scale = Math.max(1, targetSize / m.getWidth());
        int size = m.getWidth() * scale;
        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_BYTE_BINARY);
        Graphics2D g = image.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, size, size);
        g.setColor(Color.BLACK);
        for (int y = 0; y < m.getHeight(); y++) {
            for (int x = 0; x < m.getWidth(); x++) {
                if (m.get(x, y)) {
                    g.fillRect(x * scale, y * scale, scale, scale);
                }
            }
        }
        g.dispose();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            ImageIO.write(image, "png", out);
            return out.toByteArray();
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
