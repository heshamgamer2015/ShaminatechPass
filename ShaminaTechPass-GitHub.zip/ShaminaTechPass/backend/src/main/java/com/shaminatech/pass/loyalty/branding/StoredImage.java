package com.shaminatech.pass.loyalty.branding;

import java.time.Instant;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

/**
 * Imagem enviada pela empresa (logotipo ou destaque do cartão). Fica no banco (bytea), já validada e
 * <b>recodificada</b> pelo servidor: metadados (EXIF, localização) são descartados e só PNG/JPEG são aceitos.
 * Servida apenas pela API autenticada do próprio estabelecimento.
 */
@Entity
@Table(name = "stored_image", indexes = @Index(name = "idx_stored_image_establishment", columnList = "establishment_id"),
        uniqueConstraints = @jakarta.persistence.UniqueConstraint(name = "uk_stored_image_public_token", columnNames = "public_token"))
public class StoredImage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "establishment_id", nullable = false, updatable = false)
    private Long establishmentId;

    @Column(name = "content_type", nullable = false, length = 20, updatable = false)
    private String contentType;

    @JdbcTypeCode(SqlTypes.VARBINARY)
    @Column(nullable = false, updatable = false, columnDefinition = "bytea") // PostgreSQL (e H2 em modo PostgreSQL nos testes)
    private byte[] data;

    @Column(nullable = false, updatable = false)
    private int width;

    @Column(nullable = false, updatable = false)
    private int height;

    @Column(name = "size_bytes", nullable = false, updatable = false)
    private int sizeBytes;

    @Column(length = 64, nullable = false, updatable = false)
    private String sha256;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    /**
     * Token aleatório (128 bits) da URL pública da imagem, exigida pelo Google Wallet, que baixa logotipo e
     * destaque pela internet. Sem o token a imagem só é servida pela API autenticada do estabelecimento.
     */
    @Column(name = "public_token", length = 32)
    private String publicToken;

    protected StoredImage() {
    }

    public StoredImage(Long establishmentId, String contentType, byte[] data, int width, int height, String sha256) {
        this.establishmentId = establishmentId;
        this.contentType = contentType;
        this.data = data;
        this.width = width;
        this.height = height;
        this.sizeBytes = data.length;
        this.sha256 = sha256;
    }

    @PrePersist
    void onCreate() {
        createdAt = Instant.now();
        ensurePublicToken();
    }

    /** Gera o token público se ainda não existir (imagens antigas recebem na primeira publicação). */
    public String ensurePublicToken() {
        if (publicToken == null) {
            byte[] bytes = new byte[16];
            new java.security.SecureRandom().nextBytes(bytes);
            publicToken = java.util.HexFormat.of().formatHex(bytes);
        }
        return publicToken;
    }

    public Long getId() { return id; }
    public Long getEstablishmentId() { return establishmentId; }
    public String getContentType() { return contentType; }
    public byte[] getData() { return data; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public int getSizeBytes() { return sizeBytes; }
    public String getSha256() { return sha256; }
    public String getPublicToken() { return publicToken; }
}
