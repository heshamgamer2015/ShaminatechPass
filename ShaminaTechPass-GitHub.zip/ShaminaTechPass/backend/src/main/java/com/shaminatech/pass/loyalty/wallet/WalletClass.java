package com.shaminatech.pass.loyalty.wallet;

import java.time.Instant;

import com.shaminatech.pass.common.persistence.BaseEntity;
import com.shaminatech.pass.loyalty.wallet.WalletPass.Provider;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Classe do programa na carteira (Google: LoyaltyClass). Uma por programa de fidelidade, com a identidade visual do
 * estabelecimento. {@code syncedFingerprint} guarda o resumo do conteúdo enviado: a classe só é reenviada quando o
 * programa ou a personalização mudam.
 */
@Entity
@Table(name = "wallet_class",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_wallet_class_program_provider", columnNames = {"program_id", "provider"}),
                @UniqueConstraint(name = "uk_wallet_class_external", columnNames = {"provider", "external_id"})})
public class WalletClass extends BaseEntity {

    @Column(name = "establishment_id", nullable = false)
    private Long establishmentId;

    @Column(name = "program_id", nullable = false)
    private Long programId;

    @Column(nullable = false, length = 20)
    private Provider provider;

    @Column(name = "external_id", nullable = false, length = 200)
    private String externalId;

    @Column(name = "synced_fingerprint", length = 64)
    private String syncedFingerprint;

    @Column(name = "last_synced_at")
    private Instant lastSyncedAt;

    protected WalletClass() {
    }

    public WalletClass(Long establishmentId, Long programId, Provider provider, String externalId) {
        this.establishmentId = establishmentId;
        this.programId = programId;
        this.provider = provider;
        this.externalId = externalId;
    }

    public void synced(String fingerprint, Instant now) {
        this.syncedFingerprint = fingerprint;
        this.lastSyncedAt = now;
    }

    public Long getEstablishmentId() { return establishmentId; }
    public Long getProgramId() { return programId; }
    public Provider getProvider() { return provider; }
    public String getExternalId() { return externalId; }
    public String getSyncedFingerprint() { return syncedFingerprint; }
    public Instant getLastSyncedAt() { return lastSyncedAt; }
}
