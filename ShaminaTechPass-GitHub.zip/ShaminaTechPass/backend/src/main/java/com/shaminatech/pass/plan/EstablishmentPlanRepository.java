package com.shaminatech.pass.plan;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface EstablishmentPlanRepository extends JpaRepository<EstablishmentPlan, Long> {

    @Query("select p from EstablishmentPlan p where p.establishment.id = :establishmentId")
    Optional<EstablishmentPlan> findByEstablishmentId(@Param("establishmentId") Long establishmentId);

    @Query("select p from EstablishmentPlan p where p.establishment.id in :ids")
    List<EstablishmentPlan> findByEstablishmentIds(@Param("ids") Collection<Long> ids);
}
