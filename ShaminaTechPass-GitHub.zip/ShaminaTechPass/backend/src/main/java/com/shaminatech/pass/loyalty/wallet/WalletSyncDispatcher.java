package com.shaminatech.pass.loyalty.wallet;

import java.time.Clock;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import com.shaminatech.pass.loyalty.wallet.WalletPass.Provider;
import com.shaminatech.pass.loyalty.wallet.apple.AppleWalletGateway;
import com.shaminatech.pass.loyalty.wallet.apple.AppleWalletSync;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletProperties;

/**
 * Dispara as sincronizações de cada carteira (Google: envia o objeto; Apple: notifica os aparelhos registrados):
 * <ul>
 *   <li>logo após o commit de uma movimentação (em segundo plano; a resposta ao caixa não espera a carteira);</li>
 *   <li>a cada minuto, para recuperar pendências: falhas temporárias, envios interrompidos (reserva vencida) e passes
 *       que mudaram enquanto o serviço estava fora do ar.</li>
 * </ul>
 * Cada passe vai só para o serviço do seu provedor, e só se aquela integração estiver ligada.
 * Se a fila estiver cheia ou o processo cair, nada se perde: o passe continua PENDING no banco e a varredura o reenvia.
 */
@Component
public class WalletSyncDispatcher {

    private static final Logger log = LoggerFactory.getLogger(WalletSyncDispatcher.class);

    private final WalletSyncService sync;
    private final AppleWalletSync appleSync;
    private final WalletPassRepository passes;
    private final GoogleWalletProperties properties;
    private final AppleWalletGateway apple;
    private final Clock clock;
    private final ThreadPoolTaskExecutor executor;

    public WalletSyncDispatcher(WalletSyncService sync, AppleWalletSync appleSync, WalletPassRepository passes,
                                GoogleWalletProperties properties, AppleWalletGateway apple, Clock clock) {
        this.sync = sync;
        this.appleSync = appleSync;
        this.passes = passes;
        this.properties = properties;
        this.apple = apple;
        this.clock = clock;
        this.executor = new ThreadPoolTaskExecutor();
        this.executor.setThreadNamePrefix("wallet-sync-");
        this.executor.setCorePoolSize(2);
        this.executor.setMaxPoolSize(2);
        this.executor.setQueueCapacity(500);
        this.executor.initialize();
    }

    public void dispatch(Collection<Long> passIds) {
        if (!anyEnabled() || passIds.isEmpty()) {
            return;
        }
        Executor target = properties.asyncDispatch() ? executor : Runnable::run;
        for (Long id : passIds) {
            try {
                target.execute(() -> safeProcess(id));
            } catch (RejectedExecutionException e) {
                log.warn("Fila de sincronização cheia; o passe {} será enviado pela varredura periódica.", id);
            }
        }
    }

    /** Varredura de recuperação (a cada 60 s). */
    @Scheduled(initialDelayString = "${shaminatech.wallet.google.sweep-initial-delay:PT30S}", fixedDelayString = "${shaminatech.wallet.google.sweep-interval:PT60S}")
    public void sweep() {
        if (!anyEnabled()) {
            return;
        }
        List<Provider> providers = new java.util.ArrayList<>();
        if (properties.enabled()) {
            providers.add(Provider.GOOGLE_WALLET);
        }
        if (apple.enabled()) {
            providers.add(Provider.APPLE_WALLET);
        }
        List<Long> due = passes.findDueIds(clock.instant(), providers, PageRequest.of(0, 100));
        due.forEach(this::safeProcess);
    }

    private boolean anyEnabled() {
        return properties.enabled() || apple.enabled();
    }

    private void safeProcess(Long id) {
        try {
            Provider provider = passes.findProviderById(id).orElse(null);
            if (provider == Provider.GOOGLE_WALLET && properties.enabled()) {
                sync.process(id);
            } else if (provider == Provider.APPLE_WALLET && apple.enabled()) {
                appleSync.process(id);
            }
        } catch (RuntimeException e) {
            log.error("Falha ao sincronizar o passe {} com a carteira digital", id, e);
        }
    }
}
