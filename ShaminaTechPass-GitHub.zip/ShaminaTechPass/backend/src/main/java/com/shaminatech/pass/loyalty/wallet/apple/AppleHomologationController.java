package com.shaminatech.pass.loyalty.wallet.apple;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.loyalty.signup.QrCodes;

/**
 * Homologação Apple Wallet no painel ShaminaTech — <b>só no perfil {@code local}</b> (em produção o controlador nem
 * existe). As rotas {@code /api/admin/**} exigem administrador da plataforma (SecurityConfig). A rota pública entrega
 * exclusivamente o .pkpass de demonstração associado a um token temporário válido; não há acesso a arquivos em disco.
 */
@RestController
@Profile("local")
public class AppleHomologationController {

    private static final Logger log = LoggerFactory.getLogger(AppleHomologationController.class);
    public static final String PUBLIC_PATH = "/api/public/apple-wallet-homologation/";
    private static final Pattern INSTALL_PATH = Pattern.compile("^" + Pattern.quote(PUBLIC_PATH) + "([A-Za-z0-9_-]{43})$");

    private final AppleOfflineHomologation generator;
    private final AppleHomologationLinks links;
    private final AppleWalletProperties properties;

    public AppleHomologationController(AppleOfflineHomologation generator, AppleHomologationLinks links,
                                       AppleWalletProperties properties) {
        this.generator = generator;
        this.links = links;
        this.properties = properties;
    }

    public record CertificateView(boolean loaded, String passTypeIdentifier, String teamIdentifier, String subject, String issuer,
                                  Instant expiresAt, String error) {
    }

    public record StatusView(boolean ready, CertificateView certificate, List<String> missing, boolean updatablePassesConfigured,
                             List<String> lanAddresses, long linkTtlMinutes) {
    }

    public record GeneratedView(String serialNumber, String sha256, int sizeBytes, String token, String installPath,
                                Instant createdAt, Instant expiresAt) {
    }

    @GetMapping("/api/admin/apple-wallet/homologation")
    public ResponseEntity<StatusView> status() {
        List<String> missing = properties.missingForOfflinePass();
        CertificateView certificate;
        if (missing.isEmpty()) {
            try {
                AppleCredentials c = AppleCredentials.load(properties);
                certificate = new CertificateView(true, AppleCredentials.attribute(c.certificate(), "UID"),
                        AppleCredentials.attribute(c.certificate(), "OU"), AppleCredentials.attribute(c.certificate(), "CN"),
                        AppleCredentials.attribute(c.certificate(), "CN") == null ? null : issuerName(c), c.expiresAt(), null);
            } catch (AppleWalletException e) {
                certificate = new CertificateView(false, properties.passTypeIdentifier(), properties.teamIdentifier(), null, null, null,
                        e.getMessage());
            }
        } else {
            certificate = new CertificateView(false, properties.passTypeIdentifier(), properties.teamIdentifier(), null, null, null, null);
        }
        return ResponseEntity.ok().cacheControl(CacheControl.noStore())
                .body(new StatusView(certificate.loaded(), certificate, missing, properties.missing().isEmpty(), lanAddresses(),
                        AppleHomologationLinks.TTL.toMinutes()));
    }

    @PostMapping("/api/admin/apple-wallet/homologation/passes")
    public ResponseEntity<GeneratedView> generate() {
        AppleOfflineHomologation.Generated pass;
        try {
            pass = generator.build();
        } catch (AppleWalletException e) {
            throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE, "APPLE_HOMOLOGATION_UNAVAILABLE", e.getMessage());
        }
        AppleHomologationLinks.Link link = links.create(pass);
        log.info("Homologação Apple Wallet: link de instalação criado para o serial {} (válido até {})", link.serialNumber(),
                link.expiresAt());
        return ResponseEntity.status(HttpStatus.CREATED).cacheControl(CacheControl.noStore())
                .body(new GeneratedView(link.serialNumber(), link.sha256(), link.sizeBytes(), link.token(),
                        PUBLIC_PATH + link.token(), link.createdAt(), link.expiresAt()));
    }

    /**
     * QR Code (SVG) do endereço de instalação. Só aceita o endereço de um link <b>ativo</b>, em http(s), sem
     * usuário/senha, consulta ou fragmento, e nunca localhost: o QR Code não serve para codificar outros endereços.
     */
    @GetMapping("/api/admin/apple-wallet/homologation/qr")
    public ResponseEntity<byte[]> qr(@RequestParam String url) {
        URI uri;
        try {
            uri = URI.create(url);
        } catch (IllegalArgumentException e) {
            throw ApiException.badRequest("Endereço inválido.", "url");
        }
        String host = uri.getHost();
        boolean schemeOk = "http".equals(uri.getScheme()) || "https".equals(uri.getScheme());
        if (!schemeOk || host == null || uri.getRawUserInfo() != null || uri.getRawQuery() != null || uri.getRawFragment() != null
                || isLoopback(host)) {
            throw ApiException.badRequest("Use o endereço da rede local (não localhost).", "url");
        }
        Matcher m = INSTALL_PATH.matcher(uri.getRawPath() == null ? "" : uri.getRawPath());
        if (!m.matches() || links.active(m.group(1)).isEmpty()) {
            throw ApiException.badRequest("O endereço não corresponde a um link de instalação ativo.", "url");
        }
        return ResponseEntity.ok().contentType(MediaType.parseMediaType("image/svg+xml")).cacheControl(CacheControl.noStore())
                .header("X-Content-Type-Options", "nosniff")
                .body(QrCodes.svg(uri.toString()).getBytes(StandardCharsets.UTF_8));
    }

    /** Download público do passe de demonstração, só com token válido (não consumido no primeiro acesso). */
    @GetMapping(PUBLIC_PATH + "{token}")
    public ResponseEntity<byte[]> download(@PathVariable String token) {
        AppleHomologationLinks.Lookup lookup = links.find(token);
        if (lookup instanceof AppleHomologationLinks.Lookup.Found found) {
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(PkpassBuilder.CONTENT_TYPE))
                    .contentLength(found.data().length)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"shaminatech-pass-demonstracao.pkpass\"")
                    .header("X-Content-Type-Options", "nosniff")
                    .header("Referrer-Policy", "no-referrer")
                    .cacheControl(CacheControl.noStore())
                    .body(found.data());
        }
        boolean expired = lookup instanceof AppleHomologationLinks.Lookup.Expired;
        String message = expired
                ? "Este link de instalação expirou. Gere um novo cartão de demonstração no painel ShaminaTech."
                : "Link de instalação inválido.";
        return ResponseEntity.status(expired ? HttpStatus.GONE : HttpStatus.NOT_FOUND)
                .contentType(new MediaType("text", "plain", StandardCharsets.UTF_8))
                .cacheControl(CacheControl.noStore())
                .header("X-Content-Type-Options", "nosniff")
                .header("Referrer-Policy", "no-referrer")
                .body(message.getBytes(StandardCharsets.UTF_8));
    }

    /** Nome comum do emissor (ex.: "Apple Worldwide Developer Relations Certification Authority (G4)"). */
    private static String issuerName(AppleCredentials c) {
        String dn = c.certificate().getIssuerX500Principal().getName();
        Matcher cn = Pattern.compile("CN=([^,]+)").matcher(dn);
        Matcher ou = Pattern.compile("OU=([^,]+)").matcher(dn);
        return (cn.find() ? cn.group(1) : dn) + (ou.find() ? " (" + ou.group(1) + ")" : "");
    }

    private static boolean isLoopback(String host) {
        String h = host.toLowerCase();
        return h.equals("localhost") || h.endsWith(".localhost") || h.startsWith("127.") || h.equals("[::1]") || h.equals("::1")
                || h.equals("0.0.0.0");
    }

    /** IPv4 privados das interfaces ativas, com a rede física primeiro (VPNs e adaptadores virtuais por último). */
    static List<String> lanAddresses() {
        List<String[]> found = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) {
                    continue;
                }
                String name = (ni.getDisplayName() + " " + ni.getName()).toLowerCase();
                boolean virtual = ni.isVirtual() || name.matches(".*(zerotier|radmin|vpn|virtual|hyper-v|vethernet|vmware|vbox|wsl|tap|tun|docker).*");
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) {
                        String ip = a.getHostAddress();
                        int rank = (virtual ? 10 : 0) + (ip.startsWith("192.168.") ? 0 : ip.startsWith("10.") ? 1 : 2);
                        found.add(new String[] {String.valueOf(rank), ip});
                    }
                }
            }
        } catch (Exception e) {
            return List.of();
        }
        return found.stream().sorted(Comparator.comparingInt((String[] r) -> Integer.parseInt(r[0]))).map(r -> r[1]).distinct().toList();
    }
}
