package com.shaminatech.pass.loyalty.notify;

import com.shaminatech.pass.common.persistence.BaseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Preferências de lembretes e proximidade do estabelecimento. Padrões conservadores: tudo desligado até a empresa
 * ativar; quando ativado, no máximo um lembrete por cartão a cada {@code minIntervalDays} dias em cada categoria.
 * Uma linha por estabelecimento, criada na primeira leitura.
 */
@Entity
@Table(name = "notification_settings",
        uniqueConstraints = @UniqueConstraint(name = "uk_notification_settings_establishment", columnNames = "establishment_id"))
public class NotificationSettings extends BaseEntity {

    public static final int DEFAULT_NEAR_REWARD_STAMPS = 1;
    public static final int DEFAULT_NEAR_REWARD_POINTS_PERCENT = 10;
    public static final int DEFAULT_EXPIRY_DAYS = 3;
    public static final int DEFAULT_INACTIVITY_DAYS = 60;
    public static final int DEFAULT_MIN_INTERVAL_DAYS = 7;

    @Column(name = "establishment_id", nullable = false, updatable = false)
    private Long establishmentId;

    @Column(name = "near_reward_enabled", nullable = false)
    private boolean nearRewardEnabled;

    /** Carimbos: avisar quando faltarem até N (1 a 3). */
    @Column(name = "near_reward_stamps", nullable = false)
    private int nearRewardStamps = DEFAULT_NEAR_REWARD_STAMPS;

    /** Pontos: avisar quando faltarem até N% do custo da recompensa mais barata (5, 10 ou 20). */
    @Column(name = "near_reward_points_percent", nullable = false)
    private int nearRewardPointsPercent = DEFAULT_NEAR_REWARD_POINTS_PERCENT;

    @Column(name = "expiry_enabled", nullable = false)
    private boolean expiryEnabled;

    /** Avisar quando faltarem até N dias (2, 3, 5 ou 7) para o cartão vencer. */
    @Column(name = "expiry_days_before", nullable = false)
    private int expiryDaysBefore = DEFAULT_EXPIRY_DAYS;

    /** Lembrete de inatividade: só para quem consentiu em receber comunicações do estabelecimento. */
    @Column(name = "inactivity_enabled", nullable = false)
    private boolean inactivityEnabled;

    @Column(name = "inactivity_days", nullable = false)
    private int inactivityDays = DEFAULT_INACTIVITY_DAYS;

    /** Intervalo mínimo entre lembretes da mesma categoria para o mesmo cartão. */
    @Column(name = "min_interval_days", nullable = false)
    private int minIntervalDays = DEFAULT_MIN_INTERVAL_DAYS;

    /** Publica as localizações do estabelecimento nas carteiras (Google merchantLocations / Apple locations). */
    @Column(name = "proximity_enabled", nullable = false)
    private boolean proximityEnabled;

    /** Já enviamos localizações alguma vez: ao desligar, a lista vazia precisa ser enviada para removê-las. */
    @Column(name = "proximity_published", nullable = false)
    private boolean proximityPublished;

    /** Texto da tela de bloqueio do iPhone quando perto da loja (Apple relevantText). Opcional. */
    @Column(name = "proximity_text", length = 80)
    private String proximityText;

    protected NotificationSettings() {
    }

    public NotificationSettings(Long establishmentId) {
        this.establishmentId = establishmentId;
    }

    public void update(boolean nearRewardEnabled, int nearRewardStamps, int nearRewardPointsPercent, boolean expiryEnabled,
                       int expiryDaysBefore, boolean inactivityEnabled, int inactivityDays, int minIntervalDays,
                       boolean proximityEnabled, String proximityText) {
        this.nearRewardEnabled = nearRewardEnabled;
        this.nearRewardStamps = nearRewardStamps;
        this.nearRewardPointsPercent = nearRewardPointsPercent;
        this.expiryEnabled = expiryEnabled;
        this.expiryDaysBefore = expiryDaysBefore;
        this.inactivityEnabled = inactivityEnabled;
        this.inactivityDays = inactivityDays;
        this.minIntervalDays = minIntervalDays;
        this.proximityEnabled = proximityEnabled;
        this.proximityText = proximityText;
        if (proximityEnabled) {
            this.proximityPublished = true;
        }
    }

    public boolean anyReminderEnabled() {
        return nearRewardEnabled || expiryEnabled || inactivityEnabled;
    }

    public boolean enabled(ReminderCategory category) {
        return switch (category) {
            case NEAR_REWARD -> nearRewardEnabled;
            case EXPIRY -> expiryEnabled;
            case INACTIVITY -> inactivityEnabled;
        };
    }

    public Long getEstablishmentId() { return establishmentId; }
    public boolean isNearRewardEnabled() { return nearRewardEnabled; }
    public int getNearRewardStamps() { return nearRewardStamps; }
    public int getNearRewardPointsPercent() { return nearRewardPointsPercent; }
    public boolean isExpiryEnabled() { return expiryEnabled; }
    public int getExpiryDaysBefore() { return expiryDaysBefore; }
    public boolean isInactivityEnabled() { return inactivityEnabled; }
    public int getInactivityDays() { return inactivityDays; }
    public int getMinIntervalDays() { return minIntervalDays; }
    public boolean isProximityEnabled() { return proximityEnabled; }
    public boolean isProximityPublished() { return proximityPublished; }
    public String getProximityText() { return proximityText; }
}
