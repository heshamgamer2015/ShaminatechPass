package com.shaminatech.pass.tenant;

import java.util.EnumSet;
import java.util.Set;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.membership.Membership;
import com.shaminatech.pass.membership.MembershipRepository;
import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.membership.Permission;
import com.shaminatech.pass.membership.RolePermissionRepository;
import com.shaminatech.pass.security.AuthenticatedUser;
import com.shaminatech.pass.security.CurrentUser;

/**
 * Ponto único de isolamento entre estabelecimentos. Todo serviço do painel do
 * estabelecimento chama {@link #require} antes de ler ou alterar dados do tenant.
 * <p>
 * Regras: o usuário logado precisa ser a <b>conta empresarial ativa</b> do estabelecimento
 * (vínculo OWNER ativo — Etapa 2: uma única conta por estabelecimento; vínculos antigos de
 * gerente/funcionário ficam preservados no banco, mas não dão acesso), o estabelecimento precisa
 * estar ativo e o papel precisa ter a permissão (tabela role_permission). Administradores da
 * plataforma não têm acesso implícito: usam os endpoints /api/admin, que não expõem dados de fidelidade.
 */
@Service
public class TenantAccessService {

    static final String DENIED = "Você não tem acesso a este estabelecimento ou recurso.";

    private final MembershipRepository memberships;
    private final RolePermissionRepository rolePermissions;

    public TenantAccessService(MembershipRepository memberships, RolePermissionRepository rolePermissions) {
        this.memberships = memberships;
        this.rolePermissions = rolePermissions;
    }

    @Transactional(readOnly = true)
    public TenantAccess require(Long establishmentId, Permission permission) {
        AuthenticatedUser user = CurrentUser.require();
        Membership membership = memberships.findForUser(establishmentId, user.getId())
                .filter(Membership::isActiveBusinessAccount)
                .orElseThrow(() -> ApiException.forbidden(DENIED));
        if (!membership.getEstablishment().isActive()) {
            throw new ApiException(org.springframework.http.HttpStatus.FORBIDDEN, "ESTABLISHMENT_INACTIVE",
                    "Este estabelecimento está indisponível. Entre em contato com a ShaminaTech.");
        }
        Set<Permission> granted = permissionsOf(membership.getRole());
        if (!granted.contains(permission)) {
            throw ApiException.forbidden(DENIED);
        }
        return new TenantAccess(membership.getEstablishment(), membership, granted);
    }

    private Set<Permission> permissionsOf(MembershipRole role) {
        Set<Permission> result = EnumSet.noneOf(Permission.class);
        for (String code : rolePermissions.findPermissionCodesByRole(role)) {
            try {
                result.add(Permission.valueOf(code));
            } catch (IllegalArgumentException ignored) {
                // Permissão existente no banco mas desconhecida por esta versão do código: ignorada.
            }
        }
        return result;
    }
}
