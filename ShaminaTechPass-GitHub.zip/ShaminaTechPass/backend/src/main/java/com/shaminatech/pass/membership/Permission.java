package com.shaminatech.pass.membership;

import java.util.EnumSet;
import java.util.Set;

/**
 * Catálogo de permissões dentro de um estabelecimento. O catálogo e os papéis padrão são
 * gravados nas tabelas {@code permission} / {@code role_permission} na inicialização
 * (somente inserções; nunca remove o que já existe). A verificação em tempo de execução
 * lê {@code role_permission} do banco.
 */
public enum Permission {
    ESTABLISHMENT_VIEW("Visualizar dados do estabelecimento", EnumSet.allOf(MembershipRole.class)),
    ESTABLISHMENT_EDIT("Editar dados do estabelecimento", EnumSet.of(MembershipRole.OWNER)),
    AUDIT_VIEW("Visualizar auditoria do estabelecimento", EnumSet.of(MembershipRole.OWNER)),
    CONSUMERS_VIEW("Consultar clientes", EnumSet.of(MembershipRole.OWNER)),
    CONSUMERS_MANAGE("Cadastrar e alterar clientes", EnumSet.of(MembershipRole.OWNER)),
    PROGRAMS_MANAGE("Configurar programas de fidelidade e personalização", EnumSet.of(MembershipRole.OWNER)),
    CARDS_MANAGE("Emitir, desativar, cancelar e reativar cartões", EnumSet.of(MembershipRole.OWNER)),
    TRANSACTIONS_REGISTER("Registrar compras, concessões e resgates", EnumSet.of(MembershipRole.OWNER)),
    TRANSACTIONS_REVERSE("Estornar movimentações", EnumSet.of(MembershipRole.OWNER)),
    REPORTS_VIEW("Consultar indicadores", EnumSet.of(MembershipRole.OWNER));
    // MEMBERS_VIEW / MEMBERS_MANAGE (Etapa 1) foram retiradas: não há mais gestão de equipe.
    // As linhas antigas em permission/role_permission são preservadas e ignoradas.

    private final String description;
    private final Set<MembershipRole> defaultRoles;

    Permission(String description, Set<MembershipRole> defaultRoles) {
        this.description = description;
        this.defaultRoles = defaultRoles;
    }

    public String description() {
        return description;
    }

    public Set<MembershipRole> defaultRoles() {
        return defaultRoles;
    }
}
