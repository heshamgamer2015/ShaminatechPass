package com.shaminatech.pass.loyalty.notify;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import jakarta.persistence.LockModeType;

public interface WalletReminderRepository extends JpaRepository<WalletReminder, Long> {

    boolean existsByDedupKey(String dedupKey);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select r from WalletReminder r where r.id = :id")
    Optional<WalletReminder> lockById(@Param("id") Long id);

    /** Lembretes do cartão (categoria) planejados a partir de um instante, exceto os cancelados. */
    @Query("""
            select count(r) > 0 from WalletReminder r where r.cardId = :cardId and r.category = :category
              and r.plannedAt >= :since and r.status <> com.shaminatech.pass.loyalty.notify.WalletReminder.Status.CANCELLED
            """)
    boolean existsRecent(@Param("cardId") Long cardId, @Param("category") ReminderCategory category, @Param("since") Instant since);

    /** Qualquer lembrete do cartão (todas as categorias) planejado a partir de um instante, exceto os cancelados. */
    @Query("""
            select count(r) > 0 from WalletReminder r where r.cardId = :cardId and r.plannedAt >= :since
              and r.status <> com.shaminatech.pass.loyalty.notify.WalletReminder.Status.CANCELLED
            """)
    boolean existsAnyRecent(@Param("cardId") Long cardId, @Param("since") Instant since);

    @Query("""
            select r.id from WalletReminder r
            where (r.status in (com.shaminatech.pass.loyalty.notify.WalletReminder.Status.PENDING,
                                com.shaminatech.pass.loyalty.notify.WalletReminder.Status.FAILED) and r.nextAttemptAt <= :now)
               or (r.status = com.shaminatech.pass.loyalty.notify.WalletReminder.Status.SENDING and r.leaseUntil < :now)
            order by r.nextAttemptAt, r.id
            """)
    List<Long> findDueIds(@Param("now") Instant now, Pageable pageable);

    /** Lembretes ainda não enviados do cartão (para cancelar quando a situação muda). */
    @Query("""
            select r from WalletReminder r where r.cardId = :cardId
              and r.status in (com.shaminatech.pass.loyalty.notify.WalletReminder.Status.PENDING,
                               com.shaminatech.pass.loyalty.notify.WalletReminder.Status.FAILED,
                               com.shaminatech.pass.loyalty.notify.WalletReminder.Status.ACCEPTED)
            """)
    List<WalletReminder> findOpenForCard(@Param("cardId") Long cardId);

    /** Mensagens aceitas do cartão (inclui as retiradas): define o campo messages enviado na sincronização. */
    @Query("""
            select r from WalletReminder r where r.cardId = :cardId
              and r.status = com.shaminatech.pass.loyalty.notify.WalletReminder.Status.ACCEPTED order by r.id
            """)
    List<WalletReminder> findAcceptedForCard(@Param("cardId") Long cardId);

    @Query(value = "select r from WalletReminder r where r.establishmentId = :establishmentId and r.status in :statuses",
            countQuery = "select count(r) from WalletReminder r where r.establishmentId = :establishmentId and r.status in :statuses")
    Page<WalletReminder> findInEstablishment(@Param("establishmentId") Long establishmentId,
                                             @Param("statuses") Collection<WalletReminder.Status> statuses, Pageable pageable);

    @Query("""
            select r.status, count(r) from WalletReminder r where r.establishmentId = :establishmentId and r.plannedAt >= :since
            group by r.status
            """)
    List<Object[]> countByStatusSince(@Param("establishmentId") Long establishmentId, @Param("since") Instant since);
}
