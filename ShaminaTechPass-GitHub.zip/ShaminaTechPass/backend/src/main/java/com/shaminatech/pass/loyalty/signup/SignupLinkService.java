package com.shaminatech.pass.loyalty.signup;

import java.security.SecureRandom;
import java.time.Clock;
import java.time.Instant;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.consumer.Consumer;
import com.shaminatech.pass.loyalty.consumer.ConsumerRepository;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicy;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.LoyaltyProgramRepository;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ProgramStatus;
import com.shaminatech.pass.membership.Permission;
import com.shaminatech.pass.security.CurrentUser;
import com.shaminatech.pass.tenant.TenantAccessService;

/** Painel do estabelecimento: links/QR Codes públicos de cadastro (um por programa). */
@Service
public class SignupLinkService {

    private static final SecureRandom RANDOM = new SecureRandom();

    private final TenantAccessService tenantAccess;
    private final SignupLinkRepository links;
    private final PublicSignupRepository signups;
    private final LoyaltyProgramRepository programs;
    private final ConsumerRepository consumers;
    private final PolicyService policies;
    private final AuditService audit;
    private final Clock clock;
    private final String publicPageBaseUrl;

    public SignupLinkService(TenantAccessService tenantAccess, SignupLinkRepository links, PublicSignupRepository signups,
                             LoyaltyProgramRepository programs, ConsumerRepository consumers, PolicyService policies,
                             AuditService audit, Clock clock,
                             @Value("${shaminatech.wallet.public-page-base-url:http://localhost:4203}") String publicPageBaseUrl) {
        this.tenantAccess = tenantAccess;
        this.links = links;
        this.signups = signups;
        this.programs = programs;
        this.consumers = consumers;
        this.policies = policies;
        this.audit = audit;
        this.clock = clock;
        this.publicPageBaseUrl = publicPageBaseUrl.replaceAll("/+$", "");
    }

    /**
     * Um item por programa não encerrado. {@code link} nulo = QR Code ainda não gerado. {@code issue}: motivo pelo qual
     * o cadastro público não está aceitando consumidores agora (null = aceitando).
     */
    public record ProgramSignup(Long programId, String programName, ProgramType programType, ProgramStatus programStatus,
                                boolean eligible, String issue, LinkView link) {
    }

    public record LinkView(Long id, boolean active, String url, Instant tokenCreatedAt, Instant statusChangedAt, long signups,
                           Instant lastSignupAt) {
    }

    public record Overview(List<ProgramSignup> programs, long activeConsumers, int maxActiveConsumers, boolean full) {
    }

    @Transactional(readOnly = true)
    public Overview list(Long establishmentId) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        EstablishmentPolicy policy = policies.of(establishmentId);
        Map<Long, SignupLink> byProgram = new HashMap<>();
        for (SignupLink l : links.findAllInEstablishment(establishmentId)) {
            byProgram.put(l.getProgram().getId(), l);
        }
        Map<Long, Object[]> stats = new HashMap<>();
        for (Object[] row : signups.statsByLink(establishmentId)) {
            stats.put((Long) row[0], row);
        }
        long active = consumers.countByStatus(establishmentId, Consumer.Status.ACTIVE);
        boolean full = active >= policy.getMaxActiveConsumers();
        List<ProgramSignup> items = programs.findAllInEstablishment(establishmentId).stream()
                .filter(p -> p.getStatus() != ProgramStatus.ARCHIVED)
                .map(p -> {
                    SignupLink l = byProgram.get(p.getId());
                    String issue = issue(p, policy, l, full);
                    return new ProgramSignup(p.getId(), p.getName(), p.getType(), p.getStatus(), creatable(p, policy) == null,
                            issue, l == null ? null : view(l, stats.get(l.getId())));
                }).toList();
        return new Overview(items, active, policy.getMaxActiveConsumers(), full);
    }

    /** Gera o QR Code do programa (ou devolve o existente — chamada idempotente). */
    @Transactional
    public LinkView create(Long establishmentId, Long programId) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_MANAGE);
        LoyaltyProgram program = programs.findInEstablishment(establishmentId, programId)
                .orElseThrow(() -> ApiException.notFound("Programa não encontrado."));
        var existing = links.findByProgram(programId);
        if (existing.isPresent()) {
            return view(existing.get());
        }
        String reason = creatable(program, policies.of(establishmentId));
        if (reason != null) {
            throw ApiException.state("SIGNUP_LINK_NOT_ALLOWED", reason);
        }
        SignupLink link = links.save(new SignupLink(program, newToken(), clock.instant(), CurrentUser.require().getId()));
        audit.record(AuditAction.SIGNUP_LINK_CREATED, establishmentId, "SIGNUP_LINK", link.getId(), "programa=" + programId);
        return view(link);
    }

    @Transactional
    public LinkView setActive(Long establishmentId, Long linkId, boolean active) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_MANAGE);
        SignupLink link = find(establishmentId, linkId);
        if (link.isActive() != active) {
            if (active) {
                String reason = creatable(link.getProgram(), policies.of(establishmentId));
                if (reason != null) {
                    throw ApiException.state("SIGNUP_LINK_NOT_ALLOWED", reason);
                }
            }
            link.changeActive(active, clock.instant());
            audit.record(AuditAction.SIGNUP_LINK_STATUS_CHANGED, establishmentId, "SIGNUP_LINK", linkId,
                    active ? "ativado" : "desativado");
        }
        return view(link);
    }

    /** Troca o código: o QR Code impresso anteriormente deixa de funcionar. Cadastros já feitos não mudam. */
    @Transactional
    public LinkView regenerate(Long establishmentId, Long linkId) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_MANAGE);
        SignupLink link = find(establishmentId, linkId);
        link.replaceToken(newToken(), clock.instant());
        audit.record(AuditAction.SIGNUP_LINK_REGENERATED, establishmentId, "SIGNUP_LINK", linkId, null);
        return view(link);
    }

    /** Endereço público do link (conteúdo do QR Code). */
    @Transactional(readOnly = true)
    public String url(Long establishmentId, Long linkId) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        return url(find(establishmentId, linkId));
    }

    private LinkView view(SignupLink l) {
        Object[] row = signups.statsByLink(l.getEstablishmentId()).stream().filter(r -> r[0].equals(l.getId())).findFirst()
                .orElse(null);
        return view(l, row);
    }

    private LinkView view(SignupLink l, Object[] stats) {
        return new LinkView(l.getId(), l.isActive(), url(l), l.getTokenCreatedAt(), l.getStatusChangedAt(),
                stats == null ? 0 : (Long) stats[1], stats == null ? null : (Instant) stats[2]);
    }

    private String url(SignupLink l) {
        return publicPageBaseUrl + "/cadastro/" + l.getToken();
    }

    /** Null = o programa pode ter cadastro público; senão, o motivo. */
    static String creatable(LoyaltyProgram p, EstablishmentPolicy policy) {
        if (p.getStatus() == ProgramStatus.ARCHIVED) {
            return "Programa encerrado não aceita novos cadastros.";
        }
        if (!policy.allows(p.getType())) {
            return "Este tipo de programa não está habilitado para o seu estabelecimento.";
        }
        if (!p.getType().isOperational()) {
            return "Programas de níveis VIP ainda não emitem cartões; o cadastro público não está disponível para eles.";
        }
        return null;
    }

    private static String issue(LoyaltyProgram p, EstablishmentPolicy policy, SignupLink link, boolean full) {
        String reason = creatable(p, policy);
        if (reason != null) {
            return reason;
        }
        if (p.getStatus() == ProgramStatus.PAUSED) {
            return "Programa pausado: a página mostra que o cadastro está indisponível.";
        }
        if (link != null && !link.isActive()) {
            return "QR Code desativado: a página mostra que o cadastro está indisponível.";
        }
        if (full) {
            return "Limite de clientes ativos atingido: a página informa que as inscrições estão temporariamente esgotadas.";
        }
        return null;
    }

    private SignupLink find(Long establishmentId, Long linkId) {
        return links.findInEstablishment(establishmentId, linkId).orElseThrow(() -> ApiException.notFound("QR Code não encontrado."));
    }

    private String newToken() {
        String token;
        do {
            byte[] bytes = new byte[16];
            RANDOM.nextBytes(bytes);
            token = HexFormat.of().formatHex(bytes);
        } while (links.existsByToken(token));
        return token;
    }
}
