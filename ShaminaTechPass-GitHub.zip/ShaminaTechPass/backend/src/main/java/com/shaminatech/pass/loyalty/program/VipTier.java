package com.shaminatech.pass.loyalty.program;

import java.math.BigDecimal;

import com.shaminatech.pass.common.persistence.BaseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Nível de um programa VIP (Bronze, Prata, Ouro, Diamante ou definido pela empresa).
 * <b>Somente modelagem nesta etapa:</b> critérios e benefícios são cadastrados, mas a progressão
 * automática dos clientes entre níveis ainda não é calculada.
 */
@Entity
@Table(name = "vip_tier", uniqueConstraints = @UniqueConstraint(name = "uk_vip_tier_program_rank", columnNames = {"program_id", "rank_order"}))
public class VipTier extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "program_id", nullable = false, foreignKey = @ForeignKey(name = "fk_vip_tier_program"))
    private LoyaltyProgram program;

    @Column(name = "establishment_id", nullable = false)
    private Long establishmentId;

    @Column(nullable = false, length = 40)
    private String name;

    /** Ordem do nível (1 = inicial). */
    @Column(name = "rank_order", nullable = false)
    private int rankOrder;

    /** Valor gasto no período para atingir o nível (opcional). */
    @Column(name = "min_spend", precision = 12, scale = 2)
    private BigDecimal minSpend;

    /** Visitas no período para atingir o nível (opcional). */
    @Column(name = "min_visits")
    private Integer minVisits;

    @Column(name = "period_days")
    private Integer periodDays;

    @Column(length = 500)
    private String benefits;

    protected VipTier() {
    }

    public VipTier(LoyaltyProgram program, String name, int rankOrder) {
        this.program = program;
        this.establishmentId = program.getEstablishmentId();
        this.name = name;
        this.rankOrder = rankOrder;
    }

    public LoyaltyProgram getProgram() { return program; }
    public Long getEstablishmentId() { return establishmentId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getRankOrder() { return rankOrder; }
    public void setRankOrder(int rankOrder) { this.rankOrder = rankOrder; }
    public BigDecimal getMinSpend() { return minSpend; }
    public void setMinSpend(BigDecimal minSpend) { this.minSpend = minSpend; }
    public Integer getMinVisits() { return minVisits; }
    public void setMinVisits(Integer minVisits) { this.minVisits = minVisits; }
    public Integer getPeriodDays() { return periodDays; }
    public void setPeriodDays(Integer periodDays) { this.periodDays = periodDays; }
    public String getBenefits() { return benefits; }
    public void setBenefits(String benefits) { this.benefits = benefits; }
}
