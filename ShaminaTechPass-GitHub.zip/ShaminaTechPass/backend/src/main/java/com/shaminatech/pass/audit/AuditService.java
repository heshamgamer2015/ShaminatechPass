package com.shaminatech.pass.audit;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.common.web.ClientIp;
import com.shaminatech.pass.common.web.PageResponse;
import com.shaminatech.pass.security.AuthenticatedUser;
import com.shaminatech.pass.security.CurrentUser;

/** Registra eventos de auditoria. Participa da transação de quem chama (evento e alteração são gravados juntos). */
@Service
public class AuditService {

    public static final Sort NEWEST_FIRST = Sort.by(Sort.Direction.DESC, "occurredAt", "id");

    private final AuditEventRepository events;

    public AuditService(AuditEventRepository events) {
        this.events = events;
    }

    /** Evento cujo autor é o usuário autenticado da requisição (se houver). */
    @Transactional
    public void record(AuditAction action, Long establishmentId, String targetType, Object targetId, String details) {
        AuthenticatedUser actor = CurrentUser.optional().orElse(null);
        recordAs(actor == null ? null : actor.getId(), actor == null ? null : actor.getEmail(),
                action, establishmentId, targetType, targetId, details);
    }

    /** Evento com autor explícito (ex.: tentativas de login, antes de existir sessão). */
    @Transactional
    public void recordAs(Long actorUserId, String actorEmail, AuditAction action, Long establishmentId,
                         String targetType, Object targetId, String details) {
        events.save(new AuditEvent(action, actorUserId, actorEmail, establishmentId, targetType,
                targetId == null ? null : String.valueOf(targetId), details, ClientIp.current()));
    }

    @Transactional(readOnly = true)
    public PageResponse<AuditEventResponse> list(Long establishmentId, Pageable pageable) {
        var page = establishmentId == null ? events.findAll(pageable) : events.findByEstablishmentId(establishmentId, pageable);
        return PageResponse.of(page, AuditEventResponse::from);
    }
}
