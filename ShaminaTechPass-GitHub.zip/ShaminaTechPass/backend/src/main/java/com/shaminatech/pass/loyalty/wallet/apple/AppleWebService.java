package com.shaminatech.pass.loyalty.wallet.apple;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.loyalty.wallet.WalletPass;
import com.shaminatech.pass.loyalty.wallet.WalletPass.Provider;
import com.shaminatech.pass.loyalty.wallet.WalletPassRepository;

/** Registros de aparelhos e consulta de alterações (sempre depois de conferir o token do passe no controlador). */
@Service
public class AppleWebService {

    public enum Registration { CREATED, UPDATED, LIMIT, NOT_FOUND }

    public record Updated(List<String> serials, Instant lastUpdated) {
    }

    private final WalletPassRepository passes;
    private final AppleDeviceRegistrationRepository registrations;
    private final AppleWalletGateway gateway;

    public AppleWebService(WalletPassRepository passes, AppleDeviceRegistrationRepository registrations, AppleWalletGateway gateway) {
        this.passes = passes;
        this.registrations = registrations;
        this.gateway = gateway;
    }

    /** Idempotente: o mesmo aparelho registrando o mesmo passe de novo só atualiza o push token (200). */
    @Transactional
    public Registration register(String device, String serial, String pushToken) {
        WalletPass pass = passes.findByProviderAndExternalId(Provider.APPLE_WALLET, serial).orElse(null);
        if (pass == null) {
            return Registration.NOT_FOUND;
        }
        var existing = registrations.findByDeviceLibraryIdAndWalletPassId(device, pass.getId());
        if (existing.isPresent()) {
            existing.get().updatePushToken(pushToken);
            return Registration.UPDATED;
        }
        if (registrations.countByWalletPassId(pass.getId()) >= gateway.properties().maxDevicesPerPass()) {
            return Registration.LIMIT;
        }
        // Registro simultâneo do mesmo aparelho: a restrição única impede duplicar (o Wallet repete a chamada).
        registrations.save(new AppleDeviceRegistration(pass.getEstablishmentId(), pass.getId(), device, pushToken));
        return Registration.CREATED;
    }

    @Transactional
    public void unregister(String device, String serial) {
        passes.findByProviderAndExternalId(Provider.APPLE_WALLET, serial)
                .flatMap(pass -> registrations.findByDeviceLibraryIdAndWalletPassId(device, pass.getId()))
                .ifPresent(registrations::delete);
    }

    @Transactional(readOnly = true)
    public Updated updatedSerials(String device, Instant since) {
        List<String> serials = new ArrayList<>();
        Instant last = since;
        for (Object[] row : registrations.updatedSerials(device, since)) {
            serials.add((String) row[0]);
            Instant updated = (Instant) row[1];
            if (updated != null && updated.isAfter(last)) {
                last = updated;
            }
        }
        return new Updated(serials, last);
    }
}
