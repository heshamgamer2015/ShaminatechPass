package com.shaminatech.pass.loyalty.signup;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.HexFormat;
import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.common.web.ClientIp;
import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.branding.StoredImage;
import com.shaminatech.pass.loyalty.branding.StoredImageRepository;
import com.shaminatech.pass.loyalty.card.CardEngine;
import com.shaminatech.pass.loyalty.card.CardEnums.Channel;
import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.card.LoyaltyCardRepository;
import com.shaminatech.pass.loyalty.consumer.Consumer;
import com.shaminatech.pass.loyalty.consumer.ConsumerRepository;
import com.shaminatech.pass.loyalty.consumer.ConsumerService;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicy;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.LoyaltyRewardRepository;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ProgramStatus;
import com.shaminatech.pass.loyalty.signup.SignupDtos.PublicDesign;
import com.shaminatech.pass.loyalty.signup.SignupDtos.PublicReward;
import com.shaminatech.pass.loyalty.signup.SignupDtos.SignupInfo;
import com.shaminatech.pass.loyalty.signup.SignupDtos.SignupRequest;
import com.shaminatech.pass.loyalty.signup.SignupDtos.SignupResult;
import com.shaminatech.pass.loyalty.wallet.WalletService;
import com.shaminatech.pass.loyalty.wallet.WalletSyncService;

/**
 * Autocadastro do consumidor pelo QR Code público do estabelecimento.
 * <p>
 * Regras de segurança:
 * <ul>
 *   <li><b>Sem enumeração</b>: o link só é encontrado pelo token aleatório; links inexistentes, desativados, de programa
 *       pausado ou de estabelecimento suspenso dão respostas sem dados internos;</li>
 *   <li><b>Sem acesso ao cartão de outra pessoa</b>: telefone ou e-mail já cadastrado NUNCA devolve o cartão existente
 *       nem confirma de quem é. A resposta é genérica e orienta a pedir o cartão no balcão, onde a empresa confere a
 *       pessoa e gera um novo link pelo painel. (Comprovação de posse por SMS/e-mail exige serviço externo ainda não
 *       contratado.)</li>
 *   <li><b>Limite e concorrência</b>: a política do estabelecimento é travada (FOR UPDATE) antes de conferir duplicidade e
 *       vagas, como no cadastro pelo painel — cadastros simultâneos são serializados e o limite nunca é ultrapassado;</li>
 *   <li><b>Repetição do mesmo envio</b>: o identificador aleatório do formulário faz o segundo envio devolver o mesmo
 *       cadastro (sem segundo cartão), por até {@value #REPLAY_MINUTES} minutos;</li>
 *   <li><b>Robôs</b>: formulário assinado com tempo mínimo de preenchimento, campo isca e limite de tentativas por IP.</li>
 * </ul>
 * A validade do cartão começa na emissão; o cadastro não registra movimentação nem concede benefício.
 */
@Service
public class PublicSignupService {

    static final int REPLAY_MINUTES = 30;
    private static final String TOKEN_PATTERN = "^[0-9a-f]{32}$";

    private final SignupLinkRepository links;
    private final PublicSignupRepository signups;
    private final ConsumerRepository consumers;
    private final ConsumerService consumerService;
    private final CardEngine engine;
    private final LoyaltyCardRepository cards;
    private final PolicyService policies;
    private final LoyaltyRewardRepository rewards;
    private final StoredImageRepository images;
    private final WalletService wallet;
    private final SignupGuard guard;
    private final AuditService audit;
    private final Clock clock;

    public PublicSignupService(SignupLinkRepository links, PublicSignupRepository signups, ConsumerRepository consumers,
                               ConsumerService consumerService, CardEngine engine, LoyaltyCardRepository cards, PolicyService policies,
                               LoyaltyRewardRepository rewards, StoredImageRepository images, WalletService wallet,
                               SignupGuard guard, AuditService audit, Clock clock) {
        this.links = links;
        this.signups = signups;
        this.consumers = consumers;
        this.consumerService = consumerService;
        this.engine = engine;
        this.cards = cards;
        this.policies = policies;
        this.rewards = rewards;
        this.images = images;
        this.wallet = wallet;
        this.guard = guard;
        this.audit = audit;
        this.clock = clock;
    }

    /** Dados da página pública. Pode gravar o token público de imagens antigas (por isso não é somente leitura). */
    @Transactional
    public SignupInfo info(String token) {
        SignupLink link = findLink(token);
        LoyaltyProgram program = link.getProgram();
        Establishment establishment = program.getEstablishment();
        EstablishmentPolicy policy = policies.of(link.getEstablishmentId());
        if (unavailable(link, policy)) {
            return SignupInfo.unavailable();
        }
        boolean full = !consumerService.hasSlot(link.getEstablishmentId(), policy);
        List<PublicReward> rewardList = program.getType() == ProgramType.POINTS
                ? rewards.findByProgram(link.getEstablishmentId(), program.getId()).stream().filter(r -> r.isActive())
                .map(r -> new PublicReward(r.getName(), r.getDescription(), r.getCost())).toList()
                : List.of();
        PublicDesign design = new PublicDesign(
                program.getBrandColor() == null ? "#F43F5E" : program.getBrandColor(),
                program.getTextColor() == null ? "#FFFFFF" : program.getTextColor(),
                imageUrl(program.getLogoImageId(), link.getEstablishmentId()),
                imageUrl(program.getHeroImageId(), link.getEstablishmentId()),
                program.getCardMessage(), program.getRewardInfo());
        return new SignupInfo(full ? "FULL" : "OPEN",
                full ? "As inscrições estão temporariamente esgotadas. Fale com o estabelecimento." : null,
                establishment.getName(), program.getName(), program.getDescription(), program.getType(),
                ProgramPresentation.rules(program), rewardList, ProgramPresentation.validity(program),
                program.getType() == ProgramType.STAMPS ? program.getStampsRequired() : null,
                program.getType() == ProgramType.STAMPS ? program.getStampReward() : null,
                design, full ? null : guard.issueFormToken(token), wallet.anyWalletConfigured(), wallet.availableWallets());
    }

    @Transactional
    public SignupResult register(String token, SignupRequest request) {
        guard.countAttempt(ClientIp.current());
        SignupLink link = findLink(token);
        if (request.website() != null && !request.website().isBlank()) {
            // Campo isca preenchido: robô. Resposta igual à de formulário vencido (não ensina a contornar).
            throw new ApiException(HttpStatus.BAD_REQUEST, "SIGNUP_FORM_EXPIRED",
                    "O formulário expirou. Recarregue a página e preencha novamente.");
        }
        guard.verifyFormToken(token, request.formToken());
        Long establishmentId = link.getEstablishmentId();
        String phone = ConsumerService.normalizePhone(request.phone());
        String email = ConsumerService.normalizeEmail(request.email());
        String name = normalizeName(request.fullName());
        String keyHash = sha256(request.requestId());

        // Serializa os cadastros do estabelecimento (duplicidade, vagas e emissão).
        EstablishmentPolicy policy = policies.lock(establishmentId);
        Instant now = clock.instant();

        Optional<PublicSignup> previous = signups.findByRequestKeyHash(keyHash);
        if (previous.isPresent()) {
            return replay(link, previous.get(), now);
        }
        if (unavailable(link, policy)) {
            throw unavailableError();
        }
        if (consumers.existsPhone(establishmentId, phone) || (email != null && consumers.existsEmail(establishmentId, email))) {
            throw existing();
        }
        if (!consumerService.hasSlot(establishmentId, policy)) {
            throw new ApiException(HttpStatus.CONFLICT, "SIGNUP_FULL",
                    "As inscrições estão temporariamente esgotadas. Fale com o estabelecimento.");
        }
        LoyaltyProgram program = link.getProgram();
        Consumer consumer = Consumer.selfRegistered(program.getEstablishment(), name, phone, now);
        consumer.setEmail(email);
        consumer.setMarketingOptIn(Boolean.TRUE.equals(request.marketingOptIn()));
        consumers.save(consumer);
        LoyaltyCard card = engine.issue(consumer, program, null, null, Channel.PUBLIC_SIGNUP);
        signups.save(new PublicSignup(establishmentId, link.getId(), program.getId(), consumer.getId(), card.getId(), keyHash, now));
        audit.record(AuditAction.CONSUMER_SELF_REGISTERED, establishmentId, "CONSUMER", consumer.getId(),
                "qr=" + link.getId() + " programa=" + program.getId() + " comunicacoes=" + (consumer.isMarketingOptIn() ? "sim" : "nao"));
        audit.record(AuditAction.CARD_ISSUED, establishmentId, "CARD", card.getId(), "programa=" + program.getId() + " autocadastro");
        return result(program, consumer, card);
    }

    /** Mesmo envio repetido (clique duplo / rede): devolve o cadastro já feito, com um novo link de carteira. */
    private SignupResult replay(SignupLink link, PublicSignup previous, Instant now) {
        if (!previous.getLinkId().equals(link.getId())
                || Duration.between(previous.getSignedUpAt(), now).toMinutes() >= REPLAY_MINUTES) {
            throw existing();
        }
        Consumer consumer = consumers.findInEstablishment(previous.getEstablishmentId(), previous.getConsumerId())
                .orElseThrow(PublicSignupService::existing);
        LoyaltyCard card = cards.findInEstablishment(previous.getEstablishmentId(), previous.getCardId())
                .orElseThrow(PublicSignupService::existing);
        return result(link.getProgram(), consumer, card);
    }

    private SignupResult result(LoyaltyProgram program, Consumer consumer, LoyaltyCard card) {
        var created = wallet.createLinkForSignup(card.getEstablishmentId(), card.getId());
        String walletPath = created == null ? null : created.url().substring(created.url().indexOf("/carteira/"));
        return new SignupResult("REGISTERED", program.getEstablishment().getName(), program.getName(), program.getType(),
                WalletSyncService.firstName(consumer.getFullName()), walletPath, created == null ? "NOT_CONFIGURED" : "LINK_READY",
                created == null
                        ? "Seu cartão está pronto. A carteira digital ainda não está disponível: no balcão, informe seu nome ou telefone."
                        : "Seu cartão está pronto. Adicione-o à carteira do seu celular.");
    }

    private SignupLink findLink(String token) {
        if (token == null || !token.matches(TOKEN_PATTERN)) {
            throw invalidLink();
        }
        return links.findByToken(token).orElseThrow(PublicSignupService::invalidLink);
    }

    /** Link desativado, programa não ativo/permitido/operacional ou estabelecimento suspenso. */
    private static boolean unavailable(SignupLink link, EstablishmentPolicy policy) {
        LoyaltyProgram p = link.getProgram();
        return !link.isActive() || !p.getEstablishment().isActive() || p.getStatus() != ProgramStatus.ACTIVE
                || !policy.allows(p.getType()) || !p.getType().isOperational();
    }

    private String imageUrl(Long imageId, Long establishmentId) {
        if (imageId == null) {
            return null;
        }
        return images.findById(imageId).filter(i -> i.getEstablishmentId().equals(establishmentId))
                .map(StoredImage::ensurePublicToken).map(t -> "/api/public/images/" + t).orElse(null);
    }

    private static String normalizeName(String raw) {
        String name = raw == null ? "" : raw.trim().replaceAll("\\s+", " ");
        if (name.codePoints().filter(Character::isLetter).count() < 2) {
            throw ApiException.badRequest("Informe seu nome.", "fullName");
        }
        return name;
    }

    static String sha256(String value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private static ApiException invalidLink() {
        return new ApiException(HttpStatus.NOT_FOUND, "SIGNUP_LINK_INVALID",
                "Este QR Code de cadastro é inválido. Peça um novo ao estabelecimento.");
    }

    private static ApiException unavailableError() {
        return new ApiException(HttpStatus.CONFLICT, "SIGNUP_UNAVAILABLE", SignupInfo.UNAVAILABLE_MESSAGE);
    }

    /** Resposta única para telefone ou e-mail já cadastrados: não confirma quem é cliente nem entrega cartão. */
    private static ApiException existing() {
        return new ApiException(HttpStatus.CONFLICT, "SIGNUP_NOT_POSSIBLE",
                "Não foi possível concluir o cadastro online com estes dados. Se você já participa (inclusive se trocou de "
                        + "celular), peça no balcão o QR Code do seu cartão: seus pontos e benefícios continuam os mesmos.");
    }
}
