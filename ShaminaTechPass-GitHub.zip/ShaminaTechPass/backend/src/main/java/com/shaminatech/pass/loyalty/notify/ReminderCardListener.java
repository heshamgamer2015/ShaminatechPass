package com.shaminatech.pass.loyalty.notify;

import java.time.Clock;
import java.time.Instant;

import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import com.shaminatech.pass.loyalty.card.CardChangedEvent;

/**
 * Qualquer mudança no cartão (compra, resgate, estorno, bloqueio, reativação, cancelamento, expiração) torna os lembretes
 * dele obsoletos: o texto de cada aviso descreve a situação anterior. Na mesma transação da mudança, os pedidos ainda não
 * enviados são cancelados e as mensagens já aceitas são marcadas como retiradas — a sincronização seguinte do passe
 * (disparada pelo mesmo evento) remove essas mensagens do cartão no Google Wallet.
 */
@Component
class ReminderCardListener {

    private final WalletReminderRepository reminders;
    private final Clock clock;

    ReminderCardListener(WalletReminderRepository reminders, Clock clock) {
        this.reminders = reminders;
        this.clock = clock;
    }

    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
    public void onCardChanged(CardChangedEvent event) {
        Instant now = clock.instant();
        for (WalletReminder r : reminders.findOpenForCard(event.cardId())) {
            if (r.getStatus() == WalletReminder.Status.ACCEPTED) {
                r.withdraw(now);
            } else {
                r.cancel("A situação do cartão mudou antes do envio (aviso obsoleto).");
            }
        }
    }
}
