package com.shaminatech.pass.plan;

import com.shaminatech.pass.auth.AuthDtos.MeResponse;
import com.shaminatech.pass.security.StrongPassword;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** Contratos do autocadastro. O pedido não tem nenhum campo de papel/permissão: isso é decidido só no servidor. */
public final class PlanDtos {

    private PlanDtos() {
    }

    /**
     * Mesmas regras do cadastro administrativo (nome, contato, responsável e senha forte); {@code website} é campo isca.
     */
    public record SignupRequest(
            @NotBlank(message = "Escolha um plano.") @Size(max = 20) String plan,
            @NotBlank(message = "Informe o nome do estabelecimento.") @Size(max = 150, message = "Máximo de 150 caracteres.")
            String establishmentName,
            @Email(message = "E-mail inválido.") @Size(max = 254) String contactEmail,
            @Size(max = 30, message = "Máximo de 30 caracteres.") @Pattern(regexp = "^[0-9+()\\-\\s]*$", message = "Telefone inválido.")
            String contactPhone,
            @NotBlank(message = "Informe o nome do responsável.") @Size(max = 150, message = "Máximo de 150 caracteres.") String ownerName,
            @NotBlank(message = "Informe o e-mail de acesso.") @Email(message = "E-mail inválido.") @Size(max = 254) String email,
            @NotBlank(message = "Crie uma senha.") @StrongPassword String password,
            @NotBlank(message = "Confirme a senha.") @Size(max = 200) String passwordConfirmation,
            @NotNull(message = "Aceite os termos de uso e a política de privacidade.")
            @AssertTrue(message = "Aceite os termos de uso e a política de privacidade.") Boolean termsAccepted,
            @Size(max = 200) String website) {
    }

    /** Cadastro concluído: a sessão já foi aberta pelo mesmo mecanismo do login. */
    public record SignupResponse(Long establishmentId, String plan, boolean trialFree, MeResponse me) {
    }
}
