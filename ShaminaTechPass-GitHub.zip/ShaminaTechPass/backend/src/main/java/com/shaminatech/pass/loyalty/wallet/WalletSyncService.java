package com.shaminatech.pass.loyalty.wallet;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HexFormat;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.branding.StoredImage;
import com.shaminatech.pass.loyalty.branding.StoredImageRepository;
import com.shaminatech.pass.loyalty.card.BenefitLot;
import com.shaminatech.pass.loyalty.card.BenefitLotRepository;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.card.LoyaltyCardRepository;
import com.shaminatech.pass.loyalty.card.Validity;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.wallet.WalletPass.Provider;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletApi;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletMapper;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletMapper.ClassData;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletMapper.ObjectData;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletProperties;
import com.shaminatech.pass.loyalty.wallet.google.WalletApiException;

import tools.jackson.databind.json.JsonMapper;

/**
 * Envia o estado oficial de um cartão ao Google Wallet. Três passos, cada transação curta:
 * <ol>
 *   <li><b>Reserva</b> (transação com FOR UPDATE): confere se o passe está devido, monta a "fotografia" do cartão e marca
 *       SYNCING com prazo de reserva — dois processos nunca enviam o mesmo passe ao mesmo tempo;</li>
 *   <li><b>Envio</b> (sem transação aberta): cria/atualiza a classe (só se mudou) e o objeto. As chamadas são idempotentes:
 *       repetir o envio grava o mesmo estado no Google, sem duplicar nada;</li>
 *   <li><b>Confirmação</b> (transação): marca a versão enviada como sincronizada, ou registra a falha e agenda nova tentativa.</li>
 * </ol>
 * Nenhum passo altera saldo, movimentações ou validade: o Pass é a fonte oficial e o Google é só um reflexo.
 */
@Service
public class WalletSyncService {

    public enum Outcome { SYNCED, CHANGED_AGAIN, FAILED, SKIPPED }

    private static final Logger log = LoggerFactory.getLogger(WalletSyncService.class);
    private static final Duration LEASE = Duration.ofMinutes(2);
    private static final DateTimeFormatter BR = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final WalletPassRepository passes;
    private final WalletClassRepository classes;
    private final LoyaltyCardRepository cards;
    private final BenefitLotRepository lots;
    private final StoredImageRepository images;
    private final PolicyService policies;
    private final GoogleWalletApi api;
    private final GoogleWalletProperties properties;
    private final TransactionTemplate tx;
    private final JsonMapper json;
    private final Clock clock;
    private final com.shaminatech.pass.loyalty.notify.ProximityService proximity;

    public WalletSyncService(WalletPassRepository passes, WalletClassRepository classes, LoyaltyCardRepository cards,
                             BenefitLotRepository lots, StoredImageRepository images, PolicyService policies, GoogleWalletApi api,
                             GoogleWalletProperties properties, PlatformTransactionManager transactionManager, JsonMapper json,
                             Clock clock, com.shaminatech.pass.loyalty.notify.ProximityService proximity) {
        this.proximity = proximity;
        this.passes = passes;
        this.classes = classes;
        this.cards = cards;
        this.lots = lots;
        this.images = images;
        this.policies = policies;
        this.api = api;
        this.properties = properties;
        this.tx = new TransactionTemplate(transactionManager);
        this.tx.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        this.json = json;
        this.clock = clock;
    }

    private record Work(Long passId, String classId, Map<String, Object> classBody, String classFingerprint, boolean sendClass,
                        boolean classKnown, String objectId, Map<String, Object> objectBody, boolean objectKnown, String state,
                        boolean invalidate) {
    }

    /** Processa o passe até ficar sincronizado (no máximo 3 rodadas se o cartão mudar durante o envio). */
    public Outcome process(Long passId) {
        Outcome outcome = Outcome.SKIPPED;
        for (int round = 0; round < 3; round++) {
            outcome = processOnce(passId);
            if (outcome != Outcome.CHANGED_AGAIN) {
                return outcome;
            }
        }
        return outcome;
    }

    Outcome processOnce(Long passId) {
        Work work;
        try {
            work = tx.execute(status -> reserve(passId));
        } catch (WalletApiException e) {
            recordFailure(passId, e.status(), e.getMessage(), e.retryable());
            return Outcome.FAILED;
        }
        if (work == null) {
            return Outcome.SKIPPED;
        }
        try {
            // Recurso já confirmado antes: PATCH direto (insert só se o Google responder 404).
            // Ainda não confirmado: insert (PATCH se o Google responder 409 — envio anterior interrompido).
            if (work.sendClass()) {
                if (work.classKnown()) {
                    api.patchOrInsertClass(work.classId(), work.classBody());
                } else {
                    api.upsertClass(work.classId(), work.classBody());
                }
            }
            if (work.objectKnown()) {
                api.patchOrInsertObject(work.objectId(), work.objectBody());
            } else {
                api.upsertObject(work.objectId(), work.objectBody());
            }
        } catch (WalletApiException e) {
            recordFailure(passId, e.status(), e.getMessage(), e.retryable());
            return Outcome.FAILED;
        } catch (RuntimeException e) {
            log.error("Falha inesperada ao sincronizar o passe {}", passId, e);
            recordFailure(passId, 0, "Falha inesperada ao sincronizar.", true);
            return Outcome.FAILED;
        }
        return tx.execute(status -> {
            WalletPass pass = passes.lockById(passId).orElseThrow();
            pass.confirm(clock.instant(), work.state(), work.invalidate());
            if (work.sendClass()) {
                classes.findByProgramIdAndProvider(cards.findById(pass.getCardId()).orElseThrow().getProgram().getId(),
                        Provider.GOOGLE_WALLET).ifPresent(c -> c.synced(work.classFingerprint(), clock.instant()));
            }
            return pass.getSyncStatus() == WalletPass.SyncStatus.PENDING ? Outcome.CHANGED_AGAIN : Outcome.SYNCED;
        });
    }

    private void recordFailure(Long passId, int status, String message, boolean retryable) {
        tx.executeWithoutResult(s -> passes.lockById(passId)
                .ifPresent(pass -> pass.fail(clock.instant(), status, message, retryable, properties.maxAttempts())));
    }

    /** Dentro da transação de reserva: lê o estado oficial e monta o que será enviado. */
    private Work reserve(Long passId) {
        Instant now = clock.instant();
        WalletPass pass = passes.lockById(passId).orElse(null);
        if (pass == null || pass.getProvider() != Provider.GOOGLE_WALLET || !pass.isDue(now)) {
            return null; // passes Apple são tratados por AppleWalletSync
        }
        if (!api.configured()) {
            throw new WalletApiException(0, "Integração Google Wallet não configurada: " + String.join(" ", properties.missing()), false);
        }
        LoyaltyCard card = cards.findInEstablishment(pass.getEstablishmentId(), pass.getCardId()).orElseThrow();
        LoyaltyProgram program = card.getProgram();
        ZoneId zone = policies.of(card.getEstablishmentId()).zone();
        CardStatus status = card.effectiveStatus(now);

        WalletClass walletClass = classes.findByProgramIdAndProvider(program.getId(), Provider.GOOGLE_WALLET)
                .orElseGet(() -> classes.save(new WalletClass(card.getEstablishmentId(), program.getId(), Provider.GOOGLE_WALLET,
                        api.issuerId() + ".stp_prog_" + program.getId())));
        Map<String, Object> classBody = GoogleWalletMapper.loyaltyClass(new ClassData(walletClass.getExternalId(),
                program.getEstablishment().getName(), program.getName(),
                program.getBrandColor() == null ? "#F43F5E" : program.getBrandColor(),
                imageUri(program.getLogoImageId(), true), imageUri(program.getHeroImageId(), false), properties.countryCode(),
                rewardInfo(program), program.getDescription()));
        // Etapa 6: pontos da loja para avisos de proximidade (só quando o estabelecimento já usou o recurso).
        var merchantLocations = proximity.googleMerchantLocations(card.getEstablishmentId());
        if (merchantLocations != null) {
            classBody.put("merchantLocations", merchantLocations);
        }
        String fingerprint = sha256(json.writeValueAsString(classBody));
        boolean sendClass = !fingerprint.equals(walletClass.getSyncedFingerprint());

        Map<String, Object> objectBody = GoogleWalletMapper.loyaltyObject(new ObjectData(pass.getExternalId(),
                walletClass.getExternalId(), status, firstName(card.getConsumer().getFullName()),
                com.shaminatech.pass.loyalty.card.CardCodes.format(card.getCode()), card.getCode(), program.getType(),
                card.getBalance(), program.getStampsRequired(), card.getExpiresAt(),
                Validity.validUntilLocal(card.getExpiresAt(), zone).format(BR), nextBenefitExpiry(card, program.getType(), zone, now),
                program.getCardMessage()));
        // Etapa 6: mensagens de lembrete ainda válidas (retira as obsoletas). Sem lembretes, o campo não é enviado.
        var messages = proximity.googleMessages(card.getId());
        if (messages != null) {
            objectBody.put("messages", messages);
        }
        pass.reserve(now, LEASE);
        return new Work(passId, walletClass.getExternalId(), classBody, fingerprint, sendClass,
                walletClass.getSyncedFingerprint() != null, pass.getExternalId(), objectBody, pass.getRemoteState() != null,
                GoogleWalletMapper.state(status), status == CardStatus.CANCELLED);
    }

    /** URL pública da imagem; o logotipo é obrigatório no Google (usa o padrão configurado se o programa não tiver). */
    private String imageUri(Long imageId, boolean required) {
        if (imageId != null && properties.publicBaseUrl() != null) {
            StoredImage image = images.findById(imageId).orElse(null);
            if (image != null) {
                return properties.publicBaseUrl().replaceAll("/+$", "") + "/api/public/images/" + image.ensurePublicToken();
            }
        }
        if (!required) {
            return null;
        }
        if (properties.fallbackLogoUri() != null) {
            return properties.fallbackLogoUri();
        }
        throw new WalletApiException(0, "O Google Wallet exige um logotipo acessível pela internet: envie um logotipo e configure "
                + "a URL pública do backend (shaminatech.wallet.google.public-base-url).", false);
    }

    private static String rewardInfo(LoyaltyProgram program) {
        if (program.getRewardInfo() != null) {
            return program.getRewardInfo();
        }
        if (program.getType() == ProgramType.STAMPS && program.getStampReward() != null) {
            return "Complete " + program.getStampsRequired() + " carimbos: " + program.getStampReward();
        }
        return null;
    }

    private String nextBenefitExpiry(LoyaltyCard card, ProgramType type, ZoneId zone, Instant now) {
        return lots.findOpenByCard(card.getId()).stream()
                .filter(l -> l.isUsable(now) && l.getExpiresAt() != null)
                .min((a, b) -> a.getExpiresAt().compareTo(b.getExpiresAt()))
                .map(l -> amount(type, l) + " em " + Validity.validUntilLocal(l.getExpiresAt(), zone).format(BR))
                .orElse(null);
    }

    private static String amount(ProgramType type, BenefitLot lot) {
        BigDecimal v = lot.getRemaining();
        return switch (type) {
            case CASHBACK -> "R$ " + v.setScale(2).toPlainString().replace('.', ',');
            case STAMPS -> v.intValue() + " carimbo(s)";
            default -> v.intValue() + " ponto(s)";
        };
    }

    /** Minimização de dados: o passe mostra só o primeiro nome do consumidor. */
    public static String firstName(String fullName) {
        String trimmed = fullName == null ? "" : fullName.trim();
        int space = trimmed.indexOf(' ');
        return space > 0 ? trimmed.substring(0, space) : trimmed;
    }

    private static String sha256(String value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
