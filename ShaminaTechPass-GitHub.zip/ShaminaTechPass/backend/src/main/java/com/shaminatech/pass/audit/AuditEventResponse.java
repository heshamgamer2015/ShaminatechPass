package com.shaminatech.pass.audit;

import java.time.Instant;

public record AuditEventResponse(Long id, Instant occurredAt, AuditAction action, Long actorUserId, String actorEmail,
                                 Long establishmentId, String targetType, String targetId, String details) {

    public static AuditEventResponse from(AuditEvent event) {
        return new AuditEventResponse(event.getId(), event.getOccurredAt(), event.getAction(), event.getActorUserId(),
                event.getActorEmail(), event.getEstablishmentId(), event.getTargetType(), event.getTargetId(),
                event.getDetails());
    }
}
