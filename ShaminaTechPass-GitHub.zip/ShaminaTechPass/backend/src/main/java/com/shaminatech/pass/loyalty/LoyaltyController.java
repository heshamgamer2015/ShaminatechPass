package com.shaminatech.pass.loyalty;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import jakarta.validation.Valid;

import org.springframework.data.domain.Sort;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.common.web.PageResponse;
import com.shaminatech.pass.common.web.Paging;
import com.shaminatech.pass.loyalty.LoyaltyDtos.CardActionRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.CardDetail;
import com.shaminatech.pass.loyalty.LoyaltyDtos.CardView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ConsumerDetail;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ConsumerRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ConsumerUpdateRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ConsumerView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.DesignRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.EarnRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.IssueCardRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.OperationResult;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ProgramRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ProgramStatusRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ProgramView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.RedeemRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ReverseRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.RewardRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.RewardView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.StatusRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.TransactionView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.VipTierRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.VipTierView;
import com.shaminatech.pass.loyalty.branding.BrandingService;
import com.shaminatech.pass.loyalty.branding.StoredImage;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.CardEnums.TransactionType;
import com.shaminatech.pass.loyalty.card.CardService;
import com.shaminatech.pass.loyalty.consumer.Consumer;
import com.shaminatech.pass.loyalty.consumer.ConsumerService;
import com.shaminatech.pass.loyalty.metrics.MetricsService;
import com.shaminatech.pass.loyalty.program.ProgramService;

/**
 * API de fidelidade do painel do estabelecimento. O id do tenant vem do caminho e é validado em cada serviço
 * ({@code TenantAccessService}); concessões, resgates e estornos exigem o cabeçalho {@code Idempotency-Key}.
 */
@RestController
@RequestMapping("/api/establishments/{establishmentId}")
public class LoyaltyController {

    private static final Sort NEWEST = Sort.by(Sort.Direction.DESC, "occurredAt", "id");
    private static final Sort NEWEST_CARDS = Sort.by(Sort.Direction.DESC, "issuedAt", "id");

    private final ConsumerService consumers;
    private final ProgramService programs;
    private final CardService cards;
    private final BrandingService branding;
    private final MetricsService metrics;

    public LoyaltyController(ConsumerService consumers, ProgramService programs, CardService cards, BrandingService branding,
                             MetricsService metrics) {
        this.consumers = consumers;
        this.programs = programs;
        this.cards = cards;
        this.branding = branding;
        this.metrics = metrics;
    }

    // ---------------- Visão geral e indicadores ----------------

    @GetMapping("/overview")
    public MetricsService.Overview overview(@PathVariable Long establishmentId) {
        return metrics.overview(establishmentId);
    }

    @GetMapping("/indicators")
    public MetricsService.Indicators indicators(@PathVariable Long establishmentId, @RequestParam(defaultValue = "90") int days,
                                                @RequestParam(required = false) Long programId) {
        return metrics.indicators(establishmentId, days, programId);
    }

    // ---------------- Consumidores ----------------

    @GetMapping("/consumers")
    public PageResponse<ConsumerView> consumers(@PathVariable Long establishmentId, @RequestParam(required = false) String q,
                                                @RequestParam(required = false) Consumer.Status status,
                                                @RequestParam(defaultValue = "0") int page,
                                                @RequestParam(defaultValue = "20") int size) {
        return consumers.search(establishmentId, q, status, Paging.of(page, size, ConsumerService.BY_NAME));
    }

    @PostMapping("/consumers")
    @ResponseStatus(HttpStatus.CREATED)
    public ConsumerView createConsumer(@PathVariable Long establishmentId, @Valid @RequestBody ConsumerRequest body) {
        return consumers.create(establishmentId, body);
    }

    @GetMapping("/consumers/{consumerId}")
    public ConsumerDetail consumer(@PathVariable Long establishmentId, @PathVariable Long consumerId) {
        return consumers.get(establishmentId, consumerId);
    }

    @PutMapping("/consumers/{consumerId}")
    public ConsumerView updateConsumer(@PathVariable Long establishmentId, @PathVariable Long consumerId,
                                       @Valid @RequestBody ConsumerUpdateRequest body) {
        return consumers.update(establishmentId, consumerId, body);
    }

    @PatchMapping("/consumers/{consumerId}/status")
    public ConsumerView consumerStatus(@PathVariable Long establishmentId, @PathVariable Long consumerId,
                                       @Valid @RequestBody StatusRequest body) {
        return consumers.changeStatus(establishmentId, consumerId, body.status());
    }

    @GetMapping("/consumers/{consumerId}/transactions")
    public PageResponse<TransactionView> consumerHistory(@PathVariable Long establishmentId, @PathVariable Long consumerId,
                                                         @RequestParam(defaultValue = "0") int page,
                                                         @RequestParam(defaultValue = "20") int size) {
        return consumers.history(establishmentId, consumerId, Paging.of(page, size, NEWEST));
    }

    // ---------------- Programas, recompensas e níveis ----------------

    @GetMapping("/programs")
    public List<ProgramView> programs(@PathVariable Long establishmentId) {
        return programs.list(establishmentId);
    }

    @PostMapping("/programs")
    @ResponseStatus(HttpStatus.CREATED)
    public ProgramView createProgram(@PathVariable Long establishmentId, @Valid @RequestBody ProgramRequest body) {
        return programs.create(establishmentId, body);
    }

    @GetMapping("/programs/{programId}")
    public ProgramView program(@PathVariable Long establishmentId, @PathVariable Long programId) {
        return programs.get(establishmentId, programId);
    }

    @PutMapping("/programs/{programId}")
    public ProgramView updateProgram(@PathVariable Long establishmentId, @PathVariable Long programId,
                                     @Valid @RequestBody ProgramRequest body) {
        return programs.update(establishmentId, programId, body);
    }

    @PatchMapping("/programs/{programId}/status")
    public ProgramView programStatus(@PathVariable Long establishmentId, @PathVariable Long programId,
                                     @Valid @RequestBody ProgramStatusRequest body) {
        return programs.changeStatus(establishmentId, programId, body.status());
    }

    @PutMapping("/programs/{programId}/design")
    public ProgramView design(@PathVariable Long establishmentId, @PathVariable Long programId,
                              @Valid @RequestBody DesignRequest body) {
        return programs.updateDesign(establishmentId, programId, body);
    }

    @PostMapping(path = "/programs/{programId}/images/{slot}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ProgramView uploadImage(@PathVariable Long establishmentId, @PathVariable Long programId, @PathVariable String slot,
                                   @RequestPart("file") MultipartFile file) {
        try {
            return branding.upload(establishmentId, programId, BrandingService.Slot.parse(slot), file.getBytes());
        } catch (IOException e) {
            throw ApiException.badRequest("Não foi possível ler o arquivo enviado.", "file");
        }
    }

    @DeleteMapping("/programs/{programId}/images/{slot}")
    public ProgramView removeImage(@PathVariable Long establishmentId, @PathVariable Long programId, @PathVariable String slot) {
        return branding.remove(establishmentId, programId, BrandingService.Slot.parse(slot));
    }

    @GetMapping("/images/{imageId}")
    public ResponseEntity<byte[]> image(@PathVariable Long establishmentId, @PathVariable Long imageId) {
        StoredImage image = branding.get(establishmentId, imageId);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(image.getContentType()))
                .cacheControl(CacheControl.noCache().cachePrivate())
                .header("X-Content-Type-Options", "nosniff")
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline")
                .eTag(image.getSha256())
                .body(image.getData());
    }

    @GetMapping("/rewards")
    public List<RewardView> rewards(@PathVariable Long establishmentId, @RequestParam(required = false) Long programId) {
        return programs.listRewards(establishmentId, programId);
    }

    @PostMapping("/programs/{programId}/rewards")
    @ResponseStatus(HttpStatus.CREATED)
    public RewardView createReward(@PathVariable Long establishmentId, @PathVariable Long programId,
                                   @Valid @RequestBody RewardRequest body) {
        return programs.createReward(establishmentId, programId, body);
    }

    @PutMapping("/rewards/{rewardId}")
    public RewardView updateReward(@PathVariable Long establishmentId, @PathVariable Long rewardId,
                                   @Valid @RequestBody RewardRequest body) {
        return programs.updateReward(establishmentId, rewardId, body);
    }

    @GetMapping("/programs/{programId}/tiers")
    public List<VipTierView> tiers(@PathVariable Long establishmentId, @PathVariable Long programId) {
        return programs.listTiers(establishmentId, programId);
    }

    @PostMapping("/programs/{programId}/tiers")
    @ResponseStatus(HttpStatus.CREATED)
    public VipTierView createTier(@PathVariable Long establishmentId, @PathVariable Long programId,
                                  @Valid @RequestBody VipTierRequest body) {
        return programs.saveTier(establishmentId, programId, null, body);
    }

    @PutMapping("/programs/{programId}/tiers/{tierId}")
    public VipTierView updateTier(@PathVariable Long establishmentId, @PathVariable Long programId, @PathVariable Long tierId,
                                  @Valid @RequestBody VipTierRequest body) {
        return programs.saveTier(establishmentId, programId, tierId, body);
    }

    // ---------------- Cartões ----------------

    @GetMapping("/cards")
    public PageResponse<CardView> cards(@PathVariable Long establishmentId, @RequestParam(required = false) CardStatus status,
                                        @RequestParam(required = false) Long programId, @RequestParam(required = false) String q,
                                        @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size) {
        return cards.list(establishmentId, status, programId, q, Paging.of(page, size, NEWEST_CARDS));
    }

    @PostMapping("/cards")
    @ResponseStatus(HttpStatus.CREATED)
    public CardView issueCard(@PathVariable Long establishmentId, @Valid @RequestBody IssueCardRequest body) {
        return cards.issue(establishmentId, body);
    }

    @GetMapping("/cards/lookup")
    public CardDetail lookup(@PathVariable Long establishmentId, @RequestParam String code) {
        return cards.lookup(establishmentId, code);
    }

    @GetMapping("/cards/{cardId}")
    public CardDetail card(@PathVariable Long establishmentId, @PathVariable Long cardId) {
        return cards.get(establishmentId, cardId);
    }

    @GetMapping("/cards/{cardId}/transactions")
    public PageResponse<TransactionView> cardHistory(@PathVariable Long establishmentId, @PathVariable Long cardId,
                                                     @RequestParam(defaultValue = "0") int page,
                                                     @RequestParam(defaultValue = "20") int size) {
        return cards.cardHistory(establishmentId, cardId, Paging.of(page, size, NEWEST));
    }

    @PostMapping("/cards/{cardId}/suspend")
    public CardView suspend(@PathVariable Long establishmentId, @PathVariable Long cardId,
                            @Valid @RequestBody(required = false) CardActionRequest body) {
        return cards.suspend(establishmentId, cardId, body == null ? null : body.reason());
    }

    @PostMapping("/cards/{cardId}/reactivate")
    public CardView reactivate(@PathVariable Long establishmentId, @PathVariable Long cardId,
                               @Valid @RequestBody(required = false) CardActionRequest body) {
        return cards.reactivate(establishmentId, cardId, body == null ? null : body.reason());
    }

    @PostMapping("/cards/{cardId}/cancel")
    public CardView cancel(@PathVariable Long establishmentId, @PathVariable Long cardId,
                           @Valid @RequestBody(required = false) CardActionRequest body) {
        return cards.cancel(establishmentId, cardId, body == null ? null : body.reason());
    }

    // ---------------- Movimentações ----------------

    @PostMapping("/cards/{cardId}/earn")
    public ResponseEntity<OperationResult> earn(@PathVariable Long establishmentId, @PathVariable Long cardId,
                                                @RequestHeader(name = "Idempotency-Key", required = false) String key,
                                                @Valid @RequestBody EarnRequest body) {
        return created(cards.earn(establishmentId, cardId, body, key));
    }

    @PostMapping("/cards/{cardId}/redeem")
    public ResponseEntity<OperationResult> redeem(@PathVariable Long establishmentId, @PathVariable Long cardId,
                                                  @RequestHeader(name = "Idempotency-Key", required = false) String key,
                                                  @Valid @RequestBody RedeemRequest body) {
        return created(cards.redeem(establishmentId, cardId, body, key));
    }

    @PostMapping("/transactions/{transactionId}/reverse")
    public ResponseEntity<OperationResult> reverse(@PathVariable Long establishmentId, @PathVariable Long transactionId,
                                                   @RequestHeader(name = "Idempotency-Key", required = false) String key,
                                                   @Valid @RequestBody ReverseRequest body) {
        return created(cards.reverse(establishmentId, transactionId, body.reason(), key));
    }

    @GetMapping("/transactions")
    public PageResponse<TransactionView> transactions(@PathVariable Long establishmentId,
                                                      @RequestParam(required = false) Set<TransactionType> type,
                                                      @RequestParam(defaultValue = "0") int page,
                                                      @RequestParam(defaultValue = "20") int size) {
        return cards.history(establishmentId, type, Paging.of(page, size, NEWEST));
    }

    /** 201 para operação nova; 200 quando a chave de idempotência repetiu uma operação já gravada. */
    private static ResponseEntity<OperationResult> created(OperationResult result) {
        return ResponseEntity.status(result.replayed() ? HttpStatus.OK : HttpStatus.CREATED).body(result);
    }
}
