package com.shaminatech.pass.loyalty.program;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface VipTierRepository extends JpaRepository<VipTier, Long> {

    @Query("select t from VipTier t where t.id = :id and t.establishmentId = :establishmentId")
    Optional<VipTier> findInEstablishment(@Param("establishmentId") Long establishmentId, @Param("id") Long id);

    @Query("select t from VipTier t where t.program.id = :programId and t.establishmentId = :establishmentId order by t.rankOrder")
    List<VipTier> findByProgram(@Param("establishmentId") Long establishmentId, @Param("programId") Long programId);
}
