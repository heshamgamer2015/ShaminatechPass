package com.shaminatech.pass.loyalty.policy;

import java.time.Duration;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

import com.shaminatech.pass.loyalty.ProgramType;

/**
 * Configuração do módulo de fidelidade.
 * <ul>
 *   <li>{@code defaults}: valores usados só para criar o registro inicial de regras padrão (depois editável no painel);</li>
 *   <li>{@code expiration}: processamento periódico de expiração;</li>
 *   <li>{@code images}: limites de upload da personalização.</li>
 * </ul>
 */
@ConfigurationProperties(prefix = "shaminatech.loyalty")
public record LoyaltyProperties(Defaults defaults, Expiration expiration, Images images) {

    public LoyaltyProperties {
        defaults = defaults == null ? new Defaults(null, null, null, null) : defaults;
        expiration = expiration == null ? new Expiration(null, null, null) : expiration;
        images = images == null ? new Images(null, null, null) : images;
    }

    public record Defaults(Integer maxActiveConsumers, Integer inactivityDays, String timeZone, List<ProgramType> programTypes) {
        public Defaults {
            maxActiveConsumers = maxActiveConsumers == null ? 100 : maxActiveConsumers;
            inactivityDays = inactivityDays == null ? 90 : inactivityDays;
            timeZone = timeZone == null || timeZone.isBlank() ? "America/Sao_Paulo" : timeZone;
            programTypes = programTypes == null ? List.of(ProgramType.STAMPS, ProgramType.POINTS) : programTypes;
        }
    }

    public record Expiration(Boolean enabled, Duration interval, Integer batchSize) {
        public Expiration {
            enabled = enabled == null || enabled;
            interval = interval == null ? Duration.ofMinutes(10) : interval;
            batchSize = batchSize == null ? 200 : batchSize;
        }
    }

    public record Images(Long maxBytes, Integer minDimension, Integer maxDimension) {
        public Images {
            maxBytes = maxBytes == null ? 1_048_576L : maxBytes;
            minDimension = minDimension == null ? 64 : minDimension;
            maxDimension = maxDimension == null ? 4096 : maxDimension;
        }
    }
}
