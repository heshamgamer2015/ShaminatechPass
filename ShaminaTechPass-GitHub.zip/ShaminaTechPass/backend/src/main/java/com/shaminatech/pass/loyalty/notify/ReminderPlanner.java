package com.shaminatech.pass.loyalty.notify;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import com.shaminatech.pass.establishment.EstablishmentRepository;
import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.LoyaltyReward;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletApi;

/**
 * Planejamento de lembretes: percorre os cartões elegíveis de cada estabelecimento com lembretes ativos e cria pedidos
 * PENDING. Uma transação por estabelecimento, com a configuração travada (FOR UPDATE): execuções simultâneas não
 * planejam duas vezes. Nenhuma chamada externa acontece aqui.
 * <p>
 * Controles: a mesma situação (chave) nunca gera dois lembretes; intervalo mínimo por cartão e categoria; no máximo um
 * lembrete por cartão a cada 24 h, somando todas as categorias (o Google permite até 3 avisos por passe em 24 h e pode
 * limitar quem envia demais); prioridade vencimento &gt; recompensa próxima &gt; inatividade.
 */
@Service
public class ReminderPlanner {

    static final Duration PER_CARD_GAP = Duration.ofHours(24);
    static final int MAX_CARDS_PER_RUN = 2000;
    private static final List<ReminderCategory> PRIORITY =
            List.of(ReminderCategory.EXPIRY, ReminderCategory.NEAR_REWARD, ReminderCategory.INACTIVITY);
    private static final Logger log = LoggerFactory.getLogger(ReminderPlanner.class);

    private final NotificationSettingsRepository settings;
    private final ReminderCandidateRepository candidates;
    private final WalletReminderRepository reminders;
    private final EstablishmentRepository establishments;
    private final ReminderSnapshots snapshots;
    private final PolicyService policies;
    private final GoogleWalletApi google;
    private final TransactionTemplate tx;
    private final Clock clock;

    public ReminderPlanner(NotificationSettingsRepository settings, ReminderCandidateRepository candidates,
                           WalletReminderRepository reminders, EstablishmentRepository establishments, ReminderSnapshots snapshots,
                           PolicyService policies, GoogleWalletApi google, PlatformTransactionManager transactionManager, Clock clock) {
        this.settings = settings;
        this.candidates = candidates;
        this.reminders = reminders;
        this.establishments = establishments;
        this.snapshots = snapshots;
        this.policies = policies;
        this.google = google;
        this.tx = new TransactionTemplate(transactionManager);
        this.tx.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        this.clock = clock;
    }

    /** Planeja todos os estabelecimentos com alguma categoria ativa. Devolve quantos lembretes foram criados. */
    public int planAll() {
        if (!google.configured()) {
            return 0; // sem Google Wallet configurado não há para onde enviar
        }
        int created = 0;
        for (Long establishmentId : settings.findEstablishmentsWithReminders()) {
            try {
                Integer n = tx.execute(s -> plan(establishmentId));
                created += n == null ? 0 : n;
            } catch (RuntimeException e) {
                log.warn("Falha ao planejar lembretes do estabelecimento {}: {}", establishmentId, e.getMessage());
            }
        }
        return created;
    }

    private int plan(Long establishmentId) {
        NotificationSettings s = settings.lockByEstablishmentId(establishmentId).orElse(null);
        if (s == null || !s.anyReminderEnabled()) {
            return 0;
        }
        if (!establishments.findById(establishmentId).map(e -> e.isActive()).orElse(false)) {
            return 0;
        }
        Instant now = clock.instant();
        ZoneId zone = policies.of(establishmentId).zone();
        Map<Long, LoyaltyReward> cheapest = snapshots.cheapestRewards(establishmentId);
        int created = 0;
        int seen = 0;
        long afterId = 0;
        while (seen < MAX_CARDS_PER_RUN) {
            List<Object[]> page = candidates.findCandidates(establishmentId, now, afterId, PageRequest.of(0, 200));
            if (page.isEmpty()) {
                break;
            }
            for (Object[] row : page) {
                LoyaltyCard card = (LoyaltyCard) row[0];
                Long passId = (Long) row[1];
                afterId = card.getId();
                seen++;
                if (plan(card, passId, s, zone, now, cheapest)) {
                    created++;
                }
            }
        }
        return created;
    }

    private boolean plan(LoyaltyCard card, Long passId, NotificationSettings s, ZoneId zone, Instant now,
                         Map<Long, LoyaltyReward> cheapest) {
        if (reminders.existsAnyRecent(card.getId(), now.minus(PER_CARD_GAP))) {
            return false;
        }
        ReminderRules.CardSnapshot snapshot = snapshots.of(card, cheapest, now);
        for (ReminderCategory category : PRIORITY) {
            Optional<ReminderRules.Candidate> candidate = ReminderRules.evaluate(category, snapshot, s, zone, now);
            if (candidate.isEmpty() || reminders.existsByDedupKey(candidate.get().dedupKey())
                    || reminders.existsRecent(card.getId(), category, now.minus(Duration.ofDays(s.getMinIntervalDays())))) {
                continue;
            }
            ReminderRules.Candidate c = candidate.get();
            reminders.save(new WalletReminder(card.getEstablishmentId(), card.getId(), passId, category, c.dedupKey(),
                    limit(c.header(), 80), limit(c.body(), 300), c.displayUntil(), now));
            return true;
        }
        return false;
    }

    static String limit(String v, int max) {
        return v.length() > max ? v.substring(0, max - 1) + "…" : v;
    }
}
