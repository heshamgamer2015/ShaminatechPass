package com.shaminatech.pass.loyalty;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.shaminatech.pass.loyalty.LoyaltyDtos.CardView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ConsumerView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.DesignView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.LotView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.NextBenefitExpiry;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ProgramView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.RewardView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.TransactionView;
import com.shaminatech.pass.loyalty.card.BenefitLot;
import com.shaminatech.pass.loyalty.card.BenefitLotRepository;
import com.shaminatech.pass.loyalty.card.CardCodes;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.CardTransaction;
import com.shaminatech.pass.loyalty.card.CardTransactionRepository;
import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.card.Validity;
import com.shaminatech.pass.loyalty.consumer.Consumer;
import com.shaminatech.pass.loyalty.consumer.ConsumerRepository;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicy;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.LoyaltyProgramRepository;
import com.shaminatech.pass.loyalty.program.LoyaltyReward;

/** Converte entidades em respostas da API (datas de validade exibidas no fuso do estabelecimento). */
@Component
public class LoyaltyViews {

    /** Limitações conhecidas das carteiras, exibidas na tela de personalização (a prévia é interna ao Pass). */
    public static final List<String> WALLET_NOTES = List.of(
            "Prévia interna do ShaminaTech Pass: o Google Wallet define a disposição dos campos; a aparência real só é confirmada no celular.",
            "Google Wallet: usa a cor de fundo, o logotipo e a imagem de destaque. A cor do texto é escolhida automaticamente pelo Google.",
            "Logotipo: PNG quadrado de no mínimo 660 × 660 px; o Google recorta em círculo (não envie já recortado).",
            "Imagem de destaque: PNG de 1032 × 812 px recomendado, exibida na largura total abaixo dos dados.",
            "Nome do programa e do estabelecimento podem ser cortados após cerca de 20 caracteres.",
            "Enquanto a conta emissora estiver em modo de demonstração, o passe aparece com a indicação [TEST ONLY].",
            "Apple Wallet: usa a cor de fundo e a cor do texto escolhidas, o logotipo (ajustado à altura de 50 pt) e um recorte "
                    + "da imagem de destaque como faixa (proporção 375 × 123).",
            "Apple Wallet: imagens em PNG ou JPEG; o logotipo quadrado de 660 × 660 px atende aos tamanhos 1x, 2x e 3x.",
            "Apple Wallet: a aparência real só é confirmada no iPhone; a prévia do Pass é aproximada.");

    private final BenefitLotRepository lots;
    private final CardTransactionRepository transactions;
    private final ConsumerRepository consumers;
    private final LoyaltyProgramRepository programs;
    private final Clock clock;

    public LoyaltyViews(BenefitLotRepository lots, CardTransactionRepository transactions, ConsumerRepository consumers,
                        LoyaltyProgramRepository programs, Clock clock) {
        this.lots = lots;
        this.transactions = transactions;
        this.consumers = consumers;
        this.programs = programs;
        this.clock = clock;
    }

    public ConsumerView consumer(Consumer c, int activeCards) {
        return new ConsumerView(c.getId(), c.getFullName(), c.getPhone(), c.getEmail(), c.getExternalRef(), c.getStatus(),
                c.getSource(), c.isMarketingOptIn(), c.getPrivacyAcknowledgedAt(), c.getCreatedAt(), c.getStatusChangedAt(),
                activeCards);
    }

    public ProgramView program(LoyaltyProgram p, EstablishmentPolicy policy) {
        return new ProgramView(p.getId(), p.getType(), policy.allows(p.getType()), p.getType().isOperational(), p.getName(),
                p.getDescription(), p.getStatus(), p.getInactivityDays(), p.getValidityMode(), p.getExpiredBalancePolicy(),
                p.getReversalPolicy(), p.getBenefitValidityDays(), p.getMinPurchaseAmount(), p.getRounding(),
                p.getPointsPerUnit(), p.getSpendUnit(), p.getCashbackPercent(), p.getMaxCreditPerPurchase(),
                p.getMinRedeemBalance(), p.getMaxRedeemPercent(), p.getStampsRequired(), p.getStampCriterion(),
                p.getStampReward(), p.getRestartAfterRedeem(), design(p), p.getCreatedAt());
    }

    public DesignView design(LoyaltyProgram p) {
        String base = "/api/establishments/" + p.getEstablishmentId() + "/images/";
        return new DesignView(p.getBrandColor() == null ? "#F43F5E" : p.getBrandColor(),
                p.getTextColor() == null ? "#FFFFFF" : p.getTextColor(), p.getCardMessage(), p.getRewardInfo(),
                p.getLogoImageId() == null ? null : base + p.getLogoImageId(),
                p.getHeroImageId() == null ? null : base + p.getHeroImageId(), WALLET_NOTES);
    }

    public RewardView reward(LoyaltyReward r) {
        return new RewardView(r.getId(), r.getProgram().getId(), r.getProgram().getName(), r.getName(), r.getDescription(),
                r.getCost(), r.isActive());
    }

    public CardView card(LoyaltyCard card, ZoneId zone) {
        Instant now = clock.instant();
        List<BenefitLot> open = lots.findOpenByCard(card.getId());
        BigDecimal available = open.stream().filter(l -> l.isUsable(now)).map(BenefitLot::getRemaining)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        NextBenefitExpiry next = open.stream().filter(l -> l.isUsable(now) && l.getExpiresAt() != null)
                .min((a, b) -> a.getExpiresAt().compareTo(b.getExpiresAt()))
                .map(l -> new NextBenefitExpiry(l.getRemaining(), l.getExpiresAt())).orElse(null);
        LoyaltyProgram program = card.getProgram();
        CardStatus effective = card.effectiveStatus(now);
        boolean rewardAvailable = effective == CardStatus.ACTIVE && switch (program.getType()) {
            case STAMPS -> program.getStampsRequired() != null
                    && available.compareTo(BigDecimal.valueOf(program.getStampsRequired())) >= 0;
            case POINTS, CASHBACK -> available.signum() > 0;
            case VIP -> false;
        };
        return new CardView(card.getId(), card.getCode(), CardCodes.format(card.getCode()), effective, card.getStatus(),
                card.getBalance(), available, program.getId(), program.getName(), program.getType(),
                card.getConsumer().getId(), card.getConsumer().getFullName(), card.getIssuedAt(), card.getLastMovementAt(),
                card.getExpiresAt(), Validity.validUntilLocal(card.getExpiresAt(), zone), zone.getId(), card.inactivityDays(),
                card.getStatusReason(), card.getCompletedCycles(), program.getStampsRequired(), rewardAvailable, next);
    }

    public LotView lot(BenefitLot l) {
        return new LotView(l.getId(), l.getOriginalAmount(), l.getRemaining(), l.getExpiredAmount(), l.getExpiresAt(),
                l.getStatus(), l.getCreatedAt());
    }

    /** Converte uma página de histórico carregando consumidores, programas e estornos em lote (sem N+1). */
    public List<TransactionView> transactions(Collection<CardTransaction> items) {
        if (items.isEmpty()) {
            return List.of();
        }
        Set<Long> consumerIds = items.stream().map(CardTransaction::getConsumerId).collect(Collectors.toSet());
        Set<Long> programIds = items.stream().map(CardTransaction::getProgramId).collect(Collectors.toSet());
        Map<Long, Consumer> consumerMap = consumers.findAllById(consumerIds).stream()
                .collect(Collectors.toMap(Consumer::getId, Function.identity()));
        Map<Long, LoyaltyProgram> programMap = programs.findAllById(programIds).stream()
                .collect(Collectors.toMap(LoyaltyProgram::getId, Function.identity()));
        Set<Long> reversed = new HashSet<>(transactions.findReversedAmong(items.stream().map(CardTransaction::getId).toList()));
        List<TransactionView> result = new ArrayList<>();
        for (CardTransaction t : items) {
            Consumer consumer = consumerMap.get(t.getConsumerId());
            LoyaltyProgram program = programMap.get(t.getProgramId());
            boolean isReversed = reversed.contains(t.getId());
            result.add(new TransactionView(t.getId(), t.getType(), t.getChannel(), t.getAmount(), t.getBalanceAfter(),
                    t.getPurchaseAmount(), t.getDescription(), t.getNote(), t.getOccurredAt(), t.getReversesId(), isReversed,
                    t.getType().isMovement() && !isReversed, t.getCard().getId(), CardCodes.format(t.getCard().getCode()),
                    t.getConsumerId(), consumer == null ? null : consumer.getFullName(), t.getProgramId(),
                    program == null ? null : program.getName(), program == null ? null : program.getType(),
                    t.getCardStatusAfter(), t.getCardExpiresAtAfter()));
        }
        return result;
    }
}
