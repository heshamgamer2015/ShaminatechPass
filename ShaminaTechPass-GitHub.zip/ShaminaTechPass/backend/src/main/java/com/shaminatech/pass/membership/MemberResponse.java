package com.shaminatech.pass.membership;

import java.time.Instant;

import com.shaminatech.pass.user.UserStatus;

/** Vínculo exibido nas listagens de equipe. Nunca inclui dados de senha. */
public record MemberResponse(Long membershipId, Long userId, String email, String fullName, MembershipRole role,
                             MembershipStatus status, UserStatus userStatus, Instant createdAt) {

    public static MemberResponse from(Membership membership) {
        var user = membership.getUser();
        return new MemberResponse(membership.getId(), user.getId(), user.getEmail(), user.getFullName(),
                membership.getRole(), membership.getStatus(), user.getStatus(), membership.getCreatedAt());
    }
}
