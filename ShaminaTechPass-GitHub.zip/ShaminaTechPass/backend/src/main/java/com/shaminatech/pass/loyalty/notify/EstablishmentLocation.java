package com.shaminatech.pass.loyalty.notify;

import com.shaminatech.pass.common.persistence.BaseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

/**
 * Endereço físico do estabelecimento (até {@value #MAX_PER_ESTABLISHMENT}, limite das carteiras Google e Apple). Usado
 * só para publicar o ponto da loja no cartão — o Pass nunca recebe nem guarda a localização do consumidor.
 */
@Entity
@Table(name = "establishment_location",
        indexes = @Index(name = "idx_establishment_location_establishment", columnList = "establishment_id"))
public class EstablishmentLocation extends BaseEntity {

    public static final int MAX_PER_ESTABLISHMENT = 10;

    @Column(name = "establishment_id", nullable = false, updatable = false)
    private Long establishmentId;

    @Column(nullable = false, length = 60)
    private String name;

    @Column(name = "address_line", nullable = false, length = 200)
    private String addressLine;

    @Column(nullable = false, length = 80)
    private String city;

    /** UF (2 letras). */
    @Column(nullable = false, length = 2)
    private String state;

    /** CEP com 8 dígitos. */
    @Column(name = "postal_code", nullable = false, length = 8)
    private String postalCode;

    @Column(nullable = false)
    private double latitude;

    @Column(nullable = false)
    private double longitude;

    protected EstablishmentLocation() {
    }

    public EstablishmentLocation(Long establishmentId) {
        this.establishmentId = establishmentId;
    }

    public void update(String name, String addressLine, String city, String state, String postalCode, double latitude,
                       double longitude) {
        this.name = name;
        this.addressLine = addressLine;
        this.city = city;
        this.state = state;
        this.postalCode = postalCode;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Long getEstablishmentId() { return establishmentId; }
    public String getName() { return name; }
    public String getAddressLine() { return addressLine; }
    public String getCity() { return city; }
    public String getState() { return state; }
    public String getPostalCode() { return postalCode; }
    public double getLatitude() { return latitude; }
    public double getLongitude() { return longitude; }
}
