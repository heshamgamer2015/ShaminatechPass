package com.shaminatech.pass.loyalty.wallet.google;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import tools.jackson.databind.json.JsonMapper;

/**
 * Cliente da API REST do Google Wallet (walletobjects/v1), sem SDK: OAuth 2.0 da conta de serviço
 * (JWT bearer, escopo {@value #SCOPE}), chamadas JSON com tempo limite e assinatura do JWT "Adicionar ao Google Wallet".
 * <p>
 * Nunca deve ser chamado dentro de uma transação de banco aberta: as chamadas podem levar segundos.
 */
@Component
public class GoogleWalletApi {

    static final String SCOPE = "https://www.googleapis.com/auth/wallet_object.issuer";
    public static final String SAVE_URL = "https://pay.google.com/gp/v/save/";
    private static final Logger log = LoggerFactory.getLogger(GoogleWalletApi.class);

    private final GoogleWalletProperties properties;
    private final JsonMapper json;
    private final Clock clock;
    private final HttpClient http;
    private volatile ServiceAccountCredentials credentials;
    private volatile String accessToken;
    private volatile Instant accessTokenExpiresAt = Instant.EPOCH;

    public GoogleWalletApi(GoogleWalletProperties properties, JsonMapper json, Clock clock) {
        this.properties = properties;
        this.json = json;
        this.clock = clock;
        this.http = HttpClient.newBuilder().connectTimeout(properties.connectTimeout()).build();
    }

    public boolean configured() {
        return properties.missing().isEmpty();
    }

    public String issuerId() {
        return properties.issuerId();
    }

    // ---------------- Classes e objetos ----------------

    /** Cria a classe; se já existir (409), atualiza os campos enviados (PATCH). */
    public void upsertClass(String classId, Map<String, Object> body) {
        upsert("loyaltyClass", classId, body);
    }

    /** Cria o objeto; se já existir (409), atualiza os campos enviados (PATCH). */
    public void upsertObject(String objectId, Map<String, Object> body) {
        upsert("loyaltyObject", objectId, body);
    }

    /** Para recursos que já existem no Google: PATCH direto; se não existir (404), cria. */
    public void patchOrInsertClass(String classId, Map<String, Object> body) {
        patchOrInsert("loyaltyClass", classId, body);
    }

    public void patchOrInsertObject(String objectId, Map<String, Object> body) {
        patchOrInsert("loyaltyObject", objectId, body);
    }

    private void patchOrInsert(String resource, String id, Map<String, Object> body) {
        Map<String, Object> patch = new LinkedHashMap<>(body);
        patch.remove("id");
        try {
            call("PATCH", "/walletobjects/v1/" + resource + "/" + encode(id), patch);
        } catch (WalletApiException e) {
            if (e.status() != 404) {
                throw e;
            }
            call("POST", "/walletobjects/v1/" + resource, body);
        }
    }

    /**
     * Acrescenta uma mensagem ao objeto (POST loyaltyObject/{id}/addMessage). Com {@code messageType=TEXT_AND_NOTIFY} o
     * Google tenta avisar o celular; o limite oficial é de 3 avisos por passe a cada 24 h (acima disso: QuotaExceeded).
     * A resposta de sucesso confirma só que o Google aceitou o pedido — não que o aviso foi exibido.
     */
    public void addObjectMessage(String objectId, Map<String, Object> message) {
        call("POST", "/walletobjects/v1/loyaltyObject/" + encode(objectId) + "/addMessage", Map.of("message", message));
    }

    public Optional<Map<String, Object>> getObject(String objectId) {
        try {
            return Optional.of(call("GET", "/walletobjects/v1/loyaltyObject/" + encode(objectId), null));
        } catch (WalletApiException e) {
            if (e.status() == 404) {
                return Optional.empty();
            }
            throw e;
        }
    }

    /**
     * Consulta somente leitura das classes de fidelidade do emissor (verificação de acesso; não cria nada).
     * Falha com 401/403/404 quando a conta de serviço não tem acesso ou o emissor não existe.
     */
    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> listClasses() {
        Map<String, Object> page = call("GET", "/walletobjects/v1/loyaltyClass?issuerId=" + encode(issuerId()), null);
        return page.get("resources") instanceof List<?> list ? (List<Map<String, Object>>) list : List.of();
    }

    private void upsert(String resource, String id, Map<String, Object> body) {
        try {
            call("POST", "/walletobjects/v1/" + resource, body);
        } catch (WalletApiException e) {
            if (e.status() != 409) {
                throw e;
            }
            Map<String, Object> patch = new LinkedHashMap<>(body);
            patch.remove("id");
            call("PATCH", "/walletobjects/v1/" + resource + "/" + encode(id), patch);
        }
    }

    // ---------------- JWT "Adicionar ao Google Wallet" ----------------

    /**
     * URL de salvamento que referencia um objeto já criado pela API (o JWT carrega só o id).
     * O Google não adiciona o mesmo objeto duas vezes à carteira.
     */
    public String saveUrl(String objectId) {
        ServiceAccountCredentials creds = credentials();
        Map<String, Object> claims = new LinkedHashMap<>();
        claims.put("iss", creds.clientEmail());
        claims.put("aud", "google");
        claims.put("typ", "savetowallet");
        claims.put("iat", clock.instant().getEpochSecond());
        claims.put("origins", properties.origins());
        claims.put("payload", Map.of("loyaltyObjects", List.of(Map.of("id", objectId))));
        return SAVE_URL + JwtSigner.sign(claims, creds.privateKey(), json);
    }

    // ---------------- HTTP ----------------

    @SuppressWarnings("unchecked")
    private Map<String, Object> call(String method, String path, Map<String, Object> body) {
        HttpRequest.Builder request = HttpRequest.newBuilder(URI.create(properties.apiBaseUrl() + path))
                .timeout(properties.requestTimeout())
                .header("Authorization", "Bearer " + token())
                .header("Accept", "application/json");
        if (body != null) {
            request.header("Content-Type", "application/json")
                    .method(method, HttpRequest.BodyPublishers.ofByteArray(json.writeValueAsBytes(body)));
        } else {
            request.method(method, HttpRequest.BodyPublishers.noBody());
        }
        HttpResponse<String> response = send(request.build());
        if (response.statusCode() == 401) {
            accessToken = null; // token revogado/expirado: será renovado na próxima tentativa
        }
        if (response.statusCode() / 100 != 2) {
            throw error(response);
        }
        String text = response.body();
        return text == null || text.isBlank() ? Map.of() : json.readValue(text, Map.class);
    }

    private HttpResponse<String> send(HttpRequest request) {
        try {
            return http.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (HttpTimeoutException e) {
            throw new WalletApiException(0, "Tempo esgotado ao chamar o Google Wallet.", true);
        } catch (IOException e) {
            throw new WalletApiException(0, "Falha de comunicação com o Google Wallet.", true);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new WalletApiException(0, "Chamada ao Google Wallet interrompida.", true);
        }
    }

    @SuppressWarnings("unchecked")
    private WalletApiException error(HttpResponse<String> response) {
        String message = "HTTP " + response.statusCode();
        try {
            Map<String, Object> bodyMap = json.readValue(response.body(), Map.class);
            if (bodyMap.get("error") instanceof Map<?, ?> err && err.get("message") instanceof String m) {
                message = message + ": " + m;
            }
        } catch (RuntimeException ignored) {
            // corpo não JSON: mantém só o código
        }
        message = message.length() > 300 ? message.substring(0, 300) : message;
        log.warn("Google Wallet respondeu {} ({})", response.statusCode(), message);
        return new WalletApiException(response.statusCode(), message, WalletApiException.isRetryableStatus(response.statusCode()));
    }

    /** Token OAuth em cache até 1 minuto antes de expirar. */
    @SuppressWarnings("unchecked")
    private synchronized String token() {
        Instant now = clock.instant();
        if (accessToken != null && now.isBefore(accessTokenExpiresAt.minusSeconds(60))) {
            return accessToken;
        }
        ServiceAccountCredentials creds = credentials();
        String tokenUri = properties.tokenUri() != null ? properties.tokenUri() : creds.tokenUri();
        Map<String, Object> claims = new LinkedHashMap<>();
        claims.put("iss", creds.clientEmail());
        claims.put("scope", SCOPE);
        claims.put("aud", tokenUri);
        claims.put("iat", now.getEpochSecond());
        claims.put("exp", now.getEpochSecond() + 3600);
        String form = "grant_type=" + encode("urn:ietf:params:oauth:grant-type:jwt-bearer") + "&assertion="
                + JwtSigner.sign(claims, creds.privateKey(), json);
        HttpResponse<String> response = send(HttpRequest.newBuilder(URI.create(tokenUri))
                .timeout(properties.requestTimeout())
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(form)).build());
        if (response.statusCode() / 100 != 2) {
            WalletApiException e = error(response);
            throw new WalletApiException(response.statusCode(), "Autenticação da conta de serviço recusada (" + e.getMessage() + ").",
                    WalletApiException.isRetryableStatus(response.statusCode()));
        }
        Map<String, Object> body = json.readValue(response.body(), Map.class);
        accessToken = (String) body.get("access_token");
        long expiresIn = body.get("expires_in") instanceof Number n ? n.longValue() : 3600;
        accessTokenExpiresAt = now.plusSeconds(expiresIn);
        return accessToken;
    }

    private ServiceAccountCredentials credentials() {
        ServiceAccountCredentials current = credentials;
        if (current == null) {
            if (properties.serviceAccountKeyFile() == null) {
                throw new WalletApiException(0, "Chave da conta de serviço não configurada.", false);
            }
            try {
                current = ServiceAccountCredentials.load(Path.of(properties.serviceAccountKeyFile()), json);
            } catch (IllegalStateException e) {
                throw new WalletApiException(0, e.getMessage(), false);
            }
            credentials = current;
        }
        return current;
    }

    private static String encode(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8);
    }
}
