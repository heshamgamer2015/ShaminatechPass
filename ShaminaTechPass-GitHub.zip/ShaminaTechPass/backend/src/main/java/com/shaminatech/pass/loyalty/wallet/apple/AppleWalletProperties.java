package com.shaminatech.pass.loyalty.wallet.apple;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Configuração da integração Apple Wallet. <b>Nenhum segredo fica no repositório</b>: certificado (.p12), senha,
 * certificado intermediário da Apple e segredo dos tokens vêm de application-credentials.yml (ignorado pelo Git)
 * ou de variáveis de ambiente.
 *
 * @param enabled                  liga a integração (padrão: desligada)
 * @param passTypeIdentifier       Pass Type ID registrado no Apple Developer (começa com "pass.")
 * @param teamIdentifier           Team ID da conta Apple Developer (10 caracteres)
 * @param certificateFile          caminho do .p12 com o certificado Pass Type ID e a chave privada (fora do repositório)
 * @param certificatePassword      senha do .p12
 * @param wwdrCertificateFile      caminho do certificado intermediário Apple WWDR G4 (AppleWWDRCAG4.cer)
 * @param webServiceBaseUrl        URL pública HTTPS do backend (o iPhone chama {base}/api/public/apple-wallet/v1/...)
 * @param allowHttpWebService      aceita http:// no web service (só para desenvolvimento, com o ajuste de desenvolvedor do iPhone)
 * @param authSecret               segredo (32+ caracteres) que deriva o token de autenticação de cada passe (HMAC)
 * @param apnsBaseUrl              servidor de notificações (padrão: produção da Apple; substituído nos testes)
 * @param supportName              nome do emissor exibido no verso do passe (exigência da Apple: quem responde ao usuário)
 * @param supportEmail             e-mail de suporte do emissor
 * @param supportPhone             telefone de suporte do emissor
 * @param supportAddress           endereço do emissor
 * @param connectTimeout           tempo máximo para conectar ao APNs
 * @param requestTimeout           tempo máximo de cada notificação
 * @param maxDevicesPerPass        limite de aparelhos registrados por passe (evita abuso)
 */
@ConfigurationProperties(prefix = "shaminatech.wallet.apple")
public record AppleWalletProperties(Boolean enabled, String passTypeIdentifier, String teamIdentifier, String certificateFile,
                                    String certificatePassword, String wwdrCertificateFile, String webServiceBaseUrl,
                                    Boolean allowHttpWebService, String authSecret, String apnsBaseUrl, String supportName,
                                    String supportEmail, String supportPhone, String supportAddress, Duration connectTimeout,
                                    Duration requestTimeout, Integer maxDevicesPerPass) {

    public static final String WEB_SERVICE_PATH = "/api/public/apple-wallet";

    public AppleWalletProperties {
        enabled = enabled != null && enabled;
        passTypeIdentifier = blankToNull(passTypeIdentifier);
        teamIdentifier = blankToNull(teamIdentifier);
        certificateFile = blankToNull(certificateFile);
        certificatePassword = certificatePassword == null ? "" : certificatePassword;
        wwdrCertificateFile = blankToNull(wwdrCertificateFile);
        webServiceBaseUrl = blankToNull(webServiceBaseUrl) == null ? null : webServiceBaseUrl.trim().replaceAll("/+$", "");
        allowHttpWebService = allowHttpWebService != null && allowHttpWebService;
        authSecret = blankToNull(authSecret);
        apnsBaseUrl = blankToNull(apnsBaseUrl) == null ? "https://api.push.apple.com" : apnsBaseUrl.trim().replaceAll("/+$", "");
        supportName = blankToNull(supportName);
        supportEmail = blankToNull(supportEmail);
        supportPhone = blankToNull(supportPhone);
        supportAddress = blankToNull(supportAddress);
        connectTimeout = connectTimeout == null ? Duration.ofSeconds(5) : connectTimeout;
        requestTimeout = requestTimeout == null ? Duration.ofSeconds(15) : requestTimeout;
        maxDevicesPerPass = maxDevicesPerPass == null ? 10 : maxDevicesPerPass;
    }

    /** URL que vai no pass.json (webServiceURL): base + caminho dos endpoints oficiais. */
    public String webServiceUrl() {
        return webServiceBaseUrl == null ? null : webServiceBaseUrl + WEB_SERVICE_PATH;
    }

    /** Itens que faltam para a integração funcionar (vazio = configurada). */
    public List<String> missing() {
        List<String> list = new ArrayList<>();
        if (!enabled) {
            list.add("Integração desligada (shaminatech.wallet.apple.enabled=false).");
        }
        if (passTypeIdentifier == null || !passTypeIdentifier.startsWith("pass.")) {
            list.add("Pass Type ID (começa com \"pass.\") não configurado.");
        }
        if (teamIdentifier == null || !teamIdentifier.matches("[A-Z0-9]{10}")) {
            list.add("Team ID da conta Apple Developer não configurado.");
        }
        if (certificateFile == null) {
            list.add("Certificado Pass Type ID (.p12) não configurado.");
        }
        if (wwdrCertificateFile == null) {
            list.add("Certificado intermediário Apple WWDR G4 não configurado.");
        }
        if (webServiceBaseUrl == null) {
            list.add("URL pública do backend para atualização dos cartões não configurada.");
        } else if (!webServiceBaseUrl.startsWith("https://") && !allowHttpWebService) {
            list.add("A Apple exige HTTPS no serviço de atualização dos cartões (URL pública sem https://).");
        }
        if (authSecret == null || authSecret.length() < 32) {
            list.add("Segredo dos tokens de autenticação (32+ caracteres) não configurado.");
        }
        if (supportName == null || (supportEmail == null && supportPhone == null)) {
            list.add("Contato de suporte do emissor (nome e e-mail ou telefone) não configurado: a Apple exige essa informação no cartão.");
        }
        return list;
    }

    /**
     * Itens que faltam para gerar um passe <b>offline</b> de homologação local (sem {@code webServiceURL} nem
     * {@code authenticationToken}): só certificado, identificadores e contato de suporte. Não substitui
     * {@link #missing()}, que continua exigindo HTTPS público e segredo para os passes atualizáveis.
     */
    public List<String> missingForOfflinePass() {
        List<String> list = new ArrayList<>();
        if (passTypeIdentifier == null || !passTypeIdentifier.startsWith("pass.")) {
            list.add("Pass Type ID (começa com \"pass.\") não configurado.");
        }
        if (teamIdentifier == null || !teamIdentifier.matches("[A-Z0-9]{10}")) {
            list.add("Team ID da conta Apple Developer não configurado.");
        }
        if (certificateFile == null) {
            list.add("Certificado Pass Type ID (.p12) não configurado.");
        }
        if (wwdrCertificateFile == null) {
            list.add("Certificado intermediário Apple WWDR G4 não configurado.");
        }
        if (supportName == null || (supportEmail == null && supportPhone == null)) {
            list.add("Contato de suporte do emissor (nome e e-mail ou telefone) não configurado: a Apple exige essa informação no cartão.");
        }
        return list;
    }

    /** Nunca mostra a senha do .p12 nem o segredo dos tokens (o toString padrão do record mostraria). */
    @Override
    public String toString() {
        return "AppleWalletProperties[enabled=" + enabled + ", passTypeIdentifier=" + passTypeIdentifier + ", teamIdentifier="
                + teamIdentifier + ", certificateFile=" + certificateFile + ", certificatePassword=<oculta>, wwdrCertificateFile="
                + wwdrCertificateFile + ", webServiceBaseUrl=" + webServiceBaseUrl + ", authSecret=<oculto>]";
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
