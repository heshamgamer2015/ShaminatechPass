package com.shaminatech.pass.loyalty.wallet;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Clock;
import java.time.Instant;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.common.web.PageResponse;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardCodes;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.card.LoyaltyCardRepository;
import com.shaminatech.pass.loyalty.wallet.WalletPass.Provider;
import com.shaminatech.pass.loyalty.wallet.WalletPass.SyncStatus;
import com.shaminatech.pass.loyalty.wallet.apple.AppleDeviceRegistrationRepository;
import com.shaminatech.pass.loyalty.wallet.apple.AppleWalletGateway;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletApi;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletProperties;
import com.shaminatech.pass.membership.Permission;
import com.shaminatech.pass.security.CurrentUser;
import com.shaminatech.pass.tenant.TenantAccessService;

/** Operações de carteira digital no painel do estabelecimento e na página pública do consumidor. */
@Service
public class WalletService {

    private static final SecureRandom RANDOM = new SecureRandom();

    private final TenantAccessService tenantAccess;
    private final WalletPassRepository passes;
    private final WalletLinkRepository links;
    private final LoyaltyCardRepository cards;
    private final GoogleWalletApi api;
    private final GoogleWalletProperties properties;
    private final WalletSyncListener sync;
    private final AuditService audit;
    private final Clock clock;
    private final String publicPageBaseUrl;
    private final AppleWalletGateway apple;
    private final AppleDeviceRegistrationRepository appleDevices;
    private final java.time.Duration linkValidity;

    public WalletService(TenantAccessService tenantAccess, WalletPassRepository passes, WalletLinkRepository links,
                         LoyaltyCardRepository cards, GoogleWalletApi api, GoogleWalletProperties properties,
                         WalletSyncListener sync, AuditService audit, Clock clock,
                         @org.springframework.beans.factory.annotation.Value("${shaminatech.wallet.public-page-base-url:http://localhost:4203}")
                         String publicPageBaseUrl, AppleWalletGateway apple, AppleDeviceRegistrationRepository appleDevices) {
        this.tenantAccess = tenantAccess;
        this.passes = passes;
        this.links = links;
        this.cards = cards;
        this.api = api;
        this.properties = properties;
        this.sync = sync;
        this.audit = audit;
        this.clock = clock;
        this.publicPageBaseUrl = publicPageBaseUrl.replaceAll("/+$", "");
        this.apple = apple;
        this.appleDevices = appleDevices;
        this.linkValidity = properties.linkValidity();
    }

    // ---------------- Respostas ----------------

    public record IntegrationStatus(String provider, boolean enabled, boolean configured, List<String> missing,
                                    Map<SyncStatus, Long> passes, List<String> notes, AppleStatus apple) {
    }

    /** Aviso exibido no painel quando o Apple Wallet está no modo offline de homologação local. */
    static final String OFFLINE_NOTE = "Modo de homologação local: o cartão Apple é emitido com os dados reais, mas não se "
            + "atualiza sozinho no iPhone (falta a URL pública HTTPS do serviço de atualização).";

    /** Situação da integração Apple Wallet (mesmo formato da do Google). */
    public record AppleStatus(boolean enabled, boolean configured, List<String> missing, List<String> notes) {
    }

    public record PassView(Long id, Long cardId, String cardCode, String consumerName, String programName, Provider provider,
                           SyncStatus status, String remoteState, int attempts, Instant lastSyncedAt, Instant lastAttemptAt,
                           Instant nextAttemptAt, String lastError, Integer lastErrorStatus, boolean retryAllowed) {
    }

    public record LinkView(Long id, Instant createdAt, Instant expiresAt, Instant revokedAt, Instant lastUsedAt, int useCount,
                           boolean usable) {
    }

    /** {@code pass}/{@code available}/{@code missing}: Google Wallet. {@code apple*}: Apple Wallet. */
    public record CardWallet(PassView pass, List<LinkView> links, boolean available, List<String> missing, PassView apple,
                             long appleDevices, boolean appleAvailable, List<String> appleMissing) {
    }

    /** O endereço completo só aparece nesta resposta: o banco guarda apenas o resumo (hash) do token. */
    public record CreatedLink(String url, Instant expiresAt, CardWallet wallet) {
    }

    /**
     * {@code status}/{@code message}/{@code saveUrl}: situação geral do link e do Google Wallet (formato da Etapa 3).
     * {@code google}/{@code apple}: opções disponíveis para o consumidor escolher (null = carteira indisponível).
     */
    public record PublicPass(String establishmentName, String programName, ProgramType programType, String consumerFirstName,
                             String status, String message, String saveUrl, Instant linkExpiresAt, WalletOption google,
                             WalletOption apple) {
    }

    /** READY: pode adicionar ({@code url}: endereço do Google ou caminho do .pkpass). PREPARING: tente em instantes. */
    public record WalletOption(String status, String url) {
    }

    // ---------------- Painel ----------------

    @Transactional(readOnly = true)
    public IntegrationStatus status(Long establishmentId) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        Map<SyncStatus, Long> counts = new EnumMap<>(SyncStatus.class);
        for (Object[] row : passes.countByStatus(establishmentId)) {
            counts.put((SyncStatus) row[0], (Long) row[1]);
        }
        return new IntegrationStatus("GOOGLE_WALLET", properties.enabled(), api.configured(), properties.missing(), counts, List.of(
                "Enquanto a conta emissora estiver em modo de demonstração, só contas de teste cadastradas no Google Pay & Wallet "
                        + "Console conseguem salvar o cartão, e o passe aparece com a indicação [TEST ONLY].",
                "Atualizações de saldo podem levar alguns minutos (o Google informa até 24 h) para aparecer no celular.",
                "O saldo oficial é sempre o do Pass; o Google Wallet exibe uma cópia."),
                new AppleStatus(apple.enabled(), apple.issuable(), apple.offlineMode() ? List.of(OFFLINE_NOTE) : apple.missing(), List.of(
                        "O Apple Wallet atualiza o cartão quando o iPhone recebe o aviso da Apple e baixa a versão nova do Pass.",
                        "Cartão bloqueado continua visível no iPhone com a situação \"Bloqueado\"; vencido aparece como expirado; "
                                + "cancelado aparece como anulado.",
                        "O saldo oficial é sempre o do Pass; o Apple Wallet exibe uma cópia.")));
    }

    @Transactional(readOnly = true)
    public PageResponse<PassView> list(Long establishmentId, SyncStatus status, Pageable pageable) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        List<SyncStatus> filter = status == null ? List.copyOf(EnumSet.allOf(SyncStatus.class)) : List.of(status);
        var page = passes.findInEstablishment(establishmentId, filter, pageable);
        return PageResponse.of(page, p -> view(p, cards.findInEstablishment(establishmentId, p.getCardId()).orElse(null)));
    }

    @Transactional(readOnly = true)
    public CardWallet cardWallet(Long establishmentId, Long cardId) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        LoyaltyCard card = card(establishmentId, cardId);
        return cardWallet(card);
    }

    /**
     * Emite (ou reutiliza) os passes do cartão em cada carteira configurada (Google e/ou Apple) e cria um link de
     * distribuição — o consumidor escolhe a carteira do seu celular na página do link. Trava o cartão: chamadas
     * simultâneas nunca criam dois passes (também garantido pela restrição única cartão+provedor).
     */
    @Transactional
    public CreatedLink createLink(Long establishmentId, Long cardId) {
        tenantAccess.require(establishmentId, Permission.CARDS_MANAGE);
        return issueLink(establishmentId, cardId, CurrentUser.require().getId());
    }

    /** Alguma carteira digital (Google ou Apple) está configurada? */
    public boolean anyWalletConfigured() {
        return api.configured() || apple.issuable();
    }

    /** Carteiras disponíveis para os consumidores (para a página pública destacar a do aparelho). */
    public List<String> availableWallets() {
        List<String> list = new java.util.ArrayList<>();
        if (api.configured()) {
            list.add(Provider.GOOGLE_WALLET.name());
        }
        if (apple.issuable()) {
            list.add(Provider.APPLE_WALLET.name());
        }
        return list;
    }

    /**
     * Autocadastro público: emite os passes do cartão recém-criado e um link de distribuição, sem usuário autenticado.
     * Participa da transação do cadastro; a comunicação com o Google acontece só depois do commit. Devolve null se
     * nenhuma carteira estiver configurada.
     */
    @Transactional
    public CreatedLink createLinkForSignup(Long establishmentId, Long cardId) {
        return anyWalletConfigured() ? issueLink(establishmentId, cardId, null) : null;
    }

    private CreatedLink issueLink(Long establishmentId, Long cardId, Long actorUserId) {
        boolean google = api.configured();
        boolean appleReady = apple.issuable();
        if (!google && !appleReady) {
            throw new ApiException(HttpStatus.CONFLICT, "WALLET_NOT_CONFIGURED",
                    "Nenhuma carteira digital (Google Wallet ou Apple Wallet) está configurada pela ShaminaTech.");
        }
        LoyaltyCard card = cards.lockInEstablishment(establishmentId, cardId)
                .orElseThrow(() -> ApiException.notFound("Cartão não encontrado."));
        if (card.getStatus() == CardStatus.CANCELLED) {
            throw ApiException.state("CARD_CANCELLED", "Cartão cancelado não pode ser adicionado à carteira.");
        }
        if (!card.getProgram().getType().isOperational()) {
            throw ApiException.rule("PROGRAM_NOT_OPERATIONAL", "Este tipo de programa ainda não está operacional.", null);
        }
        Instant now = clock.instant();
        WalletPass googlePass = google ? ensurePass(establishmentId, cardId, Provider.GOOGLE_WALLET,
                api.issuerId() + ".stp_card_" + cardId + "_" + randomHex(5), now) : null;
        // Serial Apple: aleatório e estável (não revela o id interno do cartão).
        WalletPass applePass = appleReady ? ensurePass(establishmentId, cardId, Provider.APPLE_WALLET, "stp" + randomHex(16), now) : null;
        WalletPass main = googlePass != null ? googlePass : applePass;
        if (main.getSyncStatus() == SyncStatus.INVALIDATED) {
            throw ApiException.state("WALLET_PASS_INVALIDATED", "O passe deste cartão foi inativado.");
        }
        String token = randomHex(16);
        WalletLink link = links.save(new WalletLink(establishmentId, main.getId(), cardId, sha256(token),
                now.plus(linkValidity), actorUserId));
        audit.record(AuditAction.WALLET_LINK_CREATED, establishmentId, "WALLET_LINK", link.getId(), "card=" + cardId);
        List<Long> pending = new java.util.ArrayList<>();
        for (WalletPass p : new WalletPass[] {googlePass, applePass}) {
            if (p != null && p.getSyncStatus() != SyncStatus.SYNCED && p.getSyncStatus() != SyncStatus.INVALIDATED) {
                pending.add(p.getId());
            }
        }
        sync.afterCommit(pending);
        return new CreatedLink(publicPageBaseUrl + "/carteira/" + token, link.getExpiresAt(), cardWallet(card));
    }

    private WalletPass ensurePass(Long establishmentId, Long cardId, Provider provider, String newExternalId, Instant now) {
        return passes.findByCardIdAndProvider(cardId, provider).orElseGet(() -> {
            WalletPass created = passes.save(new WalletPass(establishmentId, cardId, provider, newExternalId, now));
            audit.record(AuditAction.WALLET_PASS_CREATED, establishmentId, "WALLET_PASS", created.getId(),
                    "card=" + cardId + " provider=" + provider);
            return created;
        });
    }

    @Transactional
    public CardWallet retry(Long establishmentId, Long passId) {
        tenantAccess.require(establishmentId, Permission.CARDS_MANAGE);
        WalletPass pass = passes.findInEstablishment(establishmentId, passId)
                .orElseThrow(() -> ApiException.notFound("Passe não encontrado."));
        if (pass.getSyncStatus() == SyncStatus.INVALIDATED) {
            throw ApiException.state("WALLET_PASS_INVALIDATED", "O passe deste cartão foi inativado.");
        }
        if (pass.getSyncStatus() == SyncStatus.SYNCED) {
            throw ApiException.state("WALLET_ALREADY_SYNCED", "Este passe já está sincronizado.");
        }
        pass.retryNow(clock.instant());
        audit.record(AuditAction.WALLET_SYNC_RETRIED, establishmentId, "WALLET_PASS", passId, null);
        sync.afterCommit(List.of(passId));
        return cardWallet(card(establishmentId, pass.getCardId()));
    }

    @Transactional
    public CardWallet revokeLink(Long establishmentId, Long linkId) {
        tenantAccess.require(establishmentId, Permission.CARDS_MANAGE);
        WalletLink link = links.findInEstablishment(establishmentId, linkId)
                .orElseThrow(() -> ApiException.notFound("Link não encontrado."));
        link.revoke(clock.instant());
        audit.record(AuditAction.WALLET_LINK_REVOKED, establishmentId, "WALLET_LINK", linkId, null);
        return cardWallet(card(establishmentId, link.getCardId()));
    }

    // ---------------- Página pública ----------------

    /**
     * Abre o link do consumidor. Respostas iguais para token inexistente, expirado ou revogado (não revela qual).
     * Mostra só o necessário: estabelecimento, programa e primeiro nome — nunca telefone, e-mail ou saldo de outros.
     */
    @Transactional
    public PublicPass openLink(String token) {
        Instant now = clock.instant();
        if (token == null || !token.matches("^[0-9a-f]{32}$")) {
            throw invalidLink();
        }
        WalletLink link = links.findByTokenHash(sha256(token)).filter(l -> l.isUsable(now)).orElseThrow(WalletService::invalidLink);
        LoyaltyCard card = cards.findInEstablishment(link.getEstablishmentId(), link.getCardId()).orElseThrow(WalletService::invalidLink);
        if (!card.getProgram().getEstablishment().isActive()) {
            throw invalidLink();
        }
        link.used(now);
        String first = WalletSyncService.firstName(card.getConsumer().getFullName());
        String establishmentName = card.getProgram().getEstablishment().getName();
        String programName = card.getProgram().getName();
        ProgramType type = card.getProgram().getType();
        Instant expires = link.getExpiresAt();
        WalletPass googlePass = passes.findByCardIdAndProvider(card.getId(), Provider.GOOGLE_WALLET).orElse(null);
        WalletPass applePass = apple.issuable() ? passes.findByCardIdAndProvider(card.getId(), Provider.APPLE_WALLET).orElse(null) : null;
        boolean invalidated = (googlePass != null && googlePass.getSyncStatus() == SyncStatus.INVALIDATED)
                || (applePass != null && applePass.getSyncStatus() == SyncStatus.INVALIDATED);
        if (card.getStatus() == CardStatus.CANCELLED || invalidated) {
            return new PublicPass(establishmentName, programName, type, first, "UNAVAILABLE",
                    "Este cartão não está mais disponível. Fale com o estabelecimento.", null, expires, null, null);
        }
        WalletOption appleOption = applePass == null ? null : new WalletOption("READY", "/api/public/wallet-links/" + token + "/apple");
        if (googlePass == null) {
            return new PublicPass(establishmentName, programName, type, first, appleOption == null ? "UNAVAILABLE" : "READY",
                    appleOption == null ? "Nenhuma carteira digital disponível para este cartão." : null, null, expires, null, appleOption);
        }
        if (googlePass.synced() == 0) {
            return new PublicPass(establishmentName, programName, type, first, "PREPARING",
                    "Seu cartão está sendo preparado. Tente novamente em alguns instantes.", null, expires,
                    new WalletOption("PREPARING", null), appleOption);
        }
        String saveUrl = api.saveUrl(googlePass.getExternalId());
        return new PublicPass(establishmentName, programName, type, first, "READY", null, saveUrl, expires,
                new WalletOption("READY", saveUrl), appleOption);
    }

    /**
     * Endereço público do link (para o QR Code mostrado no balcão ou no computador), só se o link ainda vale.
     * Não conta como acesso e não revela nada além do próprio endereço.
     */
    @Transactional(readOnly = true)
    public String publicLinkUrl(String token) {
        Instant now = clock.instant();
        if (token == null || !token.matches("^[0-9a-f]{32}$")) {
            throw invalidLink();
        }
        WalletLink link = links.findByTokenHash(sha256(token)).filter(l -> l.isUsable(now)).orElseThrow(WalletService::invalidLink);
        LoyaltyCard card = cards.findInEstablishment(link.getEstablishmentId(), link.getCardId()).orElseThrow(WalletService::invalidLink);
        if (!card.getProgram().getEstablishment().isActive() || card.getStatus() == CardStatus.CANCELLED) {
            throw invalidLink();
        }
        return publicPageBaseUrl + "/carteira/" + token;
    }

    /**
     * Valida o link para baixar o .pkpass (mesmas regras do link: expira, pode ser revogado, cartão cancelado não é
     * entregue). Devolve o id do passe Apple; a geração do arquivo acontece depois, fora da transação.
     */
    @Transactional
    public Long appleDownload(String token) {
        Instant now = clock.instant();
        if (token == null || !token.matches("^[0-9a-f]{32}$") || !apple.issuable()) {
            throw invalidLink();
        }
        WalletLink link = links.findByTokenHash(sha256(token)).filter(l -> l.isUsable(now)).orElseThrow(WalletService::invalidLink);
        LoyaltyCard card = cards.findInEstablishment(link.getEstablishmentId(), link.getCardId()).orElseThrow(WalletService::invalidLink);
        if (!card.getProgram().getEstablishment().isActive() || card.getStatus() == CardStatus.CANCELLED) {
            throw invalidLink();
        }
        WalletPass pass = passes.findByCardIdAndProvider(card.getId(), Provider.APPLE_WALLET)
                .filter(p -> p.getSyncStatus() != SyncStatus.INVALIDATED).orElseThrow(WalletService::invalidLink);
        link.used(now);
        return pass.getId();
    }

    // ---------------- Apoio ----------------

    private CardWallet cardWallet(LoyaltyCard card) {
        WalletPass pass = passes.findByCardIdAndProvider(card.getId(), Provider.GOOGLE_WALLET).orElse(null);
        Instant now = clock.instant();
        List<LinkView> linkViews = links.findByCard(card.getEstablishmentId(), card.getId()).stream()
                .map(l -> new LinkView(l.getId(), l.getCreatedAt(), l.getExpiresAt(), l.getRevokedAt(), l.getLastUsedAt(),
                        l.getUseCount(), l.isUsable(now)))
                .toList();
        WalletPass applePass = passes.findByCardIdAndProvider(card.getId(), Provider.APPLE_WALLET).orElse(null);
        return new CardWallet(pass == null ? null : view(pass, card), linkViews, api.configured(), properties.missing(),
                applePass == null ? null : view(applePass, card), applePass == null ? 0 : appleDevices.countByWalletPassId(applePass.getId()),
                apple.issuable(), apple.offlineMode() ? List.of(OFFLINE_NOTE) : apple.missing());
    }

    private PassView view(WalletPass p, LoyaltyCard card) {
        boolean retry = p.getSyncStatus() == SyncStatus.FAILED || (p.getSyncStatus() == SyncStatus.PENDING && p.getAttempts() > 0);
        return new PassView(p.getId(), p.getCardId(), card == null ? null : CardCodes.format(card.getCode()),
                card == null ? null : card.getConsumer().getFullName(), card == null ? null : card.getProgram().getName(),
                p.getProvider(), p.getSyncStatus(), p.getRemoteState(), p.getAttempts(), p.getLastSyncedAt(), p.getLastAttemptAt(),
                p.getNextAttemptAt(), p.getLastError(), p.getLastErrorStatus(), retry);
    }

    private LoyaltyCard card(Long establishmentId, Long cardId) {
        return cards.findInEstablishment(establishmentId, cardId).orElseThrow(() -> ApiException.notFound("Cartão não encontrado."));
    }

    private static ApiException invalidLink() {
        return new ApiException(HttpStatus.NOT_FOUND, "WALLET_LINK_INVALID",
                "Este link é inválido ou expirou. Peça um novo link ao estabelecimento.");
    }

    private static String randomHex(int bytes) {
        byte[] data = new byte[bytes];
        RANDOM.nextBytes(data);
        return HexFormat.of().formatHex(data);
    }

    static String sha256(String value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
