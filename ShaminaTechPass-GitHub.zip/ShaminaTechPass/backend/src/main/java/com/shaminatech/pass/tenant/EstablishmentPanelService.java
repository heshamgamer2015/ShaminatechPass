package com.shaminatech.pass.tenant;


import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditEventResponse;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.web.PageResponse;
import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.loyalty.LoyaltyDtos.PolicyView;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicy;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.membership.Permission;
import com.shaminatech.pass.tenant.TenantDtos.EstablishmentPanelResponse;
import com.shaminatech.pass.tenant.TenantDtos.UpdateEstablishmentRequest;

/** Operações do painel do estabelecimento. Cada método começa pela verificação de acesso ao tenant. */
@Service
public class EstablishmentPanelService {

    private final TenantAccessService tenantAccess;
    private final PolicyService policies;
    private final AuditService audit;

    public EstablishmentPanelService(TenantAccessService tenantAccess, PolicyService policies, AuditService audit) {
        this.tenantAccess = tenantAccess;
        this.policies = policies;
        this.audit = audit;
    }

    @Transactional(readOnly = true)
    public EstablishmentPanelResponse get(Long establishmentId) {
        return toPanel(tenantAccess.require(establishmentId, Permission.ESTABLISHMENT_VIEW));
    }

    @Transactional
    public EstablishmentPanelResponse update(Long establishmentId, UpdateEstablishmentRequest request) {
        TenantAccess access = tenantAccess.require(establishmentId, Permission.ESTABLISHMENT_EDIT);
        Establishment establishment = access.establishment();
        establishment.setName(request.name().trim());
        establishment.setContactEmail(blankToNull(request.contactEmail()));
        establishment.setContactPhone(blankToNull(request.contactPhone()));
        audit.record(AuditAction.ESTABLISHMENT_UPDATED, establishmentId, "ESTABLISHMENT", establishmentId, null);
        return toPanel(access);
    }

    @Transactional(readOnly = true)
    public PageResponse<AuditEventResponse> auditLog(Long establishmentId, Pageable pageable) {
        tenantAccess.require(establishmentId, Permission.AUDIT_VIEW);
        return audit.list(establishmentId, pageable);
    }

    private EstablishmentPanelResponse toPanel(TenantAccess access) {
        Establishment e = access.establishment();
        EstablishmentPolicy p = policies.of(e.getId());
        return new EstablishmentPanelResponse(e.getId(), e.getName(), e.getSlug(), e.getStatus(), e.getContactEmail(),
                e.getContactPhone(), access.membership().getRole(), access.permissions(),
                new PolicyView(p.getMaxActiveConsumers(), p.getAllowedProgramTypes(), p.getDefaultInactivityDays(), p.getTimeZone()));
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
