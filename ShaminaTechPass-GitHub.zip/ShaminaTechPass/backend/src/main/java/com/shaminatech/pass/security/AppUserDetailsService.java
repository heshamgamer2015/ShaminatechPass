package com.shaminatech.pass.security;

import java.time.Clock;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.shaminatech.pass.user.AppUserRepository;
import com.shaminatech.pass.user.EmailNormalizer;

@Service
public class AppUserDetailsService implements UserDetailsService {

    private final AppUserRepository users;
    private final Clock clock;

    public AppUserDetailsService(AppUserRepository users, Clock clock) {
        this.users = users;
        this.clock = clock;
    }

    /**
     * Sem @Transactional de propósito: a UsernameNotFoundException atravessaria o proxy
     * transacional e marcaria a transação do login como rollback-only, perdendo a auditoria.
     */
    @Override
    public UserDetails loadUserByUsername(String username) {
        return users.findByEmail(EmailNormalizer.normalize(username))
                .map(user -> AuthenticatedUser.from(user, clock.instant()))
                .orElseThrow(() -> new UsernameNotFoundException("Usuário não encontrado"));
    }
}
