package com.shaminatech.pass.loyalty.wallet;

import java.time.Instant;

import com.shaminatech.pass.common.persistence.BaseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Link de distribuição enviado ao consumidor para adicionar o cartão à carteira. O token (128 bits aleatórios)
 * aparece só uma vez, na criação; no banco fica apenas o SHA-256. Expira e pode ser revogado pela empresa.
 */
@Entity
@Table(name = "wallet_link",
        uniqueConstraints = @UniqueConstraint(name = "uk_wallet_link_token_hash", columnNames = "token_hash"),
        indexes = @Index(name = "idx_wallet_link_pass", columnList = "wallet_pass_id"))
public class WalletLink extends BaseEntity {

    @Column(name = "establishment_id", nullable = false)
    private Long establishmentId;

    @Column(name = "wallet_pass_id", nullable = false)
    private Long walletPassId;

    @Column(name = "card_id", nullable = false)
    private Long cardId;

    @Column(name = "token_hash", nullable = false, length = 64)
    private String tokenHash;

    @Column(name = "expires_at", nullable = false)
    private Instant expiresAt;

    @Column(name = "revoked_at")
    private Instant revokedAt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "last_used_at")
    private Instant lastUsedAt;

    @Column(name = "use_count", nullable = false)
    private int useCount;

    protected WalletLink() {
    }

    public WalletLink(Long establishmentId, Long walletPassId, Long cardId, String tokenHash, Instant expiresAt, Long createdBy) {
        this.establishmentId = establishmentId;
        this.walletPassId = walletPassId;
        this.cardId = cardId;
        this.tokenHash = tokenHash;
        this.expiresAt = expiresAt;
        this.createdBy = createdBy;
    }

    public boolean isUsable(Instant now) {
        return revokedAt == null && now.isBefore(expiresAt);
    }

    public void revoke(Instant now) {
        if (revokedAt == null) {
            revokedAt = now;
        }
    }

    public void used(Instant now) {
        lastUsedAt = now;
        useCount++;
    }

    public Long getEstablishmentId() { return establishmentId; }
    public Long getWalletPassId() { return walletPassId; }
    public Long getCardId() { return cardId; }
    public Instant getExpiresAt() { return expiresAt; }
    public Instant getRevokedAt() { return revokedAt; }
    public Instant getLastUsedAt() { return lastUsedAt; }
    public int getUseCount() { return useCount; }
}
