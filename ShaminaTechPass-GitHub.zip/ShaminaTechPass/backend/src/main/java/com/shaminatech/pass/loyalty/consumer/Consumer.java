package com.shaminatech.pass.loyalty.consumer;

import java.time.Instant;

import com.shaminatech.pass.common.persistence.BaseEntity;
import com.shaminatech.pass.common.persistence.EnumNameConverter;
import com.shaminatech.pass.establishment.Establishment;

import jakarta.persistence.Column;
import jakarta.persistence.Converter;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Consumidor (cliente final) de um estabelecimento. Cada estabelecimento tem seu próprio cadastro:
 * a mesma pessoa em duas empresas são dois registros independentes (isolamento por tenant).
 * <p>
 * LGPD: guarda apenas o necessário para o programa (nome, telefone e, opcionalmente, e-mail e um código
 * próprio da empresa). Não há CPF, endereço nem data de nascimento. O registro de quando a empresa
 * confirmou a ciência do cliente sobre o programa fica em {@code privacy_acknowledged_at}.
 */
@Entity
@Table(name = "consumer",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_consumer_establishment_phone", columnNames = {"establishment_id", "phone"}),
                @UniqueConstraint(name = "uk_consumer_establishment_email", columnNames = {"establishment_id", "email"}),
                @UniqueConstraint(name = "uk_consumer_establishment_ref", columnNames = {"establishment_id", "external_ref"})},
        indexes = @Index(name = "idx_consumer_establishment_status", columnList = "establishment_id, status"))
public class Consumer extends BaseEntity {

    public enum Status {
        ACTIVE, INACTIVE;

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<Status> {
            public JpaConverter() {
                super(Status.class);
            }
        }
    }

    /** Origem do cadastro: PANEL (empresa) ou PUBLIC_QR (o próprio consumidor, pelo QR Code de cadastro). */
    public enum Source {
        PANEL, PUBLIC_QR;

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<Source> {
            public JpaConverter() {
                super(Source.class);
            }
        }
    }

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "establishment_id", nullable = false, foreignKey = @ForeignKey(name = "fk_consumer_establishment"))
    private Establishment establishment;

    @Column(name = "full_name", nullable = false, length = 150)
    private String fullName;

    /** Somente dígitos (DDD + número, opcionalmente com DDI). */
    @Column(nullable = false, length = 15)
    private String phone;

    @Column(length = 254)
    private String email;

    /** Código opcional usado pela própria empresa (ex.: número no sistema de caixa). */
    @Column(name = "external_ref", length = 40)
    private String externalRef;

    @Column(nullable = false, length = 20)
    private Status status = Status.ACTIVE;

    @Column(name = "status_changed_at")
    private Instant statusChangedAt;

    @Column(nullable = false, length = 20)
    private Source source = Source.PANEL;

    @Column(name = "privacy_acknowledged_at", nullable = false)
    private Instant privacyAcknowledgedAt;

    @Column(name = "marketing_opt_in", nullable = false)
    private boolean marketingOptIn;

    protected Consumer() {
    }

    public Consumer(Establishment establishment, String fullName, String phone, Instant privacyAcknowledgedAt) {
        this.establishment = establishment;
        this.fullName = fullName;
        this.phone = phone;
        this.privacyAcknowledgedAt = privacyAcknowledgedAt;
    }

    /** Cadastro feito pelo próprio consumidor na página pública (ciência da privacidade dada por ele). */
    public static Consumer selfRegistered(Establishment establishment, String fullName, String phone, Instant now) {
        Consumer consumer = new Consumer(establishment, fullName, phone, now);
        consumer.source = Source.PUBLIC_QR;
        return consumer;
    }

    public boolean isActive() {
        return status == Status.ACTIVE;
    }

    public void changeStatus(Status status, Instant now) {
        this.status = status;
        this.statusChangedAt = now;
    }

    public Establishment getEstablishment() {
        return establishment;
    }

    public Long getEstablishmentId() {
        return establishment.getId();
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getExternalRef() {
        return externalRef;
    }

    public void setExternalRef(String externalRef) {
        this.externalRef = externalRef;
    }

    public Status getStatus() {
        return status;
    }

    public Instant getStatusChangedAt() {
        return statusChangedAt;
    }

    public Source getSource() {
        return source;
    }

    public Instant getPrivacyAcknowledgedAt() {
        return privacyAcknowledgedAt;
    }

    public boolean isMarketingOptIn() {
        return marketingOptIn;
    }

    public void setMarketingOptIn(boolean marketingOptIn) {
        this.marketingOptIn = marketingOptIn;
    }
}
