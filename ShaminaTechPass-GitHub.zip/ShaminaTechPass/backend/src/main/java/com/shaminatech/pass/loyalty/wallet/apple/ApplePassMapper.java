package com.shaminatech.pass.loyalty.wallet.apple;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;

/**
 * Monta o {@code pass.json} no estilo {@code storeCard} — o estilo oficial da Apple para cartões de fidelidade,
 * pontos e descontos. Disposição (fixa pela Apple): cabeçalho (situação), campo principal (saldo), campos secundários
 * e auxiliares (no máximo 4 somados, por causa do QR Code quadrado) e o verso, sem limite de campos.
 * <p>
 * Estados: ativo e bloqueado continuam válidos (o bloqueado aparece como "Bloqueado" no cabeçalho e no verso, e
 * o backend recusa qualquer movimentação); vencido usa {@code expirationDate} no passado (o Wallet mostra como
 * expirado); cancelado e concluído usam {@code voided} (o Wallet mostra como anulado).
 */
public final class ApplePassMapper {

    /** Dados oficiais do cartão para montar o passe (sem telefone, e-mail ou nome completo do consumidor). */
    public record PassData(String serialNumber, String passTypeIdentifier, String teamIdentifier, String webServiceUrl,
                           String authenticationToken, String establishmentName, String programName, String brandColor,
                           String textColor, CardStatus status, ProgramType type, BigDecimal balance, Integer stampsRequired,
                           String consumerFirstName, String displayCode, String barcodeValue, Instant expiresAt,
                           String validUntilText, String nextBenefitExpiryText, String cardMessage, String rewardInfo,
                           String programDescription, String establishmentEmail, String establishmentPhone,
                           String issuerName, String issuerEmail, String issuerPhone, String issuerAddress) {
    }

    private ApplePassMapper() {
    }

    /** Situação exibida no cabeçalho do passe. */
    public static String situation(CardStatus status) {
        return switch (status) {
            case ACTIVE -> "Ativo";
            case SUSPENDED -> "Bloqueado";
            case EXPIRED -> "Vencido";
            case COMPLETED -> "Concluído";
            case CANCELLED -> "Cancelado";
        };
    }

    /** Estado registrado no painel para o passe Apple. */
    public static String remoteState(CardStatus status) {
        return switch (status) {
            case ACTIVE -> "ACTIVE";
            case SUSPENDED -> "BLOCKED";
            case EXPIRED -> "EXPIRED";
            case COMPLETED, CANCELLED -> "VOIDED";
        };
    }

    public static boolean voided(CardStatus status) {
        return status == CardStatus.CANCELLED || status == CardStatus.COMPLETED;
    }

    public static Map<String, Object> passJson(PassData d) {
        Map<String, Object> pass = new LinkedHashMap<>();
        pass.put("formatVersion", 1);
        pass.put("passTypeIdentifier", d.passTypeIdentifier());
        pass.put("teamIdentifier", d.teamIdentifier());
        pass.put("serialNumber", d.serialNumber());
        pass.put("organizationName", truncate(d.establishmentName(), 60));
        pass.put("description", truncate("Cartão fidelidade " + d.programName() + " — " + d.establishmentName(), 120));
        pass.put("logoText", truncate(d.establishmentName(), 30));
        pass.put("backgroundColor", rgb(d.brandColor(), "#F43F5E"));
        pass.put("foregroundColor", rgb(d.textColor(), "#FFFFFF"));
        pass.put("labelColor", rgb(d.textColor(), "#FFFFFF"));
        pass.put("sharingProhibited", true); // cartão pessoal
        if (d.webServiceUrl() != null) {
            pass.put("webServiceURL", d.webServiceUrl());
            pass.put("authenticationToken", d.authenticationToken());
        }
        if (voided(d.status())) {
            pass.put("voided", true);
        } else if (d.expiresAt() != null) {
            // Validade por inatividade: renovada só quando o estabelecimento registra uma movimentação legítima.
            pass.put("expirationDate", DateTimeFormatter.ISO_INSTANT.format(d.expiresAt()));
        }
        Map<String, Object> barcode = new LinkedHashMap<>();
        barcode.put("format", "PKBarcodeFormatQR");
        barcode.put("message", d.barcodeValue());
        barcode.put("messageEncoding", "iso-8859-1");
        barcode.put("altText", d.displayCode());
        pass.put("barcodes", List.of(barcode));
        pass.put("storeCard", storeCard(d));
        return pass;
    }

    private static Map<String, Object> storeCard(PassData d) {
        Map<String, Object> card = new LinkedHashMap<>();
        card.put("headerFields", List.of(field("situacao", "SITUAÇÃO", situation(d.status()), "Situação do cartão: %@")));
        card.put("primaryFields", List.of(balanceField(d)));
        card.put("secondaryFields", List.of(
                field("programa", "PROGRAMA", truncate(d.programName(), 40), null),
                field("cliente", "CLIENTE", truncate(d.consumerFirstName(), 20), null)));
        List<Map<String, Object>> auxiliary = new ArrayList<>();
        if (!voided(d.status()) && d.validUntilText() != null) {
            auxiliary.add(field("validade", "VÁLIDO ATÉ", d.validUntilText(), "Validade renovada: %@"));
        }
        if (d.nextBenefitExpiryText() != null && !voided(d.status())) {
            auxiliary.add(field("beneficios", "PRÓXIMO VENCIMENTO", d.nextBenefitExpiryText(), null));
        }
        card.put("auxiliaryFields", auxiliary);
        card.put("backFields", backFields(d));
        return card;
    }

    private static Map<String, Object> balanceField(PassData d) {
        Map<String, Object> field = new LinkedHashMap<>();
        field.put("key", "saldo");
        field.put("changeMessage", "Saldo atualizado: %@");
        switch (d.type()) {
            case POINTS -> {
                field.put("label", "PONTOS");
                field.put("value", d.balance().intValue());
            }
            case CASHBACK -> {
                field.put("label", "CASHBACK");
                field.put("value", d.balance().setScale(2, java.math.RoundingMode.HALF_UP));
                field.put("currencyCode", "BRL");
            }
            case STAMPS -> {
                field.put("label", "CARIMBOS");
                field.put("value", d.balance().intValue() + " de " + d.stampsRequired());
            }
            default -> {
                field.put("label", "NÍVEL");
                field.put("value", "—");
            }
        }
        return field;
    }

    private static List<Map<String, Object>> backFields(PassData d) {
        List<Map<String, Object>> back = new ArrayList<>();
        if (d.status() == CardStatus.SUSPENDED) {
            back.add(field("aviso", "Cartão bloqueado",
                    "Este cartão está temporariamente bloqueado pelo estabelecimento. Procure a loja para reativá-lo.", null));
        } else if (d.status() == CardStatus.EXPIRED) {
            back.add(field("aviso", "Cartão vencido",
                    "Este cartão venceu por falta de movimentação. Procure o estabelecimento para reativá-lo.", null));
        } else if (d.status() == CardStatus.CANCELLED) {
            back.add(field("aviso", "Cartão cancelado", "Este cartão foi cancelado pelo estabelecimento.", null));
        } else if (d.status() == CardStatus.COMPLETED) {
            back.add(field("aviso", "Cartão concluído", "Todos os carimbos deste cartão foram utilizados.", null));
        }
        back.add(field("codigo", "Código do cartão", d.displayCode(), null));
        if (d.validUntilText() != null && !voided(d.status())) {
            back.add(field("regra", "Validade",
                    "Válido até " + d.validUntilText() + ". A validade é renovada a cada compra registrada pelo estabelecimento.", null));
        }
        if (d.rewardInfo() != null) {
            back.add(field("recompensa", "Recompensa", d.rewardInfo(), null));
        }
        if (d.cardMessage() != null) {
            back.add(field("mensagem", "Mensagem", d.cardMessage(), null));
        }
        if (d.programDescription() != null) {
            back.add(field("sobre", "Sobre o programa", d.programDescription(), null));
        }
        String establishmentContact = join(d.establishmentPhone(), d.establishmentEmail());
        back.add(field("estabelecimento", d.establishmentName(),
                establishmentContact == null ? "Dúvidas sobre o saldo: fale com o estabelecimento."
                        : "Dúvidas sobre o saldo: " + establishmentContact, null));
        String issuer = join(d.issuerName(), d.issuerAddress(), d.issuerPhone(), d.issuerEmail());
        if (issuer != null) {
            back.add(field("emissor", "Emissão do cartão digital", issuer
                    + ". O saldo oficial é o registrado pelo estabelecimento no ShaminaTech Pass.", null));
        }
        return back;
    }

    private static Map<String, Object> field(String key, String label, Object value, String changeMessage) {
        Map<String, Object> field = new LinkedHashMap<>();
        field.put("key", key);
        field.put("label", label);
        field.put("value", value == null ? "" : value);
        if (changeMessage != null) {
            field.put("changeMessage", changeMessage);
        }
        return field;
    }

    /** "#RRGGBB" → "rgb(r, g, b)" (formato do pass.json). */
    static String rgb(String hex, String fallback) {
        String value = hex == null || !hex.matches("#[0-9A-Fa-f]{6}") ? fallback : hex;
        int r = Integer.parseInt(value.substring(1, 3), 16);
        int g = Integer.parseInt(value.substring(3, 5), 16);
        int b = Integer.parseInt(value.substring(5, 7), 16);
        return String.format(Locale.ROOT, "rgb(%d, %d, %d)", r, g, b);
    }

    private static String join(String... parts) {
        List<String> present = new ArrayList<>();
        for (String p : parts) {
            if (p != null && !p.isBlank()) {
                present.add(p.trim());
            }
        }
        return present.isEmpty() ? null : String.join(" · ", present);
    }

    private static String truncate(String value, int max) {
        return value == null || value.length() <= max ? value : value.substring(0, max);
    }
}
