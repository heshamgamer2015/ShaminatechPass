package com.shaminatech.pass.loyalty.notify;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/** Toda busca exige o estabelecimento: id de outra empresa resulta em "não encontrado". */
public interface EstablishmentLocationRepository extends JpaRepository<EstablishmentLocation, Long> {

    @Query("select l from EstablishmentLocation l where l.establishmentId = :establishmentId order by l.id")
    List<EstablishmentLocation> findByEstablishment(@Param("establishmentId") Long establishmentId);

    @Query("select l from EstablishmentLocation l where l.id = :id and l.establishmentId = :establishmentId")
    Optional<EstablishmentLocation> findInEstablishment(@Param("establishmentId") Long establishmentId, @Param("id") Long id);

    @Query("select count(l) from EstablishmentLocation l where l.establishmentId = :establishmentId")
    long countByEstablishment(@Param("establishmentId") Long establishmentId);
}
