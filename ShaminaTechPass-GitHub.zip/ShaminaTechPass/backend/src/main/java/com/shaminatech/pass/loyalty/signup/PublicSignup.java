package com.shaminatech.pass.loyalty.signup;

import java.time.Instant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Registro de cada autocadastro concluído pelo QR Code. Guarda só referências (nenhum dado pessoal) e o resumo
 * (SHA-256) do identificador aleatório que a página gera para cada envio: repetir o mesmo envio (clique duplo,
 * rede instável) devolve o mesmo cadastro em vez de recusá-lo como duplicidade.
 */
@Entity
@Table(name = "public_signup",
        uniqueConstraints = @UniqueConstraint(name = "uk_public_signup_request", columnNames = "request_key_hash"),
        indexes = {
                @Index(name = "idx_public_signup_link", columnList = "link_id, signed_up_at"),
                @Index(name = "idx_public_signup_establishment", columnList = "establishment_id, signed_up_at")})
public class PublicSignup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "establishment_id", nullable = false)
    private Long establishmentId;

    @Column(name = "link_id", nullable = false)
    private Long linkId;

    @Column(name = "program_id", nullable = false)
    private Long programId;

    @Column(name = "consumer_id", nullable = false)
    private Long consumerId;

    @Column(name = "card_id", nullable = false)
    private Long cardId;

    @Column(name = "request_key_hash", nullable = false, length = 64)
    private String requestKeyHash;

    @Column(name = "signed_up_at", nullable = false)
    private Instant signedUpAt;

    protected PublicSignup() {
    }

    public PublicSignup(Long establishmentId, Long linkId, Long programId, Long consumerId, Long cardId, String requestKeyHash,
                        Instant signedUpAt) {
        this.establishmentId = establishmentId;
        this.linkId = linkId;
        this.programId = programId;
        this.consumerId = consumerId;
        this.cardId = cardId;
        this.requestKeyHash = requestKeyHash;
        this.signedUpAt = signedUpAt;
    }

    public Long getId() { return id; }
    public Long getEstablishmentId() { return establishmentId; }
    public Long getLinkId() { return linkId; }
    public Long getProgramId() { return programId; }
    public Long getConsumerId() { return consumerId; }
    public Long getCardId() { return cardId; }
    public Instant getSignedUpAt() { return signedUpAt; }
}
