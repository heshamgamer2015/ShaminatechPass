package com.shaminatech.pass.membership;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/** Concessão de uma permissão a um papel de estabelecimento. */
@Entity
@Table(name = "role_permission",
        uniqueConstraints = @UniqueConstraint(name = "uk_role_permission", columnNames = {"role", "permission_code"}))
public class RolePermission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 30)
    private MembershipRole role;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "permission_code", nullable = false, foreignKey = @ForeignKey(name = "fk_role_permission_permission"))
    private PermissionEntity permission;

    protected RolePermission() {
    }

    public RolePermission(MembershipRole role, PermissionEntity permission) {
        this.role = role;
        this.permission = permission;
    }

    public MembershipRole getRole() {
        return role;
    }

    public PermissionEntity getPermission() {
        return permission;
    }
}
