package com.shaminatech.pass.common.persistence;

import org.hibernate.dialect.Dialect;
import org.hibernate.type.descriptor.converter.spi.BasicValueConverter;
import org.hibernate.type.descriptor.java.EnumJavaType;
import org.hibernate.type.descriptor.jdbc.JdbcType;

/**
 * Descritor de enum igual ao padrão do Hibernate, exceto por não gerar a restrição
 * {@code CHECK (coluna IN (...))} no DDL. Leitura, gravação e comparação continuam iguais.
 * Só os enums persistidos via {@link EnumNameConverter} recebem este descritor; restrições de outra natureza
 * (por exemplo {@code @Check} explícito) não são afetadas.
 */
public class EnumWithoutCheckJavaType<E extends Enum<E>> extends EnumJavaType<E> {

    public EnumWithoutCheckJavaType(Class<E> type) {
        super(type);
    }

    @Override
    public String getCheckCondition(String columnName, JdbcType jdbcType, BasicValueConverter<E, ?> converter, Dialect dialect) {
        return null;
    }
}
