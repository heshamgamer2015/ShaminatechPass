package com.shaminatech.pass.loyalty.notify;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Optional;

import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.Validity;

/**
 * Regras de elegibilidade e texto dos lembretes. Funções puras sobre a "fotografia" do cartão: o texto usa só dados
 * verdadeiros do cartão, e a chave de deduplicação muda quando a situação muda (ex.: compra renova a validade).
 * Nenhuma regra renova validade nem altera saldo.
 */
public final class ReminderRules {

    static final Duration DISPLAY_DEFAULT = Duration.ofDays(14);
    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("dd/MM");

    private ReminderRules() {
    }

    /** Dados do cartão no momento da avaliação. {@code cheapestReward*}: recompensa ativa mais barata (pontos). */
    public record CardSnapshot(Long cardId, CardStatus status, ProgramType type, String programName, String establishmentName,
                               BigDecimal available, Integer stampsRequired, String stampReward, int completedCycles,
                               Instant expiresAt, Instant lastMovementAt, Instant issuedAt, boolean consumerActive,
                               boolean marketingOptIn, BigDecimal cheapestRewardCost, String cheapestRewardName) {
    }

    public record Candidate(ReminderCategory category, String dedupKey, String header, String body, Instant displayUntil) {
    }

    /** Avalia uma categoria; vazio = não elegível. */
    public static Optional<Candidate> evaluate(ReminderCategory category, CardSnapshot c, NotificationSettings s, ZoneId zone,
                                               Instant now) {
        if (c.status() != CardStatus.ACTIVE || !c.consumerActive() || !c.expiresAt().isAfter(now) || !s.enabled(category)) {
            return Optional.empty();
        }
        if (category.requiresMarketingConsent() && !c.marketingOptIn()) {
            return Optional.empty();
        }
        return switch (category) {
            case EXPIRY -> expiry(c, s, zone, now);
            case NEAR_REWARD -> nearReward(c, s, now);
            case INACTIVITY -> inactivity(c, s, now);
        };
    }

    /** Dias de calendário (no fuso do estabelecimento) entre hoje e o último dia de validade. */
    static long daysLeft(Instant expiresAt, ZoneId zone, Instant now) {
        LocalDate lastDay = Validity.validUntilLocal(expiresAt, zone).toLocalDate();
        return ChronoUnit.DAYS.between(now.atZone(zone).toLocalDate(), lastDay);
    }

    private static Optional<Candidate> expiry(CardSnapshot c, NotificationSettings s, ZoneId zone, Instant now) {
        long days = daysLeft(c.expiresAt(), zone, now);
        if (days < 0 || days > s.getExpiryDaysBefore()) {
            return Optional.empty();
        }
        String lastDay = Validity.validUntilLocal(c.expiresAt(), zone).format(DAY);
        String when = days == 0 ? "vence hoje" : days == 1 ? "vence amanhã (" + lastDay + ")" : "vence em " + days + " dias (" + lastDay + ")";
        String body = "Seu cartão " + c.programName() + " " + when + ". Uma compra registrada em " + c.establishmentName()
                + " renova a validade.";
        return Optional.of(new Candidate(ReminderCategory.EXPIRY, "EXPIRY:" + c.cardId() + ":" + c.expiresAt().getEpochSecond(),
                header(c), body, c.expiresAt()));
    }

    private static Optional<Candidate> nearReward(CardSnapshot c, NotificationSettings s, Instant now) {
        if (c.type() == ProgramType.STAMPS && c.stampsRequired() != null) {
            int remaining = c.stampsRequired() - c.available().setScale(0, RoundingMode.DOWN).intValue();
            if (remaining < 1 || remaining > s.getNearRewardStamps()) {
                return Optional.empty();
            }
            String body = (remaining == 1 ? "Falta apenas 1 carimbo" : "Faltam apenas " + remaining + " carimbos")
                    + " para completar seu cartão" + (c.stampReward() != null ? " e ganhar: " + c.stampReward() + "!" : "!");
            return Optional.of(new Candidate(ReminderCategory.NEAR_REWARD,
                    "NEAR:" + c.cardId() + ":" + c.completedCycles() + ":" + remaining, header(c), body, now.plus(DISPLAY_DEFAULT)));
        }
        if (c.type() == ProgramType.POINTS && c.cheapestRewardCost() != null && c.cheapestRewardCost().signum() > 0) {
            BigDecimal remaining = c.cheapestRewardCost().subtract(c.available());
            BigDecimal limit = c.cheapestRewardCost().multiply(BigDecimal.valueOf(s.getNearRewardPointsPercent()))
                    .divide(BigDecimal.valueOf(100), 0, RoundingMode.CEILING);
            if (remaining.signum() <= 0 || remaining.compareTo(limit) > 0) {
                return Optional.empty();
            }
            int points = remaining.setScale(0, RoundingMode.CEILING).intValue();
            String body = (points == 1 ? "Falta apenas 1 ponto" : "Faltam apenas " + points + " pontos") + " para trocar por: "
                    + c.cheapestRewardName() + "!";
            return Optional.of(new Candidate(ReminderCategory.NEAR_REWARD,
                    "NEAR:" + c.cardId() + ":P" + points, header(c), body, now.plus(DISPLAY_DEFAULT)));
        }
        return Optional.empty(); // cashback e VIP: não há "próxima recompensa" definida no programa
    }

    private static Optional<Candidate> inactivity(CardSnapshot c, NotificationSettings s, Instant now) {
        Instant last = c.lastMovementAt() != null ? c.lastMovementAt() : c.issuedAt();
        long days = Duration.between(last, now).toDays();
        if (days < s.getInactivityDays()) {
            return Optional.empty();
        }
        String body = "Faz " + days + " dias desde sua última visita a " + c.establishmentName() + ". Seu cartão "
                + c.programName() + " está esperando por você.";
        return Optional.of(new Candidate(ReminderCategory.INACTIVITY, "INACT:" + c.cardId() + ":" + last.getEpochSecond(),
                header(c), body, now.plus(DISPLAY_DEFAULT)));
    }

    private static String header(CardSnapshot c) {
        String h = c.programName();
        return h.length() > 80 ? h.substring(0, 80) : h;
    }
}
