package com.shaminatech.pass.establishment;

import com.shaminatech.pass.common.persistence.EnumNameConverter;

import jakarta.persistence.Converter;

/** Situação da conta do estabelecimento na plataforma. */
public enum EstablishmentStatus {
    ACTIVE,
    SUSPENDED,
    CANCELLED;

    @Converter(autoApply = true)
    public static class JpaConverter extends EnumNameConverter<EstablishmentStatus> {
        public JpaConverter() {
            super(EstablishmentStatus.class);
        }
    }
}
