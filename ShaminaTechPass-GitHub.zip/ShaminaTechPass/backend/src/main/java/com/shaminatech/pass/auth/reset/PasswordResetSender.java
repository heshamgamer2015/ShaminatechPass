package com.shaminatech.pass.auth.reset;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Canal de entrega do link de recuperação (e-mail, por exemplo). NÃO há provedor configurado nesta versão: o envio
 * fica desativado e nenhum token é criado. Para ativar, registre um bean que implemente esta interface (ex.: SMTP ou
 * serviço transacional contratado) — o restante do fluxo (token, validade, uso único, auditoria) já está pronto.
 */
public interface PasswordResetSender {

    /** Se há canal de entrega real. Sem canal, o pedido é registrado na auditoria, mas nenhum token é emitido. */
    boolean available();

    /**
     * Entrega o link ao dono da conta. Recebe o token em texto apenas para montar o link; implementações não podem
     * registrar o token em logs.
     */
    void send(String email, String fullName, String token);

    @Configuration
    class Defaults {
        private static final Logger log = LoggerFactory.getLogger(PasswordResetSender.class);

        @Bean
        @ConditionalOnMissingBean(PasswordResetSender.class)
        PasswordResetSender disabledPasswordResetSender() {
            log.info("Recuperação de senha por e-mail desativada: nenhum provedor de envio configurado.");
            return new PasswordResetSender() {
                @Override
                public boolean available() {
                    return false;
                }

                @Override
                public void send(String email, String fullName, String token) {
                    throw new IllegalStateException("Envio de recuperação não configurado.");
                }
            };
        }
    }
}
