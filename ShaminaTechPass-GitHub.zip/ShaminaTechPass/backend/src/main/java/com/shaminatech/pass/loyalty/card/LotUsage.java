package com.shaminatech.pass.loyalty.card;

import java.math.BigDecimal;

import org.hibernate.annotations.Immutable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

/** Quanto cada débito (resgate ou estorno de concessão) retirou de cada lote. Permite estornar um resgate devolvendo aos mesmos lotes. */
@Entity
@Immutable
@Table(name = "benefit_lot_usage", indexes = @Index(name = "idx_lot_usage_transaction", columnList = "transaction_id"))
public class LotUsage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "lot_id", nullable = false)
    private Long lotId;

    @Column(name = "transaction_id", nullable = false)
    private Long transactionId;

    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal amount;

    protected LotUsage() {
    }

    LotUsage(Long lotId, Long transactionId, BigDecimal amount) {
        this.lotId = lotId;
        this.transactionId = transactionId;
        this.amount = amount;
    }

    public Long getLotId() { return lotId; }
    public Long getTransactionId() { return transactionId; }
    public BigDecimal getAmount() { return amount; }
}
