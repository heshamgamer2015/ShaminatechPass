package com.shaminatech.pass.loyalty.card;

import java.math.BigDecimal;
import java.time.Instant;

import com.shaminatech.pass.common.persistence.BaseEntity;
import com.shaminatech.pass.loyalty.card.CardEnums.LotStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * Lote de benefícios gerado por uma concessão (pontos, R$ de cashback ou carimbos), com validade própria.
 * Resgates consomem os lotes na ordem de vencimento (o que vence primeiro sai primeiro). O estado dos
 * benefícios fica aqui, separado do estado do cartão.
 */
@Entity
@Table(name = "benefit_lot", indexes = {
        @Index(name = "idx_benefit_lot_card", columnList = "card_id, status"),
        @Index(name = "idx_benefit_lot_expiration", columnList = "status, expires_at")})
public class BenefitLot extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "card_id", nullable = false, foreignKey = @ForeignKey(name = "fk_benefit_lot_card"))
    private LoyaltyCard card;

    @Column(name = "establishment_id", nullable = false)
    private Long establishmentId;

    @Column(name = "source_transaction_id", nullable = false)
    private Long sourceTransactionId;

    @Column(name = "original_amount", nullable = false, precision = 14, scale = 2)
    private BigDecimal originalAmount;

    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal remaining;

    /** Quanto deste lote venceu (pela validade própria ou por expiração do cartão com FORFEIT). */
    @Column(name = "expired_amount", nullable = false, precision = 14, scale = 2)
    private BigDecimal expiredAmount = BigDecimal.ZERO;

    @Column(name = "expires_at")
    private Instant expiresAt;

    @Column(nullable = false, length = 20)
    private LotStatus status = LotStatus.OPEN;

    protected BenefitLot() {
    }

    BenefitLot(LoyaltyCard card, Long sourceTransactionId, BigDecimal originalAmount, BigDecimal remaining, Instant expiresAt) {
        this.card = card;
        this.establishmentId = card.getEstablishmentId();
        this.sourceTransactionId = sourceTransactionId;
        this.originalAmount = originalAmount;
        this.remaining = remaining;
        this.expiresAt = expiresAt;
        this.status = remaining.signum() > 0 ? LotStatus.OPEN : LotStatus.CONSUMED;
    }

    public boolean isUsable(Instant now) {
        return status == LotStatus.OPEN && (expiresAt == null || now.isBefore(expiresAt));
    }

    /** Retira até {@code wanted} do lote; devolve o quanto foi retirado. */
    BigDecimal take(BigDecimal wanted) {
        BigDecimal taken = remaining.min(wanted);
        remaining = remaining.subtract(taken);
        if (remaining.signum() == 0) {
            status = LotStatus.CONSUMED;
        }
        return taken;
    }

    void restore(BigDecimal amount) {
        remaining = remaining.add(amount);
        status = LotStatus.OPEN;
    }

    /** Vence o saldo restante; devolve o quanto venceu. */
    BigDecimal expire(LotStatus finalStatus) {
        BigDecimal amount = remaining;
        expiredAmount = expiredAmount.add(amount);
        remaining = BigDecimal.ZERO;
        status = finalStatus;
        return amount;
    }

    public LoyaltyCard getCard() { return card; }
    public Long getEstablishmentId() { return establishmentId; }
    public Long getSourceTransactionId() { return sourceTransactionId; }
    public BigDecimal getOriginalAmount() { return originalAmount; }
    public BigDecimal getRemaining() { return remaining; }
    public BigDecimal getExpiredAmount() { return expiredAmount; }
    public Instant getExpiresAt() { return expiresAt; }
    public LotStatus getStatus() { return status; }
}
