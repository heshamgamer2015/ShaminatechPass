package com.shaminatech.pass.loyalty.notify;

import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

/**
 * Localizações do estabelecimento no formato de cada carteira. Só o ponto da loja é publicado; a decisão de mostrar o
 * cartão perto da loja é do Google/Apple, no celular do consumidor — o Pass não recebe a posição de ninguém.
 */
@Service
public class ProximityService {

    private final NotificationSettingsRepository settings;
    private final EstablishmentLocationRepository locations;
    private final WalletReminderRepository reminders;
    private final Clock clock;

    public ProximityService(NotificationSettingsRepository settings, EstablishmentLocationRepository locations,
                            WalletReminderRepository reminders, Clock clock) {
        this.settings = settings;
        this.locations = locations;
        this.reminders = reminders;
        this.clock = clock;
    }

    /**
     * Google {@code merchantLocations} da classe: null = não enviar o campo (proximidade nunca usada, comportamento
     * anterior preservado); lista vazia = remover localizações publicadas antes; senão, até 10 pontos.
     */
    public List<Map<String, Object>> googleMerchantLocations(Long establishmentId) {
        NotificationSettings s = settings.findByEstablishmentId(establishmentId).orElse(null);
        if (s == null || !s.isProximityPublished()) {
            return null;
        }
        if (!s.isProximityEnabled()) {
            return List.of();
        }
        List<Map<String, Object>> result = new ArrayList<>();
        for (EstablishmentLocation l : locations.findByEstablishment(establishmentId)) {
            if (result.size() == EstablishmentLocation.MAX_PER_ESTABLISHMENT) {
                break;
            }
            result.add(Map.of("latitude", l.getLatitude(), "longitude", l.getLongitude()));
        }
        return result;
    }

    /** Apple {@code locations} do pass.json (até 10, com texto opcional da tela de bloqueio). Vazio = sem o campo. */
    public List<Map<String, Object>> appleLocations(Long establishmentId) {
        NotificationSettings s = settings.findByEstablishmentId(establishmentId).orElse(null);
        if (s == null || !s.isProximityEnabled()) {
            return List.of();
        }
        List<Map<String, Object>> result = new ArrayList<>();
        for (EstablishmentLocation l : locations.findByEstablishment(establishmentId)) {
            if (result.size() == EstablishmentLocation.MAX_PER_ESTABLISHMENT) {
                break;
            }
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("latitude", l.getLatitude());
            item.put("longitude", l.getLongitude());
            if (s.getProximityText() != null && !s.getProximityText().isBlank()) {
                item.put("relevantText", s.getProximityText());
            }
            result.add(item);
        }
        return result;
    }

    /**
     * Campo {@code messages} do objeto Google na sincronização: as mensagens de lembrete ainda válidas, como TEXT (sem
     * novo aviso). Null quando o cartão nunca teve lembrete aceito (o campo não é enviado, como antes).
     */
    public List<Map<String, Object>> googleMessages(Long cardId) {
        List<WalletReminder> accepted = reminders.findAcceptedForCard(cardId);
        if (accepted.isEmpty()) {
            return null;
        }
        Instant now = clock.instant();
        List<Map<String, Object>> result = new ArrayList<>();
        for (WalletReminder r : accepted) {
            if (r.getWithdrawnAt() == null && r.getDisplayUntil().isAfter(now)) {
                Map<String, Object> m = new LinkedHashMap<>(ReminderSender.message(r, r.getAcceptedAt()));
                m.put("messageType", "TEXT");
                result.add(m);
            }
        }
        return result;
    }
}
