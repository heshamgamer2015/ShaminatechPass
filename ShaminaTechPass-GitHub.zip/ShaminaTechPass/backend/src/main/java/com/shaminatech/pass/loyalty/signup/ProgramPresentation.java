package com.shaminatech.pass.loyalty.signup;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ExpiredBalancePolicy;
import com.shaminatech.pass.loyalty.program.ProgramEnums.StampCriterion;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ValidityMode;

/**
 * Descreve, em linguagem simples, as regras JÁ configuradas no programa (página pública de cadastro). Não cria regra:
 * cada frase corresponde a um campo do programa usado pelo motor de fidelidade.
 */
final class ProgramPresentation {

    private static final Locale PT_BR = Locale.forLanguageTag("pt-BR");

    private ProgramPresentation() {
    }

    static List<String> rules(LoyaltyProgram p) {
        List<String> rules = new ArrayList<>();
        switch (p.getType()) {
            case STAMPS -> {
                StampCriterion criterion = p.getStampCriterion() == null ? StampCriterion.VISIT : p.getStampCriterion();
                rules.add(switch (criterion) {
                    case VISIT -> "Ganhe 1 carimbo a cada visita registrada no balcão.";
                    case PURCHASE -> p.getMinPurchaseAmount() != null
                            ? "Ganhe 1 carimbo a cada compra a partir de " + money(p.getMinPurchaseAmount()) + "."
                            : "Ganhe 1 carimbo a cada compra.";
                    case PRODUCT -> "Ganhe 1 carimbo por produto participante comprado.";
                });
                if (p.getStampsRequired() != null) {
                    rules.add("Junte " + p.getStampsRequired() + " carimbos"
                            + (p.getStampReward() != null ? " e ganhe: " + p.getStampReward() + "." : " para ganhar a recompensa."));
                }
                if (Boolean.TRUE.equals(p.getRestartAfterRedeem())) {
                    rules.add("Depois do resgate, o cartão recomeça do zero.");
                }
            }
            case POINTS -> {
                int points = p.getPointsPerUnit() == null ? 1 : p.getPointsPerUnit();
                String unit = p.getSpendUnit() == null ? money(BigDecimal.ONE) : money(p.getSpendUnit());
                rules.add("Ganhe " + points + (points == 1 ? " ponto" : " pontos") + " a cada " + unit + " em compras.");
                if (p.getMinPurchaseAmount() != null) {
                    rules.add("Compras a partir de " + money(p.getMinPurchaseAmount()) + " pontuam.");
                }
                rules.add("Troque seus pontos pelas recompensas abaixo.");
            }
            case CASHBACK -> {
                rules.add(percent(p.getCashbackPercent()) + " do valor da compra volta como crédito para usar aqui.");
                if (p.getMinPurchaseAmount() != null) {
                    rules.add("Vale para compras a partir de " + money(p.getMinPurchaseAmount()) + ".");
                }
                if (p.getMaxCreditPerPurchase() != null) {
                    rules.add("Crédito máximo de " + money(p.getMaxCreditPerPurchase()) + " por compra.");
                }
                if (p.getMinRedeemBalance() != null) {
                    rules.add("Use o crédito a partir de " + money(p.getMinRedeemBalance()) + " de saldo.");
                }
                if (p.getMaxRedeemPercent() != null) {
                    rules.add("Até " + percent(p.getMaxRedeemPercent()) + " de uma compra pode ser paga com o crédito.");
                }
                rules.add("O cashback é um crédito promocional para usar neste estabelecimento: não há saque nem transferência.");
            }
            case VIP -> rules.add("Programa de níveis VIP.");
        }
        return rules;
    }

    static List<String> validity(LoyaltyProgram p) {
        List<String> lines = new ArrayList<>();
        lines.add("O cartão vence após " + p.getInactivityDays() + " dias sem compras registradas"
                + (p.getValidityMode() == ValidityMode.END_OF_DAY ? " (vale até o fim do último dia)" : "")
                + ". Cada compra ou resgate confirmado no balcão renova o prazo.");
        if (p.getExpiredBalancePolicy() == ExpiredBalancePolicy.FORFEIT) {
            lines.add("Se o cartão vencer, o saldo acumulado é zerado.");
        } else {
            lines.add("Se o cartão vencer, o saldo fica guardado e volta a valer se o estabelecimento reativar o cartão.");
        }
        if (p.getBenefitValidityDays() != null) {
            lines.add("Cada " + switch (p.getType()) {
                case STAMPS -> "carimbo";
                case POINTS -> "lote de pontos";
                case CASHBACK -> "crédito";
                case VIP -> "benefício";
            } + " vale por " + p.getBenefitValidityDays() + " dias a partir da concessão.");
        }
        return lines;
    }

    static String money(BigDecimal value) {
        return NumberFormat.getCurrencyInstance(PT_BR).format(value).replace(' ', ' ');
    }

    static String percent(BigDecimal value) {
        if (value == null) {
            return "Uma parte";
        }
        return value.stripTrailingZeros().toPlainString().replace('.', ',') + "%";
    }
}
