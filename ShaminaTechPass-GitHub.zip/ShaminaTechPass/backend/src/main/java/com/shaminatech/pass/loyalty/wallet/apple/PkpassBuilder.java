package com.shaminatech.pass.loyalty.wallet.apple;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.bouncycastle.cert.jcajce.JcaCertStore;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoGeneratorBuilder;

import tools.jackson.databind.json.JsonMapper;

/**
 * Monta o arquivo .pkpass conforme o formato da Apple:
 * <ol>
 *   <li>{@code pass.json} e imagens na raiz do pacote;</li>
 *   <li>{@code manifest.json}: SHA-1 (hexadecimal) de cada arquivo, exceto o próprio manifesto e a assinatura;</li>
 *   <li>{@code signature}: assinatura PKCS #7 destacada do manifesto, com o certificado Pass Type ID e o intermediário
 *       Apple WWDR incluídos (com o atributo signing-time);</li>
 *   <li>ZIP do conteúdo (sem pasta raiz).</li>
 * </ol>
 */
public final class PkpassBuilder {

    public static final String CONTENT_TYPE = "application/vnd.apple.pkpass";

    private PkpassBuilder() {
    }

    public static byte[] build(Map<String, Object> passJson, Map<String, byte[]> images, AppleCredentials credentials, JsonMapper json) {
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("pass.json", json.writeValueAsBytes(passJson));
        files.putAll(images);
        byte[] manifest = json.writeValueAsBytes(manifest(files));
        byte[] signature = sign(manifest, credentials);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(out)) {
            for (Map.Entry<String, byte[]> file : files.entrySet()) {
                put(zip, file.getKey(), file.getValue());
            }
            put(zip, "manifest.json", manifest);
            put(zip, "signature", signature);
        } catch (IOException e) {
            throw new AppleWalletException(0, "Falha ao compactar o cartão.", false);
        }
        return out.toByteArray();
    }

    /** Caminho relativo → SHA-1 em hexadecimal (ordem alfabética: o conteúdo do manifesto fica determinístico). */
    static Map<String, String> manifest(Map<String, byte[]> files) {
        Map<String, String> manifest = new TreeMap<>();
        files.forEach((name, data) -> manifest.put(name, sha1(data)));
        return manifest;
    }

    static byte[] sign(byte[] manifest, AppleCredentials credentials) {
        try {
            String algorithm = "EC".equals(credentials.privateKey().getAlgorithm()) ? "SHA256withECDSA" : "SHA256withRSA";
            CMSSignedDataGenerator generator = new CMSSignedDataGenerator();
            generator.addSignerInfoGenerator(new JcaSimpleSignerInfoGeneratorBuilder()
                    .build(algorithm, credentials.privateKey(), credentials.certificate()));
            generator.addCertificates(new JcaCertStore(List.of(credentials.certificate(), credentials.wwdr())));
            // Assinatura destacada (o conteúdo assinado é o manifest.json, que vai à parte no pacote).
            return generator.generate(new CMSProcessableByteArray(manifest), false).getEncoded();
        } catch (Exception e) {
            throw new AppleWalletException(0, "Falha ao assinar o cartão com o certificado Pass Type ID.", false);
        }
    }

    private static void put(ZipOutputStream zip, String name, byte[] data) throws IOException {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(data);
        zip.closeEntry();
    }

    static String sha1(byte[] data) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-1").digest(data));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    static String utf8(byte[] data) {
        return new String(data, StandardCharsets.UTF_8);
    }
}
