package com.shaminatech.pass.common.web;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public final class ClientIp {

    private ClientIp() {
    }

    /**
     * IP da requisição atual. Usa apenas o endereço da conexão: cabeçalhos como
     * X-Forwarded-For só devem ser considerados quando houver proxy reverso confiável (produção).
     */
    public static String current() {
        if (RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes attributes) {
            return attributes.getRequest().getRemoteAddr();
        }
        return null;
    }
}
