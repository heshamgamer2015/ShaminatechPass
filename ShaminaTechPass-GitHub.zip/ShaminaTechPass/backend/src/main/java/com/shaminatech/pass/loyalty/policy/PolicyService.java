package com.shaminatech.pass.loyalty.policy;

import java.time.DateTimeException;
import java.time.ZoneId;
import java.util.EnumSet;
import java.util.Set;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.loyalty.ProgramType;

/** Regras padrão da plataforma e políticas (limites) dos estabelecimentos. */
@Service
public class PolicyService {

    public static final int MAX_CONSUMER_LIMIT = 1_000_000;
    public static final int MAX_INACTIVITY_DAYS = 3650;

    private final PlatformLoyaltyDefaultsRepository defaults;
    private final EstablishmentPolicyRepository policies;
    private final LoyaltyProperties properties;

    public PolicyService(PlatformLoyaltyDefaultsRepository defaults, EstablishmentPolicyRepository policies,
                         LoyaltyProperties properties) {
        this.defaults = defaults;
        this.policies = policies;
        this.properties = properties;
    }

    /** Regras padrão; cria o registro a partir da configuração na primeira vez. */
    @Transactional
    public PlatformLoyaltyDefaults defaults() {
        return defaults.findFirstByOrderByIdAsc().orElseGet(() -> {
            var d = properties.defaults();
            Set<ProgramType> types = d.programTypes().isEmpty() ? EnumSet.noneOf(ProgramType.class) : EnumSet.copyOf(d.programTypes());
            return defaults.save(new PlatformLoyaltyDefaults(d.maxActiveConsumers(), d.inactivityDays(), d.timeZone(), types));
        });
    }

    @Transactional
    public EstablishmentPolicy createFor(Establishment establishment) {
        return policies.save(new EstablishmentPolicy(establishment, defaults()));
    }

    @Transactional(readOnly = true)
    public EstablishmentPolicy of(Long establishmentId) {
        return policies.findByEstablishmentId(establishmentId).orElseThrow(PolicyService::missing);
    }

    /** Trava a política (FOR UPDATE) para validar limites sem condição de corrida. */
    @Transactional
    public EstablishmentPolicy lock(Long establishmentId) {
        return policies.lockByEstablishmentId(establishmentId).orElseThrow(PolicyService::missing);
    }

    /** Valida os valores de limite/regra informados pelo administrador. */
    public static void validate(int maxActiveConsumers, int inactivityDays, String timeZone) {
        if (maxActiveConsumers < 0 || maxActiveConsumers > MAX_CONSUMER_LIMIT) {
            throw ApiException.badRequest("O limite deve estar entre 0 e " + MAX_CONSUMER_LIMIT + ".", "maxActiveConsumers");
        }
        if (inactivityDays < 1 || inactivityDays > MAX_INACTIVITY_DAYS) {
            throw ApiException.badRequest("O prazo deve estar entre 1 e " + MAX_INACTIVITY_DAYS + " dias.", "defaultInactivityDays");
        }
        try {
            ZoneId.of(timeZone);
        } catch (DateTimeException | NullPointerException e) {
            throw ApiException.badRequest("Fuso horário inválido.", "timeZone");
        }
    }

    private static ApiException missing() {
        return new ApiException(HttpStatus.CONFLICT, "POLICY_MISSING",
                "Os limites deste estabelecimento ainda não foram configurados pela ShaminaTech.");
    }
}
