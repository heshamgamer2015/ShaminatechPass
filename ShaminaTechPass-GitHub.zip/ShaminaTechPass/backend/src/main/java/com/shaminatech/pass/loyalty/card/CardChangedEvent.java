package com.shaminatech.pass.loyalty.card;

/**
 * Publicado na transação de qualquer alteração de saldo ou estado do cartão. Usado pela integração futura
 * com carteiras digitais (sincronização após o commit); o saldo oficial continua sendo o do backend.
 */
public record CardChangedEvent(Long cardId, Long establishmentId) {
}
