package com.shaminatech.pass.membership;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RolePermissionRepository extends JpaRepository<RolePermission, Long> {

    @Query("select rp.permission.code from RolePermission rp where rp.role = :role")
    List<String> findPermissionCodesByRole(@Param("role") MembershipRole role);
}
