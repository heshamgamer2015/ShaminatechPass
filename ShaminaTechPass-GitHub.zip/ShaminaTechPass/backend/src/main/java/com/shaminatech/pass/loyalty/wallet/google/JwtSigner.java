package com.shaminatech.pass.loyalty.wallet.google;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

import tools.jackson.databind.json.JsonMapper;

/** Assinatura de JWT compacto RS256 (RFC 7515/7519) com a chave da conta de serviço, sem dependências externas. */
final class JwtSigner {

    private static final Base64.Encoder B64 = Base64.getUrlEncoder().withoutPadding();

    private JwtSigner() {
    }

    static String sign(Map<String, Object> claims, PrivateKey key, JsonMapper json) {
        Map<String, Object> header = new LinkedHashMap<>();
        header.put("alg", "RS256");
        header.put("typ", "JWT");
        String signingInput = B64.encodeToString(json.writeValueAsBytes(header)) + "." + B64.encodeToString(json.writeValueAsBytes(claims));
        try {
            Signature signature = Signature.getInstance("SHA256withRSA");
            signature.initSign(key);
            signature.update(signingInput.getBytes(StandardCharsets.US_ASCII));
            return signingInput + "." + B64.encodeToString(signature.sign());
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Falha ao assinar o JWT.", e);
        }
    }
}
