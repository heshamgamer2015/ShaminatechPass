package com.shaminatech.pass.plan;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Fase de testes dos planos ({@code shaminatech.plans}).
 *
 * @param trialFree         todos os planos podem ser escolhidos sem cobrança (fase de testes). Desligado, o autocadastro
 *                          aceita só o Free: não existe cobrança implementada para liberar Growth e Pro.
 * @param selfSignupEnabled autocadastro público de estabelecimentos ligado
 * @param termsVersion      versão dos termos aceitos no cadastro (registrada junto com o aceite)
 */
@ConfigurationProperties(prefix = "shaminatech.plans")
public record PlanProperties(Boolean trialFree, Boolean selfSignupEnabled, String termsVersion) {

    public PlanProperties {
        trialFree = trialFree == null || trialFree;
        selfSignupEnabled = selfSignupEnabled == null || selfSignupEnabled;
        termsVersion = termsVersion == null || termsVersion.isBlank() ? "fase-de-testes-2026-11" : termsVersion.trim();
    }
}
