package com.shaminatech.pass.loyalty.card;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface BenefitLotRepository extends JpaRepository<BenefitLot, Long> {

    /** Lotes abertos na ordem de consumo: vence primeiro sai primeiro (sem validade por último). */
    @Query("""
            select l from BenefitLot l where l.card.id = :cardId
              and l.status = com.shaminatech.pass.loyalty.card.CardEnums.LotStatus.OPEN
            order by case when l.expiresAt is null then 1 else 0 end, l.expiresAt, l.id
            """)
    List<BenefitLot> findOpenByCard(@Param("cardId") Long cardId);

    Optional<BenefitLot> findBySourceTransactionId(Long sourceTransactionId);

    @Query("select l from BenefitLot l where l.card.id = :cardId order by l.id desc")
    List<BenefitLot> findByCard(@Param("cardId") Long cardId);

    /** Cartões com lotes vencidos pela validade própria (exceto cartões cancelados, cujos benefícios ficam congelados). */
    @Query("""
            select distinct l.card.id from BenefitLot l
            where l.status = com.shaminatech.pass.loyalty.card.CardEnums.LotStatus.OPEN and l.expiresAt <= :now
              and l.card.status <> com.shaminatech.pass.loyalty.card.CardEnums.CardStatus.CANCELLED
            """)
    List<Long> findCardIdsWithDueLots(@Param("now") Instant now, Pageable pageable);
}
