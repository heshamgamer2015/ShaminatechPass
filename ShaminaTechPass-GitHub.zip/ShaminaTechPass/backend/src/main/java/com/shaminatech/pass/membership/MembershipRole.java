package com.shaminatech.pass.membership;

import com.shaminatech.pass.common.persistence.EnumNameConverter;

import jakarta.persistence.Converter;

/** Papel do usuário dentro de um estabelecimento. */
public enum MembershipRole {
    /** Proprietário: controle total do estabelecimento. */
    OWNER,
    /** Gerente: acompanha a operação e a equipe. */
    MANAGER,
    /** Funcionário autorizado: operação do dia a dia. */
    STAFF;

    @Converter(autoApply = true)
    public static class JpaConverter extends EnumNameConverter<MembershipRole> {
        public JpaConverter() {
            super(MembershipRole.class);
        }
    }
}
