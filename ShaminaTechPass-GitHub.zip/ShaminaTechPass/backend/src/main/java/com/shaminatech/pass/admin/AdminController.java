package com.shaminatech.pass.admin;

import jakarta.validation.Valid;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.shaminatech.pass.admin.AdminDtos.ChangeEstablishmentStatusRequest;
import com.shaminatech.pass.admin.AdminDtos.ChangeUserStatusRequest;
import com.shaminatech.pass.admin.AdminDtos.CreateEstablishmentRequest;
import com.shaminatech.pass.admin.AdminDtos.EstablishmentDetail;
import com.shaminatech.pass.admin.AdminDtos.EstablishmentSummary;
import com.shaminatech.pass.admin.AdminDtos.PolicyRequest;
import com.shaminatech.pass.admin.AdminDtos.ResetPasswordRequest;
import com.shaminatech.pass.admin.AdminDtos.UserSummary;
import com.shaminatech.pass.audit.AuditEventResponse;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.web.PageResponse;
import com.shaminatech.pass.common.web.Paging;
import com.shaminatech.pass.establishment.EstablishmentStatus;
import com.shaminatech.pass.loyalty.LoyaltyDtos.PolicyView;

/** Painel ShaminaTech: protegido por /api/admin/** → ROLE_PLATFORM_ADMIN. */
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AdminService service;
    private final AuditService audit;

    public AdminController(AdminService service, AuditService audit) {
        this.service = service;
        this.audit = audit;
    }

    @GetMapping("/establishments")
    public PageResponse<EstablishmentSummary> establishments(@RequestParam(required = false) String q,
                                                             @RequestParam(required = false) EstablishmentStatus status,
                                                             @RequestParam(defaultValue = "0") int page,
                                                             @RequestParam(defaultValue = "20") int size) {
        return service.listEstablishments(q, status, Paging.of(page, size, Sort.by("name")));
    }

    @PostMapping("/establishments")
    @ResponseStatus(HttpStatus.CREATED)
    public EstablishmentDetail createEstablishment(@Valid @RequestBody CreateEstablishmentRequest body) {
        return service.createEstablishment(body);
    }

    @GetMapping("/establishments/{id}")
    public EstablishmentDetail establishment(@PathVariable Long id) {
        return service.getEstablishment(id);
    }

    @PatchMapping("/establishments/{id}/status")
    public EstablishmentDetail changeEstablishmentStatus(@PathVariable Long id,
                                                         @Valid @RequestBody ChangeEstablishmentStatusRequest body) {
        return service.changeEstablishmentStatus(id, body.status());
    }

    @PutMapping("/establishments/{id}/policy")
    public EstablishmentDetail updatePolicy(@PathVariable Long id, @Valid @RequestBody PolicyRequest body) {
        return service.updatePolicy(id, body);
    }

    @PostMapping("/establishments/{id}/account/reset-password")
    public EstablishmentDetail resetAccountPassword(@PathVariable Long id, @Valid @RequestBody ResetPasswordRequest body) {
        return service.resetAccountPassword(id, body.temporaryPassword());
    }

    @GetMapping("/loyalty-defaults")
    public PolicyView defaults() {
        return service.defaults();
    }

    @PutMapping("/loyalty-defaults")
    public PolicyView updateDefaults(@Valid @RequestBody PolicyRequest body) {
        return service.updateDefaults(body);
    }

    @GetMapping("/users")
    public PageResponse<UserSummary> users(@RequestParam(required = false) String q,
                                           @RequestParam(defaultValue = "0") int page,
                                           @RequestParam(defaultValue = "20") int size) {
        return service.listUsers(q, Paging.of(page, size, Sort.by("fullName")));
    }

    @PatchMapping("/users/{id}/status")
    public UserSummary changeUserStatus(@PathVariable Long id, @Valid @RequestBody ChangeUserStatusRequest body) {
        return service.changeUserStatus(id, body.status());
    }

    @PostMapping("/users/{id}/unlock")
    public UserSummary unlockUser(@PathVariable Long id) {
        return service.unlockUser(id);
    }

    @GetMapping("/audit")
    public PageResponse<AuditEventResponse> audit(@RequestParam(required = false) Long establishmentId,
                                                  @RequestParam(defaultValue = "0") int page,
                                                  @RequestParam(defaultValue = "30") int size) {
        return audit.list(establishmentId, Paging.of(page, size, AuditService.NEWEST_FIRST));
    }
}
