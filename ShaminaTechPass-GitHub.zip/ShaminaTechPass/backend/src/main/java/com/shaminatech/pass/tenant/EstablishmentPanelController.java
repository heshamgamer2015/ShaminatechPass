package com.shaminatech.pass.tenant;


import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shaminatech.pass.audit.AuditEventResponse;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.web.PageResponse;
import com.shaminatech.pass.common.web.Paging;
import com.shaminatech.pass.tenant.TenantDtos.EstablishmentPanelResponse;
import com.shaminatech.pass.tenant.TenantDtos.UpdateEstablishmentRequest;

/**
 * Painel do estabelecimento (dados cadastrais e auditoria). O id do tenant vem do caminho e é validado em toda
 * chamada. A gestão de equipe da Etapa 1 foi retirada: cada estabelecimento tem uma única conta empresarial.
 */
@RestController
@RequestMapping("/api/establishments/{establishmentId}")
public class EstablishmentPanelController {

    private final EstablishmentPanelService service;

    public EstablishmentPanelController(EstablishmentPanelService service) {
        this.service = service;
    }

    @GetMapping
    public EstablishmentPanelResponse get(@PathVariable Long establishmentId) {
        return service.get(establishmentId);
    }

    @PutMapping
    public EstablishmentPanelResponse update(@PathVariable Long establishmentId,
                                             @Valid @RequestBody UpdateEstablishmentRequest body) {
        return service.update(establishmentId, body);
    }

    @GetMapping("/audit")
    public PageResponse<AuditEventResponse> audit(@PathVariable Long establishmentId,
                                                  @RequestParam(defaultValue = "0") int page,
                                                  @RequestParam(defaultValue = "20") int size) {
        return service.auditLog(establishmentId, Paging.of(page, size, AuditService.NEWEST_FIRST));
    }
}
