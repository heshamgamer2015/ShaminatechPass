package com.shaminatech.pass.plan;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.shaminatech.pass.auth.AuthDtos.MeResponse;
import com.shaminatech.pass.auth.SessionLogin;

/** Planos e autocadastro de estabelecimentos. */
@RestController
public class PlanController {

    private final PlanService plans;
    private final EstablishmentSignupService signup;
    private final SessionLogin sessionLogin;

    public PlanController(PlanService plans, EstablishmentSignupService signup, SessionLogin sessionLogin) {
        this.plans = plans;
        this.signup = signup;
        this.sessionLogin = sessionLogin;
    }

    /** Catálogo público: planos, preços comerciais previstos e se a fase de testes (sem cobrança) está ativa. */
    @GetMapping("/api/public/plans")
    public ResponseEntity<PlanService.Catalog> catalog() {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(plans.catalog());
    }

    /**
     * Autocadastro: cria o estabelecimento e a conta (transação única) e, em seguida, entra com o mesmo mecanismo do
     * login. Exige CSRF como qualquer POST.
     */
    @PostMapping("/api/public/establishment-signup")
    public ResponseEntity<PlanDtos.SignupResponse> register(@Valid @RequestBody PlanDtos.SignupRequest body, HttpServletRequest request,
                                                            HttpServletResponse response) {
        EstablishmentSignupService.Created created;
        try {
            created = signup.register(body);
        } catch (DataIntegrityViolationException e) {
            // Cadastro simultâneo com o mesmo e-mail: a restrição única desfez a transação inteira.
            throw EstablishmentSignupService.emailUnavailable();
        }
        MeResponse me = sessionLogin.login(created.email(), body.password(), request, response);
        return ResponseEntity.status(HttpStatus.CREATED).cacheControl(CacheControl.noStore())
                .body(new PlanDtos.SignupResponse(created.establishmentId(), created.plan().name(), created.trialFree(), me));
    }

    /** Plano, limites e utilização do estabelecimento (painel do estabelecimento). */
    @GetMapping("/api/establishments/{establishmentId}/plan")
    public PlanService.PlanView plan(@PathVariable Long establishmentId) {
        return plans.view(establishmentId);
    }
}
