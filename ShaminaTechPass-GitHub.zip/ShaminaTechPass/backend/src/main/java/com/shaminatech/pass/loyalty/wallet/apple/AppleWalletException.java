package com.shaminatech.pass.loyalty.wallet.apple;

/** Falha da integração Apple Wallet (configuração, assinatura ou notificação). Nunca carrega segredos na mensagem. */
public class AppleWalletException extends RuntimeException {

    private final int status;
    private final boolean retryable;

    public AppleWalletException(int status, String message, boolean retryable) {
        super(message);
        this.status = status;
        this.retryable = retryable;
    }

    public int status() {
        return status;
    }

    public boolean retryable() {
        return retryable;
    }
}
