package com.shaminatech.pass.loyalty.notify;

import java.time.Duration;
import java.time.Instant;

import com.shaminatech.pass.common.persistence.BaseEntity;
import com.shaminatech.pass.common.persistence.EnumNameConverter;

import jakarta.persistence.Column;
import jakarta.persistence.Converter;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Pedido de notificação (mensagem com aviso) ao Google Wallet para um cartão.
 * <p>
 * Estados — nenhum deles significa "entregue" ou "lido": o Google não informa entrega nem leitura.
 * <ul>
 *   <li>PENDING: elegível, aguardando a janela de envio;</li>
 *   <li>SENDING: reservado por um processo (prazo de reserva), chamada em andamento;</li>
 *   <li>ACCEPTED: o Google aceitou o pedido (a mensagem foi gravada no cartão); a exibição do aviso depende do Google e do
 *       celular do consumidor;</li>
 *   <li>FAILED: falha temporária com nova tentativa agendada ({@code nextAttemptAt}) ou tentativas esgotadas (nulo);</li>
 *   <li>REJECTED: o Google recusou o pedido (erro permanente);</li>
 *   <li>QUOTA_EXCEEDED: limite de avisos do Google para o cartão atingido; não é reenviado;</li>
 *   <li>CANCELLED: não foi enviado porque a situação mudou (ex.: compra renovou a validade) ou deixou de ser elegível.</li>
 * </ul>
 * {@code dedupKey} identifica a situação (cartão + categoria + estado que motivou o aviso): a mesma situação nunca gera
 * dois lembretes (restrição única).
 */
@Entity
@Table(name = "wallet_reminder",
        uniqueConstraints = @UniqueConstraint(name = "uk_wallet_reminder_dedup", columnNames = "dedup_key"),
        indexes = {
                @Index(name = "idx_wallet_reminder_due", columnList = "status, next_attempt_at"),
                @Index(name = "idx_wallet_reminder_card", columnList = "card_id, category, created_at"),
                @Index(name = "idx_wallet_reminder_establishment", columnList = "establishment_id, planned_at")})
public class WalletReminder extends BaseEntity {

    public enum Status {
        PENDING, SENDING, ACCEPTED, FAILED, REJECTED, QUOTA_EXCEEDED, CANCELLED;

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<Status> {
            public JpaConverter() {
                super(Status.class);
            }
        }
    }

    @Column(name = "establishment_id", nullable = false, updatable = false)
    private Long establishmentId;

    @Column(name = "card_id", nullable = false, updatable = false)
    private Long cardId;

    @Column(name = "wallet_pass_id", nullable = false, updatable = false)
    private Long walletPassId;

    @Column(nullable = false, length = 20, updatable = false)
    private ReminderCategory category;

    @Column(name = "dedup_key", nullable = false, length = 120, updatable = false)
    private String dedupKey;

    @Column(nullable = false, length = 20)
    private Status status = Status.PENDING;

    @Column(nullable = false, length = 80)
    private String header;

    @Column(nullable = false, length = 300)
    private String body;

    /** Até quando a mensagem fica visível no cartão (displayInterval.end). */
    @Column(name = "display_until", nullable = false)
    private Instant displayUntil;

    @Column(name = "planned_at", nullable = false, updatable = false)
    private Instant plannedAt;

    @Column(name = "next_attempt_at")
    private Instant nextAttemptAt;

    @Column(name = "lease_until")
    private Instant leaseUntil;

    @Column(nullable = false)
    private int attempts;

    @Column(name = "last_attempt_at")
    private Instant lastAttemptAt;

    /** Quando o Google aceitou o pedido (não é horário de entrega). */
    @Column(name = "accepted_at")
    private Instant acceptedAt;

    /** Mensagem já aceita e depois retirada do cartão porque a situação mudou. */
    @Column(name = "withdrawn_at")
    private Instant withdrawnAt;

    @Column(name = "closed_reason", length = 200)
    private String closedReason;

    @Column(name = "last_error", length = 300)
    private String lastError;

    @Column(name = "last_error_status")
    private Integer lastErrorStatus;

    protected WalletReminder() {
    }

    public WalletReminder(Long establishmentId, Long cardId, Long walletPassId, ReminderCategory category, String dedupKey,
                          String header, String body, Instant displayUntil, Instant now) {
        this.establishmentId = establishmentId;
        this.cardId = cardId;
        this.walletPassId = walletPassId;
        this.category = category;
        this.dedupKey = dedupKey;
        this.header = header;
        this.body = body;
        this.displayUntil = displayUntil;
        this.plannedAt = now;
        this.nextAttemptAt = now;
    }

    /** Id da mensagem no Google: estável por lembrete (reenvio após falha usa o mesmo id). */
    public String messageId() {
        return "stp_reminder_" + getId();
    }

    public boolean isDue(Instant now) {
        return (status == Status.PENDING || status == Status.FAILED) && nextAttemptAt != null && !nextAttemptAt.isAfter(now)
                || status == Status.SENDING && leaseUntil != null && leaseUntil.isBefore(now);
    }

    void refreshText(String header, String body, Instant displayUntil) {
        this.header = header;
        this.body = body;
        this.displayUntil = displayUntil;
    }

    /** Fora da janela de envio: aguarda o próximo início (não conta tentativa). */
    void defer(Instant at) {
        if (status == Status.SENDING) {
            status = Status.PENDING;
        }
        leaseUntil = null;
        nextAttemptAt = at;
    }

    void reserve(Instant now, Duration lease) {
        status = Status.SENDING;
        leaseUntil = now.plus(lease);
        attempts++;
        lastAttemptAt = now;
    }

    void accepted(Instant now, String note) {
        status = Status.ACCEPTED;
        acceptedAt = now;
        leaseUntil = null;
        nextAttemptAt = null;
        lastError = null;
        lastErrorStatus = null;
        closedReason = note;
    }

    void failed(Instant now, int httpStatus, String message, Instant retryAt) {
        status = Status.FAILED;
        leaseUntil = null;
        nextAttemptAt = retryAt;
        lastError = truncate(message);
        lastErrorStatus = httpStatus;
        if (retryAt == null) {
            closedReason = "Tentativas esgotadas.";
        }
    }

    void close(Status finalStatus, String reason, int httpStatus, String error) {
        status = finalStatus;
        leaseUntil = null;
        nextAttemptAt = null;
        closedReason = truncate(reason);
        if (error != null) {
            lastError = truncate(error);
            lastErrorStatus = httpStatus;
        }
    }

    void cancel(String reason) {
        close(Status.CANCELLED, reason, 0, null);
    }

    void withdraw(Instant now) {
        if (status == Status.ACCEPTED && withdrawnAt == null) {
            withdrawnAt = now;
        }
    }

    private static String truncate(String v) {
        return v == null ? null : v.length() > 200 ? v.substring(0, 200) : v;
    }

    public Long getEstablishmentId() { return establishmentId; }
    public Long getCardId() { return cardId; }
    public Long getWalletPassId() { return walletPassId; }
    public ReminderCategory getCategory() { return category; }
    public String getDedupKey() { return dedupKey; }
    public Status getStatus() { return status; }
    public String getHeader() { return header; }
    public String getBody() { return body; }
    public Instant getDisplayUntil() { return displayUntil; }
    public Instant getPlannedAt() { return plannedAt; }
    public Instant getNextAttemptAt() { return nextAttemptAt; }
    public int getAttempts() { return attempts; }
    public Instant getLastAttemptAt() { return lastAttemptAt; }
    public Instant getAcceptedAt() { return acceptedAt; }
    public Instant getWithdrawnAt() { return withdrawnAt; }
    public String getClosedReason() { return closedReason; }
    public String getLastError() { return lastError; }
    public Integer getLastErrorStatus() { return lastErrorStatus; }
}
