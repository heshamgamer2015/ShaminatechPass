package com.shaminatech.pass.loyalty.signup;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SignupLinkRepository extends JpaRepository<SignupLink, Long> {

    @Query("select l from SignupLink l join fetch l.program p join fetch p.establishment where l.token = :token")
    Optional<SignupLink> findByToken(@Param("token") String token);

    @Query("select l from SignupLink l join fetch l.program where l.id = :id and l.establishmentId = :establishmentId")
    Optional<SignupLink> findInEstablishment(@Param("establishmentId") Long establishmentId, @Param("id") Long id);

    @Query("select l from SignupLink l join fetch l.program where l.establishmentId = :establishmentId order by l.id")
    List<SignupLink> findAllInEstablishment(@Param("establishmentId") Long establishmentId);

    @Query("select l from SignupLink l where l.program.id = :programId")
    Optional<SignupLink> findByProgram(@Param("programId") Long programId);

    boolean existsByToken(String token);

    @Query("select count(l) from SignupLink l where l.establishmentId = :establishmentId and l.active = true")
    long countActive(@Param("establishmentId") Long establishmentId);
}
