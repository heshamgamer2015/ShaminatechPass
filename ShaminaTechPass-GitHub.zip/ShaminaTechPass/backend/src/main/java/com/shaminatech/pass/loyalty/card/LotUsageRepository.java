package com.shaminatech.pass.loyalty.card;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LotUsageRepository extends JpaRepository<LotUsage, Long> {

    List<LotUsage> findByTransactionId(Long transactionId);
}
