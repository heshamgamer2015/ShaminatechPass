package com.shaminatech.pass.user;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.security.PasswordPolicy;

/** Regras de criação de contas compartilhadas pelo painel ShaminaTech e pelo painel do estabelecimento. */
@Service
public class UserAccountService {

    private final AppUserRepository users;
    private final PasswordEncoder passwordEncoder;
    private final AuditService audit;

    public UserAccountService(AppUserRepository users, PasswordEncoder passwordEncoder, AuditService audit) {
        this.users = users;
        this.passwordEncoder = passwordEncoder;
        this.audit = audit;
    }

    public record Result(AppUser user, boolean created) {
    }

    /**
     * Retorna a conta existente com o e-mail, ou cria uma nova com senha temporária
     * (troca obrigatória no primeiro acesso).
     */
    @Transactional
    public Result findOrCreate(String email, String fullName, String temporaryPassword, Long establishmentIdForAudit) {
        String normalized = EmailNormalizer.normalize(email);
        var existing = users.findByEmail(normalized);
        if (existing.isPresent()) {
            return new Result(existing.get(), false);
        }
        if (temporaryPassword == null || temporaryPassword.isBlank()) {
            throw ApiException.badRequest("Informe uma senha temporária para o novo usuário.", "temporaryPassword");
        }
        PasswordPolicy.violation(temporaryPassword).ifPresent(message -> {
            throw ApiException.badRequest(message, "temporaryPassword");
        });
        AppUser user = users.save(new AppUser(normalized, fullName.trim(), passwordEncoder.encode(temporaryPassword), true));
        audit.record(AuditAction.USER_CREATED, establishmentIdForAudit, "USER", user.getId(), null);
        return new Result(user, true);
    }
}
