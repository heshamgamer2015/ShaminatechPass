package com.shaminatech.pass.loyalty.notify;

import com.shaminatech.pass.common.persistence.EnumNameConverter;

import jakarta.persistence.Converter;

/**
 * Categorias de lembrete. NEAR_REWARD e EXPIRY são avisos operacionais sobre o próprio cartão; INACTIVITY é um convite
 * para voltar (comunicação de relacionamento) e só vai para quem consentiu em receber comunicações do estabelecimento.
 */
public enum ReminderCategory {
    NEAR_REWARD, EXPIRY, INACTIVITY;

    public boolean requiresMarketingConsent() {
        return this == INACTIVITY;
    }

    @Converter(autoApply = true)
    public static class JpaConverter extends EnumNameConverter<ReminderCategory> {
        public JpaConverter() {
            super(ReminderCategory.class);
        }
    }
}
