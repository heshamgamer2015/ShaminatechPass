package com.shaminatech.pass.loyalty.wallet;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shaminatech.pass.loyalty.wallet.WalletPass.Provider;

public interface WalletClassRepository extends JpaRepository<WalletClass, Long> {

    Optional<WalletClass> findByProgramIdAndProvider(Long programId, Provider provider);
}
