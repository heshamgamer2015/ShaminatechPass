package com.shaminatech.pass.loyalty.consumer;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import jakarta.persistence.LockModeType;

/** Toda busca exige o estabelecimento: um id de consumidor de outro tenant resulta em "não encontrado". */
public interface ConsumerRepository extends JpaRepository<Consumer, Long>, JpaSpecificationExecutor<Consumer> {

    @Query("select c from Consumer c where c.id = :id and c.establishment.id = :establishmentId")
    Optional<Consumer> findInEstablishment(@Param("establishmentId") Long establishmentId, @Param("id") Long id);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select c from Consumer c where c.id = :id and c.establishment.id = :establishmentId")
    Optional<Consumer> lockInEstablishment(@Param("establishmentId") Long establishmentId, @Param("id") Long id);

    @Query("select count(c) from Consumer c where c.establishment.id = :establishmentId and c.status = :status")
    long countByStatus(@Param("establishmentId") Long establishmentId, @Param("status") Consumer.Status status);

    @Query("select count(c) from Consumer c where c.establishment.id = :establishmentId")
    long countAll(@Param("establishmentId") Long establishmentId);

    @Query("""
            select c.establishment.id, count(c) from Consumer c
            where c.establishment.id in :ids and c.status = com.shaminatech.pass.loyalty.consumer.Consumer.Status.ACTIVE
            group by c.establishment.id
            """)
    List<Object[]> countActiveByEstablishment(@Param("ids") Collection<Long> ids);

    @Query("""
            select c.establishment.id, count(c) from Consumer c where c.establishment.id in :ids group by c.establishment.id
            """)
    List<Object[]> countAllByEstablishment(@Param("ids") Collection<Long> ids);

    /**
     * Cadastros no período, por origem. Usa {@code privacy_acknowledged_at}, gravado com o relógio da aplicação no
     * momento do cadastro (o {@code created_at} técnico usa o relógio do sistema).
     */
    @Query("""
            select c.source, count(c) from Consumer c where c.establishment.id = :establishmentId
              and c.privacyAcknowledgedAt >= :from and c.privacyAcknowledgedAt <= :to
            group by c.source
            """)
    List<Object[]> countRegisteredBetween(@Param("establishmentId") Long establishmentId, @Param("from") java.time.Instant from,
                                          @Param("to") java.time.Instant to);

    /**
     * Clientes ativos cadastrados antes de {@code cut} sem nenhuma visita (concessão não estornada) desde {@code cut}.
     */
    @Query("""
            select count(c) from Consumer c where c.establishment.id = :establishmentId
              and c.status = com.shaminatech.pass.loyalty.consumer.Consumer.Status.ACTIVE and c.privacyAcknowledgedAt < :cut
              and not exists (select 1 from CardTransaction t where t.consumerId = c.id
                  and t.type = com.shaminatech.pass.loyalty.card.CardEnums.TransactionType.EARN and t.occurredAt >= :cut
                  and not exists (select 1 from CardTransaction r where r.reversesId = t.id))
            """)
    long countInactiveSince(@Param("establishmentId") Long establishmentId, @Param("cut") java.time.Instant cut);

    /** Igual a {@link #countInactiveSince}, só entre clientes com cartão do programa e visitas desse programa. */
    @Query("""
            select count(c) from Consumer c where c.establishment.id = :establishmentId
              and c.status = com.shaminatech.pass.loyalty.consumer.Consumer.Status.ACTIVE and c.privacyAcknowledgedAt < :cut
              and exists (select 1 from LoyaltyCard k where k.consumer.id = c.id and k.program.id = :programId)
              and not exists (select 1 from CardTransaction t where t.consumerId = c.id and t.programId = :programId
                  and t.type = com.shaminatech.pass.loyalty.card.CardEnums.TransactionType.EARN and t.occurredAt >= :cut
                  and not exists (select 1 from CardTransaction r where r.reversesId = t.id))
            """)
    long countInactiveSince(@Param("establishmentId") Long establishmentId, @Param("programId") Long programId,
                            @Param("cut") java.time.Instant cut);

    @Query("select count(c) > 0 from Consumer c where c.establishment.id = :establishmentId and c.phone = :phone")
    boolean existsPhone(@Param("establishmentId") Long establishmentId, @Param("phone") String phone);

    @Query("select count(c) > 0 from Consumer c where c.establishment.id = :establishmentId and c.email = :email")
    boolean existsEmail(@Param("establishmentId") Long establishmentId, @Param("email") String email);

    @Query("select count(c) > 0 from Consumer c where c.establishment.id = :establishmentId and c.externalRef = :ref")
    boolean existsExternalRef(@Param("establishmentId") Long establishmentId, @Param("ref") String ref);
}
