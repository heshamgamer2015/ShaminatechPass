package com.shaminatech.pass.loyalty.consumer;

import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Subquery;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.common.web.PageResponse;
import com.shaminatech.pass.common.web.Paging;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ConsumerDetail;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ConsumerRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ConsumerUpdateRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ConsumerView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.TransactionView;
import com.shaminatech.pass.loyalty.LoyaltyViews;
import com.shaminatech.pass.loyalty.card.CardCodes;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.CardTransactionRepository;
import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.card.LoyaltyCardRepository;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicy;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.membership.Permission;
import com.shaminatech.pass.tenant.TenantAccess;
import com.shaminatech.pass.tenant.TenantAccessService;
import com.shaminatech.pass.user.EmailNormalizer;

/**
 * Cadastro de consumidores do estabelecimento.
 * <p>
 * Limite de clientes: conta consumidores com cadastro ATIVO (não cartões). Cadastrar ou reativar trava a política
 * do estabelecimento (FOR UPDATE), conta e só então grava — duas requisições simultâneas não ultrapassam o limite.
 * Se o limite for reduzido abaixo do uso atual, os cadastros existentes são preservados e novas ativações são
 * recusadas até o uso voltar ao limite.
 */
@Service
public class ConsumerService {

    public static final Sort BY_NAME = Sort.by("fullName", "id");

    private final TenantAccessService tenantAccess;
    private final ConsumerRepository consumers;
    private final LoyaltyCardRepository cards;
    private final CardTransactionRepository transactions;
    private final PolicyService policies;
    private final LoyaltyViews views;
    private final AuditService audit;
    private final Clock clock;

    public ConsumerService(TenantAccessService tenantAccess, ConsumerRepository consumers, LoyaltyCardRepository cards,
                           CardTransactionRepository transactions, PolicyService policies, LoyaltyViews views,
                           AuditService audit, Clock clock) {
        this.tenantAccess = tenantAccess;
        this.consumers = consumers;
        this.cards = cards;
        this.transactions = transactions;
        this.policies = policies;
        this.views = views;
        this.audit = audit;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public PageResponse<ConsumerView> search(Long establishmentId, String query, Consumer.Status status, Pageable pageable) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        Specification<Consumer> spec = (root, q, cb) -> {
            List<Predicate> and = new ArrayList<>();
            and.add(cb.equal(root.get("establishment").get("id"), establishmentId));
            if (status != null) {
                and.add(cb.equal(root.get("status"), status));
            }
            String like = Paging.likePattern(query);
            if (like != null) {
                List<Predicate> or = new ArrayList<>();
                or.add(cb.like(cb.lower(root.get("fullName")), like));
                or.add(cb.like(cb.lower(root.get("email")), like));
                or.add(cb.equal(cb.lower(root.get("externalRef")), query.trim().toLowerCase(Locale.ROOT)));
                String digits = query.replaceAll("\\D", "");
                if (digits.length() >= 4) {
                    or.add(cb.like(root.get("phone"), "%" + digits + "%"));
                }
                if (query.trim().matches("^#?\\d{1,15}$")) {
                    or.add(cb.equal(root.get("id"), Long.parseLong(query.trim().replace("#", ""))));
                }
                String code = CardCodes.normalize(query);
                if (code != null) {
                    Subquery<Long> byCard = q.subquery(Long.class);
                    var card = byCard.from(LoyaltyCard.class);
                    byCard.select(card.get("consumer").get("id"))
                            .where(cb.equal(card.get("code"), code), cb.equal(card.get("establishmentId"), establishmentId));
                    or.add(root.get("id").in(byCard));
                }
                and.add(cb.or(or.toArray(Predicate[]::new)));
            }
            return cb.and(and.toArray(Predicate[]::new));
        };
        Instant now = clock.instant();
        return PageResponse.of(consumers.findAll(spec, pageable), c -> views.consumer(c, activeCards(establishmentId, c.getId(), now)));
    }

    @Transactional
    public ConsumerView create(Long establishmentId, ConsumerRequest request) {
        TenantAccess access = tenantAccess.require(establishmentId, Permission.CONSUMERS_MANAGE);
        EstablishmentPolicy policy = policies.lock(establishmentId);
        String phone = normalizePhone(request.phone());
        String email = normalizeEmail(request.email());
        String ref = blankToNull(request.externalRef());
        checkDuplicates(establishmentId, null, phone, email, ref);
        requireSlot(establishmentId, policy);
        Consumer consumer = new Consumer(access.establishment(), request.fullName().trim(), phone, clock.instant());
        consumer.setEmail(email);
        consumer.setExternalRef(ref);
        consumer.setMarketingOptIn(Boolean.TRUE.equals(request.marketingOptIn()));
        consumers.save(consumer);
        audit.record(AuditAction.CONSUMER_CREATED, establishmentId, "CONSUMER", consumer.getId(), null);
        return views.consumer(consumer, 0);
    }

    @Transactional(readOnly = true)
    public ConsumerDetail get(Long establishmentId, Long consumerId) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        Consumer consumer = find(establishmentId, consumerId);
        var zone = policies.of(establishmentId).zone();
        var cardViews = cards.findByConsumer(establishmentId, consumerId).stream().map(c -> views.card(c, zone)).toList();
        int active = (int) cardViews.stream().filter(c -> c.status() == CardStatus.ACTIVE).count();
        return new ConsumerDetail(views.consumer(consumer, active), cardViews);
    }

    @Transactional
    public ConsumerView update(Long establishmentId, Long consumerId, ConsumerUpdateRequest request) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_MANAGE);
        Consumer consumer = find(establishmentId, consumerId);
        String phone = normalizePhone(request.phone());
        String email = normalizeEmail(request.email());
        String ref = blankToNull(request.externalRef());
        checkDuplicates(establishmentId, consumer, phone, email, ref);
        consumer.setFullName(request.fullName().trim());
        consumer.setPhone(phone);
        consumer.setEmail(email);
        consumer.setExternalRef(ref);
        consumer.setMarketingOptIn(Boolean.TRUE.equals(request.marketingOptIn()));
        audit.record(AuditAction.CONSUMER_UPDATED, establishmentId, "CONSUMER", consumerId, null);
        return views.consumer(consumer, activeCards(establishmentId, consumerId, clock.instant()));
    }

    /** Desativar libera a vaga; reativar ocupa uma vaga e respeita o limite. Cartões não são alterados. */
    @Transactional
    public ConsumerView changeStatus(Long establishmentId, Long consumerId, Consumer.Status status) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_MANAGE);
        EstablishmentPolicy policy = policies.lock(establishmentId);
        Consumer consumer = consumers.lockInEstablishment(establishmentId, consumerId)
                .orElseThrow(() -> ApiException.notFound("Cliente não encontrado."));
        if (consumer.getStatus() != status) {
            if (status == Consumer.Status.ACTIVE) {
                requireSlot(establishmentId, policy);
            }
            Consumer.Status previous = consumer.getStatus();
            consumer.changeStatus(status, clock.instant());
            audit.record(AuditAction.CONSUMER_STATUS_CHANGED, establishmentId, "CONSUMER", consumerId, previous + "->" + status);
        }
        return views.consumer(consumer, activeCards(establishmentId, consumerId, clock.instant()));
    }

    @Transactional(readOnly = true)
    public PageResponse<TransactionView> history(Long establishmentId, Long consumerId, Pageable pageable) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        find(establishmentId, consumerId);
        var page = transactions.findByConsumer(establishmentId, consumerId, pageable);
        var content = views.transactions(page.getContent());
        return new PageResponse<>(content, page.getNumber(), page.getSize(), page.getTotalElements(), page.getTotalPages());
    }

    /** Há vaga para mais um cliente ativo? A política deve estar travada (FOR UPDATE) pelo chamador. */
    public boolean hasSlot(Long establishmentId, EstablishmentPolicy policy) {
        return consumers.countByStatus(establishmentId, Consumer.Status.ACTIVE) < policy.getMaxActiveConsumers();
    }

    private void requireSlot(Long establishmentId, EstablishmentPolicy policy) {
        long active = consumers.countByStatus(establishmentId, Consumer.Status.ACTIVE);
        if (active >= policy.getMaxActiveConsumers()) {
            throw ApiException.state("CONSUMER_LIMIT_REACHED", "O limite de " + policy.getMaxActiveConsumers()
                    + " clientes ativos foi atingido. Desative cadastros sem uso ou fale com a ShaminaTech para ampliar o limite.");
        }
    }

    private void checkDuplicates(Long establishmentId, Consumer current, String phone, String email, String ref) {
        if ((current == null || !phone.equals(current.getPhone())) && consumers.existsPhone(establishmentId, phone)) {
            throw ApiException.conflict("Já existe um cliente com este telefone (verifique também os inativos).", "phone");
        }
        if (email != null && (current == null || !email.equals(current.getEmail()))
                && consumers.existsEmail(establishmentId, email)) {
            throw ApiException.conflict("Já existe um cliente com este e-mail.", "email");
        }
        if (ref != null && (current == null || !ref.equals(current.getExternalRef()))
                && consumers.existsExternalRef(establishmentId, ref)) {
            throw ApiException.conflict("Já existe um cliente com este código.", "externalRef");
        }
    }

    private int activeCards(Long establishmentId, Long consumerId, Instant now) {
        return (int) cards.findByConsumer(establishmentId, consumerId).stream()
                .filter(c -> c.effectiveStatus(now) == CardStatus.ACTIVE).count();
    }

    private Consumer find(Long establishmentId, Long consumerId) {
        return consumers.findInEstablishment(establishmentId, consumerId)
                .orElseThrow(() -> ApiException.notFound("Cliente não encontrado."));
    }

    /** Telefone: somente dígitos, de 10 a 13 (DDD + número, com DDI opcional). */
    public static String normalizePhone(String raw) {
        String digits = raw == null ? "" : raw.replaceAll("\\D", "");
        if (digits.length() < 10 || digits.length() > 13) {
            throw ApiException.badRequest("Informe o telefone com DDD (10 a 13 dígitos).", "phone");
        }
        return digits;
    }

    public static String normalizeEmail(String raw) {
        return raw == null || raw.isBlank() ? null : EmailNormalizer.normalize(raw);
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
