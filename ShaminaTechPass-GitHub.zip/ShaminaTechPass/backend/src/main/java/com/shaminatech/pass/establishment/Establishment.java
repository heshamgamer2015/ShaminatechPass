package com.shaminatech.pass.establishment;

import com.shaminatech.pass.common.persistence.BaseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/** Tenant da plataforma: cada estabelecimento possui seus próprios dados. */
@Entity
@Table(name = "establishment", uniqueConstraints = @UniqueConstraint(name = "uk_establishment_slug", columnNames = "slug"))
public class Establishment extends BaseEntity {

    @Column(nullable = false, length = 150)
    private String name;

    @Column(nullable = false, length = 80)
    private String slug;

    @Column(nullable = false, length = 20)
    private EstablishmentStatus status = EstablishmentStatus.ACTIVE;

    @Column(name = "contact_email", length = 254)
    private String contactEmail;

    @Column(name = "contact_phone", length = 30)
    private String contactPhone;

    protected Establishment() {
    }

    public Establishment(String name, String slug) {
        this.name = name;
        this.slug = slug;
    }

    public boolean isActive() {
        return status == EstablishmentStatus.ACTIVE;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSlug() {
        return slug;
    }

    public EstablishmentStatus getStatus() {
        return status;
    }

    public void setStatus(EstablishmentStatus status) {
        this.status = status;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }
}
