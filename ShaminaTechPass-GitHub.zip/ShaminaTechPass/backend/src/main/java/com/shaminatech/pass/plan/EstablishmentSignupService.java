package com.shaminatech.pass.plan;

import java.security.SecureRandom;
import java.text.Normalizer;
import java.time.Clock;
import java.time.Instant;
import java.util.HexFormat;
import java.util.Locale;

import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.common.web.ClientIp;
import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.establishment.EstablishmentRepository;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.signup.SignupGuard;
import com.shaminatech.pass.membership.Membership;
import com.shaminatech.pass.membership.MembershipRepository;
import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.security.PasswordPolicy;
import com.shaminatech.pass.user.AppUser;
import com.shaminatech.pass.user.AppUserRepository;
import com.shaminatech.pass.user.EmailNormalizer;

/**
 * Autocadastro público de estabelecimentos: cria, numa <b>única transação</b>, o estabelecimento, a política (padrões
 * da plataforma), a conta empresarial (dono), o vínculo OWNER e o plano escolhido. Se qualquer passo falhar, nada fica
 * gravado (sem estabelecimento órfão nem usuário sem vínculo).
 * <p>
 * Segurança:
 * <ul>
 *   <li>a conta criada é sempre uma conta empresarial comum, dona só do estabelecimento novo: o pedido não tem nenhum
 *       campo de papel ou permissão, e o papel é fixado aqui (nunca administrador da plataforma);</li>
 *   <li>e-mail já usado é recusado (nunca vincula o estabelecimento a uma conta existente); duplicidade simultânea é
 *       barrada pela restrição única do PostgreSQL ({@code uk_app_user_email}) e desfaz a transação inteira;</li>
 *   <li>plano validado no servidor: Growth e Pro só fora da cobrança, durante a fase de testes;</li>
 *   <li>limite de tentativas por IP (janela de 1 hora) além do limite geral por minuto de {@code /api/public/**}.</li>
 * </ul>
 */
@Service
public class EstablishmentSignupService {

    private static final SecureRandom RANDOM = new SecureRandom();

    private final EstablishmentRepository establishments;
    private final AppUserRepository users;
    private final MembershipRepository memberships;
    private final PolicyService policies;
    private final PlanService plans;
    private final PlanProperties properties;
    private final PasswordEncoder passwordEncoder;
    private final SignupGuard guard;
    private final AuditService audit;
    private final Clock clock;

    public EstablishmentSignupService(EstablishmentRepository establishments, AppUserRepository users, MembershipRepository memberships,
                                      PolicyService policies, PlanService plans, PlanProperties properties,
                                      PasswordEncoder passwordEncoder, SignupGuard guard, AuditService audit, Clock clock) {
        this.establishments = establishments;
        this.users = users;
        this.memberships = memberships;
        this.policies = policies;
        this.plans = plans;
        this.properties = properties;
        this.passwordEncoder = passwordEncoder;
        this.guard = guard;
        this.audit = audit;
        this.clock = clock;
    }

    public record Created(Long establishmentId, String email, Plan plan, boolean trialFree) {
    }

    @Transactional
    public Created register(PlanDtos.SignupRequest request) {
        guard.countAttempt("empresa:" + ClientIp.current());
        if (!properties.selfSignupEnabled()) {
            throw new ApiException(HttpStatus.FORBIDDEN, "SELF_SIGNUP_DISABLED",
                    "O cadastro de novos estabelecimentos está fechado no momento. Fale com a ShaminaTech.");
        }
        if (request.website() != null && !request.website().isBlank()) {
            throw ApiException.badRequest("Não foi possível concluir o cadastro. Recarregue a página e tente novamente.", null);
        }
        Plan plan = parsePlan(request.plan());
        if (!plans.selectable(plan)) {
            throw ApiException.badRequest("Este plano ainda não pode ser contratado pelo site. Escolha o Free ou fale com a ShaminaTech.", "plan");
        }
        if (!request.password().equals(request.passwordConfirmation())) {
            throw ApiException.badRequest("As senhas não conferem.", "passwordConfirmation");
        }
        PasswordPolicy.violation(request.password()).ifPresent(message -> {
            throw ApiException.badRequest(message, "password");
        });
        String email = EmailNormalizer.normalize(request.email());
        if (users.findByEmail(email).isPresent()) {
            throw emailUnavailable();
        }
        Instant now = clock.instant();

        Establishment establishment = new Establishment(request.establishmentName().trim(), newSlug(request.establishmentName()));
        establishment.setContactEmail(blankToNull(request.contactEmail()) == null ? email : EmailNormalizer.normalize(request.contactEmail()));
        establishment.setContactPhone(blankToNull(request.contactPhone()));
        establishment = establishments.save(establishment);
        policies.createFor(establishment);

        // Conta empresarial comum (nunca administradora da plataforma); a senha foi escolhida pela pessoa.
        AppUser owner = users.saveAndFlush(new AppUser(email, request.ownerName().trim(), passwordEncoder.encode(request.password()), false));
        Membership membership = memberships.save(new Membership(establishment, owner, MembershipRole.OWNER));
        EstablishmentPlan chosen = plans.assign(establishment, plan, EstablishmentPlan.Origin.SELF_SIGNUP, now);

        audit.record(AuditAction.ESTABLISHMENT_SELF_REGISTERED, establishment.getId(), "ESTABLISHMENT", establishment.getId(),
                "slug=" + establishment.getSlug() + " plano=" + plan.name() + (properties.trialFree() ? " fase-de-testes" : ""));
        audit.record(AuditAction.USER_CREATED, establishment.getId(), "USER", owner.getId(), "autocadastro");
        audit.record(AuditAction.MEMBER_ADDED, establishment.getId(), "MEMBERSHIP", membership.getId(), "conta empresarial, autocadastro");
        return new Created(establishment.getId(), email, plan, chosen.isTrialFree());
    }

    static ApiException emailUnavailable() {
        return ApiException.conflict("Não foi possível criar a conta com este e-mail. Se você já tem acesso ao ShaminaTech Pass, "
                + "entre com ele ou use “Esqueci minha senha”.", "email");
    }

    private static Plan parsePlan(String value) {
        try {
            return Plan.valueOf(value == null ? "" : value.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            throw ApiException.badRequest("Escolha um plano.", "plan");
        }
    }

    /** Identificador gerado no servidor a partir do nome (+ sufixo aleatório): o visitante não escolhe nem descobre slugs. */
    private String newSlug(String name) {
        String base = Normalizer.normalize(name, Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", "-").replaceAll("(^-+|-+$)", "");
        if (base.length() > 60) {
            base = base.substring(0, 60).replaceAll("-+$", "");
        }
        if (base.length() < 2) {
            base = "estabelecimento";
        }
        String slug;
        do {
            byte[] bytes = new byte[3];
            RANDOM.nextBytes(bytes);
            slug = base + "-" + HexFormat.of().formatHex(bytes);
        } while (establishments.existsBySlug(slug));
        return slug;
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
