package com.shaminatech.pass.membership;

import com.shaminatech.pass.common.persistence.EnumNameConverter;

import jakarta.persistence.Converter;

public enum MembershipStatus {
    ACTIVE,
    DISABLED;

    @Converter(autoApply = true)
    public static class JpaConverter extends EnumNameConverter<MembershipStatus> {
        public JpaConverter() {
            super(MembershipStatus.class);
        }
    }
}
