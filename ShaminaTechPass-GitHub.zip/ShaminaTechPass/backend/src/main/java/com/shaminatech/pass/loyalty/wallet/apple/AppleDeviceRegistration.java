package com.shaminatech.pass.loyalty.wallet.apple;

import java.time.Instant;

import com.shaminatech.pass.common.persistence.BaseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Aparelho (iPhone/Apple Watch) que registrou um passe para receber atualizações. Criado pelo próprio Apple Wallet
 * via web service, sempre autenticado pelo token do passe. O push token só serve para notificar o aparelho de que
 * há uma versão nova — não dá acesso a nada.
 */
@Entity
@Table(name = "apple_device_registration",
        uniqueConstraints = @UniqueConstraint(name = "uk_apple_device_pass", columnNames = {"device_library_id", "wallet_pass_id"}),
        indexes = {
                @Index(name = "idx_apple_device_pass", columnList = "wallet_pass_id"),
                @Index(name = "idx_apple_device_library", columnList = "device_library_id")})
public class AppleDeviceRegistration extends BaseEntity {

    @Column(name = "establishment_id", nullable = false)
    private Long establishmentId;

    @Column(name = "wallet_pass_id", nullable = false)
    private Long walletPassId;

    @Column(name = "device_library_id", nullable = false, length = 128)
    private String deviceLibraryId;

    @Column(name = "push_token", nullable = false, length = 200)
    private String pushToken;

    @Column(name = "last_push_at")
    private Instant lastPushAt;

    protected AppleDeviceRegistration() {
    }

    public AppleDeviceRegistration(Long establishmentId, Long walletPassId, String deviceLibraryId, String pushToken) {
        this.establishmentId = establishmentId;
        this.walletPassId = walletPassId;
        this.deviceLibraryId = deviceLibraryId;
        this.pushToken = pushToken;
    }

    public void updatePushToken(String token) {
        this.pushToken = token;
    }

    public void pushed(Instant now) {
        this.lastPushAt = now;
    }

    public Long getEstablishmentId() { return establishmentId; }
    public Long getWalletPassId() { return walletPassId; }
    public String getDeviceLibraryId() { return deviceLibraryId; }
    public String getPushToken() { return pushToken; }
    public Instant getLastPushAt() { return lastPushAt; }
}
