package com.shaminatech.pass.loyalty.card;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

import jakarta.persistence.criteria.Predicate;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.common.web.PageResponse;
import com.shaminatech.pass.common.web.Paging;
import com.shaminatech.pass.loyalty.LoyaltyDtos.CardDetail;
import com.shaminatech.pass.loyalty.LoyaltyDtos.CardView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.EarnRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.IssueCardRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.OperationResult;
import com.shaminatech.pass.loyalty.LoyaltyDtos.RedeemRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.TransactionView;
import com.shaminatech.pass.loyalty.LoyaltyViews;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.CardEnums.TransactionType;
import com.shaminatech.pass.loyalty.consumer.Consumer;
import com.shaminatech.pass.loyalty.consumer.ConsumerRepository;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.LoyaltyRewardRepository;
import com.shaminatech.pass.loyalty.program.ProgramService;
import com.shaminatech.pass.membership.Permission;
import com.shaminatech.pass.security.CurrentUser;
import com.shaminatech.pass.tenant.TenantAccessService;

/** Camada do painel sobre o {@link CardEngine}: autorização do tenant, consultas e auditoria. */
@Service
public class CardService {

    private final TenantAccessService tenantAccess;
    private final CardEngine engine;
    private final LoyaltyCardRepository cards;
    private final CardTransactionRepository transactions;
    private final BenefitLotRepository lots;
    private final ConsumerRepository consumers;
    private final LoyaltyRewardRepository rewards;
    private final ProgramService programs;
    private final PolicyService policies;
    private final LoyaltyViews views;
    private final AuditService audit;
    private final java.time.Clock clock;

    public CardService(TenantAccessService tenantAccess, CardEngine engine, LoyaltyCardRepository cards,
                       CardTransactionRepository transactions, BenefitLotRepository lots, ConsumerRepository consumers,
                       LoyaltyRewardRepository rewards, ProgramService programs, PolicyService policies, LoyaltyViews views,
                       AuditService audit, java.time.Clock clock) {
        this.clock = clock;
        this.tenantAccess = tenantAccess;
        this.engine = engine;
        this.cards = cards;
        this.transactions = transactions;
        this.lots = lots;
        this.consumers = consumers;
        this.rewards = rewards;
        this.programs = programs;
        this.policies = policies;
        this.views = views;
        this.audit = audit;
    }

    @Transactional
    public CardView issue(Long establishmentId, IssueCardRequest request) {
        tenantAccess.require(establishmentId, Permission.CARDS_MANAGE);
        // Trava o consumidor: duas emissões simultâneas para o mesmo cliente/programa não geram dois cartões.
        Consumer consumer = consumers.lockInEstablishment(establishmentId, request.consumerId())
                .orElseThrow(() -> ApiException.notFound("Cliente não encontrado."));
        LoyaltyProgram program = programs.find(establishmentId, request.programId());
        if (!program.isActive()) {
            throw ApiException.state("PROGRAM_NOT_ACTIVE", "Este programa está pausado ou encerrado.");
        }
        LoyaltyCard card = engine.issue(consumer, program, request.inactivityDaysOverride(), actor());
        audit.record(AuditAction.CARD_ISSUED, establishmentId, "CARD", card.getId(), "programa=" + program.getId());
        return views.card(card, zone(establishmentId));
    }

    @Transactional(readOnly = true)
    public PageResponse<CardView> list(Long establishmentId, CardStatus status, Long programId, String query, Pageable pageable) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        java.time.Instant now = clock.instant();
        Specification<LoyaltyCard> spec = (root, q, cb) -> {
            List<Predicate> and = new ArrayList<>();
            and.add(cb.equal(root.get("establishmentId"), establishmentId));
            if (programId != null) {
                and.add(cb.equal(root.get("program").get("id"), programId));
            }
            if (status == CardStatus.EXPIRED) {
                // inclui cartões vencidos pela data ainda não marcados pelo processamento
                and.add(cb.or(cb.equal(root.get("status"), CardStatus.EXPIRED),
                        cb.and(root.get("status").in(CardStatus.ACTIVE, CardStatus.SUSPENDED),
                                cb.lessThanOrEqualTo(root.get("expiresAt"), now))));
            } else if (status == CardStatus.ACTIVE || status == CardStatus.SUSPENDED) {
                and.add(cb.equal(root.get("status"), status));
                and.add(cb.greaterThan(root.get("expiresAt"), now));
            } else if (status != null) {
                and.add(cb.equal(root.get("status"), status));
            }
            String like = Paging.likePattern(query);
            if (like != null) {
                String code = CardCodes.normalize(query);
                var consumer = root.join("consumer");
                List<Predicate> or = new ArrayList<>();
                or.add(cb.like(cb.lower(consumer.get("fullName")), like));
                String digits = query.replaceAll("\\D", "");
                if (digits.length() >= 4) {
                    or.add(cb.like(consumer.get("phone"), "%" + digits + "%"));
                }
                if (code != null) {
                    or.add(cb.equal(root.get("code"), code));
                }
                and.add(cb.or(or.toArray(Predicate[]::new)));
            }
            return cb.and(and.toArray(Predicate[]::new));
        };
        ZoneId zone = zone(establishmentId);
        return PageResponse.of(cards.findAll(spec, pageable), c -> views.card(c, zone));
    }

    @Transactional(readOnly = true)
    public CardDetail get(Long establishmentId, Long cardId) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        LoyaltyCard card = find(establishmentId, cardId);
        return detail(card, zone(establishmentId));
    }

    /**
     * Modo leitura: identifica o cartão pelo código lido no QR Code / código de barras. Apenas consulta;
     * nenhuma concessão acontece sem a confirmação explícita da empresa em uma segunda requisição autenticada.
     */
    @Transactional(readOnly = true)
    public CardDetail lookup(Long establishmentId, String rawCode) {
        tenantAccess.require(establishmentId, Permission.TRANSACTIONS_REGISTER);
        String code = CardCodes.normalize(rawCode);
        if (code == null) {
            throw ApiException.badRequest("Código de cartão inválido.", "code");
        }
        LoyaltyCard card = cards.findByCode(establishmentId, code)
                .orElseThrow(() -> ApiException.notFound("Nenhum cartão deste estabelecimento tem este código."));
        return detail(card, zone(establishmentId));
    }

    @Transactional
    public CardView suspend(Long establishmentId, Long cardId, String reason) {
        tenantAccess.require(establishmentId, Permission.CARDS_MANAGE);
        LoyaltyCard card = engine.suspend(establishmentId, cardId, reason, actor());
        audit.record(AuditAction.CARD_STATUS_CHANGED, establishmentId, "CARD", cardId, "->SUSPENDED");
        return views.card(card, zone(establishmentId));
    }

    @Transactional
    public CardView reactivate(Long establishmentId, Long cardId, String reason) {
        tenantAccess.require(establishmentId, Permission.CARDS_MANAGE);
        LoyaltyCard card = engine.reactivate(establishmentId, cardId, reason, actor());
        audit.record(AuditAction.CARD_STATUS_CHANGED, establishmentId, "CARD", cardId, "->ACTIVE (reativação)");
        return views.card(card, zone(establishmentId));
    }

    @Transactional
    public CardView cancel(Long establishmentId, Long cardId, String reason) {
        tenantAccess.require(establishmentId, Permission.CARDS_MANAGE);
        LoyaltyCard card = engine.cancel(establishmentId, cardId, reason, actor());
        audit.record(AuditAction.CARD_STATUS_CHANGED, establishmentId, "CARD", cardId, "->CANCELLED");
        return views.card(card, zone(establishmentId));
    }

    @Transactional
    public OperationResult earn(Long establishmentId, Long cardId, EarnRequest request, String idempotencyKey) {
        tenantAccess.require(establishmentId, Permission.TRANSACTIONS_REGISTER);
        var result = engine.earn(establishmentId, cardId,
                new CardEngine.EarnCommand(request.purchaseAmount(), request.quantity(), request.channel(), request.note()),
                idempotencyKey, actor());
        return toResult(result, establishmentId);
    }

    @Transactional
    public OperationResult redeem(Long establishmentId, Long cardId, RedeemRequest request, String idempotencyKey) {
        tenantAccess.require(establishmentId, Permission.TRANSACTIONS_REGISTER);
        var result = engine.redeem(establishmentId, cardId,
                new CardEngine.RedeemCommand(request.rewardId(), request.amount(), request.purchaseAmount(), request.channel(),
                        request.note()), idempotencyKey, actor());
        return toResult(result, establishmentId);
    }

    @Transactional
    public OperationResult reverse(Long establishmentId, Long transactionId, String reason, String idempotencyKey) {
        tenantAccess.require(establishmentId, Permission.TRANSACTIONS_REVERSE);
        var result = engine.reverse(establishmentId, transactionId, reason, idempotencyKey, actor());
        if (!result.replayed()) {
            audit.record(AuditAction.TRANSACTION_REVERSED, establishmentId, "CARD_TRANSACTION", transactionId,
                    "estorno=" + result.transaction().getId());
        }
        return toResult(result, establishmentId);
    }

    @Transactional(readOnly = true)
    public PageResponse<TransactionView> cardHistory(Long establishmentId, Long cardId, Pageable pageable) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        find(establishmentId, cardId);
        var page = transactions.findByCard(establishmentId, cardId, pageable);
        return new PageResponse<>(views.transactions(page.getContent()), page.getNumber(), page.getSize(),
                page.getTotalElements(), page.getTotalPages());
    }

    /** Histórico do estabelecimento; {@code movementsOnly} limita a concessões, resgates, estornos e vencimentos. */
    @Transactional(readOnly = true)
    public PageResponse<TransactionView> history(Long establishmentId, Set<TransactionType> types, Pageable pageable) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        Set<TransactionType> filter = types == null || types.isEmpty() ? EnumSet.allOf(TransactionType.class) : types;
        var page = transactions.findInEstablishment(establishmentId, filter, pageable);
        return new PageResponse<>(views.transactions(page.getContent()), page.getNumber(), page.getSize(),
                page.getTotalElements(), page.getTotalPages());
    }

    private CardDetail detail(LoyaltyCard card, ZoneId zone) {
        LoyaltyProgram program = card.getProgram();
        var rewardViews = program.getType() == ProgramType.POINTS
                ? rewards.findByProgram(card.getEstablishmentId(), program.getId()).stream().filter(r -> r.isActive())
                .map(views::reward).toList()
                : List.<com.shaminatech.pass.loyalty.LoyaltyDtos.RewardView>of();
        return new CardDetail(views.card(card, zone), lots.findByCard(card.getId()).stream().limit(50).map(views::lot).toList(),
                rewardViews, views.design(program), program.getDescription());
    }

    private OperationResult toResult(CardEngine.Result result, Long establishmentId) {
        return new OperationResult(views.transactions(List.of(result.transaction())).get(0),
                views.card(result.card(), zone(establishmentId)), result.replayed(), result.notRestored());
    }

    private LoyaltyCard find(Long establishmentId, Long cardId) {
        return cards.findInEstablishment(establishmentId, cardId).orElseThrow(() -> ApiException.notFound("Cartão não encontrado."));
    }

    private ZoneId zone(Long establishmentId) {
        return policies.of(establishmentId).zone();
    }

    private static Long actor() {
        return CurrentUser.require().getId();
    }
}
