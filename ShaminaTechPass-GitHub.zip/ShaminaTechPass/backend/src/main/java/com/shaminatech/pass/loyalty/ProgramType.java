package com.shaminatech.pass.loyalty;

import java.util.EnumSet;
import java.util.Set;
import java.util.stream.Collectors;

import com.shaminatech.pass.common.persistence.EnumNameConverter;

import jakarta.persistence.Converter;

/** Tipos de programa de fidelidade. {@code operational=false}: modelagem pronta, motor ainda não liberado. */
public enum ProgramType {
    POINTS(true),
    CASHBACK(true),
    STAMPS(true),
    /** Níveis VIP: cadastro de níveis e benefícios disponível; progressão automática ainda não operacional. */
    VIP(false);

    private final boolean operational;

    ProgramType(boolean operational) {
        this.operational = operational;
    }

    public boolean isOperational() {
        return operational;
    }

    /** Serializa um conjunto como "POINTS,STAMPS" (ordem do enum). */
    public static String join(Set<ProgramType> types) {
        return types.stream().sorted().map(Enum::name).collect(Collectors.joining(","));
    }

    /** Lê o formato de {@link #join}; valores desconhecidos são ignorados. */
    public static Set<ProgramType> parse(String value) {
        Set<ProgramType> result = EnumSet.noneOf(ProgramType.class);
        if (value == null || value.isBlank()) {
            return result;
        }
        for (String part : value.split(",")) {
            try {
                result.add(ProgramType.valueOf(part.trim()));
            } catch (IllegalArgumentException ignored) {
                // valor gravado por outra versão: ignorado
            }
        }
        return result;
    }

    @Converter(autoApply = true)
    public static class JpaConverter extends EnumNameConverter<ProgramType> {
        public JpaConverter() {
            super(ProgramType.class);
        }
    }
}
