package com.shaminatech.pass.loyalty.program;

import java.math.BigDecimal;

import com.shaminatech.pass.common.persistence.BaseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/** Recompensa resgatável com pontos. Nunca é apagada: é desativada, preservando o histórico de resgates. */
@Entity
@Table(name = "loyalty_reward", indexes = @Index(name = "idx_loyalty_reward_program", columnList = "program_id"))
public class LoyaltyReward extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "program_id", nullable = false, foreignKey = @ForeignKey(name = "fk_loyalty_reward_program"))
    private LoyaltyProgram program;

    @Column(name = "establishment_id", nullable = false)
    private Long establishmentId;

    @Column(nullable = false, length = 80)
    private String name;

    @Column(length = 300)
    private String description;

    /** Custo em pontos. */
    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal cost;

    @Column(nullable = false)
    private boolean active = true;

    protected LoyaltyReward() {
    }

    public LoyaltyReward(LoyaltyProgram program, String name, BigDecimal cost) {
        this.program = program;
        this.establishmentId = program.getEstablishmentId();
        this.name = name;
        this.cost = cost;
    }

    public LoyaltyProgram getProgram() { return program; }
    public Long getEstablishmentId() { return establishmentId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public BigDecimal getCost() { return cost; }
    public void setCost(BigDecimal cost) { this.cost = cost; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}
