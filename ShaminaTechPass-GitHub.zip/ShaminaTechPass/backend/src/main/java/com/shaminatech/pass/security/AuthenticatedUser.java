package com.shaminatech.pass.security;

import java.io.Serial;
import java.time.Instant;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.CredentialsContainer;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.shaminatech.pass.user.AppUser;
import com.shaminatech.pass.user.PlatformRole;

/**
 * Principal guardado na sessão. Contém apenas dados de identidade: permissões por
 * estabelecimento são sempre consultadas no banco, para que revogações valham na hora.
 */
public final class AuthenticatedUser implements UserDetails, CredentialsContainer {

    @Serial
    private static final long serialVersionUID = 1L;

    public static final String ROLE_PLATFORM_ADMIN = "ROLE_PLATFORM_ADMIN";

    private final Long id;
    private final String email;
    private final String fullName;
    private final PlatformRole platformRole;
    private final boolean enabled;
    private final boolean locked;
    private String passwordHash;
    /**
     * Marca da credencial vigente no login (SHA-256 do hash da senha — nunca o hash em si). Se a senha mudar, a
     * marca deixa de bater e a sessão é encerrada pelo {@link SessionUserRevalidationFilter}.
     */
    private final String credentialStamp;

    private AuthenticatedUser(Long id, String email, String fullName, PlatformRole platformRole,
                              boolean enabled, boolean locked, String passwordHash) {
        this.id = id;
        this.email = email;
        this.fullName = fullName;
        this.platformRole = platformRole;
        this.enabled = enabled;
        this.locked = locked;
        this.passwordHash = passwordHash;
        this.credentialStamp = stampOf(passwordHash);
    }

    /** Marca irreversível da credencial: muda sempre que o hash da senha muda. */
    public static String stampOf(String passwordHash) {
        if (passwordHash == null) {
            return null;
        }
        try {
            byte[] digest = java.security.MessageDigest.getInstance("SHA-256")
                    .digest(passwordHash.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            return java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(digest);
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    public String getCredentialStamp() {
        return credentialStamp;
    }

    public static AuthenticatedUser from(AppUser user, Instant now) {
        return new AuthenticatedUser(user.getId(), user.getEmail(), user.getFullName(), user.getPlatformRole(),
                user.isActive(), user.isLocked(now), user.getPasswordHash());
    }

    public Long getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getFullName() {
        return fullName;
    }

    public PlatformRole getPlatformRole() {
        return platformRole;
    }

    public boolean isPlatformAdmin() {
        return platformRole == PlatformRole.PLATFORM_ADMIN;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return isPlatformAdmin() ? List.of(new SimpleGrantedAuthority(ROLE_PLATFORM_ADMIN)) : List.of();
    }

    @Override
    public String getPassword() {
        return passwordHash;
    }

    @Override
    public String getUsername() {
        return email;
    }

    @Override
    public boolean isAccountNonLocked() {
        return !locked;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public void eraseCredentials() {
        passwordHash = null;
    }
}
