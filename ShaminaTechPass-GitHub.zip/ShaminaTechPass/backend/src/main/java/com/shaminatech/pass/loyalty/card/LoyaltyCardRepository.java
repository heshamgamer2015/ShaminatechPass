package com.shaminatech.pass.loyalty.card;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;

import jakarta.persistence.LockModeType;

/** Toda busca de cartão exige o estabelecimento (isolamento por tenant). */
public interface LoyaltyCardRepository extends JpaRepository<LoyaltyCard, Long>, JpaSpecificationExecutor<LoyaltyCard> {

    @Query("""
            select c from LoyaltyCard c join fetch c.consumer join fetch c.program
            where c.id = :id and c.establishmentId = :establishmentId
            """)
    Optional<LoyaltyCard> findInEstablishment(@Param("establishmentId") Long establishmentId, @Param("id") Long id);

    /** Trava o cartão (SELECT ... FOR UPDATE): serializa movimentações concorrentes do mesmo cartão. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select c from LoyaltyCard c where c.id = :id and c.establishmentId = :establishmentId")
    Optional<LoyaltyCard> lockInEstablishment(@Param("establishmentId") Long establishmentId, @Param("id") Long id);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select c from LoyaltyCard c where c.id = :id")
    Optional<LoyaltyCard> lockById(@Param("id") Long id);

    @Query("""
            select c from LoyaltyCard c join fetch c.consumer join fetch c.program
            where c.code = :code and c.establishmentId = :establishmentId
            """)
    Optional<LoyaltyCard> findByCode(@Param("establishmentId") Long establishmentId, @Param("code") String code);

    @Query("""
            select c from LoyaltyCard c join fetch c.program
            where c.consumer.id = :consumerId and c.establishmentId = :establishmentId
            order by c.issuedAt desc
            """)
    List<LoyaltyCard> findByConsumer(@Param("establishmentId") Long establishmentId, @Param("consumerId") Long consumerId);

    @Query("""
            select count(c) > 0 from LoyaltyCard c
            where c.consumer.id = :consumerId and c.program.id = :programId and c.status in :statuses
            """)
    boolean existsOpenCard(@Param("consumerId") Long consumerId, @Param("programId") Long programId,
                           @Param("statuses") Collection<CardStatus> statuses);

    boolean existsByCode(String code);

    /** Cartões ativos e dentro da validade do programa com saldo a partir de um valor (clientes perto da recompensa). */
    @Query("""
            select c from LoyaltyCard c join fetch c.consumer join fetch c.program
            where c.establishmentId = :establishmentId and c.program.id = :programId
              and c.status = com.shaminatech.pass.loyalty.card.CardEnums.CardStatus.ACTIVE and c.expiresAt > :now
              and c.balance >= :threshold
            order by c.balance desc, c.id
            """)
    List<LoyaltyCard> findWithBalanceAtLeast(@Param("establishmentId") Long establishmentId, @Param("programId") Long programId,
                                             @Param("threshold") java.math.BigDecimal threshold, @Param("now") Instant now,
                                             Pageable pageable);

    /** Cartões vencidos por inatividade ainda não marcados como EXPIRED. */
    @Query("""
            select c.id from LoyaltyCard c
            where c.status in (com.shaminatech.pass.loyalty.card.CardEnums.CardStatus.ACTIVE,
                               com.shaminatech.pass.loyalty.card.CardEnums.CardStatus.SUSPENDED)
              and c.expiresAt <= :now
            order by c.expiresAt, c.id
            """)
    List<Long> findOverdueIds(@Param("now") Instant now, Pageable pageable);

    @Query("select c.status, count(c) from LoyaltyCard c where c.establishmentId = :establishmentId group by c.status")
    List<Object[]> countByStatus(@Param("establishmentId") Long establishmentId);

    /** Cartões ACTIVE já vencidos (contados como expirados nos indicadores, mesmo antes do processamento). */
    @Query("""
            select count(c) from LoyaltyCard c where c.establishmentId = :establishmentId
              and c.status = com.shaminatech.pass.loyalty.card.CardEnums.CardStatus.ACTIVE and c.expiresAt <= :now
            """)
    long countOverdueActive(@Param("establishmentId") Long establishmentId, @Param("now") Instant now);

    @Query("""
            select c.establishmentId, c.status, count(c) from LoyaltyCard c
            where c.establishmentId in :ids group by c.establishmentId, c.status
            """)
    List<Object[]> countByEstablishmentAndStatus(@Param("ids") Collection<Long> ids);
}
