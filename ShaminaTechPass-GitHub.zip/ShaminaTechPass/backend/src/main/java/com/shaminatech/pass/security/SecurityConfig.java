package com.shaminatech.pass.security;

import java.time.Clock;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.intercept.AuthorizationFilter;
import org.springframework.security.web.authentication.logout.HttpStatusReturningLogoutSuccessHandler;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfTokenRepository;

import com.shaminatech.pass.user.AppUserRepository;

/**
 * Segurança da API:
 * <ul>
 *   <li>sessão no servidor com cookie HttpOnly (sem token no localStorage);</li>
 *   <li>CSRF obrigatório em requisições que alteram dados (cookie XSRF-TOKEN + cabeçalho X-XSRF-TOKEN, padrão do Angular);</li>
 *   <li>/api/admin/** apenas para administradores da plataforma;</li>
 *   <li>endpoints de estabelecimento exigem vínculo e permissão, verificados no serviço ({@code TenantAccessService});</li>
 *   <li>tudo que não está mapeado é negado.</li>
 * </ul>
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    public static final String SESSION_COOKIE = "STPASS_SESSION";

    @Bean
    Clock clock() {
        return Clock.systemUTC();
    }

    @Bean
    PasswordEncoder passwordEncoder() {
        // BCrypt por padrão, com prefixo {id} que permite migrar o algoritmo no futuro.
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }

    @Bean
    SecurityContextRepository securityContextRepository() {
        return new HttpSessionSecurityContextRepository();
    }

    @Bean
    CsrfTokenRepository csrfTokenRepository(@Value("${server.servlet.session.cookie.secure:false}") boolean secureCookies) {
        // O Angular precisa ler o XSRF-TOKEN (HttpOnly=false). Secure/SameSite seguem o cookie de sessão do ambiente.
        CookieCsrfTokenRepository repository = CookieCsrfTokenRepository.withHttpOnlyFalse();
        repository.setCookieCustomizer(cookie -> cookie.secure(secureCookies).sameSite("Lax").path("/"));
        return repository;
    }

    @Bean
    AuthenticationManager authenticationManager(AppUserDetailsService userDetailsService, PasswordEncoder passwordEncoder) {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder);
        return new ProviderManager(provider);
    }

    @Bean
    SecurityFilterChain apiSecurity(HttpSecurity http, SecurityContextRepository contextRepository,
                                    CsrfTokenRepository csrfTokenRepository, AppUserRepository users) throws Exception {
        ProblemResponses problems = new ProblemResponses();
        http
                .csrf(csrf -> csrf.spa().csrfTokenRepository(csrfTokenRepository)
                        // Web service do Apple Wallet: chamado pelo iPhone (sem cookie), autenticado pelo token do passe.
                        .ignoringRequestMatchers("/api/public/apple-wallet/**"))
                .securityContext(context -> context.securityContextRepository(contextRepository))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(HttpMethod.GET, "/api/health", "/api/auth/csrf").permitAll()
                        // Link do consumidor (token aleatório, expira) e imagens buscadas pelo Google Wallet.
                        .requestMatchers(HttpMethod.GET, "/api/public/wallet-links/*", "/api/public/wallet-links/*/apple", "/api/public/wallet-links/*/qr", "/api/public/images/*").permitAll()
                        .requestMatchers("/api/public/apple-wallet/**").permitAll()
                        // Homologação Apple Wallet: só existe no perfil local; token temporário de 15 minutos.
                        .requestMatchers(HttpMethod.GET, "/api/public/apple-wallet-homologation/*").permitAll()
                        // Cadastro público pelo QR Code do estabelecimento (token aleatório; POST continua exigindo CSRF).
                        .requestMatchers(HttpMethod.GET, "/api/public/signup/*").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/public/signup/*").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/auth/login").permitAll()
                        // Autocadastro de estabelecimentos (POST exige CSRF) e catálogo de planos.
                        .requestMatchers(HttpMethod.GET, "/api/public/plans").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/public/establishment-signup").permitAll()
                        // Recuperação de senha: público, mas com CSRF (resposta genérica; limite de tentativas no serviço).
                        .requestMatchers(HttpMethod.POST, "/api/auth/password-reset/request", "/api/auth/password-reset/confirm").permitAll()
                        .requestMatchers("/error").permitAll()
                        .requestMatchers("/api/admin/**").hasAuthority(AuthenticatedUser.ROLE_PLATFORM_ADMIN)
                        .requestMatchers("/api/**").authenticated()
                        .anyRequest().denyAll())
                .exceptionHandling(exceptions -> exceptions
                        .authenticationEntryPoint(problems)
                        .accessDeniedHandler(problems))
                .formLogin(AbstractHttpConfigurer::disable)
                .httpBasic(AbstractHttpConfigurer::disable)
                .requestCache(AbstractHttpConfigurer::disable)
                .logout(logout -> logout
                        .logoutUrl("/api/auth/logout")
                        .logoutSuccessHandler(new HttpStatusReturningLogoutSuccessHandler(HttpStatus.NO_CONTENT))
                        .deleteCookies(SESSION_COOKIE))
                .headers(headers -> headers
                        .contentSecurityPolicy(csp -> csp.policyDirectives("default-src 'none'; frame-ancestors 'none'")))
                .addFilterBefore(new SessionUserRevalidationFilter(users), AuthorizationFilter.class);
        return http.build();
    }
}
