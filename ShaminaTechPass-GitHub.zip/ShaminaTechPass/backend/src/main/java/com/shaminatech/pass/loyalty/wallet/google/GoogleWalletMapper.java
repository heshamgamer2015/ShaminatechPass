package com.shaminatech.pass.loyalty.wallet.google;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;

/**
 * Converte os dados do Pass nos recursos do Google Wallet (LoyaltyClass / LoyaltyObject), respeitando o que a API
 * permite: o Google define a disposição dos campos, mascara o logotipo em círculo, escolhe a cor do texto e limita o
 * tamanho de títulos e rótulos. Não há posicionamento livre.
 */
public final class GoogleWalletMapper {

    /** Dados do programa (uma classe por programa, com a marca do estabelecimento). */
    public record ClassData(String classId, String issuerName, String programName, String hexBackgroundColor, String logoUri,
                            String heroUri, String countryCode, String rewardInfo, String description) {
    }

    /** Dados do cartão do consumidor (um objeto por cartão). */
    public record ObjectData(String objectId, String classId, CardStatus status, String accountName, String displayCode,
                             String barcodeValue, ProgramType type, BigDecimal balance, Integer stampsRequired, Instant expiresAt,
                             String validUntilText, String nextBenefitExpiryText, String cardMessage) {
    }

    private GoogleWalletMapper() {
    }

    /**
     * Estado no Google a partir do estado do CARTÃO (não confundir com validade dos benefícios):
     * ativo → ACTIVE; expirado por inatividade → EXPIRED; carimbos concluídos → COMPLETED;
     * cancelado → INACTIVE (definitivo: depois disso o passe não é mais sincronizado).
     * <p>
     * Desativado (temporário) continua ACTIVE no Google, com a situação "Bloqueado" em destaque: estados
     * INACTIVE/EXPIRED tiram o passe da lista principal do Google Wallet (vai para "vencidos") e ele não volta
     * sozinho quando o cartão é reativado.
     */
    public static String state(CardStatus status) {
        return switch (status) {
            case ACTIVE, SUSPENDED -> "ACTIVE";
            case CANCELLED -> "INACTIVE";
            case EXPIRED -> "EXPIRED";
            case COMPLETED -> "COMPLETED";
        };
    }

    /** Situação exibida em destaque na frente do passe (sempre enviada: o PATCH do Google não apaga campos omitidos). */
    public static String situation(CardStatus status) {
        return switch (status) {
            case ACTIVE -> "Ativo";
            case SUSPENDED -> "Bloqueado";
            case EXPIRED -> "Vencido";
            case COMPLETED -> "Concluído";
            case CANCELLED -> "Cancelado";
        };
    }

    public static Map<String, Object> loyaltyClass(ClassData d) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("id", d.classId());
        body.put("issuerName", truncate(d.issuerName(), 40));
        body.put("programName", truncate(d.programName(), 40));
        body.put("programLogo", image(d.logoUri(), "Logotipo de " + d.issuerName()));
        if (d.heroUri() != null) {
            body.put("heroImage", image(d.heroUri(), d.programName()));
        }
        if (d.hexBackgroundColor() != null) {
            body.put("hexBackgroundColor", d.hexBackgroundColor().toLowerCase(Locale.ROOT));
        }
        body.put("countryCode", d.countryCode());
        body.put("reviewStatus", "UNDER_REVIEW");
        // Um cartão por pessoa: só o consumidor que salvou o passe pode vê-lo (em quantos aparelhos quiser).
        body.put("multipleDevicesAndHoldersAllowedStatus", "ONE_USER_ALL_DEVICES");
        body.put("accountNameLabel", "Cliente");
        body.put("accountIdLabel", "Cartão");
        List<Map<String, Object>> modules = new ArrayList<>();
        if (d.rewardInfo() != null) {
            modules.add(text("recompensa", "Recompensa", d.rewardInfo()));
        }
        if (d.description() != null) {
            modules.add(text("programa", "Sobre o programa", d.description()));
        }
        if (!modules.isEmpty()) {
            body.put("textModulesData", modules);
        }
        return body;
    }

    public static Map<String, Object> loyaltyObject(ObjectData d) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("id", d.objectId());
        body.put("classId", d.classId());
        body.put("state", state(d.status()));
        body.put("accountName", truncate(d.accountName(), 20));
        body.put("accountId", d.displayCode());
        body.put("loyaltyPoints", points(d));
        body.put("secondaryLoyaltyPoints", Map.of("label", "Situação", "balance", Map.of("string", situation(d.status()))));
        Map<String, Object> barcode = new LinkedHashMap<>();
        barcode.put("type", "QR_CODE");
        barcode.put("value", d.barcodeValue());
        barcode.put("alternateText", d.displayCode());
        body.put("barcode", barcode);
        if (d.status() != CardStatus.COMPLETED && d.status() != CardStatus.CANCELLED) {
            // Validade por inatividade: o Google move o passe para "Expirados" até 24 h após o fim.
            body.put("validTimeInterval", Map.of("end", Map.of("date", DateTimeFormatter.ISO_INSTANT.format(d.expiresAt()))));
        }
        List<Map<String, Object>> modules = new ArrayList<>();
        if (d.status() == CardStatus.SUSPENDED) {
            modules.add(text("situacao", "Cartão bloqueado",
                    "Este cartão está temporariamente bloqueado pelo estabelecimento. Procure a loja para reativá-lo."));
        }
        modules.add(text("validade", "Válido até", d.validUntilText() + " (renova a cada compra)"));
        if (d.nextBenefitExpiryText() != null) {
            modules.add(text("beneficios", "Próximo vencimento", d.nextBenefitExpiryText()));
        }
        if (d.cardMessage() != null) {
            modules.add(text("mensagem", "Mensagem", d.cardMessage()));
        }
        body.put("textModulesData", modules);
        return body;
    }

    /** Saldo conforme o tipo: pontos (inteiro), cashback (dinheiro em micros, BRL), carimbos ("3 de 10"). */
    static Map<String, Object> points(ObjectData d) {
        Map<String, Object> balance = new LinkedHashMap<>();
        String label;
        switch (d.type()) {
            case POINTS -> {
                label = "Pontos";
                balance.put("int", d.balance().intValue());
            }
            case CASHBACK -> {
                label = "Cashback";
                balance.put("money", Map.of("micros", d.balance().movePointRight(6).longValueExact(), "currencyCode", "BRL"));
            }
            case STAMPS -> {
                label = "Carimbos";
                balance.put("string", d.balance().intValue() + " de " + d.stampsRequired());
            }
            default -> {
                label = "Nível";
                balance.put("string", "—");
            }
        }
        return Map.of("label", label, "balance", balance);
    }

    private static Map<String, Object> image(String uri, String description) {
        return Map.of("sourceUri", Map.of("uri", uri),
                "contentDescription", Map.of("defaultValue", Map.of("language", "pt-BR", "value", truncate(description, 60))));
    }

    private static Map<String, Object> text(String id, String header, String body) {
        return Map.of("id", id, "header", header, "body", body);
    }

    private static String truncate(String value, int max) {
        return value == null || value.length() <= max ? value : value.substring(0, max);
    }
}
