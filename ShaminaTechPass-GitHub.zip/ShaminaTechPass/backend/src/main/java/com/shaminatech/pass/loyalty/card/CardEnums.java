package com.shaminatech.pass.loyalty.card;

import com.shaminatech.pass.common.persistence.EnumNameConverter;

import jakarta.persistence.Converter;

public final class CardEnums {

    private CardEnums() {
    }

    /**
     * Estado do CARTÃO (independente do estado dos benefícios, que ficam nos lotes).
     * <ul>
     *   <li>ACTIVE: aceita movimentações enquanto estiver dentro da validade;</li>
     *   <li>SUSPENDED: desativado pela empresa (reversível); a validade continua correndo;</li>
     *   <li>EXPIRED: venceu por inatividade; a empresa pode reativá-lo;</li>
     *   <li>COMPLETED: cartão de carimbos concluído e resgatado, sem reinício;</li>
     *   <li>CANCELLED: definitivo, nunca mais aceita movimentações.</li>
     * </ul>
     */
    public enum CardStatus {
        ACTIVE, SUSPENDED, EXPIRED, COMPLETED, CANCELLED;

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<CardStatus> {
            public JpaConverter() {
                super(CardStatus.class);
            }
        }
    }

    /** Tipos de registro no histórico (imutável) do cartão. */
    public enum TransactionType {
        /** Concessão de pontos, cashback ou carimbos (renova a validade). */
        EARN,
        /** Resgate aceito (renova a validade). */
        REDEEM,
        /** Operação compensatória de um EARN ou REDEEM (não renova a validade). */
        REVERSAL,
        /** Benefícios que venceram pela validade própria. */
        BENEFIT_EXPIRED,
        /** Saldo zerado porque o cartão expirou e o programa usa a regra FORFEIT. */
        BALANCE_FORFEITED,
        CARD_ISSUED,
        CARD_SUSPENDED,
        CARD_REACTIVATED,
        CARD_EXPIRED,
        CARD_CANCELLED;

        public boolean isMovement() {
            return this == EARN || this == REDEEM;
        }

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<TransactionType> {
            public JpaConverter() {
                super(TransactionType.class);
            }
        }
    }

    /**
     * Canal pelo qual o cartão foi identificado. NFC e API ficam reservados para canais futuros
     * (ex.: equipamento próprio com ESP32) e são recusados até serem habilitados.
     */
    public enum Channel {
        /** PUBLIC_SIGNUP: cartão emitido pelo autocadastro do consumidor (QR Code público do estabelecimento). */
        MANUAL, QR_CODE, NFC, API, SYSTEM, PUBLIC_SIGNUP;

        public boolean acceptedFromPanel() {
            return this == MANUAL || this == QR_CODE;
        }

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<Channel> {
            public JpaConverter() {
                super(Channel.class);
            }
        }
    }

    /** Situação de um lote de benefícios (cada concessão gera um lote com validade própria). */
    public enum LotStatus {
        OPEN, CONSUMED, EXPIRED, FORFEITED;

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<LotStatus> {
            public JpaConverter() {
                super(LotStatus.class);
            }
        }
    }
}
