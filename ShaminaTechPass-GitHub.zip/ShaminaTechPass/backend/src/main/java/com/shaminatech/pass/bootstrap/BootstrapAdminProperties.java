package com.shaminatech.pass.bootstrap;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "shaminatech.bootstrap.admin")
public record BootstrapAdminProperties(String email, String name, String password) {

    public boolean isConfigured() {
        return email != null && !email.isBlank() && password != null && !password.isBlank();
    }
}
