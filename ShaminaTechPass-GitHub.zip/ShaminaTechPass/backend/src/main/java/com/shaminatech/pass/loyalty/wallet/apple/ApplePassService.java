package com.shaminatech.pass.loyalty.wallet.apple;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.branding.StoredImage;
import com.shaminatech.pass.loyalty.branding.StoredImageRepository;
import com.shaminatech.pass.loyalty.card.BenefitLot;
import com.shaminatech.pass.loyalty.card.BenefitLotRepository;
import com.shaminatech.pass.loyalty.card.CardCodes;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.card.LoyaltyCardRepository;
import com.shaminatech.pass.loyalty.card.Validity;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.wallet.WalletPass;
import com.shaminatech.pass.loyalty.wallet.WalletPass.Provider;
import com.shaminatech.pass.loyalty.wallet.WalletPassRepository;

import tools.jackson.databind.json.JsonMapper;

/**
 * Gera o .pkpass de um passe Apple a partir do estado oficial do cartão. A leitura acontece numa transação curta
 * somente leitura; o tratamento das imagens e a assinatura acontecem depois, sem transação aberta.
 * Gerar ou baixar o passe nunca altera saldo nem validade.
 */
@Service
public class ApplePassService {

    private static final DateTimeFormatter BR = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    /** Arquivo gerado e a data da última alteração do conteúdo (Last-Modified). */
    public record Pkpass(byte[] data, Instant lastModified, String serialNumber) {
    }

    private record Snapshot(ApplePassMapper.PassData data, Instant lastModified, byte[] logo, String logoKey, byte[] hero,
                            String heroKey, java.util.List<Map<String, Object>> locations) {
    }

    private final WalletPassRepository passes;
    private final LoyaltyCardRepository cards;
    private final BenefitLotRepository lots;
    private final StoredImageRepository images;
    private final PolicyService policies;
    private final AppleWalletGateway gateway;
    private final AppleImages appleImages;
    private final TransactionTemplate readTx;
    private final JsonMapper json;
    private final Clock clock;
    private final com.shaminatech.pass.loyalty.notify.ProximityService proximity;

    public ApplePassService(WalletPassRepository passes, LoyaltyCardRepository cards, BenefitLotRepository lots,
                            StoredImageRepository images, PolicyService policies, AppleWalletGateway gateway, AppleImages appleImages,
                            PlatformTransactionManager transactionManager, JsonMapper json, Clock clock,
                            com.shaminatech.pass.loyalty.notify.ProximityService proximity) {
        this.proximity = proximity;
        this.passes = passes;
        this.cards = cards;
        this.lots = lots;
        this.images = images;
        this.policies = policies;
        this.gateway = gateway;
        this.appleImages = appleImages;
        this.readTx = new TransactionTemplate(transactionManager);
        this.readTx.setReadOnly(true);
        this.json = json;
        this.clock = clock;
    }

    /** Passe Apple pelo serial (usado pelo web service, depois de conferir o token). */
    public Optional<Pkpass> bySerial(String serialNumber) {
        Long passId = readTx.execute(s -> passes.findByProviderAndExternalId(Provider.APPLE_WALLET, serialNumber)
                .map(WalletPass::getId).orElse(null));
        return passId == null ? Optional.empty() : Optional.of(build(passId));
    }

    public Instant lastModified(String serialNumber) {
        return readTx.execute(s -> passes.findByProviderAndExternalId(Provider.APPLE_WALLET, serialNumber)
                .map(WalletPass::getContentUpdatedAt).orElse(null));
    }

    public Pkpass build(Long passId) {
        if (!gateway.issuable()) {
            throw new AppleWalletException(0, "Integração Apple Wallet não configurada.", false);
        }
        Snapshot snapshot = readTx.execute(s -> snapshot(passId));
        if (snapshot == null) {
            throw new AppleWalletException(404, "Passe não encontrado.", false);
        }
        Map<String, byte[]> files = appleImages.passImages(snapshot.logo(), snapshot.logoKey(), snapshot.hero(), snapshot.heroKey());
        Map<String, Object> passJson = ApplePassMapper.passJson(snapshot.data());
        if (!snapshot.locations().isEmpty()) {
            passJson.put("locations", snapshot.locations()); // até 10; o iPhone decide quando mostrar o cartão
        }
        if (snapshot.data().webServiceUrl() == null) {
            offlineNotice(passJson);
        }
        byte[] data = PkpassBuilder.build(passJson, files, gateway.credentials(), json);
        return new Pkpass(data, snapshot.lastModified(), snapshot.data().serialNumber());
    }

    private Snapshot snapshot(Long passId) {
        WalletPass pass = passes.findById(passId).filter(p -> p.getProvider() == Provider.APPLE_WALLET).orElse(null);
        if (pass == null) {
            return null;
        }
        LoyaltyCard card = cards.findInEstablishment(pass.getEstablishmentId(), pass.getCardId()).orElse(null);
        if (card == null) {
            return null;
        }
        Instant now = clock.instant();
        LoyaltyProgram program = card.getProgram();
        Establishment establishment = program.getEstablishment();
        ZoneId zone = policies.of(card.getEstablishmentId()).zone();
        CardStatus status = card.effectiveStatus(now);
        AppleWalletProperties p = gateway.properties();
        // Modo offline de homologação: sem serviço de atualização, o passe sai sem webServiceURL e sem token.
        boolean updatable = gateway.configured();
        ApplePassMapper.PassData data = new ApplePassMapper.PassData(pass.getExternalId(), p.passTypeIdentifier(),
                p.teamIdentifier(), updatable ? p.webServiceUrl() : null,
                updatable ? gateway.authenticationToken(pass.getExternalId()) : null, establishment.getName(),
                program.getName(), program.getBrandColor(), program.getTextColor(), status, program.getType(), card.getBalance(),
                program.getStampsRequired(), firstName(card.getConsumer().getFullName()), CardCodes.format(card.getCode()),
                card.getCode(), card.getExpiresAt(),
                card.getExpiresAt() == null ? null : Validity.validUntilLocal(card.getExpiresAt(), zone).format(BR),
                nextBenefitExpiry(card, program.getType(), zone, now), program.getCardMessage(), rewardInfo(program),
                program.getDescription(), establishment.getContactEmail(), establishment.getContactPhone(), p.supportName(),
                p.supportEmail(), p.supportPhone(), p.supportAddress());
        StoredImage logo = program.getLogoImageId() == null ? null : images.findById(program.getLogoImageId()).orElse(null);
        StoredImage hero = program.getHeroImageId() == null ? null : images.findById(program.getHeroImageId()).orElse(null);
        return new Snapshot(data, pass.getContentUpdatedAt(), logo == null ? null : logo.getData(), logo == null ? null : logo.getSha256(),
                hero == null ? null : hero.getData(), hero == null ? null : hero.getSha256(),
                proximity.appleLocations(card.getEstablishmentId()));
    }

    /** Verso do passe offline: avisa que o saldo mostrado é o do momento do download. */
    @SuppressWarnings("unchecked")
    static void offlineNotice(Map<String, Object> passJson) {
        Map<String, Object> storeCard = (Map<String, Object>) passJson.get("storeCard");
        java.util.List<Map<String, Object>> back = new java.util.ArrayList<>((java.util.List<Map<String, Object>>) storeCard.get("backFields"));
        Map<String, Object> field = new java.util.LinkedHashMap<>();
        field.put("key", "atualizacao");
        field.put("label", "Atualização do cartão");
        field.put("value", "Este cartão mostra o saldo do momento em que foi adicionado e ainda não se atualiza sozinho. "
                + "Para ver o saldo atual, abra novamente o link do cartão.");
        back.add(0, field);
        storeCard.put("backFields", back);
    }

    private static String rewardInfo(LoyaltyProgram program) {
        if (program.getRewardInfo() != null) {
            return program.getRewardInfo();
        }
        if (program.getType() == ProgramType.STAMPS && program.getStampReward() != null) {
            return "Complete " + program.getStampsRequired() + " carimbos: " + program.getStampReward();
        }
        return null;
    }

    private String nextBenefitExpiry(LoyaltyCard card, ProgramType type, ZoneId zone, Instant now) {
        return lots.findOpenByCard(card.getId()).stream()
                .filter(l -> l.isUsable(now) && l.getExpiresAt() != null)
                .min((a, b) -> a.getExpiresAt().compareTo(b.getExpiresAt()))
                .map(l -> amount(type, l) + " em " + Validity.validUntilLocal(l.getExpiresAt(), zone).format(BR))
                .orElse(null);
    }

    private static String amount(ProgramType type, BenefitLot lot) {
        BigDecimal v = lot.getRemaining();
        return switch (type) {
            case CASHBACK -> "R$ " + v.setScale(2).toPlainString().replace('.', ',');
            case STAMPS -> v.intValue() + " carimbo(s)";
            default -> v.intValue() + " ponto(s)";
        };
    }

    /** Minimização de dados: o passe mostra só o primeiro nome do consumidor. */
    static String firstName(String fullName) {
        String trimmed = fullName == null ? "" : fullName.trim();
        int space = trimmed.indexOf(' ');
        return space > 0 ? trimmed.substring(0, space) : trimmed;
    }
}
