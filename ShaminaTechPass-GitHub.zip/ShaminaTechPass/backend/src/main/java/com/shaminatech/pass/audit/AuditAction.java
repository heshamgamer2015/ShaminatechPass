package com.shaminatech.pass.audit;

import com.shaminatech.pass.common.persistence.EnumNameConverter;

import jakarta.persistence.Converter;

public enum AuditAction {
    LOGIN_SUCCEEDED,
    LOGIN_FAILED,
    LOGIN_BLOCKED,
    PASSWORD_CHANGED,
    PLATFORM_ADMIN_BOOTSTRAPPED,
    USER_CREATED,
    USER_STATUS_CHANGED,
    USER_UNLOCKED,
    ESTABLISHMENT_CREATED,
    ESTABLISHMENT_SELF_REGISTERED,
    ESTABLISHMENT_UPDATED,
    ESTABLISHMENT_STATUS_CHANGED,
    MEMBER_ADDED,
    MEMBER_UPDATED,
    // Etapa 2 — administração
    ESTABLISHMENT_POLICY_CHANGED,
    LOYALTY_DEFAULTS_CHANGED,
    ACCOUNT_PASSWORD_RESET,
    // Etapa 2 — fidelidade (as movimentações em si ficam no histórico imutável card_transaction)
    CONSUMER_CREATED,
    CONSUMER_UPDATED,
    CONSUMER_STATUS_CHANGED,
    PROGRAM_CREATED,
    PROGRAM_UPDATED,
    PROGRAM_STATUS_CHANGED,
    REWARD_SAVED,
    VIP_TIER_SAVED,
    CARD_DESIGN_UPDATED,
    CARD_IMAGE_UPLOADED,
    CARD_IMAGE_REMOVED,
    CARD_ISSUED,
    CARD_STATUS_CHANGED,
    TRANSACTION_REVERSED,
    // Etapa 3 — carteiras digitais
    WALLET_PASS_CREATED,
    WALLET_LINK_CREATED,
    WALLET_LINK_REVOKED,
    WALLET_SYNC_RETRIED,
    // Etapa 5 — cadastro público por QR Code
    SIGNUP_LINK_CREATED,
    SIGNUP_LINK_STATUS_CHANGED,
    SIGNUP_LINK_REGENERATED,
    CONSUMER_SELF_REGISTERED,
    // Etapa 6 — notificações e proximidade
    NOTIFICATION_SETTINGS_CHANGED,
    ESTABLISHMENT_LOCATION_SAVED,
    ESTABLISHMENT_LOCATION_REMOVED,
    // Etapa 8 — recuperação de acesso
    PASSWORD_RESET_REQUESTED,
    PASSWORD_RESET_COMPLETED;

    @Converter(autoApply = true)
    public static class JpaConverter extends EnumNameConverter<AuditAction> {
        public JpaConverter() {
            super(AuditAction.class);
        }
    }
}
