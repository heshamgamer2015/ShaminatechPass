package com.shaminatech.pass.loyalty.wallet;

/** Programa ou personalização alterados: todos os passes do programa precisam ser reenviados (classe e objetos). */
public record ProgramChangedEvent(Long programId) {
}
