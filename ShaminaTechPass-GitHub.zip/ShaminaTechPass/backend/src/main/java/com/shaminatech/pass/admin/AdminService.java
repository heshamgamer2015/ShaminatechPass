package com.shaminatech.pass.admin;

import java.time.Clock;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jakarta.persistence.criteria.Predicate;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.admin.AdminDtos.CreateEstablishmentRequest;
import com.shaminatech.pass.admin.AdminDtos.EstablishmentDetail;
import com.shaminatech.pass.admin.AdminDtos.EstablishmentSummary;
import com.shaminatech.pass.admin.AdminDtos.PolicyRequest;
import com.shaminatech.pass.admin.AdminDtos.Usage;
import com.shaminatech.pass.admin.AdminDtos.UserSummary;
import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.common.web.PageResponse;
import com.shaminatech.pass.common.web.Paging;
import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.establishment.EstablishmentRepository;
import com.shaminatech.pass.establishment.EstablishmentStatus;
import com.shaminatech.pass.loyalty.LoyaltyDtos.PolicyView;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.LoyaltyCardRepository;
import com.shaminatech.pass.loyalty.consumer.ConsumerRepository;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicy;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicyRepository;
import com.shaminatech.pass.loyalty.policy.PlatformLoyaltyDefaults;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.LoyaltyProgramRepository;
import com.shaminatech.pass.membership.MemberResponse;
import com.shaminatech.pass.membership.Membership;
import com.shaminatech.pass.membership.MembershipRepository;
import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.security.CurrentUser;
import com.shaminatech.pass.security.PasswordPolicy;
import com.shaminatech.pass.user.AppUser;
import com.shaminatech.pass.user.AppUserRepository;
import com.shaminatech.pass.user.EmailNormalizer;
import com.shaminatech.pass.user.UserAccountService;
import com.shaminatech.pass.user.UserStatus;

/**
 * Operações do painel ShaminaTech. O acesso é restrito a PLATFORM_ADMIN no {@code SecurityConfig}.
 * A plataforma vê apenas contagens de uso dos estabelecimentos — nunca dados pessoais dos consumidores
 * nem o conteúdo dos cartões.
 */
@Service
public class AdminService {

    private final EstablishmentRepository establishments;
    private final MembershipRepository memberships;
    private final AppUserRepository users;
    private final UserAccountService accounts;
    private final PolicyService policyService;
    private final EstablishmentPolicyRepository policies;
    private final ConsumerRepository consumers;
    private final LoyaltyCardRepository cards;
    private final LoyaltyProgramRepository programs;
    private final PasswordEncoder passwordEncoder;
    private final AuditService audit;
    private final Clock clock;

    private final com.shaminatech.pass.plan.PlanService planService;

    public AdminService(EstablishmentRepository establishments, MembershipRepository memberships, AppUserRepository users,
                        UserAccountService accounts, PolicyService policyService, EstablishmentPolicyRepository policies,
                        ConsumerRepository consumers, LoyaltyCardRepository cards, LoyaltyProgramRepository programs,
                        PasswordEncoder passwordEncoder, AuditService audit, Clock clock,
                        com.shaminatech.pass.plan.PlanService planService) {
        this.planService = planService;
        this.establishments = establishments;
        this.memberships = memberships;
        this.users = users;
        this.accounts = accounts;
        this.policyService = policyService;
        this.policies = policies;
        this.consumers = consumers;
        this.cards = cards;
        this.programs = programs;
        this.passwordEncoder = passwordEncoder;
        this.audit = audit;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public PageResponse<EstablishmentSummary> listEstablishments(String query, EstablishmentStatus status, Pageable pageable) {
        String like = Paging.likePattern(query);
        Specification<Establishment> spec = (root, q, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            if (like != null) {
                predicates.add(cb.or(cb.like(cb.lower(root.get("name")), like), cb.like(root.get("slug"), like)));
            }
            if (status != null) {
                predicates.add(cb.equal(root.get("status"), status));
            }
            return cb.and(predicates.toArray(Predicate[]::new));
        };
        var page = establishments.findAll(spec, pageable);
        List<Long> ids = page.getContent().stream().map(Establishment::getId).toList();
        Map<Long, Usage> usage = usage(ids);
        Map<Long, com.shaminatech.pass.plan.PlanService.PlanBadge> badges = planService.badges(ids);
        return PageResponse.of(page, e -> EstablishmentSummary.from(e, usage.get(e.getId()), badges.get(e.getId())));
    }

    @Transactional
    public EstablishmentDetail createEstablishment(CreateEstablishmentRequest request) {
        if (establishments.existsBySlug(request.slug())) {
            throw ApiException.conflict("Este identificador já está em uso.", "slug");
        }
        users.findByEmail(EmailNormalizer.normalize(request.owner().email())).filter(AppUser::isPlatformAdmin).ifPresent(u -> {
            throw ApiException.badRequest("Contas de administrador da ShaminaTech não podem ser contas empresariais.", "owner.email");
        });
        Establishment establishment = new Establishment(request.name().trim(), request.slug());
        establishment.setContactEmail(blankToNull(request.contactEmail()));
        establishment.setContactPhone(blankToNull(request.contactPhone()));
        establishment = establishments.save(establishment);
        policyService.createFor(establishment);

        var owner = accounts.findOrCreate(request.owner().email(), request.owner().fullName(),
                request.owner().temporaryPassword(), establishment.getId());
        Membership membership = memberships.save(new Membership(establishment, owner.user(), MembershipRole.OWNER));

        audit.record(AuditAction.ESTABLISHMENT_CREATED, establishment.getId(), "ESTABLISHMENT", establishment.getId(),
                "slug=" + establishment.getSlug());
        audit.record(AuditAction.MEMBER_ADDED, establishment.getId(), "MEMBERSHIP", membership.getId(),
                "conta empresarial" + (owner.created() ? ", nova conta" : ", conta existente"));
        return getEstablishment(establishment.getId());
    }

    @Transactional(readOnly = true)
    public EstablishmentDetail getEstablishment(Long id) {
        Establishment e = findEstablishment(id);
        MemberResponse account = memberships.findBusinessAccount(id).map(MemberResponse::from).orElse(null);
        EstablishmentPolicy policy = policyService.of(id);
        Map<ProgramType, Long> byType = new EnumMap<>(ProgramType.class);
        for (LoyaltyProgram p : programs.findAllInEstablishment(id)) {
            byType.merge(p.getType(), 1L, Long::sum);
        }
        return new EstablishmentDetail(e.getId(), e.getName(), e.getSlug(), e.getStatus(), e.getContactEmail(),
                e.getContactPhone(), e.getCreatedAt(), e.getUpdatedAt(), account, view(policy), usage(List.of(id)).get(id), byType,
                planService.badges(List.of(id)).get(id));
    }

    @Transactional
    public EstablishmentDetail changeEstablishmentStatus(Long id, EstablishmentStatus status) {
        Establishment establishment = findEstablishment(id);
        EstablishmentStatus previous = establishment.getStatus();
        if (previous != status) {
            establishment.setStatus(status);
            audit.record(AuditAction.ESTABLISHMENT_STATUS_CHANGED, id, "ESTABLISHMENT", id, previous + "->" + status);
        }
        return getEstablishment(id);
    }

    /**
     * Limites individuais. Reduzir o limite abaixo do uso atual não apaga nem desativa nada: só impede novas ativações.
     * Desabilitar um tipo preserva programas e cartões existentes, mas bloqueia novas emissões e movimentações dele.
     */
    @Transactional
    public EstablishmentDetail updatePolicy(Long id, PolicyRequest request) {
        findEstablishment(id);
        PolicyService.validate(request.maxActiveConsumers(), request.defaultInactivityDays(), request.timeZone());
        EstablishmentPolicy policy = policyService.lock(id);
        String before = policy.describe();
        policy.update(request.maxActiveConsumers(), request.defaultInactivityDays(), request.timeZone().trim(),
                types(request.allowedProgramTypes()));
        String after = policy.describe();
        if (!before.equals(after)) {
            audit.record(AuditAction.ESTABLISHMENT_POLICY_CHANGED, id, "ESTABLISHMENT_POLICY", policy.getId(), before + " -> " + after);
        }
        return getEstablishment(id);
    }

    @Transactional
    public PolicyView defaults() {
        PlatformLoyaltyDefaults d = policyService.defaults();
        return new PolicyView(d.getMaxActiveConsumers(), d.getAllowedProgramTypes(), d.getDefaultInactivityDays(), d.getTimeZone());
    }

    /** Regras padrão: valem para estabelecimentos criados depois da alteração (os existentes não mudam). */
    @Transactional
    public PolicyView updateDefaults(PolicyRequest request) {
        PolicyService.validate(request.maxActiveConsumers(), request.defaultInactivityDays(), request.timeZone());
        PlatformLoyaltyDefaults d = policyService.defaults();
        String before = d.describe();
        d.update(request.maxActiveConsumers(), request.defaultInactivityDays(), request.timeZone().trim(),
                types(request.allowedProgramTypes()));
        if (!before.equals(d.describe())) {
            audit.record(AuditAction.LOYALTY_DEFAULTS_CHANGED, null, "PLATFORM_DEFAULTS", d.getId(), before + " -> " + d.describe());
        }
        return defaults();
    }

    /** Nova senha temporária para a conta empresarial (troca obrigatória no próximo acesso; desbloqueia a conta). */
    @Transactional
    public EstablishmentDetail resetAccountPassword(Long id, String temporaryPassword) {
        findEstablishment(id);
        Membership account = memberships.findBusinessAccount(id)
                .orElseThrow(() -> ApiException.notFound("Este estabelecimento não tem conta empresarial ativa."));
        PasswordPolicy.violation(temporaryPassword).ifPresent(message -> {
            throw ApiException.badRequest(message, "temporaryPassword");
        });
        AppUser user = account.getUser();
        user.changePassword(passwordEncoder.encode(temporaryPassword), true);
        user.unlock();
        audit.record(AuditAction.ACCOUNT_PASSWORD_RESET, id, "USER", user.getId(), null);
        return getEstablishment(id);
    }

    @Transactional(readOnly = true)
    public PageResponse<UserSummary> listUsers(String query, Pageable pageable) {
        String like = Paging.likePattern(query);
        Specification<AppUser> spec = (root, q, cb) -> like == null ? cb.conjunction()
                : cb.or(cb.like(root.get("email"), like), cb.like(cb.lower(root.get("fullName")), like));
        var now = clock.instant();
        return PageResponse.of(users.findAll(spec, pageable), u -> UserSummary.from(u, now));
    }

    @Transactional
    public UserSummary changeUserStatus(Long id, UserStatus status) {
        AppUser user = findUser(id);
        if (user.getId().equals(CurrentUser.require().getId())) {
            throw ApiException.badRequest("Você não pode alterar a situação da sua própria conta.", "status");
        }
        UserStatus previous = user.getStatus();
        if (previous != status) {
            user.setStatus(status);
            audit.record(AuditAction.USER_STATUS_CHANGED, null, "USER", id, previous + "->" + status);
        }
        return UserSummary.from(user, clock.instant());
    }

    @Transactional
    public UserSummary unlockUser(Long id) {
        AppUser user = findUser(id);
        user.unlock();
        audit.record(AuditAction.USER_UNLOCKED, null, "USER", id, null);
        return UserSummary.from(user, clock.instant());
    }

    private Map<Long, Usage> usage(List<Long> ids) {
        Map<Long, Usage> result = new HashMap<>();
        if (ids.isEmpty()) {
            return result;
        }
        Map<Long, Long> active = toMap(consumers.countActiveByEstablishment(ids));
        Map<Long, Long> total = toMap(consumers.countAllByEstablishment(ids));
        Map<Long, Integer> limits = new HashMap<>();
        for (EstablishmentPolicy p : policies.findByEstablishmentIds(ids)) {
            limits.put(p.getEstablishment().getId(), p.getMaxActiveConsumers());
        }
        Map<Long, long[]> cardCounts = new HashMap<>();
        for (Object[] row : cards.countByEstablishmentAndStatus(ids)) {
            long[] c = cardCounts.computeIfAbsent((Long) row[0], k -> new long[2]);
            long n = (Long) row[2];
            c[1] += n;
            if (row[1] == CardStatus.ACTIVE) {
                c[0] += n;
            }
        }
        for (Long id : ids) {
            long[] c = cardCounts.getOrDefault(id, new long[2]);
            result.put(id, new Usage(active.getOrDefault(id, 0L), total.getOrDefault(id, 0L), limits.getOrDefault(id, 0), c[0], c[1]));
        }
        return result;
    }

    private static Map<Long, Long> toMap(List<Object[]> rows) {
        Map<Long, Long> map = new HashMap<>();
        for (Object[] row : rows) {
            map.put((Long) row[0], (Long) row[1]);
        }
        return map;
    }

    private static Set<ProgramType> types(Set<ProgramType> requested) {
        return requested == null || requested.isEmpty() ? EnumSet.noneOf(ProgramType.class) : EnumSet.copyOf(requested);
    }

    private static PolicyView view(EstablishmentPolicy p) {
        return new PolicyView(p.getMaxActiveConsumers(), p.getAllowedProgramTypes(), p.getDefaultInactivityDays(), p.getTimeZone());
    }

    private Establishment findEstablishment(Long id) {
        return establishments.findById(id).orElseThrow(() -> ApiException.notFound("Estabelecimento não encontrado."));
    }

    private AppUser findUser(Long id) {
        return users.findById(id).orElseThrow(() -> ApiException.notFound("Usuário não encontrado."));
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
