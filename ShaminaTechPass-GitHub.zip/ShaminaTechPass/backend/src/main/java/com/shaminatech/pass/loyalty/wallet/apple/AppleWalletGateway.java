package com.shaminatech.pass.loyalty.wallet.apple;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Ponto único de acesso às credenciais Apple: configuração, certificado (carregado sob demanda e mantido em memória),
 * cliente APNs e token de autenticação de cada passe.
 * <p>
 * O token de autenticação (vai dentro do pass.json e volta no cabeçalho {@code Authorization: ApplePass <token>})
 * é derivado por HMAC-SHA256 do serial com um segredo externo: não fica no banco, não pode ser adivinhado e não
 * muda entre versões do passe (a Apple proíbe alterá-lo).
 */
@Component
public class AppleWalletGateway {

    private final AppleWalletProperties properties;
    private final boolean offlinePasses;
    private volatile AppleCredentials credentials;
    private volatile ApnsClient apns;

    public AppleWalletGateway(AppleWalletProperties properties) {
        this(properties, false);
    }

    /**
     * @param offlinePasses {@code shaminatech.wallet.apple.offline-passes}: <b>só para homologação local</b> (recusado no
     *                      perfil prod pelo ProductionSafetyCheck). Sem URL pública HTTPS, emite os passes dos cartões
     *                      reais sem {@code webServiceURL}/{@code authenticationToken}: o cartão é instalado no iPhone, mas
     *                      não se atualiza sozinho (o consumidor reabre o link para baixar a versão atual).
     */
    @org.springframework.beans.factory.annotation.Autowired
    public AppleWalletGateway(AppleWalletProperties properties,
                              @Value("${shaminatech.wallet.apple.offline-passes:false}") boolean offlinePasses) {
        this.properties = properties;
        this.offlinePasses = offlinePasses;
    }

    public AppleWalletProperties properties() {
        return properties;
    }

    public boolean enabled() {
        return properties.enabled();
    }

    public boolean configured() {
        return properties.missing().isEmpty();
    }

    public List<String> missing() {
        return properties.missing();
    }

    /** Modo offline de homologação ativo: integração ligada, certificado completo e sem o serviço de atualização. */
    public boolean offlineMode() {
        return offlinePasses && properties.enabled() && !configured() && properties.missingForOfflinePass().isEmpty();
    }

    /** Pode emitir passes Apple de cartões: integração completa (atualizável) ou modo offline de homologação. */
    public boolean issuable() {
        return configured() || offlineMode();
    }

    public AppleCredentials credentials() {
        AppleCredentials current = credentials;
        if (current == null) {
            synchronized (this) {
                if (credentials == null) {
                    credentials = AppleCredentials.load(properties);
                }
                current = credentials;
            }
        }
        return current;
    }

    public ApnsClient apns() {
        ApnsClient current = apns;
        if (current == null) {
            synchronized (this) {
                if (apns == null) {
                    apns = new ApnsClient(properties, credentials());
                }
                current = apns;
            }
        }
        return current;
    }

    /** Token do passe: HMAC-SHA256(segredo, passTypeIdentifier + serial), em hexadecimal (64 caracteres). */
    public String authenticationToken(String serialNumber) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(properties.authSecret().getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return HexFormat.of().formatHex(mac.doFinal((properties.passTypeIdentifier() + "|" + serialNumber)
                    .getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    /** Confere o cabeçalho {@code Authorization: ApplePass <token>} em tempo constante. */
    public boolean authorized(String serialNumber, String authorizationHeader) {
        if (!configured() || serialNumber == null || authorizationHeader == null || !authorizationHeader.startsWith("ApplePass ")) {
            return false;
        }
        byte[] given = authorizationHeader.substring("ApplePass ".length()).trim().getBytes(StandardCharsets.UTF_8);
        byte[] expected = authenticationToken(serialNumber).getBytes(StandardCharsets.UTF_8);
        return MessageDigest.isEqual(given, expected);
    }
}
