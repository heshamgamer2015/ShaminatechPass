package com.shaminatech.pass.common.web;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

public final class Paging {

    public static final int MAX_SIZE = 100;

    private Paging() {
    }

    /** Página segura: índice nunca negativo e tamanho limitado a {@value #MAX_SIZE}. */
    public static Pageable of(int page, int size, Sort sort) {
        return PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), MAX_SIZE), sort);
    }

    /** Converte um termo de busca em padrão LIKE minúsculo, removendo curingas digitados pelo usuário. */
    public static String likePattern(String term) {
        if (term == null) {
            return null;
        }
        String cleaned = term.replace("%", "").replace("_", "").trim().toLowerCase();
        return cleaned.isEmpty() ? null : "%" + cleaned + "%";
    }
}
