package com.shaminatech.pass.loyalty.wallet;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.shaminatech.pass.loyalty.wallet.WalletPass.Provider;
import com.shaminatech.pass.loyalty.wallet.WalletPass.SyncStatus;

import jakarta.persistence.LockModeType;

public interface WalletPassRepository extends JpaRepository<WalletPass, Long> {

    List<WalletPass> findByCardId(Long cardId);

    @Query("""
            select p from WalletPass p
            where p.cardId in (select c.id from LoyaltyCard c where c.program.id = :programId)
            """)
    List<WalletPass> findByProgram(@Param("programId") Long programId);

    Optional<WalletPass> findByCardIdAndProvider(Long cardId, Provider provider);

    Optional<WalletPass> findByProviderAndExternalId(Provider provider, String externalId);

    @Query("select p.provider from WalletPass p where p.id = :id")
    Optional<Provider> findProviderById(@Param("id") Long id);

    @Query("select p from WalletPass p where p.id = :id and p.establishmentId = :establishmentId")
    Optional<WalletPass> findInEstablishment(@Param("establishmentId") Long establishmentId, @Param("id") Long id);

    /** Reserva exclusiva para envio (SELECT ... FOR UPDATE): dois processos nunca enviam o mesmo passe ao mesmo tempo. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select p from WalletPass p where p.id = :id")
    Optional<WalletPass> lockById(@Param("id") Long id);

    @Query("""
            select p.id from WalletPass p
            where p.provider in :providers
              and ((p.syncStatus = com.shaminatech.pass.loyalty.wallet.WalletPass.SyncStatus.PENDING
                     and (p.nextAttemptAt is null or p.nextAttemptAt <= :now))
               or (p.syncStatus = com.shaminatech.pass.loyalty.wallet.WalletPass.SyncStatus.FAILED
                     and p.nextAttemptAt is not null and p.nextAttemptAt <= :now)
               or (p.syncStatus = com.shaminatech.pass.loyalty.wallet.WalletPass.SyncStatus.SYNCING
                     and (p.leaseUntil is null or p.leaseUntil <= :now)))
            order by p.nextAttemptAt, p.id
            """)
    List<Long> findDueIds(@Param("now") Instant now, @Param("providers") List<Provider> providers, Pageable pageable);

    @Query(value = "select p from WalletPass p where p.establishmentId = :establishmentId and p.syncStatus in :statuses",
            countQuery = "select count(p) from WalletPass p where p.establishmentId = :establishmentId and p.syncStatus in :statuses")
    Page<WalletPass> findInEstablishment(@Param("establishmentId") Long establishmentId,
                                         @Param("statuses") List<SyncStatus> statuses, Pageable pageable);

    @Query("select p.syncStatus, count(p) from WalletPass p where p.establishmentId = :establishmentId group by p.syncStatus")
    List<Object[]> countByStatus(@Param("establishmentId") Long establishmentId);
}
