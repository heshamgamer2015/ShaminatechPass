package com.shaminatech.pass.loyalty.wallet;

import java.time.Clock;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.shaminatech.pass.loyalty.card.CardChangedEvent;

/**
 * Liga o motor de fidelidade à carteira sem alterá-lo:
 * <ol>
 *   <li>BEFORE_COMMIT (mesma transação da movimentação): marca os passes do cartão como pendentes. Se a movimentação
 *       for desfeita, a marcação também é — e nunca existe saldo novo sem pendência de envio;</li>
 *   <li>após o commit: pede o envio ao {@link WalletSyncDispatcher}, fora de qualquer transação.</li>
 * </ol>
 */
@Component
public class WalletSyncListener {

    private final WalletPassRepository passes;
    private final WalletSyncDispatcher dispatcher;
    private final Clock clock;

    public WalletSyncListener(WalletPassRepository passes, WalletSyncDispatcher dispatcher, Clock clock) {
        this.passes = passes;
        this.dispatcher = dispatcher;
        this.clock = clock;
    }

    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
    public void onCardChanged(CardChangedEvent event) {
        List<Long> ids = new ArrayList<>();
        for (WalletPass pass : passes.findByCardId(event.cardId())) {
            pass.markChanged(clock.instant());
            ids.add(pass.getId());
        }
        afterCommit(ids);
    }

    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
    public void onProgramChanged(ProgramChangedEvent event) {
        List<Long> ids = new ArrayList<>();
        for (WalletPass pass : passes.findByProgram(event.programId())) {
            pass.markChanged(clock.instant());
            ids.add(pass.getId());
        }
        afterCommit(ids);
    }

    /** Pede o envio dos passes ao final do commit (agrupa vários eventos da mesma transação). */
    public void afterCommit(List<Long> ids) {
        if (ids.isEmpty()) {
            return;
        }
        if (!TransactionSynchronizationManager.isSynchronizationActive()) {
            dispatcher.dispatch(ids);
            return;
        }
        Set<Long> pending = pendingSet();
        pending.addAll(ids);
    }

    @SuppressWarnings("unchecked")
    private Set<Long> pendingSet() {
        Object key = WalletSyncListener.class;
        Set<Long> set = (Set<Long>) TransactionSynchronizationManager.getResource(key);
        if (set == null) {
            Set<Long> created = new LinkedHashSet<>();
            TransactionSynchronizationManager.bindResource(key, created);
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCompletion(int status) {
                    TransactionSynchronizationManager.unbindResourceIfPossible(key);
                    if (status == STATUS_COMMITTED) {
                        dispatcher.dispatch(List.copyOf(created));
                    }
                }
            });
            set = created;
        }
        return set;
    }
}
