package com.shaminatech.pass.auth.reset;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.HexFormat;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.common.web.ClientIp;
import com.shaminatech.pass.user.AppUser;
import com.shaminatech.pass.user.AppUserRepository;
import com.shaminatech.pass.user.EmailNormalizer;

/**
 * Recuperação de senha da conta empresarial (fundação — Etapa 8).
 * <ul>
 *   <li>Pedido: resposta sempre igual (não revela se o e-mail existe); limite por e-mail e por IP; um pedido novo
 *       invalida os anteriores; token de 256 bits aleatórios, gravado só como SHA-256; validade curta.</li>
 *   <li>Confirmação: uso único (com bloqueio de linha), política de senha forte, desbloqueio da conta; a troca do
 *       hash encerra todas as sessões abertas do usuário (marca de credencial). Erro sempre genérico.</li>
 *   <li>Sem canal de entrega configurado ({@link PasswordResetSender#available()} = false) nenhum token é emitido.</li>
 * </ul>
 * Nunca registra o token, o hash nem a senha em logs ou auditoria.
 */
@Service
public class PasswordResetService {

    private static final Logger log = LoggerFactory.getLogger(PasswordResetService.class);
    private static final SecureRandom RANDOM = new SecureRandom();
    public static final String INVALID_LINK = "Link de recuperação inválido ou expirado. Peça um novo.";

    private record Window(long hour, int count) {
    }

    private final PasswordResetTokenRepository tokens;
    private final AppUserRepository users;
    private final PasswordEncoder passwordEncoder;
    private final PasswordResetSender sender;
    private final AuditService audit;
    private final Clock clock;
    private final Duration validity;
    private final int maxPerEmailPerHour;
    private final int maxPerIpPerHour;
    private final Map<String, Window> attempts = new ConcurrentHashMap<>();

    public PasswordResetService(PasswordResetTokenRepository tokens, AppUserRepository users, PasswordEncoder passwordEncoder,
                                PasswordResetSender sender, AuditService audit, Clock clock,
                                @Value("${shaminatech.password-reset.validity:PT30M}") Duration validity,
                                @Value("${shaminatech.password-reset.max-per-email-per-hour:3}") int maxPerEmailPerHour,
                                @Value("${shaminatech.password-reset.max-per-ip-per-hour:20}") int maxPerIpPerHour) {
        this.tokens = tokens;
        this.users = users;
        this.passwordEncoder = passwordEncoder;
        this.sender = sender;
        this.audit = audit;
        this.clock = clock;
        this.validity = validity;
        this.maxPerEmailPerHour = maxPerEmailPerHour;
        this.maxPerIpPerHour = maxPerIpPerHour;
    }

    /** Pedido de recuperação. Não lança erro para e-mail inexistente; só para excesso de tentativas da conexão. */
    @Transactional
    public void request(String rawEmail) {
        String email = EmailNormalizer.normalize(rawEmail);
        String ip = ClientIp.current();
        if (!allow("ip:" + (ip == null ? "?" : ip), maxPerIpPerHour)) {
            throw new ApiException(HttpStatus.TOO_MANY_REQUESTS, "RATE_LIMITED", "Muitas tentativas. Aguarde e tente novamente.");
        }
        if (email == null || email.isBlank() || !allow("email:" + sha256(email), maxPerEmailPerHour)) {
            return; // excesso para o mesmo e-mail: resposta igual, sem novo token (não revela nada)
        }
        Optional<AppUser> user = users.findByEmail(email);
        if (user.isEmpty() || !user.get().isActive()) {
            return;
        }
        AppUser account = user.get();
        if (!sender.available()) {
            audit.recordAs(account.getId(), account.getEmail(), AuditAction.PASSWORD_RESET_REQUESTED, null, "USER", account.getId(),
                    "Envio de recuperação não configurado: nenhum link emitido");
            return;
        }
        Instant now = clock.instant();
        tokens.invalidateOpen(account.getId(), now);
        String token = newToken();
        tokens.save(new PasswordResetToken(account, sha256(token), now, now.plus(validity)));
        audit.recordAs(account.getId(), account.getEmail(), AuditAction.PASSWORD_RESET_REQUESTED, null, "USER", account.getId(),
                "Link de recuperação emitido (validade " + validity.toMinutes() + " min)");
        try {
            sender.send(account.getEmail(), account.getFullName(), token);
        } catch (RuntimeException e) {
            log.warn("Falha ao entregar o link de recuperação da conta {}", account.getId()); // sem e-mail nem token no log
            throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE, "RESET_DELIVERY_FAILED",
                    "Não foi possível enviar agora. Tente novamente em alguns minutos.");
        }
    }

    /** Troca a senha com um link válido. Qualquer problema com o link gera a mesma resposta. */
    @Transactional
    public void confirm(String token, String newPassword) {
        if (token == null || !token.matches("^[A-Za-z0-9_-]{43}$")) {
            throw invalidLink();
        }
        if (!allow("confirm:" + Optional.ofNullable(ClientIp.current()).orElse("?"), maxPerIpPerHour)) {
            throw new ApiException(HttpStatus.TOO_MANY_REQUESTS, "RATE_LIMITED", "Muitas tentativas. Aguarde e tente novamente.");
        }
        Instant now = clock.instant();
        PasswordResetToken reset = tokens.lockByHash(sha256(token)).orElseThrow(PasswordResetService::invalidLink);
        AppUser user = reset.getUser();
        if (!reset.usableAt(now) || !user.isActive()) {
            throw invalidLink();
        }
        if (passwordEncoder.matches(newPassword, user.getPasswordHash())) {
            throw ApiException.badRequest("A nova senha deve ser diferente da atual.", "newPassword");
        }
        reset.consume(now);
        tokens.invalidateOpen(user.getId(), now);
        user.changePassword(passwordEncoder.encode(newPassword), false); // novo hash: todas as sessões abertas são encerradas
        user.unlock();
        audit.recordAs(user.getId(), user.getEmail(), AuditAction.PASSWORD_RESET_COMPLETED, null, "USER", user.getId(),
                "Senha redefinida pelo link de recuperação; sessões anteriores encerradas");
    }

    private boolean allow(String key, int max) {
        long hour = clock.millis() / 3_600_000L;
        Window w = attempts.merge(key, new Window(hour, 1), (old, fresh) -> old.hour() == hour ? new Window(hour, old.count() + 1) : fresh);
        if (attempts.size() > 10_000) {
            attempts.entrySet().removeIf(e -> e.getValue().hour() < hour);
        }
        return w.count() <= max;
    }

    private static ApiException invalidLink() {
        return new ApiException(HttpStatus.BAD_REQUEST, "RESET_LINK_INVALID", INVALID_LINK);
    }

    /** 32 bytes aleatórios em Base64 URL (43 caracteres). */
    static String newToken() {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    static String sha256(String value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
