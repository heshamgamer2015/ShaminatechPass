package com.shaminatech.pass.common.persistence;

import jakarta.persistence.AttributeConverter;

/**
 * Persiste enums como texto legível (VARCHAR com o nome da constante) e valida na aplicação:
 * ao ler, um valor desconhecido gera erro ({@link Enum#valueOf}); ao gravar, só existem os valores do enum.
 * <p>
 * <b>CHECK no banco:</b> o conversor sozinho NÃO impede o Hibernate 7 de gerar
 * {@code CHECK (coluna IN (...))} — o Hibernate deriva essa lista do tipo Java do atributo (o enum), mesmo com
 * conversor. Quem impede é {@link EnumWithoutCheckJavaType}, registrado para todo enum que tenha um conversor
 * desta classe (ver {@link EnumCheckFreeTypeContributor}). Assim, novos valores de enum não exigem alteração
 * manual do banco.
 */
public abstract class EnumNameConverter<E extends Enum<E>> implements AttributeConverter<E, String> {

    private final Class<E> type;

    protected EnumNameConverter(Class<E> type) {
        this.type = type;
    }

    /** Enum convertido por este conversor. */
    public Class<E> enumType() {
        return type;
    }

    @Override
    public String convertToDatabaseColumn(E value) {
        return value == null ? null : value.name();
    }

    @Override
    public E convertToEntityAttribute(String value) {
        return value == null ? null : Enum.valueOf(type, value);
    }
}
