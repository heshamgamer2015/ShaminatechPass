package com.shaminatech.pass.loyalty.card;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.CardEnums.Channel;
import com.shaminatech.pass.loyalty.card.CardEnums.LotStatus;
import com.shaminatech.pass.loyalty.card.CardEnums.TransactionType;
import com.shaminatech.pass.loyalty.consumer.Consumer;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicy;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.LoyaltyReward;
import com.shaminatech.pass.loyalty.program.LoyaltyRewardRepository;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ExpiredBalancePolicy;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ProgramStatus;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ReversalPolicy;
import com.shaminatech.pass.loyalty.program.ProgramEnums.Rounding;
import com.shaminatech.pass.loyalty.program.ProgramEnums.StampCriterion;

/**
 * Motor de fidelidade: concessões, resgates, estornos, mudanças de estado e expiração.
 * <p>
 * Garantias:
 * <ul>
 *   <li><b>Concorrência:</b> toda operação trava a linha do cartão (SELECT ... FOR UPDATE) antes de ler o saldo;</li>
 *   <li><b>Idempotência:</b> concessões, resgates e estornos exigem uma chave; repetir a chave com os mesmos dados devolve
 *       o resultado original sem gravar nada; com dados diferentes, é recusado (409);</li>
 *   <li><b>Histórico imutável:</b> cada operação grava um {@link CardTransaction}; estornos são registros compensatórios;</li>
 *   <li><b>Validade:</b> renovada apenas por concessão ou resgate aceito, na mesma transação da movimentação.
 *       Estornos, consultas, mudanças de estado e operações recusadas ou repetidas não renovam.</li>
 * </ul>
 * Os métodos recebem o id do estabelecimento já autorizado pelo {@code TenantAccessService} e só encontram
 * cartões desse estabelecimento.
 */
@Service
public class CardEngine {

    public static final int MAX_STAMPS_PER_OPERATION = 50;
    public static final BigDecimal MAX_PURCHASE = new BigDecimal("9999999.99");
    private static final Pattern IDEMPOTENCY_KEY = Pattern.compile("^[A-Za-z0-9_-]{8,80}$");
    private static final EnumSet<CardStatus> OPEN_STATUSES = EnumSet.of(CardStatus.ACTIVE, CardStatus.SUSPENDED, CardStatus.EXPIRED);

    private final LoyaltyCardRepository cards;
    private final CardTransactionRepository transactions;
    private final BenefitLotRepository lots;
    private final LotUsageRepository usages;
    private final LoyaltyRewardRepository rewards;
    private final PolicyService policies;
    private final ApplicationEventPublisher events;
    private final Clock clock;

    public CardEngine(LoyaltyCardRepository cards, CardTransactionRepository transactions, BenefitLotRepository lots,
                      LotUsageRepository usages, LoyaltyRewardRepository rewards, PolicyService policies,
                      ApplicationEventPublisher events, Clock clock) {
        this.cards = cards;
        this.transactions = transactions;
        this.lots = lots;
        this.usages = usages;
        this.rewards = rewards;
        this.policies = policies;
        this.events = events;
        this.clock = clock;
    }

    public record EarnCommand(BigDecimal purchaseAmount, Integer quantity, Channel channel, String note) {
    }

    public record RedeemCommand(Long rewardId, BigDecimal amount, BigDecimal purchaseAmount, Channel channel, String note) {
    }

    /** {@code replayed=true}: a chave de idempotência já tinha sido usada; nada novo foi gravado. */
    public record Result(CardTransaction transaction, LoyaltyCard card, boolean replayed, BigDecimal notRestored) {
    }

    private record Take(BenefitLot lot, BigDecimal amount) {
    }

    // =====================================================================================
    // Emissão e estados do cartão
    // =====================================================================================

    /** Emite um cartão. O consumidor já deve estar travado (FOR UPDATE) pelo chamador. */
    @Transactional
    public LoyaltyCard issue(Consumer consumer, LoyaltyProgram program, Integer inactivityDaysOverride, Long actorUserId) {
        return issue(consumer, program, inactivityDaysOverride, actorUserId, Channel.MANUAL);
    }

    /** Emissão com canal explícito ({@link Channel#PUBLIC_SIGNUP} no autocadastro, sem usuário autor). */
    @Transactional
    public LoyaltyCard issue(Consumer consumer, LoyaltyProgram program, Integer inactivityDaysOverride, Long actorUserId,
                             Channel channel) {
        if (!consumer.isActive()) {
            throw ApiException.state("CONSUMER_INACTIVE", "O cadastro deste cliente está inativo. Reative-o antes de emitir um cartão.");
        }
        EstablishmentPolicy policy = policies.of(program.getEstablishmentId());
        requireProgramAvailable(program, policy);
        if (cards.existsOpenCard(consumer.getId(), program.getId(), OPEN_STATUSES)) {
            throw ApiException.state("CARD_ALREADY_EXISTS",
                    "Este cliente já tem um cartão deste programa. Se ele estiver expirado ou desativado, reative-o.");
        }
        Instant now = clock.instant();
        int days = inactivityDaysOverride != null ? inactivityDaysOverride : program.getInactivityDays();
        LoyaltyCard card = new LoyaltyCard(consumer, program, uniqueCode(), now,
                Validity.expiresAt(now, days, program.getValidityMode(), policy.zone()), inactivityDaysOverride);
        cards.save(card);
        transactions.save(new CardTransaction(card, TransactionType.CARD_ISSUED, channel, BigDecimal.ZERO, now, actorUserId));
        publish(card);
        return card;
    }

    @Transactional
    public LoyaltyCard suspend(Long establishmentId, Long cardId, String reason, Long actorUserId) {
        LoyaltyCard card = lock(establishmentId, cardId);
        Instant now = clock.instant();
        if (card.isOverdue(now)) {
            throw ApiException.state("CARD_EXPIRED", "Este cartão venceu por inatividade.");
        }
        if (card.getStatus() != CardStatus.ACTIVE) {
            throw ApiException.state("CARD_NOT_ACTIVE", "Somente cartões ativos podem ser desativados.");
        }
        card.changeStatus(CardStatus.SUSPENDED, now, trimToNull(reason));
        transactions.save(new CardTransaction(card, TransactionType.CARD_SUSPENDED, Channel.MANUAL, BigDecimal.ZERO, now, actorUserId)
                .note(trimToNull(reason)));
        publish(card);
        return card;
    }

    /**
     * Reativação autorizada pela empresa. Cartão desativado ainda dentro da validade mantém a data de vencimento;
     * cartão expirado recebe nova validade contada a partir da reativação.
     */
    @Transactional
    public LoyaltyCard reactivate(Long establishmentId, Long cardId, String reason, Long actorUserId) {
        LoyaltyCard card = lock(establishmentId, cardId);
        Instant now = clock.instant();
        if (card.isOverdue(now)) {
            expireCard(card, now); // aplica a regra de saldo do programa antes de reativar
        }
        if (card.getStatus() != CardStatus.SUSPENDED && card.getStatus() != CardStatus.EXPIRED) {
            throw ApiException.state("CARD_NOT_REACTIVATABLE", "Somente cartões desativados ou expirados podem ser reativados.");
        }
        if (!card.getConsumer().isActive()) {
            throw ApiException.state("CONSUMER_INACTIVE", "O cadastro deste cliente está inativo. Reative-o antes do cartão.");
        }
        LoyaltyProgram program = card.getProgram();
        EstablishmentPolicy policy = policies.of(establishmentId);
        requireProgramAvailable(program, policy);
        if (card.getStatus() == CardStatus.EXPIRED) {
            card.reactivateUntil(Validity.expiresAt(now, card.inactivityDays(), program.getValidityMode(), policy.zone()));
        }
        card.changeStatus(CardStatus.ACTIVE, now, trimToNull(reason));
        transactions.save(new CardTransaction(card, TransactionType.CARD_REACTIVATED, Channel.MANUAL, BigDecimal.ZERO, now, actorUserId)
                .note(trimToNull(reason)));
        publish(card);
        return card;
    }

    /** Cancelamento definitivo. O registro e o histórico são preservados; o cartão nunca mais aceita movimentações. */
    @Transactional
    public LoyaltyCard cancel(Long establishmentId, Long cardId, String reason, Long actorUserId) {
        if (reason == null || reason.isBlank()) {
            throw ApiException.badRequest("Informe o motivo do cancelamento.", "reason");
        }
        LoyaltyCard card = lock(establishmentId, cardId);
        if (card.getStatus() == CardStatus.CANCELLED) {
            throw ApiException.state("CARD_CANCELLED", "Este cartão já está cancelado.");
        }
        Instant now = clock.instant();
        card.changeStatus(CardStatus.CANCELLED, now, reason.trim());
        transactions.save(new CardTransaction(card, TransactionType.CARD_CANCELLED, Channel.MANUAL, BigDecimal.ZERO, now, actorUserId)
                .note(reason.trim()));
        publish(card);
        return card;
    }

    // =====================================================================================
    // Concessão
    // =====================================================================================

    @Transactional
    public Result earn(Long establishmentId, Long cardId, EarnCommand command, String idempotencyKey, Long actorUserId) {
        requireKey(idempotencyKey);
        Channel channel = requireChannel(command.channel());
        BigDecimal purchase = money(command.purchaseAmount(), "purchaseAmount");
        LoyaltyCard card = lock(establishmentId, cardId);
        String fingerprint = fingerprint("EARN", cardId, purchase, command.quantity(), null, null, channel);
        Optional<Result> replay = replay(establishmentId, idempotencyKey, fingerprint, card);
        if (replay.isPresent()) {
            return replay.get();
        }
        Instant now = clock.instant();
        EstablishmentPolicy policy = policies.of(establishmentId);
        ensureUsable(card, policy, now);
        LoyaltyProgram program = card.getProgram();

        BigDecimal amount = switch (program.getType()) {
            case POINTS -> points(program, purchase);
            case CASHBACK -> cashback(program, purchase);
            case STAMPS -> stamps(program, card, purchase, command.quantity());
            case VIP -> throw notOperational();
        };

        BigDecimal before = card.getBalance();
        card.applyDelta(amount);
        renew(card, policy, now);
        CardTransaction tx = transactions.save(new CardTransaction(card, TransactionType.EARN, channel, amount, now, actorUserId)
                .purchase(purchase).note(trimToNull(command.note())).idempotency(idempotencyKey, fingerprint));
        // Se o saldo estava negativo (estorno com ALLOW_NEGATIVE), parte da concessão apenas quita a diferença.
        BigDecimal lotAmount = before.signum() < 0 ? amount.add(before).max(BigDecimal.ZERO) : amount;
        Instant benefitExpiry = program.getBenefitValidityDays() == null ? null
                : Validity.expiresAt(now, program.getBenefitValidityDays(), program.getValidityMode(), policy.zone());
        lots.save(new BenefitLot(card, tx.getId(), amount, lotAmount, benefitExpiry));
        publish(card);
        return new Result(tx, card, false, BigDecimal.ZERO);
    }

    private BigDecimal points(LoyaltyProgram program, BigDecimal purchase) {
        requirePurchase(purchase);
        requireMinimum(program, purchase);
        BigDecimal units = purchase.divide(program.getSpendUnit(), 10, RoundingMode.DOWN);
        BigDecimal points = units.multiply(BigDecimal.valueOf(program.getPointsPerUnit()))
                .setScale(0, rounding(program).mode());
        if (points.signum() <= 0) {
            throw ApiException.rule("NO_BENEFIT", "Este valor não gera pontos pelas regras do programa.", "purchaseAmount");
        }
        return points.setScale(2);
    }

    private BigDecimal cashback(LoyaltyProgram program, BigDecimal purchase) {
        requirePurchase(purchase);
        requireMinimum(program, purchase);
        BigDecimal credit = purchase.multiply(program.getCashbackPercent())
                .divide(BigDecimal.valueOf(100), 2, rounding(program).mode());
        if (program.getMaxCreditPerPurchase() != null) {
            credit = credit.min(program.getMaxCreditPerPurchase());
        }
        if (credit.signum() <= 0) {
            throw ApiException.rule("NO_BENEFIT", "Este valor não gera cashback pelas regras do programa.", "purchaseAmount");
        }
        return credit;
    }

    private BigDecimal stamps(LoyaltyProgram program, LoyaltyCard card, BigDecimal purchase, Integer quantity) {
        int qty = quantity == null ? 1 : quantity;
        if (qty < 1 || qty > MAX_STAMPS_PER_OPERATION) {
            throw ApiException.badRequest("Informe de 1 a " + MAX_STAMPS_PER_OPERATION + " carimbos.", "quantity");
        }
        if (program.getStampCriterion() == StampCriterion.PURCHASE && program.getMinPurchaseAmount() != null) {
            requirePurchase(purchase);
            requireMinimum(program, purchase);
        }
        BigDecimal required = BigDecimal.valueOf(program.getStampsRequired());
        BigDecimal balance = card.getBalance();
        if (balance.compareTo(required) >= 0) {
            throw ApiException.state("CARD_FULL", "Cartão completo: resgate a recompensa antes de conceder novos carimbos.");
        }
        BigDecimal missing = required.subtract(balance.max(BigDecimal.ZERO));
        if (BigDecimal.valueOf(qty).compareTo(missing) > 0) {
            throw ApiException.rule("TOO_MANY_STAMPS", "Faltam apenas " + missing.toBigInteger() + " carimbo(s) para completar o cartão.",
                    "quantity");
        }
        return BigDecimal.valueOf(qty).setScale(2);
    }

    // =====================================================================================
    // Resgate
    // =====================================================================================

    @Transactional
    public Result redeem(Long establishmentId, Long cardId, RedeemCommand command, String idempotencyKey, Long actorUserId) {
        requireKey(idempotencyKey);
        Channel channel = requireChannel(command.channel());
        BigDecimal requestedAmount = money(command.amount(), "amount");
        BigDecimal purchase = money(command.purchaseAmount(), "purchaseAmount");
        LoyaltyCard card = lock(establishmentId, cardId);
        String fingerprint = fingerprint("REDEEM", cardId, purchase, null, command.rewardId(), requestedAmount, channel);
        Optional<Result> replay = replay(establishmentId, idempotencyKey, fingerprint, card);
        if (replay.isPresent()) {
            return replay.get();
        }
        Instant now = clock.instant();
        EstablishmentPolicy policy = policies.of(establishmentId);
        ensureUsable(card, policy, now);
        LoyaltyProgram program = card.getProgram();
        BigDecimal available = available(card, now);

        BigDecimal cost;
        Long rewardId = null;
        String description;
        switch (program.getType()) {
            case POINTS -> {
                if (command.rewardId() == null) {
                    throw ApiException.badRequest("Escolha a recompensa.", "rewardId");
                }
                LoyaltyReward reward = rewards.findInEstablishment(establishmentId, command.rewardId())
                        .filter(r -> r.getProgram().getId().equals(program.getId()))
                        .orElseThrow(() -> ApiException.notFound("Recompensa não encontrada neste programa."));
                if (!reward.isActive()) {
                    throw ApiException.state("REWARD_INACTIVE", "Esta recompensa está desativada.");
                }
                cost = reward.getCost();
                rewardId = reward.getId();
                description = reward.getName();
            }
            case CASHBACK -> {
                if (requestedAmount == null || requestedAmount.signum() <= 0) {
                    throw ApiException.badRequest("Informe o valor a utilizar.", "amount");
                }
                if (program.getMinRedeemBalance() != null && available.compareTo(program.getMinRedeemBalance()) < 0) {
                    throw ApiException.rule("BELOW_MIN_REDEEM_BALANCE",
                            "O saldo mínimo para usar o cashback é R$ " + program.getMinRedeemBalance() + ".", "amount");
                }
                if (program.getMaxRedeemPercent() != null) {
                    requirePurchase(purchase);
                    BigDecimal limit = purchase.multiply(program.getMaxRedeemPercent()).divide(BigDecimal.valueOf(100), 2, RoundingMode.DOWN);
                    if (requestedAmount.compareTo(limit) > 0) {
                        throw ApiException.rule("ABOVE_MAX_REDEEM", "Nesta compra, o máximo que pode ser abatido é R$ " + limit + ".", "amount");
                    }
                }
                cost = requestedAmount;
                description = "Uso de cashback";
            }
            case STAMPS -> {
                cost = BigDecimal.valueOf(program.getStampsRequired()).setScale(2);
                description = program.getStampReward();
            }
            default -> throw notOperational();
        }
        if (available.compareTo(cost) < 0) {
            throw ApiException.state("INSUFFICIENT_BALANCE", program.getType() == ProgramType.STAMPS
                    ? "O cartão ainda não está completo." : "Saldo insuficiente para este resgate.");
        }

        List<Take> takes = takeFifo(card, cost, now, false);
        card.applyDelta(cost.negate());
        if (program.getType() == ProgramType.STAMPS) {
            card.completeCycle();
            if (!Boolean.TRUE.equals(program.getRestartAfterRedeem())) {
                card.changeStatus(CardStatus.COMPLETED, now, "Cartão concluído e recompensa resgatada");
            }
        }
        renew(card, policy, now);
        CardTransaction tx = transactions.save(new CardTransaction(card, TransactionType.REDEEM, channel, cost.negate(), now, actorUserId)
                .purchase(purchase).reward(rewardId).description(description).note(trimToNull(command.note()))
                .idempotency(idempotencyKey, fingerprint));
        saveUsages(takes, tx);
        publish(card);
        return new Result(tx, card, false, BigDecimal.ZERO);
    }

    // =====================================================================================
    // Estorno (operação compensatória)
    // =====================================================================================

    @Transactional
    public Result reverse(Long establishmentId, Long transactionId, String reason, String idempotencyKey, Long actorUserId) {
        requireKey(idempotencyKey);
        if (reason == null || reason.isBlank()) {
            throw ApiException.badRequest("Informe o motivo do estorno.", "reason");
        }
        CardTransaction original = transactions.findInEstablishment(establishmentId, transactionId)
                .orElseThrow(() -> ApiException.notFound("Movimentação não encontrada."));
        LoyaltyCard card = lock(establishmentId, original.getCard().getId());
        String fingerprint = fingerprint("REVERSAL", transactionId, null, null, null, null, Channel.MANUAL);
        Optional<Result> replay = replay(establishmentId, idempotencyKey, fingerprint, card);
        if (replay.isPresent()) {
            return replay.get();
        }
        if (!original.getType().isMovement()) {
            throw ApiException.rule("NOT_REVERSIBLE", "Somente concessões e resgates podem ser estornados.", null);
        }
        if (transactions.existsByReversesId(transactionId)) {
            throw ApiException.state("ALREADY_REVERSED", "Esta movimentação já foi estornada.");
        }
        if (card.getStatus() == CardStatus.CANCELLED) {
            throw ApiException.state("CARD_CANCELLED", "Cartão cancelado: não aceita novas movimentações, nem estornos.");
        }
        Instant now = clock.instant();
        LoyaltyProgram program = card.getProgram();
        BigDecimal delta;
        BigDecimal notRestored = BigDecimal.ZERO;
        List<Take> takes = List.of();

        if (original.getType() == TransactionType.EARN) {
            BenefitLot sourceLot = lots.findBySourceTransactionId(original.getId()).orElse(null);
            // O que já venceu deste lote saiu do saldo pela expiração: não é debitado de novo.
            BigDecimal toRemove = original.getAmount().subtract(sourceLot == null ? BigDecimal.ZERO : sourceLot.getExpiredAmount())
                    .max(BigDecimal.ZERO);
            takes = new ArrayList<>();
            BigDecimal pending = toRemove;
            if (sourceLot != null && sourceLot.getStatus() == LotStatus.OPEN) {
                BigDecimal taken = sourceLot.take(pending);
                if (taken.signum() > 0) {
                    takes.add(new Take(sourceLot, taken));
                    pending = pending.subtract(taken);
                }
            }
            if (pending.signum() > 0) {
                List<Take> others = takeFifo(card, pending, now, true);
                takes.addAll(others);
                pending = pending.subtract(others.stream().map(Take::amount).reduce(BigDecimal.ZERO, BigDecimal::add));
            }
            if (pending.signum() > 0 && program.getReversalPolicy() == ReversalPolicy.REQUIRE_BALANCE) {
                throw ApiException.state("INSUFFICIENT_BALANCE_FOR_REVERSAL",
                        "O saldo atual não cobre este estorno (parte já foi utilizada). Pela regra do programa, o estorno não é permitido.");
            }
            delta = toRemove.negate();
        } else {
            BigDecimal restored = BigDecimal.ZERO;
            for (LotUsage usage : usages.findByTransactionId(original.getId())) {
                BenefitLot lot = lots.findById(usage.getLotId()).orElse(null);
                boolean stillValid = lot != null && (lot.getStatus() == LotStatus.OPEN || lot.getStatus() == LotStatus.CONSUMED)
                        && (lot.getExpiresAt() == null || now.isBefore(lot.getExpiresAt()));
                if (stillValid) {
                    lot.restore(usage.getAmount());
                    restored = restored.add(usage.getAmount());
                } else {
                    notRestored = notRestored.add(usage.getAmount());
                }
            }
            delta = restored;
            if (program.getType() == ProgramType.STAMPS) {
                card.undoCycle();
                if (card.getStatus() == CardStatus.COMPLETED) {
                    card.changeStatus(CardStatus.ACTIVE, now, "Resgate estornado");
                }
            }
        }
        card.applyDelta(delta);
        CardTransaction tx = transactions.save(new CardTransaction(card, TransactionType.REVERSAL, Channel.MANUAL, delta, now, actorUserId)
                .reverses(original.getId()).note(reason.trim()).idempotency(idempotencyKey, fingerprint)
                .description(notRestored.signum() > 0 ? notRestored.stripTrailingZeros().toPlainString()
                        + " não restaurado(s): os benefícios originais já tinham vencido" : null));
        saveUsages(takes, tx);
        publish(card);
        return new Result(tx, card, false, notRestored);
    }

    // =====================================================================================
    // Expiração (chamada pelo processamento periódico, com o cartão já travado)
    // =====================================================================================

    /** Marca o cartão como EXPIRED se venceu por inatividade. Idempotente. Devolve true se alterou. */
    @Transactional
    public boolean expireCard(LoyaltyCard card, Instant now) {
        if (!card.isOverdue(now)) {
            return false;
        }
        card.changeStatus(CardStatus.EXPIRED, now, "Inatividade");
        transactions.save(new CardTransaction(card, TransactionType.CARD_EXPIRED, Channel.SYSTEM, BigDecimal.ZERO, now, null));
        if (card.getProgram().getExpiredBalancePolicy() == ExpiredBalancePolicy.FORFEIT) {
            BigDecimal forfeited = BigDecimal.ZERO;
            for (BenefitLot lot : lots.findOpenByCard(card.getId())) {
                forfeited = forfeited.add(lot.expire(LotStatus.FORFEITED));
            }
            if (forfeited.signum() > 0) {
                card.applyDelta(forfeited.negate());
                transactions.save(new CardTransaction(card, TransactionType.BALANCE_FORFEITED, Channel.SYSTEM, forfeited.negate(), now, null)
                        .description("Saldo zerado pela expiração do cartão (regra do programa)"));
            }
        }
        publish(card);
        return true;
    }

    /** Vence os lotes cuja validade própria passou. Idempotente. Devolve o total vencido. */
    @Transactional
    public BigDecimal expireLots(LoyaltyCard card, Instant now) {
        if (card.getStatus() == CardStatus.CANCELLED) {
            return BigDecimal.ZERO;
        }
        BigDecimal expired = BigDecimal.ZERO;
        for (BenefitLot lot : lots.findOpenByCard(card.getId())) {
            if (lot.getExpiresAt() != null && !now.isBefore(lot.getExpiresAt())) {
                expired = expired.add(lot.expire(LotStatus.EXPIRED));
            }
        }
        if (expired.signum() > 0) {
            card.applyDelta(expired.negate());
            transactions.save(new CardTransaction(card, TransactionType.BENEFIT_EXPIRED, Channel.SYSTEM, expired.negate(), now, null)
                    .description("Benefícios vencidos pela validade própria"));
            publish(card);
        }
        return expired;
    }

    // =====================================================================================
    // Apoio
    // =====================================================================================

    /** Saldo utilizável agora: soma dos lotes abertos e dentro da validade. */
    public BigDecimal available(LoyaltyCard card, Instant now) {
        return lots.findOpenByCard(card.getId()).stream().filter(l -> l.isUsable(now))
                .map(BenefitLot::getRemaining).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private List<Take> takeFifo(LoyaltyCard card, BigDecimal amount, Instant now, boolean includeOverdue) {
        List<Take> takes = new ArrayList<>();
        BigDecimal pending = amount;
        for (BenefitLot lot : lots.findOpenByCard(card.getId())) {
            if (pending.signum() <= 0) {
                break;
            }
            if (!includeOverdue && !lot.isUsable(now)) {
                continue;
            }
            BigDecimal taken = lot.take(pending);
            if (taken.signum() > 0) {
                takes.add(new Take(lot, taken));
                pending = pending.subtract(taken);
            }
        }
        return takes;
    }

    private void saveUsages(List<Take> takes, CardTransaction tx) {
        for (Take take : takes) {
            usages.save(new LotUsage(take.lot().getId(), tx.getId(), take.amount()));
        }
    }

    private void renew(LoyaltyCard card, EstablishmentPolicy policy, Instant now) {
        card.renew(now, Validity.expiresAt(now, card.inactivityDays(), card.getProgram().getValidityMode(), policy.zone()));
    }

    private void ensureUsable(LoyaltyCard card, EstablishmentPolicy policy, Instant now) {
        switch (card.getStatus()) {
            case CANCELLED -> throw ApiException.state("CARD_CANCELLED", "Cartão cancelado: não aceita movimentações.");
            case SUSPENDED -> throw ApiException.state("CARD_SUSPENDED", "Cartão desativado. Reative-o para movimentar.");
            case COMPLETED -> throw ApiException.state("CARD_COMPLETED", "Cartão concluído. Emita um novo cartão para o cliente.");
            case EXPIRED -> throw ApiException.state("CARD_EXPIRED", "Cartão expirado por inatividade. A empresa pode reativá-lo.");
            case ACTIVE -> {
                if (card.isOverdue(now)) {
                    throw ApiException.state("CARD_EXPIRED", "Cartão expirado por inatividade. A empresa pode reativá-lo.");
                }
            }
        }
        if (!card.getConsumer().isActive()) {
            throw ApiException.state("CONSUMER_INACTIVE", "O cadastro deste cliente está inativo.");
        }
        LoyaltyProgram program = card.getProgram();
        if (program.getStatus() != ProgramStatus.ACTIVE) {
            throw ApiException.state("PROGRAM_NOT_ACTIVE", "Este programa está pausado ou encerrado.");
        }
        requireProgramAvailable(program, policy);
    }

    private static void requireProgramAvailable(LoyaltyProgram program, EstablishmentPolicy policy) {
        if (program.getStatus() == ProgramStatus.ARCHIVED) {
            throw ApiException.state("PROGRAM_ARCHIVED", "Este programa foi encerrado.");
        }
        if (!policy.allows(program.getType())) {
            throw new ApiException(org.springframework.http.HttpStatus.FORBIDDEN, "PROGRAM_TYPE_NOT_ALLOWED",
                    "Este tipo de cartão não está habilitado para o seu estabelecimento. Fale com a ShaminaTech.");
        }
        if (!program.getType().isOperational()) {
            throw notOperational();
        }
    }

    private Optional<Result> replay(Long establishmentId, String key, String fingerprint, LoyaltyCard card) {
        return transactions.findByEstablishmentIdAndIdempotencyKey(establishmentId, key).map(existing -> {
            if (!Objects.equals(existing.getRequestFingerprint(), fingerprint)) {
                throw ApiException.state("IDEMPOTENCY_CONFLICT",
                        "Esta chave de operação já foi usada com outros dados. Recarregue a tela e tente novamente.");
            }
            return new Result(existing, card, true, BigDecimal.ZERO);
        });
    }

    private LoyaltyCard lock(Long establishmentId, Long cardId) {
        return cards.lockInEstablishment(establishmentId, cardId)
                .orElseThrow(() -> ApiException.notFound("Cartão não encontrado."));
    }

    private String uniqueCode() {
        for (int attempt = 0; attempt < 10; attempt++) {
            String code = CardCodes.generate();
            if (!cards.existsByCode(code)) {
                return code;
            }
        }
        throw new IllegalStateException("Não foi possível gerar um código de cartão único.");
    }

    private void publish(LoyaltyCard card) {
        events.publishEvent(new CardChangedEvent(card.getId(), card.getEstablishmentId()));
    }

    private static void requireKey(String key) {
        if (key == null || !IDEMPOTENCY_KEY.matcher(key).matches()) {
            throw ApiException.badRequest("Chave de idempotência ausente ou inválida (cabeçalho Idempotency-Key).", null);
        }
    }

    private static Channel requireChannel(Channel channel) {
        Channel value = channel == null ? Channel.MANUAL : channel;
        if (!value.acceptedFromPanel()) {
            throw ApiException.badRequest("Canal ainda não habilitado: " + value + ".", "channel");
        }
        return value;
    }

    private static BigDecimal money(BigDecimal value, String field) {
        if (value == null) {
            return null;
        }
        if (value.signum() <= 0 || value.compareTo(MAX_PURCHASE) > 0) {
            throw ApiException.badRequest("Informe um valor maior que zero.", field);
        }
        if (value.stripTrailingZeros().scale() > 2) {
            throw ApiException.badRequest("Use no máximo 2 casas decimais.", field);
        }
        return value.setScale(2, RoundingMode.UNNECESSARY);
    }

    private static void requirePurchase(BigDecimal purchase) {
        if (purchase == null) {
            throw ApiException.badRequest("Informe o valor da compra.", "purchaseAmount");
        }
    }

    private static void requireMinimum(LoyaltyProgram program, BigDecimal purchase) {
        if (program.getMinPurchaseAmount() != null && purchase.compareTo(program.getMinPurchaseAmount()) < 0) {
            throw ApiException.rule("BELOW_MINIMUM", "O valor mínimo da compra para este programa é R$ "
                    + program.getMinPurchaseAmount() + ".", "purchaseAmount");
        }
    }

    private static Rounding rounding(LoyaltyProgram program) {
        return program.getRounding() == null ? Rounding.DOWN : program.getRounding();
    }

    private static ApiException notOperational() {
        return ApiException.rule("PROGRAM_NOT_OPERATIONAL", "Este tipo de programa ainda não está operacional.", null);
    }

    private static String fingerprint(String operation, Long id, BigDecimal purchase, Integer quantity, Long rewardId,
                                      BigDecimal amount, Channel channel) {
        String raw = String.join("|", operation, String.valueOf(id), plain(purchase), String.valueOf(quantity),
                String.valueOf(rewardId), plain(amount), String.valueOf(channel));
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    private static String plain(BigDecimal value) {
        return value == null ? "null" : value.stripTrailingZeros().toPlainString();
    }

    private static String trimToNull(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.length() > 200 ? trimmed.substring(0, 200) : trimmed;
    }
}
