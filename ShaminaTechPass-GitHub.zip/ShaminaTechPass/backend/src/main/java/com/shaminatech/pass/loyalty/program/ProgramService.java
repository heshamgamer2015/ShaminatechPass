package com.shaminatech.pass.loyalty.program;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.loyalty.LoyaltyDtos.DesignRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ProgramRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ProgramView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.RewardRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.RewardView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.VipTierRequest;
import com.shaminatech.pass.loyalty.LoyaltyDtos.VipTierView;
import com.shaminatech.pass.loyalty.LoyaltyViews;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicy;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ProgramStatus;
import com.shaminatech.pass.loyalty.program.ProgramEnums.Rounding;
import com.shaminatech.pass.loyalty.program.ProgramEnums.StampCriterion;
import com.shaminatech.pass.membership.Permission;
import com.shaminatech.pass.tenant.TenantAccess;
import com.shaminatech.pass.tenant.TenantAccessService;

/**
 * Configuração dos programas de fidelidade. O backend valida que o tipo esteja habilitado para o estabelecimento
 * pela ShaminaTech, independentemente da interface. Mudanças de regra valem para as próximas movimentações.
 */
@Service
public class ProgramService {

    private static final List<String> DEFAULT_VIP_TIERS = List.of("Bronze", "Prata", "Ouro", "Diamante");

    private final TenantAccessService tenantAccess;
    private final LoyaltyProgramRepository programs;
    private final LoyaltyRewardRepository rewards;
    private final VipTierRepository tiers;
    private final PolicyService policies;
    private final LoyaltyViews views;
    private final AuditService audit;
    private final org.springframework.context.ApplicationEventPublisher events;
    private final com.shaminatech.pass.plan.PlanService planLimits;

    public ProgramService(TenantAccessService tenantAccess, LoyaltyProgramRepository programs, LoyaltyRewardRepository rewards,
                          VipTierRepository tiers, PolicyService policies, LoyaltyViews views, AuditService audit,
                          org.springframework.context.ApplicationEventPublisher events,
                          com.shaminatech.pass.plan.PlanService planLimits) {
        this.events = events;
        this.planLimits = planLimits;
        this.tenantAccess = tenantAccess;
        this.programs = programs;
        this.rewards = rewards;
        this.tiers = tiers;
        this.policies = policies;
        this.views = views;
        this.audit = audit;
    }

    @Transactional(readOnly = true)
    public List<ProgramView> list(Long establishmentId) {
        tenantAccess.require(establishmentId, Permission.ESTABLISHMENT_VIEW);
        EstablishmentPolicy policy = policies.of(establishmentId);
        return programs.findAllInEstablishment(establishmentId).stream().map(p -> views.program(p, policy)).toList();
    }

    @Transactional(readOnly = true)
    public ProgramView get(Long establishmentId, Long programId) {
        tenantAccess.require(establishmentId, Permission.ESTABLISHMENT_VIEW);
        return views.program(find(establishmentId, programId), policies.of(establishmentId));
    }

    @Transactional
    public ProgramView create(Long establishmentId, ProgramRequest request) {
        TenantAccess access = tenantAccess.require(establishmentId, Permission.PROGRAMS_MANAGE);
        // Política travada: criações simultâneas do mesmo estabelecimento são serializadas (limites do plano).
        EstablishmentPolicy policy = policies.lock(establishmentId);
        if (!policy.allows(request.type())) {
            throw new ApiException(org.springframework.http.HttpStatus.FORBIDDEN, "PROGRAM_TYPE_NOT_ALLOWED",
                    "Este tipo de cartão não está habilitado para o seu estabelecimento. Fale com a ShaminaTech.");
        }
        planLimits.requireProgramSlot(establishmentId, request.type());
        LoyaltyProgram program = new LoyaltyProgram(access.establishment(), request.type(), request.name().trim(),
                request.inactivityDays());
        apply(program, request);
        programs.save(program);
        if (program.getType() == ProgramType.VIP) {
            for (int i = 0; i < DEFAULT_VIP_TIERS.size(); i++) {
                tiers.save(new VipTier(program, DEFAULT_VIP_TIERS.get(i), i + 1));
            }
        }
        audit.record(AuditAction.PROGRAM_CREATED, establishmentId, "PROGRAM", program.getId(), "type=" + program.getType());
        return views.program(program, policy);
    }

    @Transactional
    public ProgramView update(Long establishmentId, Long programId, ProgramRequest request) {
        tenantAccess.require(establishmentId, Permission.PROGRAMS_MANAGE);
        LoyaltyProgram program = find(establishmentId, programId);
        if (request.type() != program.getType()) {
            throw ApiException.badRequest("O tipo de um programa não pode ser alterado. Crie um novo programa.", "type");
        }
        if (program.getStatus() == ProgramStatus.ARCHIVED) {
            throw ApiException.state("PROGRAM_ARCHIVED", "Programas encerrados não podem ser alterados.");
        }
        program.setName(request.name().trim());
        program.setInactivityDays(request.inactivityDays());
        apply(program, request);
        audit.record(AuditAction.PROGRAM_UPDATED, establishmentId, "PROGRAM", programId, null);
        events.publishEvent(new com.shaminatech.pass.loyalty.wallet.ProgramChangedEvent(programId));
        return views.program(program, policies.of(establishmentId));
    }

    /** ACTIVE ↔ PAUSED; ARCHIVED é definitivo (cartões e histórico são preservados). */
    @Transactional
    public ProgramView changeStatus(Long establishmentId, Long programId, ProgramStatus status) {
        tenantAccess.require(establishmentId, Permission.PROGRAMS_MANAGE);
        LoyaltyProgram program = find(establishmentId, programId);
        EstablishmentPolicy policy = policies.of(establishmentId);
        if (program.getStatus() == ProgramStatus.ARCHIVED && status != ProgramStatus.ARCHIVED) {
            throw ApiException.state("PROGRAM_ARCHIVED", "Programas encerrados não podem ser reabertos.");
        }
        if (status == ProgramStatus.ACTIVE && !policy.allows(program.getType())) {
            throw new ApiException(org.springframework.http.HttpStatus.FORBIDDEN, "PROGRAM_TYPE_NOT_ALLOWED",
                    "Este tipo de cartão não está habilitado para o seu estabelecimento. Fale com a ShaminaTech.");
        }
        if (program.getStatus() != status) {
            ProgramStatus previous = program.getStatus();
            program.setStatus(status);
            audit.record(AuditAction.PROGRAM_STATUS_CHANGED, establishmentId, "PROGRAM", programId, previous + "->" + status);
        }
        return views.program(program, policy);
    }

    @Transactional
    public ProgramView updateDesign(Long establishmentId, Long programId, DesignRequest request) {
        tenantAccess.require(establishmentId, Permission.PROGRAMS_MANAGE);
        LoyaltyProgram program = find(establishmentId, programId);
        program.setBrandColor(request.brandColor().toUpperCase());
        program.setTextColor(request.textColor().toUpperCase());
        program.setCardMessage(blankToNull(request.cardMessage()));
        program.setRewardInfo(blankToNull(request.rewardInfo()));
        audit.record(AuditAction.CARD_DESIGN_UPDATED, establishmentId, "PROGRAM", programId, null);
        events.publishEvent(new com.shaminatech.pass.loyalty.wallet.ProgramChangedEvent(programId));
        return views.program(program, policies.of(establishmentId));
    }

    // ---------------- Recompensas (programas de pontos) ----------------

    @Transactional(readOnly = true)
    public List<RewardView> listRewards(Long establishmentId, Long programId) {
        tenantAccess.require(establishmentId, Permission.ESTABLISHMENT_VIEW);
        if (programId == null) {
            return rewards.findAllInEstablishment(establishmentId).stream().map(views::reward).toList();
        }
        find(establishmentId, programId);
        return rewards.findByProgram(establishmentId, programId).stream().map(views::reward).toList();
    }

    @Transactional
    public RewardView createReward(Long establishmentId, Long programId, RewardRequest request) {
        tenantAccess.require(establishmentId, Permission.PROGRAMS_MANAGE);
        LoyaltyProgram program = find(establishmentId, programId);
        if (program.getType() != ProgramType.POINTS) {
            throw ApiException.badRequest("Recompensas por pontos só existem em programas de pontos.", null);
        }
        LoyaltyReward reward = new LoyaltyReward(program, request.name().trim(), BigDecimal.valueOf(request.cost()).setScale(2));
        reward.setDescription(blankToNull(request.description()));
        reward.setActive(request.active() == null || request.active());
        rewards.save(reward);
        audit.record(AuditAction.REWARD_SAVED, establishmentId, "REWARD", reward.getId(), "criada");
        return views.reward(reward);
    }

    @Transactional
    public RewardView updateReward(Long establishmentId, Long rewardId, RewardRequest request) {
        tenantAccess.require(establishmentId, Permission.PROGRAMS_MANAGE);
        LoyaltyReward reward = rewards.findInEstablishment(establishmentId, rewardId)
                .orElseThrow(() -> ApiException.notFound("Recompensa não encontrada."));
        reward.setName(request.name().trim());
        reward.setDescription(blankToNull(request.description()));
        reward.setCost(BigDecimal.valueOf(request.cost()).setScale(2));
        if (request.active() != null) {
            reward.setActive(request.active());
        }
        audit.record(AuditAction.REWARD_SAVED, establishmentId, "REWARD", rewardId, "alterada");
        return views.reward(reward);
    }

    // ---------------- Níveis VIP (modelagem) ----------------

    @Transactional(readOnly = true)
    public List<VipTierView> listTiers(Long establishmentId, Long programId) {
        tenantAccess.require(establishmentId, Permission.ESTABLISHMENT_VIEW);
        find(establishmentId, programId);
        return tiers.findByProgram(establishmentId, programId).stream().map(ProgramService::tier).toList();
    }

    @Transactional
    public VipTierView saveTier(Long establishmentId, Long programId, Long tierId, VipTierRequest request) {
        tenantAccess.require(establishmentId, Permission.PROGRAMS_MANAGE);
        LoyaltyProgram program = find(establishmentId, programId);
        if (program.getType() != ProgramType.VIP) {
            throw ApiException.badRequest("Níveis só existem em programas VIP.", null);
        }
        VipTier tier = tierId == null ? new VipTier(program, request.name().trim(), request.rankOrder())
                : tiers.findInEstablishment(establishmentId, tierId).filter(t -> t.getProgram().getId().equals(programId))
                .orElseThrow(() -> ApiException.notFound("Nível não encontrado."));
        boolean rankTaken = tiers.findByProgram(establishmentId, programId).stream()
                .anyMatch(t -> t.getRankOrder() == request.rankOrder() && !t.getId().equals(tier.getId()));
        if (rankTaken) {
            throw ApiException.conflict("Já existe um nível nesta posição.", "rankOrder");
        }
        tier.setName(request.name().trim());
        tier.setRankOrder(request.rankOrder());
        tier.setMinSpend(request.minSpend());
        tier.setMinVisits(request.minVisits());
        tier.setPeriodDays(request.periodDays());
        tier.setBenefits(blankToNull(request.benefits()));
        tiers.save(tier);
        audit.record(AuditAction.VIP_TIER_SAVED, establishmentId, "VIP_TIER", tier.getId(), null);
        return tier(tier);
    }

    public LoyaltyProgram find(Long establishmentId, Long programId) {
        return programs.findInEstablishment(establishmentId, programId)
                .orElseThrow(() -> ApiException.notFound("Programa não encontrado."));
    }

    private static VipTierView tier(VipTier t) {
        return new VipTierView(t.getId(), t.getName(), t.getRankOrder(), t.getMinSpend(), t.getMinVisits(), t.getPeriodDays(),
                t.getBenefits());
    }

    /** Copia e valida as regras específicas de cada tipo; zera os campos que não se aplicam. */
    private static void apply(LoyaltyProgram p, ProgramRequest r) {
        p.setDescription(blankToNull(r.description()));
        p.setValidityMode(r.validityMode());
        p.setExpiredBalancePolicy(r.expiredBalancePolicy());
        p.setReversalPolicy(r.reversalPolicy());
        p.setBenefitValidityDays(r.benefitValidityDays());
        p.setMinPurchaseAmount(r.minPurchaseAmount());
        p.setRounding(null);
        p.setPointsPerUnit(null);
        p.setSpendUnit(null);
        p.setCashbackPercent(null);
        p.setMaxCreditPerPurchase(null);
        p.setMinRedeemBalance(null);
        p.setMaxRedeemPercent(null);
        p.setStampsRequired(null);
        p.setStampCriterion(null);
        p.setStampReward(null);
        p.setRestartAfterRedeem(null);
        switch (p.getType()) {
            case POINTS -> {
                require(r.pointsPerUnit(), "pointsPerUnit", "Informe quantos pontos são concedidos.");
                require(r.spendUnit(), "spendUnit", "Informe a cada quantos reais os pontos são concedidos.");
                p.setPointsPerUnit(r.pointsPerUnit());
                p.setSpendUnit(r.spendUnit());
                p.setRounding(r.rounding() == null ? Rounding.DOWN : r.rounding());
            }
            case CASHBACK -> {
                require(r.cashbackPercent(), "cashbackPercent", "Informe o percentual de cashback.");
                p.setCashbackPercent(r.cashbackPercent());
                p.setMaxCreditPerPurchase(r.maxCreditPerPurchase());
                p.setMinRedeemBalance(r.minRedeemBalance());
                p.setMaxRedeemPercent(r.maxRedeemPercent());
                p.setRounding(r.rounding() == null ? Rounding.DOWN : r.rounding());
            }
            case STAMPS -> {
                require(r.stampsRequired(), "stampsRequired", "Informe quantos carimbos completam o cartão.");
                require(r.stampCriterion(), "stampCriterion", "Informe o critério de concessão.");
                if (r.stampReward() == null || r.stampReward().isBlank()) {
                    throw ApiException.badRequest("Informe a recompensa do cartão completo.", "stampReward");
                }
                p.setStampsRequired(r.stampsRequired());
                p.setStampCriterion(r.stampCriterion());
                p.setStampReward(r.stampReward().trim());
                p.setRestartAfterRedeem(r.restartAfterRedeem() == null || r.restartAfterRedeem());
                if (r.stampCriterion() != StampCriterion.PURCHASE) {
                    p.setMinPurchaseAmount(null);
                }
            }
            case VIP -> {
                p.setMinPurchaseAmount(null);
                p.setBenefitValidityDays(null);
            }
        }
    }

    private static void require(Object value, String field, String message) {
        if (value == null) {
            throw ApiException.badRequest(message, field);
        }
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
