package com.shaminatech.pass.loyalty.branding;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface StoredImageRepository extends JpaRepository<StoredImage, Long> {

    @Query("select i from StoredImage i where i.id = :id and i.establishmentId = :establishmentId")
    Optional<StoredImage> findInEstablishment(@Param("establishmentId") Long establishmentId, @Param("id") Long id);

    Optional<StoredImage> findByPublicToken(String publicToken);
}
