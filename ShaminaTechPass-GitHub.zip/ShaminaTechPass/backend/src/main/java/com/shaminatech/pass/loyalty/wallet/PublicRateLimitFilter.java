package com.shaminatech.pass.loyalty.wallet;

import java.io.IOException;
import java.time.Clock;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Limite de requisições por IP nos endpoints públicos ({@code /api/public/**}): janela fixa de 1 minuto.
 * Dificulta tentativas de adivinhar tokens de link. Contadores em memória (suficiente para uma instância).
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 10)
public class PublicRateLimitFilter extends OncePerRequestFilter {

    private record Window(long minute, int count) {
    }

    private final Map<String, Window> windows = new ConcurrentHashMap<>();
    private final int limitPerMinute;
    private final Clock clock;

    public PublicRateLimitFilter(@Value("${shaminatech.public.rate-limit-per-minute:60}") int limitPerMinute, Clock clock) {
        this.limitPerMinute = limitPerMinute;
        this.clock = clock;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        return !request.getRequestURI().startsWith("/api/public/");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        long minute = clock.millis() / 60_000;
        Window window = windows.merge(request.getRemoteAddr(), new Window(minute, 1),
                (old, fresh) -> old.minute() == minute ? new Window(minute, old.count() + 1) : fresh);
        if (windows.size() > 10_000) {
            windows.entrySet().removeIf(e -> e.getValue().minute() < minute);
        }
        if (window.count() > limitPerMinute) {
            response.setStatus(429);
            response.setHeader("Retry-After", "60");
            response.setContentType("application/problem+json;charset=UTF-8");
            response.getWriter().write("{\"status\":429,\"code\":\"RATE_LIMITED\",\"detail\":\"Muitas tentativas. Aguarde um minuto.\"}");
            return;
        }
        chain.doFilter(request, response);
    }
}
