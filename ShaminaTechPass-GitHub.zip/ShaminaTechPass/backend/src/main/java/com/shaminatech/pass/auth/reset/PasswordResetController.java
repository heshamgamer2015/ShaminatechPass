package com.shaminatech.pass.auth.reset;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shaminatech.pass.security.StrongPassword;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Endpoints públicos (sem login, COM CSRF) da recuperação de senha. O pedido responde sempre 202 com a mesma mensagem.
 */
@RestController
@RequestMapping("/api/auth/password-reset")
public class PasswordResetController {

    public static final String GENERIC_ANSWER =
            "Se houver uma conta ativa com este e-mail, enviaremos as instruções de recuperação.";

    public record ResetRequest(@NotBlank(message = "Informe o e-mail.") @Size(max = 254) String email) {
    }

    public record ResetConfirm(@NotBlank @Size(max = 100) String token,
                               @NotBlank(message = "Informe a nova senha.") @StrongPassword String newPassword) {
    }

    public record Message(String message) {
    }

    private final PasswordResetService service;

    public PasswordResetController(PasswordResetService service) {
        this.service = service;
    }

    @PostMapping("/request")
    public ResponseEntity<Message> request(@Valid @RequestBody ResetRequest body) {
        service.request(body.email());
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(new Message(GENERIC_ANSWER));
    }

    @PostMapping("/confirm")
    public ResponseEntity<Void> confirm(@Valid @RequestBody ResetConfirm body) {
        service.confirm(body.token(), body.newPassword());
        return ResponseEntity.noContent().build();
    }
}
