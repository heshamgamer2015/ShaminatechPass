package com.shaminatech.pass.loyalty.signup;

import java.math.BigDecimal;
import java.util.List;

import com.shaminatech.pass.loyalty.ProgramType;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** Contratos da página pública de cadastro. Nada aqui identifica ids internos ou outros consumidores. */
public final class SignupDtos {

    private SignupDtos() {
    }

    /**
     * {@code requestId}: identificador aleatório gerado pela página a cada formulário (repetir o envio não duplica).
     * {@code formToken}: recebido em {@link SignupInfo}. {@code website}: campo isca, deve ficar vazio.
     * {@code privacyAccepted} é obrigatório; {@code marketingOptIn} é um consentimento separado e opcional.
     */
    public record SignupRequest(
            @NotBlank(message = "Informe seu nome.") @Size(max = 150, message = "Máximo de 150 caracteres.") String fullName,
            @NotBlank(message = "Informe seu telefone.") @Size(max = 25)
            @Pattern(regexp = "^[0-9+()\\-\\s]*$", message = "Telefone inválido.") String phone,
            @Email(message = "E-mail inválido.") @Size(max = 254) String email,
            @NotNull(message = "Confirme que leu as informações de privacidade.")
            @AssertTrue(message = "Confirme que leu as informações de privacidade.") Boolean privacyAccepted,
            Boolean marketingOptIn,
            @NotBlank(message = "Recarregue a página.") @Pattern(regexp = "^[A-Za-z0-9_-]{16,80}$", message = "Recarregue a página.")
            String requestId,
            @Size(max = 120) String formToken,
            @Size(max = 200) String website) {
    }

    public record PublicReward(String name, String description, BigDecimal cost) {
    }

    public record PublicDesign(String brandColor, String textColor, String logoUrl, String heroUrl, String cardMessage,
                               String rewardInfo) {
    }

    /**
     * {@code status}: OPEN (aceitando cadastros), FULL (limite de clientes atingido) ou UNAVAILABLE (link desativado,
     * programa pausado ou estabelecimento indisponível — sem nenhum dado do estabelecimento).
     * {@code walletAvailable}: alguma carteira digital está configurada pela ShaminaTech.
     * {@code wallets}: carteiras disponíveis ({@code GOOGLE_WALLET}, {@code APPLE_WALLET}) — a página destaca a do aparelho.
     */
    public record SignupInfo(String status, String message, String establishmentName, String programName,
                             String programDescription, ProgramType programType, List<String> rules, List<PublicReward> rewards,
                             List<String> validity, Integer stampsRequired, String stampReward, PublicDesign design,
                             String formToken, boolean walletAvailable, List<String> wallets) {

        static final String UNAVAILABLE_MESSAGE =
                "O cadastro neste programa não está disponível no momento. Fale com o estabelecimento.";

        static SignupInfo unavailable() {
            return new SignupInfo("UNAVAILABLE", UNAVAILABLE_MESSAGE, null, null, null, null, List.of(), List.of(), List.of(),
                    null, null, null, null, false, List.of());
        }
    }

    /**
     * {@code walletPath}: página do consumidor para adicionar o cartão (Google/Apple), quando há carteira configurada.
     * {@code walletStatus}: LINK_READY ou NOT_CONFIGURED. O cartão existe nos dois casos.
     */
    public record SignupResult(String status, String establishmentName, String programName, ProgramType programType,
                               String consumerFirstName, String walletPath, String walletStatus, String message) {
    }
}
