package com.shaminatech.pass.loyalty.wallet;

import java.time.Duration;
import java.time.Instant;

import com.shaminatech.pass.common.persistence.BaseEntity;
import com.shaminatech.pass.common.persistence.EnumNameConverter;

import jakarta.persistence.Column;
import jakarta.persistence.Converter;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Passe de um cartão em uma carteira digital (Google Wallet nesta etapa; Apple Wallet depois, com o mesmo modelo).
 * O saldo oficial continua no {@code loyalty_card}; aqui fica apenas o estado da cópia remota.
 * <p>
 * Sincronização por versão: cada alteração do cartão incrementa {@code desiredVersion} na mesma transação da
 * movimentação. O envio ao Google acontece depois do commit, fora da transação, e só marca {@code syncedVersion}
 * quando o Google confirma. Uma falha nunca desfaz a movimentação: o passe fica pendente e é reenviado.
 */
@Entity
@Table(name = "wallet_pass",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_wallet_pass_card_provider", columnNames = {"card_id", "provider"}),
                @UniqueConstraint(name = "uk_wallet_pass_external", columnNames = {"provider", "external_id"})},
        indexes = {
                @Index(name = "idx_wallet_pass_sync", columnList = "sync_status"),
                @Index(name = "idx_wallet_pass_establishment", columnList = "establishment_id")})
public class WalletPass extends BaseEntity {

    public enum Provider {
        GOOGLE_WALLET, APPLE_WALLET;

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<Provider> {
            public JpaConverter() {
                super(Provider.class);
            }
        }
    }

    /**
     * PENDING: há alteração a enviar. SYNCING: envio em andamento (com prazo de reserva). SYNCED: o Google confirmou a
     * versão atual. FAILED: a última tentativa falhou (nova tentativa agendada ou reenvio manual). INVALIDATED: cartão
     * cancelado e passe inativado no Google; não sincroniza mais.
     */
    public enum SyncStatus {
        PENDING, SYNCING, SYNCED, FAILED, INVALIDATED;

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<SyncStatus> {
            public JpaConverter() {
                super(SyncStatus.class);
            }
        }
    }

    @Column(name = "establishment_id", nullable = false)
    private Long establishmentId;

    @Column(name = "card_id", nullable = false)
    private Long cardId;

    @Column(nullable = false, length = 20)
    private Provider provider;

    /** Id do objeto no provedor (Google: "issuerId.sufixo"). Gerado uma única vez, estável. */
    @Column(name = "external_id", length = 200)
    private String externalId;

    @Column(name = "sync_status", nullable = false, length = 20)
    private SyncStatus syncStatus = SyncStatus.PENDING;

    @Column(name = "desired_version")
    private Long desiredVersion;

    @Column(name = "synced_version")
    private Long syncedVersion;

    /** Versão em envio (definida ao reservar). */
    @Column(name = "sending_version")
    private Long sendingVersion;

    @Column(name = "last_synced_at")
    private Instant lastSyncedAt;

    @Column(name = "last_attempt_at")
    private Instant lastAttemptAt;

    @Column(name = "next_attempt_at")
    private Instant nextAttemptAt;

    @Column(name = "lease_until")
    private Instant leaseUntil;

    @Column(name = "last_error", length = 500)
    private String lastError;

    @Column(name = "last_error_status")
    private Integer lastErrorStatus;

    @Column(nullable = false)
    private int attempts;

    /** Último estado enviado ao provedor (ACTIVE, INACTIVE, EXPIRED, COMPLETED). */
    @Column(name = "remote_state", length = 20)
    private String remoteState;

    /**
     * Momento da última alteração do conteúdo do passe (Apple Wallet: Last-Modified e marca de atualização). Sempre
     * avança pelo menos 1 segundo a cada alteração, porque o protocolo da Apple compara datas com precisão de segundos.
     */
    @Column(name = "content_updated_at")
    private Instant contentUpdatedAt;

    protected WalletPass() {
    }

    public WalletPass(Long establishmentId, Long cardId, Provider provider, String externalId, Instant now) {
        this.establishmentId = establishmentId;
        this.cardId = cardId;
        this.provider = provider;
        this.externalId = externalId;
        this.desiredVersion = 1L;
        this.syncedVersion = 0L;
        this.nextAttemptAt = now;
        this.contentUpdatedAt = now.truncatedTo(java.time.temporal.ChronoUnit.SECONDS);
    }

    private void touchContent(Instant now) {
        Instant second = now.truncatedTo(java.time.temporal.ChronoUnit.SECONDS);
        contentUpdatedAt = contentUpdatedAt == null || second.isAfter(contentUpdatedAt) ? second : contentUpdatedAt.plusSeconds(1);
    }

    public long desired() {
        return desiredVersion == null ? 0 : desiredVersion;
    }

    public long synced() {
        return syncedVersion == null ? 0 : syncedVersion;
    }

    /** Alteração do cartão: precisa reenviar. Chamado na transação da movimentação. */
    public void markChanged(Instant now) {
        if (syncStatus == SyncStatus.INVALIDATED) {
            return;
        }
        desiredVersion = desired() + 1;
        touchContent(now);
        if (syncStatus != SyncStatus.SYNCING) {
            syncStatus = SyncStatus.PENDING;
            attempts = 0;
            nextAttemptAt = now;
        }
    }

    /** Pode ser reservado para envio agora? */
    public boolean isDue(Instant now) {
        return switch (syncStatus) {
            case PENDING -> nextAttemptAt == null || !now.isBefore(nextAttemptAt);
            case FAILED -> nextAttemptAt != null && !now.isBefore(nextAttemptAt);
            case SYNCING -> leaseUntil == null || !now.isBefore(leaseUntil); // reserva expirada (processo caiu)
            case SYNCED, INVALIDATED -> false;
        };
    }

    public void reserve(Instant now, Duration lease) {
        syncStatus = SyncStatus.SYNCING;
        sendingVersion = desired();
        leaseUntil = now.plus(lease);
        lastAttemptAt = now;
        attempts++;
    }

    /** O Google confirmou a versão enviada. Se houve nova alteração no meio, continua pendente. */
    public void confirm(Instant now, String sentState, boolean invalidated) {
        long sent = sendingVersion == null ? desired() : sendingVersion;
        syncedVersion = Math.max(synced(), sent);
        lastSyncedAt = now;
        remoteState = sentState;
        lastError = null;
        lastErrorStatus = null;
        leaseUntil = null;
        sendingVersion = null;
        if (invalidated) {
            syncStatus = SyncStatus.INVALIDATED;
            nextAttemptAt = null;
        } else if (desired() > synced()) {
            syncStatus = SyncStatus.PENDING;
            attempts = 0;
            nextAttemptAt = now;
        } else {
            syncStatus = SyncStatus.SYNCED;
            attempts = 0;
            nextAttemptAt = null;
        }
    }

    /** Falha: agenda nova tentativa (backoff) se temporária e ainda dentro do limite; senão aguarda reenvio manual. */
    public void fail(Instant now, int status, String message, boolean retryable, int maxAttempts) {
        syncStatus = SyncStatus.FAILED;
        lastError = message == null ? null : message.substring(0, Math.min(500, message.length()));
        lastErrorStatus = status;
        leaseUntil = null;
        sendingVersion = null;
        nextAttemptAt = retryable && attempts < maxAttempts ? now.plus(backoff(attempts)) : null;
    }

    /** Reenvio autorizado pela empresa. */
    public void retryNow(Instant now) {
        if (syncStatus == SyncStatus.INVALIDATED) {
            return;
        }
        syncStatus = SyncStatus.PENDING;
        attempts = 0;
        nextAttemptAt = now;
        leaseUntil = null;
    }

    /** 30 s, 2 min, 8 min, 32 min... limitado a 6 h. */
    static Duration backoff(int attempt) {
        long seconds = (long) (30 * Math.pow(4, Math.max(0, attempt - 1)));
        return Duration.ofSeconds(Math.min(seconds, Duration.ofHours(6).toSeconds()));
    }

    public Long getEstablishmentId() { return establishmentId; }
    public Long getCardId() { return cardId; }
    public Provider getProvider() { return provider; }
    public String getExternalId() { return externalId; }
    public SyncStatus getSyncStatus() { return syncStatus; }
    public Instant getLastSyncedAt() { return lastSyncedAt; }
    public Instant getLastAttemptAt() { return lastAttemptAt; }
    public Instant getNextAttemptAt() { return nextAttemptAt; }
    public String getLastError() { return lastError; }
    public Integer getLastErrorStatus() { return lastErrorStatus; }
    public int getAttempts() { return attempts; }
    public String getRemoteState() { return remoteState; }
    public Instant getContentUpdatedAt() { return contentUpdatedAt; }
}
