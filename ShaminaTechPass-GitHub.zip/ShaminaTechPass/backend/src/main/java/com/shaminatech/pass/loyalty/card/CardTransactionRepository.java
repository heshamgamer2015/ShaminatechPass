package com.shaminatech.pass.loyalty.card;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.shaminatech.pass.loyalty.card.CardEnums.TransactionType;

public interface CardTransactionRepository extends JpaRepository<CardTransaction, Long> {

    Optional<CardTransaction> findByEstablishmentIdAndIdempotencyKey(Long establishmentId, String idempotencyKey);

    @Query("select t from CardTransaction t where t.id = :id and t.establishmentId = :establishmentId")
    Optional<CardTransaction> findInEstablishment(@Param("establishmentId") Long establishmentId, @Param("id") Long id);

    boolean existsByReversesId(Long reversesId);

    @Query("select t.reversesId from CardTransaction t where t.reversesId in :ids")
    List<Long> findReversedAmong(@Param("ids") Collection<Long> ids);

    @Query(value = "select t from CardTransaction t join fetch t.card where t.card.id = :cardId and t.establishmentId = :establishmentId",
            countQuery = "select count(t) from CardTransaction t where t.card.id = :cardId and t.establishmentId = :establishmentId")
    Page<CardTransaction> findByCard(@Param("establishmentId") Long establishmentId, @Param("cardId") Long cardId, Pageable pageable);

    @Query(value = "select t from CardTransaction t join fetch t.card where t.consumerId = :consumerId and t.establishmentId = :establishmentId",
            countQuery = "select count(t) from CardTransaction t where t.consumerId = :consumerId and t.establishmentId = :establishmentId")
    Page<CardTransaction> findByConsumer(@Param("establishmentId") Long establishmentId, @Param("consumerId") Long consumerId,
                                         Pageable pageable);

    @Query(value = "select t from CardTransaction t join fetch t.card where t.establishmentId = :establishmentId and t.type in :types",
            countQuery = "select count(t) from CardTransaction t where t.establishmentId = :establishmentId and t.type in :types")
    Page<CardTransaction> findInEstablishment(@Param("establishmentId") Long establishmentId,
                                              @Param("types") Collection<TransactionType> types, Pageable pageable);

    /** Movimentações do tipo no período, sem as estornadas (indicadores). */
    @Query("""
            select t from CardTransaction t where t.establishmentId = :establishmentId and t.type = :type
              and t.occurredAt >= :from and t.occurredAt <= :to
              and not exists (select 1 from CardTransaction r where r.reversesId = t.id)
            """)
    List<CardTransaction> findOfTypeBetween(@Param("establishmentId") Long establishmentId, @Param("type") TransactionType type,
                                            @Param("from") Instant from, @Param("to") Instant to);

    @Query("""
            select count(t) from CardTransaction t where t.establishmentId = :establishmentId
              and t.type = com.shaminatech.pass.loyalty.card.CardEnums.TransactionType.CARD_ISSUED
              and t.occurredAt >= :from and t.occurredAt <= :to and (:programId is null or t.programId = :programId)
            """)
    long countIssuedBetween(@Param("establishmentId") Long establishmentId, @Param("programId") Long programId,
                            @Param("from") Instant from, @Param("to") Instant to);

    /** Última concessão de cada consumidor antes de um instante (para "clientes recuperados"). */
    @Query("""
            select t.consumerId, max(t.occurredAt) from CardTransaction t
            where t.establishmentId = :establishmentId and t.type = com.shaminatech.pass.loyalty.card.CardEnums.TransactionType.EARN
              and t.occurredAt < :before and t.consumerId in :consumerIds
              and (:programId is null or t.programId = :programId)
              and not exists (select 1 from CardTransaction r where r.reversesId = t.id)
            group by t.consumerId
            """)
    List<Object[]> lastEarnBefore(@Param("establishmentId") Long establishmentId, @Param("programId") Long programId,
                                  @Param("before") Instant before, @Param("consumerIds") Collection<Long> consumerIds);
}
