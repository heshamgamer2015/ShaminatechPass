package com.shaminatech.pass.plan;

import java.time.Instant;

import com.shaminatech.pass.common.persistence.BaseEntity;
import com.shaminatech.pass.establishment.Establishment;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Plano escolhido pelo estabelecimento. Guarda <b>separadamente</b> o plano, o preço comercial previsto no momento da
 * escolha, a condição gratuita da fase de testes e o estado de acesso.
 * <p>
 * Não é uma assinatura financeira: não há cobrança, vencimento, meio de pagamento nem data de fim da fase de testes.
 * Quando a cobrança existir, ela deverá ser criada à parte, com aceite explícito das condições comerciais — nunca
 * ativada automaticamente a partir deste registro e nunca retroativa.
 * <p>
 * Estabelecimentos criados pelo administrador antes do autocadastro não têm registro: continuam com os limites definidos
 * na política (sem limite de programas).
 */
@Entity
@Table(name = "establishment_plan",
        uniqueConstraints = @UniqueConstraint(name = "uk_establishment_plan_establishment", columnNames = "establishment_id"))
public class EstablishmentPlan extends BaseEntity {

    public enum Origin {
        SELF_SIGNUP, PLATFORM_ADMIN;

        @jakarta.persistence.Converter(autoApply = true)
        public static class JpaConverter extends com.shaminatech.pass.common.persistence.EnumNameConverter<Origin> {
            public JpaConverter() {
                super(Origin.class);
            }
        }
    }

    public enum AccessStatus {
        ACTIVE;

        @jakarta.persistence.Converter(autoApply = true)
        public static class JpaConverter extends com.shaminatech.pass.common.persistence.EnumNameConverter<AccessStatus> {
            public JpaConverter() {
                super(AccessStatus.class);
            }
        }
    }

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "establishment_id", nullable = false, foreignKey = @ForeignKey(name = "fk_establishment_plan_establishment"))
    private Establishment establishment;

    @Column(name = "plan_code", nullable = false, length = 20)
    private Plan plan;

    /** Preço comercial previsto quando o plano foi escolhido (centavos de real). Só informativo. */
    @Column(name = "list_price_cents", nullable = false)
    private int listPriceCents;

    /** Uso gratuito da fase de testes (nenhuma cobrança é feita). */
    @Column(name = "trial_free", nullable = false)
    private boolean trialFree;

    @Column(name = "access_status", nullable = false, length = 20)
    private AccessStatus accessStatus = AccessStatus.ACTIVE;

    @Column(name = "origin", nullable = false, length = 20)
    private Origin origin;

    @Column(name = "terms_accepted_at")
    private Instant termsAcceptedAt;

    @Column(name = "terms_version", length = 40)
    private String termsVersion;

    protected EstablishmentPlan() {
    }

    public EstablishmentPlan(Establishment establishment, Plan plan, boolean trialFree, Origin origin, Instant termsAcceptedAt,
                             String termsVersion) {
        this.establishment = establishment;
        this.plan = plan;
        this.listPriceCents = plan.listPriceCents();
        this.trialFree = trialFree;
        this.origin = origin;
        this.termsAcceptedAt = termsAcceptedAt;
        this.termsVersion = termsVersion;
    }

    public Establishment getEstablishment() { return establishment; }
    public Long getEstablishmentId() { return establishment.getId(); }
    public Plan getPlan() { return plan; }
    public int getListPriceCents() { return listPriceCents; }
    public boolean isTrialFree() { return trialFree; }
    public AccessStatus getAccessStatus() { return accessStatus; }
    public Origin getOrigin() { return origin; }
    public Instant getTermsAcceptedAt() { return termsAcceptedAt; }
    public String getTermsVersion() { return termsVersion; }
}
