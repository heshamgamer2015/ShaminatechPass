package com.shaminatech.pass.membership;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/** Linha do catálogo de permissões (tabela {@code permission}). */
@Entity
@Table(name = "permission")
public class PermissionEntity {

    @Id
    @Column(length = 60)
    private String code;

    @Column(nullable = false, length = 255)
    private String description;

    protected PermissionEntity() {
    }

    public PermissionEntity(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}
