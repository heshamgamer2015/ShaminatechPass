package com.shaminatech.pass.loyalty.notify;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.shaminatech.pass.common.web.PageResponse;
import com.shaminatech.pass.common.web.Paging;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.LocationRequest;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.LocationView;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.Overview;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.ReminderView;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.SettingsRequest;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.SettingsView;

import jakarta.validation.Valid;

/** Notificações e proximidade: painel do estabelecimento e manutenção de localizações pela ShaminaTech. */
@RestController
public class NotificationController {

    private final NotificationService service;

    public NotificationController(NotificationService service) {
        this.service = service;
    }

    @GetMapping("/api/establishments/{establishmentId}/notifications")
    public Overview overview(@PathVariable Long establishmentId) {
        return service.overview(establishmentId);
    }

    @PutMapping("/api/establishments/{establishmentId}/notifications/settings")
    public SettingsView settings(@PathVariable Long establishmentId, @Valid @RequestBody SettingsRequest body) {
        return service.updateSettings(establishmentId, body);
    }

    @GetMapping("/api/establishments/{establishmentId}/notifications/history")
    public PageResponse<ReminderView> history(@PathVariable Long establishmentId,
                                              @RequestParam(required = false) WalletReminder.Status status,
                                              @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size) {
        return service.history(establishmentId, status, Paging.of(page, size, Sort.by(Sort.Direction.DESC, "plannedAt", "id")));
    }

    @PostMapping("/api/establishments/{establishmentId}/locations")
    @ResponseStatus(HttpStatus.CREATED)
    public LocationView addLocation(@PathVariable Long establishmentId, @Valid @RequestBody LocationRequest body) {
        return service.saveLocation(establishmentId, null, body);
    }

    @PutMapping("/api/establishments/{establishmentId}/locations/{locationId}")
    public LocationView updateLocation(@PathVariable Long establishmentId, @PathVariable Long locationId,
                                       @Valid @RequestBody LocationRequest body) {
        return service.saveLocation(establishmentId, locationId, body);
    }

    @DeleteMapping("/api/establishments/{establishmentId}/locations/{locationId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteLocation(@PathVariable Long establishmentId, @PathVariable Long locationId) {
        service.deleteLocation(establishmentId, locationId);
    }

    // ---------------- ShaminaTech (/api/admin/** exige administrador da plataforma) ----------------

    @GetMapping("/api/admin/establishments/{establishmentId}/locations")
    public List<LocationView> adminLocations(@PathVariable Long establishmentId) {
        return service.adminLocations(establishmentId);
    }

    @PostMapping("/api/admin/establishments/{establishmentId}/locations")
    @ResponseStatus(HttpStatus.CREATED)
    public LocationView adminAdd(@PathVariable Long establishmentId, @Valid @RequestBody LocationRequest body) {
        return service.adminSaveLocation(establishmentId, null, body);
    }

    @PutMapping("/api/admin/establishments/{establishmentId}/locations/{locationId}")
    public LocationView adminUpdate(@PathVariable Long establishmentId, @PathVariable Long locationId,
                                    @Valid @RequestBody LocationRequest body) {
        return service.adminSaveLocation(establishmentId, locationId, body);
    }

    @DeleteMapping("/api/admin/establishments/{establishmentId}/locations/{locationId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void adminDelete(@PathVariable Long establishmentId, @PathVariable Long locationId) {
        service.adminDeleteLocation(establishmentId, locationId);
    }
}
