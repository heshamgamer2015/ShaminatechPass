package com.shaminatech.pass.loyalty.card;

import java.math.BigDecimal;
import java.time.Instant;

import org.hibernate.annotations.Immutable;

import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.CardEnums.Channel;
import com.shaminatech.pass.loyalty.card.CardEnums.TransactionType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Histórico <b>imutável</b> do cartão: movimentações e mudanças de estado. Nenhum registro é alterado
 * ou apagado; correções são feitas por um novo registro REVERSAL que aponta o original.
 * <ul>
 *   <li>{@code uk_card_tx_idempotency}: a mesma chave de idempotência nunca gera dois registros no estabelecimento;</li>
 *   <li>{@code uk_card_tx_reverses}: uma movimentação só pode ser estornada uma vez.</li>
 * </ul>
 */
@Entity
@Immutable
@Table(name = "card_transaction",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_card_tx_idempotency", columnNames = {"establishment_id", "idempotency_key"}),
                @UniqueConstraint(name = "uk_card_tx_reverses", columnNames = "reverses_id")},
        indexes = {
                @Index(name = "idx_card_tx_card", columnList = "card_id, occurred_at"),
                @Index(name = "idx_card_tx_establishment", columnList = "establishment_id, occurred_at"),
                @Index(name = "idx_card_tx_consumer", columnList = "consumer_id, occurred_at")})
public class CardTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "establishment_id", nullable = false)
    private Long establishmentId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "card_id", nullable = false, foreignKey = @ForeignKey(name = "fk_card_tx_card"))
    private LoyaltyCard card;

    @Column(name = "consumer_id", nullable = false)
    private Long consumerId;

    @Column(name = "program_id", nullable = false)
    private Long programId;

    @Column(nullable = false, length = 30)
    private TransactionType type;

    @Column(nullable = false, length = 20)
    private Channel channel;

    /** Variação do saldo (positiva ou negativa; zero em mudanças de estado). */
    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal amount;

    @Column(name = "balance_after", nullable = false, precision = 14, scale = 2)
    private BigDecimal balanceAfter;

    /** Valor da compra informado pela empresa (quando aplicável). */
    @Column(name = "purchase_amount", precision = 12, scale = 2)
    private BigDecimal purchaseAmount;

    @Column(name = "reward_id")
    private Long rewardId;

    /** Descrição gravada no momento (ex.: nome da recompensa), para o histórico não mudar se a recompensa mudar. */
    @Column(length = 200)
    private String description;

    @Column(length = 200)
    private String note;

    @Column(name = "idempotency_key", length = 80)
    private String idempotencyKey;

    @Column(name = "request_fingerprint", length = 64)
    private String requestFingerprint;

    @Column(name = "reverses_id")
    private Long reversesId;

    @Column(name = "actor_user_id")
    private Long actorUserId;

    @Column(name = "occurred_at", nullable = false)
    private Instant occurredAt;

    @Column(name = "card_status_after", nullable = false, length = 20)
    private CardStatus cardStatusAfter;

    @Column(name = "card_expires_at_after", nullable = false)
    private Instant cardExpiresAtAfter;

    protected CardTransaction() {
    }

    CardTransaction(LoyaltyCard card, TransactionType type, Channel channel, BigDecimal amount, Instant occurredAt,
                    Long actorUserId) {
        this.establishmentId = card.getEstablishmentId();
        this.card = card;
        this.consumerId = card.getConsumer().getId();
        this.programId = card.getProgram().getId();
        this.type = type;
        this.channel = channel;
        this.amount = amount;
        this.occurredAt = occurredAt;
        this.actorUserId = actorUserId;
        this.balanceAfter = card.getBalance();
        this.cardStatusAfter = card.getStatus();
        this.cardExpiresAtAfter = card.getExpiresAt();
    }

    /** Fotografa o estado final do cartão (chamar depois de aplicar a movimentação). */
    CardTransaction snapshot(LoyaltyCard card) {
        this.balanceAfter = card.getBalance();
        this.cardStatusAfter = card.getStatus();
        this.cardExpiresAtAfter = card.getExpiresAt();
        return this;
    }

    CardTransaction purchase(BigDecimal purchaseAmount) { this.purchaseAmount = purchaseAmount; return this; }
    CardTransaction reward(Long rewardId) { this.rewardId = rewardId; return this; }
    CardTransaction description(String description) { this.description = description; return this; }
    CardTransaction note(String note) { this.note = note; return this; }
    CardTransaction reverses(Long reversesId) { this.reversesId = reversesId; return this; }

    CardTransaction idempotency(String key, String fingerprint) {
        this.idempotencyKey = key;
        this.requestFingerprint = fingerprint;
        return this;
    }

    public Long getId() { return id; }
    public Long getEstablishmentId() { return establishmentId; }
    public LoyaltyCard getCard() { return card; }
    public Long getConsumerId() { return consumerId; }
    public Long getProgramId() { return programId; }
    public TransactionType getType() { return type; }
    public Channel getChannel() { return channel; }
    public BigDecimal getAmount() { return amount; }
    public BigDecimal getBalanceAfter() { return balanceAfter; }
    public BigDecimal getPurchaseAmount() { return purchaseAmount; }
    public Long getRewardId() { return rewardId; }
    public String getDescription() { return description; }
    public String getNote() { return note; }
    public String getIdempotencyKey() { return idempotencyKey; }
    public String getRequestFingerprint() { return requestFingerprint; }
    public Long getReversesId() { return reversesId; }
    public Long getActorUserId() { return actorUserId; }
    public Instant getOccurredAt() { return occurredAt; }
    public CardStatus getCardStatusAfter() { return cardStatusAfter; }
    public Instant getCardExpiresAtAfter() { return cardExpiresAtAfter; }
}
