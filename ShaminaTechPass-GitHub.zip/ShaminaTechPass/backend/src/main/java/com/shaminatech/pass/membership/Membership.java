package com.shaminatech.pass.membership;

import com.shaminatech.pass.common.persistence.BaseEntity;
import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.user.AppUser;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Vínculo usuário ↔ estabelecimento.
 * <p>
 * Desde a Etapa 2 cada estabelecimento tem <b>uma única conta empresarial</b>: o vínculo com papel
 * {@link MembershipRole#OWNER}. Os papéis MANAGER/STAFF continuam no modelo para uso futuro, mas não
 * concedem acesso. A coluna {@code account_slot} recebe o id do estabelecimento enquanto o vínculo for a
 * conta empresarial ativa (e {@code null} nos demais casos); a restrição UNIQUE impede, no próprio banco,
 * uma segunda conta empresarial ativa no mesmo estabelecimento.
 */
@Entity
@Table(name = "membership",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_membership_establishment_user", columnNames = {"establishment_id", "user_id"}),
                // Garante no banco uma única conta empresarial ativa por estabelecimento (ver accountSlot).
                @UniqueConstraint(name = "uk_membership_account_slot", columnNames = "account_slot")},
        indexes = @Index(name = "idx_membership_user", columnList = "user_id"))
public class Membership extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "establishment_id", nullable = false, foreignKey = @ForeignKey(name = "fk_membership_establishment"))
    private Establishment establishment;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false, foreignKey = @ForeignKey(name = "fk_membership_user"))
    private AppUser user;

    @Column(nullable = false, length = 30)
    private MembershipRole role;

    @Column(nullable = false, length = 20)
    private MembershipStatus status = MembershipStatus.ACTIVE;

    @Column(name = "account_slot")
    private Long accountSlot;

    protected Membership() {
    }

    public Membership(Establishment establishment, AppUser user, MembershipRole role) {
        this.establishment = establishment;
        this.user = user;
        this.role = role;
        refreshAccountSlot();
    }

    public boolean isActive() {
        return status == MembershipStatus.ACTIVE;
    }

    /** Conta empresarial ativa: o único vínculo que dá acesso ao painel do estabelecimento. */
    public boolean isActiveBusinessAccount() {
        return isActive() && role == MembershipRole.OWNER;
    }

    private void refreshAccountSlot() {
        accountSlot = isActiveBusinessAccount() ? establishment.getId() : null;
    }

    public Long getAccountSlot() {
        return accountSlot;
    }

    public Establishment getEstablishment() {
        return establishment;
    }

    public AppUser getUser() {
        return user;
    }

    public MembershipRole getRole() {
        return role;
    }

    public void setRole(MembershipRole role) {
        this.role = role;
        refreshAccountSlot();
    }

    public MembershipStatus getStatus() {
        return status;
    }

    public void setStatus(MembershipStatus status) {
        this.status = status;
        refreshAccountSlot();
    }
}
