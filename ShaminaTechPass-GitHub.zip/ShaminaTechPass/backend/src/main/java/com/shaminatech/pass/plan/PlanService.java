package com.shaminatech.pass.plan;

import java.time.Instant;
import java.util.Collection;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ProgramStatus;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.consumer.Consumer;
import com.shaminatech.pass.loyalty.consumer.ConsumerRepository;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicy;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.LoyaltyProgramRepository;
import com.shaminatech.pass.membership.Permission;
import com.shaminatech.pass.tenant.TenantAccessService;

/**
 * Planos: catálogo público, registro do plano do estabelecimento e aplicação dos limites no backend.
 * <ul>
 *   <li><b>Clientes ativos</b>: usa o limite já existente da política do estabelecimento
 *       ({@code maxActiveConsumers}, conferido pelo cadastro de consumidores e pelo autocadastro), gravado conforme o
 *       plano. Só consumidores ATIVOS contam — inativos não bloqueiam nem contam.</li>
 *   <li><b>Programas e tipos</b>: conferidos na criação de programa, com a política travada (FOR UPDATE), contando só
 *       os programas não encerrados.</li>
 * </ul>
 * Reduzir o plano nunca apaga programas ou clientes: só impede criar novos acima do limite.
 */
@Service
public class PlanService {

    private final EstablishmentPlanRepository plans;
    private final LoyaltyProgramRepository programs;
    private final ConsumerRepository consumers;
    private final PolicyService policies;
    private final PlanProperties properties;
    private final TenantAccessService tenantAccess;

    public PlanService(EstablishmentPlanRepository plans, LoyaltyProgramRepository programs, ConsumerRepository consumers,
                       PolicyService policies, PlanProperties properties, TenantAccessService tenantAccess) {
        this.plans = plans;
        this.programs = programs;
        this.consumers = consumers;
        this.policies = policies;
        this.properties = properties;
        this.tenantAccess = tenantAccess;
    }

    public record PlanOffer(String code, String name, int listPriceCents, Integer maxActiveConsumers, Integer maxPrograms,
                            int maxProgramTypes, boolean selectable) {
    }

    public record Catalog(boolean trialFree, boolean selfSignupEnabled, String trialMessage, List<PlanOffer> plans) {
    }

    public record Limits(Integer maxActiveConsumers, Integer maxPrograms, Integer maxProgramTypes) {
    }

    public record Usage(long activeConsumers, long programs, List<ProgramType> typesInUse) {
    }

    /** Plano do estabelecimento. {@code code} nulo = limites definidos individualmente pela ShaminaTech. */
    public record PlanView(String code, String name, Integer listPriceCents, boolean trialFree, String accessStatus, String origin,
                           Instant since, String trialMessage, Limits limits, Usage usage, List<ProgramType> allowedTypes) {
    }

    /** Resumo para o painel ShaminaTech. */
    public record PlanBadge(String code, String name, boolean selfSignup, boolean trialFree) {
    }

    static final String TRIAL_MESSAGE = "Fase de testes: o uso é gratuito e nenhuma cobrança é feita. O valor mostrado é o preço "
            + "comercial previsto; quando a cobrança existir, ela só começará com o seu aceite explícito.";

    public Catalog catalog() {
        List<PlanOffer> offers = java.util.Arrays.stream(Plan.values())
                .map(p -> new PlanOffer(p.name(), p.displayName(), p.listPriceCents(), p.maxActiveConsumers(), p.maxPrograms(),
                        p.maxProgramTypes(), selectable(p)))
                .toList();
        return new Catalog(properties.trialFree(), properties.selfSignupEnabled(), properties.trialFree() ? TRIAL_MESSAGE : null, offers);
    }

    /** Sem cobrança implementada, planos pagos só podem ser escolhidos durante a fase de testes. */
    public boolean selectable(Plan plan) {
        return !plan.isPaid() || properties.trialFree();
    }

    /** Registra o plano e grava na política o limite de clientes e os tipos (a escolha do tipo é do estabelecimento). */
    @Transactional
    public EstablishmentPlan assign(Establishment establishment, Plan plan, EstablishmentPlan.Origin origin, Instant termsAcceptedAt) {
        EstablishmentPolicy policy = policies.lock(establishment.getId());
        int maxConsumers = plan.maxActiveConsumers() == null ? PolicyService.MAX_CONSUMER_LIMIT : plan.maxActiveConsumers();
        policy.update(maxConsumers, policy.getDefaultInactivityDays(), policy.getTimeZone(), EnumSet.allOf(ProgramType.class));
        return plans.save(new EstablishmentPlan(establishment, plan, !plan.isPaid() || properties.trialFree(), origin,
                termsAcceptedAt, properties.termsVersion()));
    }

    /**
     * Confere os limites do plano antes de criar um programa. Chame com a política já travada (serializa criações
     * simultâneas do mesmo estabelecimento). Sem plano registrado (criado pelo administrador): sem limite de programas.
     */
    public void requireProgramSlot(Long establishmentId, ProgramType newType) {
        EstablishmentPlan record = plans.findByEstablishmentId(establishmentId).orElse(null);
        if (record == null) {
            return;
        }
        Plan plan = record.getPlan();
        List<LoyaltyProgram> open = openPrograms(establishmentId);
        if (plan.maxPrograms() != null && open.size() >= plan.maxPrograms()) {
            throw ApiException.state("PLAN_PROGRAM_LIMIT", "O plano " + plan.displayName() + " permite até " + plan.maxPrograms()
                    + (plan.maxPrograms() == 1 ? " programa" : " programas") + " de fidelidade. Encerre um programa ou escolha um plano maior.");
        }
        Set<ProgramType> types = open.stream().map(LoyaltyProgram::getType).collect(Collectors.toCollection(() -> EnumSet.noneOf(ProgramType.class)));
        types.add(newType);
        if (types.size() > plan.maxProgramTypes()) {
            throw ApiException.state("PLAN_TYPE_LIMIT", "O plano " + plan.displayName() + " permite até " + plan.maxProgramTypes()
                    + (plan.maxProgramTypes() == 1 ? " tipo" : " tipos") + " de fidelidade. Use um tipo que você já tem ou escolha um plano maior.");
        }
    }

    @Transactional(readOnly = true)
    public PlanView view(Long establishmentId) {
        tenantAccess.require(establishmentId, Permission.ESTABLISHMENT_VIEW);
        EstablishmentPolicy policy = policies.of(establishmentId);
        List<LoyaltyProgram> open = openPrograms(establishmentId);
        Usage usage = new Usage(consumers.countByStatus(establishmentId, Consumer.Status.ACTIVE), open.size(),
                open.stream().map(LoyaltyProgram::getType).distinct().sorted().toList());
        List<ProgramType> allowed = List.copyOf(policy.getAllowedProgramTypes());
        EstablishmentPlan record = plans.findByEstablishmentId(establishmentId).orElse(null);
        if (record == null) {
            return new PlanView(null, null, null, false, null, null, null, null,
                    new Limits(policy.getMaxActiveConsumers(), null, null), usage, allowed);
        }
        Plan plan = record.getPlan();
        return new PlanView(plan.name(), plan.displayName(), record.getListPriceCents(), record.isTrialFree(),
                record.getAccessStatus().name(), record.getOrigin().name(), record.getCreatedAt(),
                record.isTrialFree() ? TRIAL_MESSAGE : null,
                new Limits(plan.maxActiveConsumers(), plan.maxPrograms(), plan.maxProgramTypes()), usage, allowed);
    }

    @Transactional(readOnly = true)
    public Map<Long, PlanBadge> badges(Collection<Long> establishmentIds) {
        if (establishmentIds.isEmpty()) {
            return Map.of();
        }
        return plans.findByEstablishmentIds(establishmentIds).stream().collect(Collectors.toMap(EstablishmentPlan::getEstablishmentId,
                p -> new PlanBadge(p.getPlan().name(), p.getPlan().displayName(), p.getOrigin() == EstablishmentPlan.Origin.SELF_SIGNUP,
                        p.isTrialFree()), (a, b) -> a, java.util.HashMap::new));
    }

    private List<LoyaltyProgram> openPrograms(Long establishmentId) {
        return programs.findAllInEstablishment(establishmentId).stream().filter(p -> p.getStatus() != ProgramStatus.ARCHIVED).toList();
    }
}
