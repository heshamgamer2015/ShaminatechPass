package com.shaminatech.pass.loyalty.wallet.apple;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.card.LoyaltyCardRepository;
import com.shaminatech.pass.loyalty.wallet.WalletPass;
import com.shaminatech.pass.loyalty.wallet.WalletPass.Provider;
import com.shaminatech.pass.loyalty.wallet.WalletPassRepository;

/**
 * Atualização dos passes Apple. Diferente do Google, a Apple não recebe o conteúdo: o servidor avisa os aparelhos
 * registrados (notificação APNs vazia) e o próprio Wallet busca a versão nova no web service. Mesmo modelo de três
 * passos curtos do Google:
 * <ol>
 *   <li><b>Reserva</b> (FOR UPDATE): confere se está devido e coleta os aparelhos registrados;</li>
 *   <li><b>Notificação</b> (sem transação aberta): uma notificação por aparelho. Repetir é inofensivo — o aparelho
 *       só confere se há versão nova;</li>
 *   <li><b>Confirmação</b>: marca a versão como entregue, remove aparelhos que a Apple diz não existirem mais (410)
 *       ou agenda nova tentativa em falha temporária.</li>
 * </ol>
 */
@Service
public class AppleWalletSync {

    private static final Logger log = LoggerFactory.getLogger(AppleWalletSync.class);
    private static final Duration LEASE = Duration.ofMinutes(2);
    private static final int MAX_ATTEMPTS = 8;

    public enum Outcome { SYNCED, CHANGED_AGAIN, FAILED, SKIPPED }

    private record Target(Long registrationId, String pushToken) {
    }

    private record Work(Long passId, List<Target> targets, String state, boolean invalidate) {
    }

    private final WalletPassRepository passes;
    private final LoyaltyCardRepository cards;
    private final AppleDeviceRegistrationRepository registrations;
    private final AppleWalletGateway gateway;
    private final TransactionTemplate tx;
    private final Clock clock;

    public AppleWalletSync(WalletPassRepository passes, LoyaltyCardRepository cards, AppleDeviceRegistrationRepository registrations,
                           AppleWalletGateway gateway, PlatformTransactionManager transactionManager, Clock clock) {
        this.passes = passes;
        this.cards = cards;
        this.registrations = registrations;
        this.gateway = gateway;
        this.tx = new TransactionTemplate(transactionManager);
        this.tx.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        this.clock = clock;
    }

    public Outcome process(Long passId) {
        Outcome outcome = Outcome.SKIPPED;
        for (int round = 0; round < 3; round++) {
            outcome = processOnce(passId);
            if (outcome != Outcome.CHANGED_AGAIN) {
                return outcome;
            }
        }
        return outcome;
    }

    Outcome processOnce(Long passId) {
        Work work;
        try {
            work = tx.execute(s -> reserve(passId));
        } catch (AppleWalletException e) {
            recordFailure(passId, e.status(), e.getMessage(), e.retryable());
            return Outcome.FAILED;
        }
        if (work == null) {
            return Outcome.SKIPPED;
        }
        List<Long> delivered = new ArrayList<>();
        List<Long> gone = new ArrayList<>();
        ApnsClient.Result failure = null;
        try {
            ApnsClient apns = work.targets().isEmpty() ? null : gateway.apns();
            for (Target target : work.targets()) {
                ApnsClient.Result result = apns.notify(target.pushToken());
                if (result.ok()) {
                    delivered.add(target.registrationId());
                } else if (result.unregistered()) {
                    gone.add(target.registrationId());
                } else if (failure == null || result.retryable()) {
                    failure = result;
                }
            }
        } catch (AppleWalletException e) {
            recordFailure(passId, e.status(), e.getMessage(), e.retryable());
            return Outcome.FAILED;
        } catch (RuntimeException e) {
            log.error("Falha inesperada ao notificar o passe Apple {}", passId, e);
            recordFailure(passId, 0, "Falha inesperada ao notificar os aparelhos.", true);
            return Outcome.FAILED;
        }
        ApnsClient.Result finalFailure = failure;
        return tx.execute(s -> {
            Instant now = clock.instant();
            if (!gone.isEmpty()) {
                registrations.deleteByIds(gone);
            }
            if (!delivered.isEmpty()) {
                registrations.findAllById(delivered).forEach(r -> r.pushed(now));
            }
            WalletPass pass = passes.lockById(passId).orElseThrow();
            if (finalFailure != null) {
                pass.fail(now, finalFailure.status(), finalFailure.reason(), finalFailure.retryable(), MAX_ATTEMPTS);
                return Outcome.FAILED;
            }
            pass.confirm(now, work.state(), work.invalidate());
            return pass.getSyncStatus() == WalletPass.SyncStatus.PENDING ? Outcome.CHANGED_AGAIN : Outcome.SYNCED;
        });
    }

    private Work reserve(Long passId) {
        Instant now = clock.instant();
        WalletPass pass = passes.lockById(passId).orElse(null);
        if (pass == null || pass.getProvider() != Provider.APPLE_WALLET || !pass.isDue(now)) {
            return null;
        }
        if (!gateway.issuable()) {
            throw new AppleWalletException(0, "Integração Apple Wallet não configurada: " + String.join(" ", gateway.missing()), false);
        }
        LoyaltyCard card = cards.findInEstablishment(pass.getEstablishmentId(), pass.getCardId()).orElseThrow();
        CardStatus status = card.effectiveStatus(now);
        // Modo offline: o passe não tem webServiceURL, então nenhum aparelho se registra e não há aviso a enviar.
        List<Target> targets = !gateway.configured() ? List.of() : registrations.findByWalletPassId(passId).stream()
                .map(r -> new Target(r.getId(), r.getPushToken())).toList();
        pass.reserve(now, LEASE);
        return new Work(passId, targets, ApplePassMapper.remoteState(status), status == CardStatus.CANCELLED);
    }

    private void recordFailure(Long passId, int status, String message, boolean retryable) {
        tx.executeWithoutResult(s -> passes.lockById(passId)
                .ifPresent(pass -> pass.fail(clock.instant(), status, message, retryable, MAX_ATTEMPTS)));
    }
}
