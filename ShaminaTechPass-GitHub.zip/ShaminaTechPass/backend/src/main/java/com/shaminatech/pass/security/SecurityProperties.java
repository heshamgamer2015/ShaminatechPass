package com.shaminatech.pass.security;

import java.time.Duration;

import org.springframework.boot.context.properties.ConfigurationProperties;

/** Parâmetros de proteção contra força bruta no login. */
@ConfigurationProperties(prefix = "shaminatech.security")
public record SecurityProperties(int maxFailedLogins, Duration lockDuration) {

    public SecurityProperties {
        if (maxFailedLogins <= 0) {
            maxFailedLogins = 5;
        }
        if (lockDuration == null) {
            lockDuration = Duration.ofMinutes(15);
        }
    }
}
