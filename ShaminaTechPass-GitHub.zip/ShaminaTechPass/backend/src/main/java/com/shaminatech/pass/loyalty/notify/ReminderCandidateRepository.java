package com.shaminatech.pass.loyalty.notify;

import java.time.Instant;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import com.shaminatech.pass.loyalty.card.LoyaltyCard;

/**
 * Cartões que podem receber lembrete: ativos e dentro da validade, de programa ativo, com passe Google Wallet já criado
 * no Google (estado remoto conhecido) e não inativado. Devolve pares [cartão, id do passe].
 */
public interface ReminderCandidateRepository extends Repository<LoyaltyCard, Long> {

    @Query("""
            select c, p.id from LoyaltyCard c join fetch c.consumer join fetch c.program prog, WalletPass p
            where p.cardId = c.id and p.provider = com.shaminatech.pass.loyalty.wallet.WalletPass.Provider.GOOGLE_WALLET
              and p.syncStatus <> com.shaminatech.pass.loyalty.wallet.WalletPass.SyncStatus.INVALIDATED
              and p.remoteState is not null
              and c.establishmentId = :establishmentId
              and c.status = com.shaminatech.pass.loyalty.card.CardEnums.CardStatus.ACTIVE and c.expiresAt > :now
              and prog.status = com.shaminatech.pass.loyalty.program.ProgramEnums.ProgramStatus.ACTIVE
              and c.id > :afterId
            order by c.id
            """)
    List<Object[]> findCandidates(@Param("establishmentId") Long establishmentId, @Param("now") Instant now,
                                  @Param("afterId") Long afterId, Pageable pageable);
}
