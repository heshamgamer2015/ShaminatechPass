package com.shaminatech.pass.common.persistence;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.boot.model.TypeContributions;
import org.hibernate.boot.model.TypeContributor;
import org.hibernate.jpa.boot.spi.TypeContributorList;
import org.hibernate.service.ServiceRegistry;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.hibernate.autoconfigure.HibernatePropertiesCustomizer;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AssignableTypeFilter;
import org.springframework.stereotype.Component;
import org.springframework.util.ClassUtils;

/**
 * Registra {@link EnumWithoutCheckJavaType} para todo enum que tenha um conversor {@link EnumNameConverter}
 * no pacote da aplicação. A descoberta é automática: um enum novo, com seu conversor, já nasce sem CHECK —
 * em tabelas novas (create/update) e em colunas novas de tabelas existentes.
 * <p>
 * Entregue ao Hibernate pela propriedade {@code hibernate.type_contributors}, que ele lê ao montar a
 * EntityManagerFactory.
 */
@Component
public class EnumCheckFreeTypeContributor implements TypeContributor, HibernatePropertiesCustomizer {

    static final String BASE_PACKAGE = "com.shaminatech.pass";

    private final Set<Class<? extends Enum<?>>> enums = discover();

    @Override
    public void customize(java.util.Map<String, Object> hibernateProperties) {
        Object existing = hibernateProperties.get("hibernate.type_contributors");
        List<TypeContributor> contributors = new ArrayList<>();
        if (existing instanceof TypeContributorList list) {
            contributors.addAll(list.getTypeContributors());
        }
        contributors.add(this);
        hibernateProperties.put("hibernate.type_contributors", (TypeContributorList) () -> contributors);
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void contribute(TypeContributions typeContributions, ServiceRegistry serviceRegistry) {
        for (Class<? extends Enum<?>> type : enums) {
            typeContributions.contributeJavaType(new EnumWithoutCheckJavaType(type));
        }
    }

    /** Enums cobertos (usado nos testes). */
    public Set<Class<? extends Enum<?>>> enums() {
        return enums;
    }

    @SuppressWarnings("unchecked")
    static Set<Class<? extends Enum<?>>> discover() {
        var scanner = new ClassPathScanningCandidateComponentProvider(false);
        scanner.addIncludeFilter(new AssignableTypeFilter(EnumNameConverter.class));
        Set<Class<? extends Enum<?>>> result = new LinkedHashSet<>();
        for (var candidate : scanner.findCandidateComponents(BASE_PACKAGE)) {
            Class<?> type = ClassUtils.resolveClassName(candidate.getBeanClassName(), EnumCheckFreeTypeContributor.class.getClassLoader());
            if (EnumNameConverter.class.isAssignableFrom(type)) {
                EnumNameConverter<?> converter = (EnumNameConverter<?>) BeanUtils.instantiateClass(type);
                result.add((Class<? extends Enum<?>>) converter.enumType());
            }
        }
        return result;
    }
}
