package com.shaminatech.pass.loyalty.wallet.apple;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.time.Instant;
import java.util.Collections;

import javax.naming.ldap.LdapName;
import javax.naming.ldap.Rdn;

/**
 * Certificado Pass Type ID (com a chave privada) e intermediário Apple WWDR, carregados dos arquivos externos.
 * A chave fica só em memória; {@link #toString()} nunca a mostra.
 */
public final class AppleCredentials {

    private final PrivateKey privateKey;
    private final X509Certificate certificate;
    private final X509Certificate wwdr;
    private final KeyStore keyStore;
    private final char[] password;

    private AppleCredentials(PrivateKey privateKey, X509Certificate certificate, X509Certificate wwdr, KeyStore keyStore,
                             char[] password) {
        this.privateKey = privateKey;
        this.certificate = certificate;
        this.wwdr = wwdr;
        this.keyStore = keyStore;
        this.password = password;
    }

    /** Lê o .p12 e o intermediário; confere se o certificado é do Pass Type ID e do Team ID configurados. */
    public static AppleCredentials load(AppleWalletProperties properties) {
        char[] password = properties.certificatePassword().toCharArray();
        KeyStore store;
        PrivateKey key = null;
        X509Certificate cert = null;
        try (InputStream in = Files.newInputStream(Path.of(properties.certificateFile()))) {
            store = KeyStore.getInstance("PKCS12");
            store.load(in, password);
            for (String alias : Collections.list(store.aliases())) {
                if (store.isKeyEntry(alias)) {
                    key = (PrivateKey) store.getKey(alias, password);
                    cert = (X509Certificate) store.getCertificate(alias);
                    break;
                }
            }
        } catch (java.io.IOException e) {
            throw new AppleWalletException(0, "Não foi possível ler o certificado .p12 (arquivo ausente ou senha incorreta).", false);
        } catch (Exception e) {
            throw new AppleWalletException(0, "Certificado .p12 inválido.", false);
        }
        if (key == null || cert == null) {
            throw new AppleWalletException(0, "O .p12 não contém a chave privada do certificado Pass Type ID.", false);
        }
        X509Certificate intermediate;
        try (InputStream in = Files.newInputStream(Path.of(properties.wwdrCertificateFile()))) {
            intermediate = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(in);
        } catch (Exception e) {
            throw new AppleWalletException(0, "Não foi possível ler o certificado intermediário Apple WWDR.", false);
        }
        String uid = attribute(cert, "UID");
        if (uid != null && !uid.equals(properties.passTypeIdentifier())) {
            throw new AppleWalletException(0, "O certificado é do Pass Type ID " + uid + ", diferente do configurado ("
                    + properties.passTypeIdentifier() + ").", false);
        }
        String team = attribute(cert, "OU");
        if (team != null && !team.equals(properties.teamIdentifier())) {
            throw new AppleWalletException(0, "O certificado é do Team ID " + team + ", diferente do configurado.", false);
        }
        if (cert.getNotAfter().toInstant().isBefore(Instant.now())) {
            throw new AppleWalletException(0, "O certificado Pass Type ID expirou: gere um novo no Apple Developer.", false);
        }
        return new AppleCredentials(key, cert, intermediate, store, password);
    }

    /** Atributo do titular do certificado (UID = Pass Type ID, OU = Team ID nos certificados da Apple). */
    static String attribute(X509Certificate cert, String type) {
        try {
            for (Rdn rdn : new LdapName(cert.getSubjectX500Principal().getName()).getRdns()) {
                if (rdn.getType().equalsIgnoreCase(type) || ("UID".equals(type) && "0.9.2342.19200300.100.1.1".equals(rdn.getType()))) {
                    Object value = rdn.getValue();
                    if (value instanceof byte[] bytes) {
                        return decodeDer(bytes);
                    }
                    return value.toString();
                }
            }
        } catch (Exception ignored) {
            // titular em formato inesperado: a conferência é só uma proteção extra
        }
        return null;
    }

    /** Valor de atributo DER (#0c.. / #13..) em formato hexadecimal pelo RFC 2253. */
    private static String decodeDer(byte[] der) {
        if (der.length > 2) {
            int length = der[1] & 0xff;
            if (length + 2 == der.length) {
                return new String(der, 2, length, java.nio.charset.StandardCharsets.UTF_8);
            }
        }
        return null;
    }

    public PrivateKey privateKey() {
        return privateKey;
    }

    public X509Certificate certificate() {
        return certificate;
    }

    public X509Certificate wwdr() {
        return wwdr;
    }

    /** Usado só para o TLS com o APNs (a Apple autentica a notificação pelo mesmo certificado). */
    KeyStore keyStore() {
        return keyStore;
    }

    char[] password() {
        return password.clone();
    }

    public Instant expiresAt() {
        return certificate.getNotAfter().toInstant();
    }

    @Override
    public String toString() {
        return "AppleCredentials[" + certificate.getSubjectX500Principal().getName() + ", chave=<oculta>]";
    }
}
