package com.shaminatech.pass.loyalty.notify;

import java.time.Instant;
import java.util.List;
import java.util.Map;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** Contratos da página "Notificações e Proximidade". */
public final class NotificationDtos {

    private NotificationDtos() {
    }

    public record SettingsRequest(
            @NotNull Boolean nearRewardEnabled,
            @NotNull @Min(value = 1, message = "Escolha de 1 a 3 carimbos.") @Max(value = 3, message = "Escolha de 1 a 3 carimbos.")
            Integer nearRewardStamps,
            @NotNull Integer nearRewardPointsPercent,
            @NotNull Boolean expiryEnabled,
            @NotNull Integer expiryDaysBefore,
            @NotNull Boolean inactivityEnabled,
            @NotNull @Min(value = 15, message = "Mínimo de 15 dias.") @Max(value = 365, message = "Máximo de 365 dias.")
            Integer inactivityDays,
            @NotNull @Min(value = 3, message = "Mínimo de 3 dias entre avisos.") @Max(value = 90, message = "Máximo de 90 dias.")
            Integer minIntervalDays,
            @NotNull Boolean proximityEnabled,
            @Size(max = 80, message = "Máximo de 80 caracteres.") String proximityText) {
    }

    public record SettingsView(boolean nearRewardEnabled, int nearRewardStamps, int nearRewardPointsPercent, boolean expiryEnabled,
                               int expiryDaysBefore, boolean inactivityEnabled, int inactivityDays, int minIntervalDays,
                               boolean proximityEnabled, String proximityText) {
    }

    public record LocationRequest(
            @NotBlank(message = "Informe um nome (ex.: Loja Centro).") @Size(max = 60, message = "Máximo de 60 caracteres.") String name,
            @NotBlank(message = "Informe o endereço.") @Size(max = 200, message = "Máximo de 200 caracteres.") String addressLine,
            @NotBlank(message = "Informe a cidade.") @Size(max = 80, message = "Máximo de 80 caracteres.") String city,
            @NotBlank(message = "Informe a UF.") @Pattern(regexp = "^[A-Za-z]{2}$", message = "Use a sigla do estado (ex.: SP).") String state,
            @NotBlank(message = "Informe o CEP.") @Pattern(regexp = "^\\d{5}-?\\d{3}$", message = "CEP inválido (ex.: 01310-100).") String postalCode,
            @NotNull(message = "Informe a latitude.") @DecimalMin(value = "-90", message = "Latitude entre -90 e 90.")
            @DecimalMax(value = "90", message = "Latitude entre -90 e 90.") Double latitude,
            @NotNull(message = "Informe a longitude.") @DecimalMin(value = "-180", message = "Longitude entre -180 e 180.")
            @DecimalMax(value = "180", message = "Longitude entre -180 e 180.") Double longitude) {
    }

    public record LocationView(Long id, String name, String addressLine, String city, String state, String postalCode,
                               double latitude, double longitude) {
    }

    /** Recurso de carteira: o que existe de fato e o que depende de configuração externa. */
    public record Capability(String key, String title, boolean available, String detail) {
    }

    public record IntegrationView(boolean googleConfigured, List<String> googleMissing, boolean appleConfigured) {
    }

    public record Overview(SettingsView settings, List<LocationView> locations, int maxLocations, IntegrationView integration,
                           List<Capability> capabilities, Map<WalletReminder.Status, Long> last30Days, List<ReminderView> recentFailures,
                           List<String> notes) {
    }

    public record ReminderView(Long id, ReminderCategory category, WalletReminder.Status status, String header, String body,
                               Long cardId, String consumerFirstName, String programName, Instant plannedAt, Instant lastAttemptAt,
                               Instant acceptedAt, Instant withdrawnAt, int attempts, Instant nextAttemptAt, String closedReason,
                               String lastError, Integer lastErrorStatus) {
    }
}
