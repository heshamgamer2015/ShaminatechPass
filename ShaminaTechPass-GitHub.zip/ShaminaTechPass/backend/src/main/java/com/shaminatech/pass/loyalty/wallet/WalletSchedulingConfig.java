package com.shaminatech.pass.loyalty.wallet;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/** Habilita a varredura periódica de sincronização ({@link WalletSyncDispatcher#sweep}); sem efeito com a integração desligada. */
@Configuration
@EnableScheduling
public class WalletSchedulingConfig {
}
