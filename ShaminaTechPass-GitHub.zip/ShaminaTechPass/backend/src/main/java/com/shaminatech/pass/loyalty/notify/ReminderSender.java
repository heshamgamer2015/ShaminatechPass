package com.shaminatech.pass.loyalty.notify;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.card.LoyaltyCardRepository;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.wallet.WalletPass;
import com.shaminatech.pass.loyalty.wallet.WalletPassRepository;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletApi;
import com.shaminatech.pass.loyalty.wallet.google.WalletApiException;

/**
 * Envio dos lembretes ao Google Wallet em três passos curtos, como a sincronização de passes:
 * <ol>
 *   <li><b>Reserva</b> (transação, FOR UPDATE): confere a janela de horário, <b>reavalia</b> a situação do cartão (se uma
 *       compra renovou a validade ou completou o cartão, o lembrete é cancelado) e marca SENDING com prazo de reserva;</li>
 *   <li><b>Pedido</b> (sem transação): {@code addMessage} com {@code TEXT_AND_NOTIFY};</li>
 *   <li><b>Resultado</b> (transação): ACCEPTED quando o Google aceita o pedido; falhas temporárias voltam com espera
 *       crescente; limite de avisos (QuotaExceeded) e erros permanentes encerram sem nova tentativa.</li>
 * </ol>
 * ACCEPTED não significa entregue: o Google não informa se o aviso apareceu nem se foi lido.
 */
@Service
public class ReminderSender {

    static final Duration LEASE = Duration.ofMinutes(2);
    static final Duration MAX_AGE = Duration.ofHours(48);
    static final int MAX_ATTEMPTS = 4;
    private static final Duration[] BACKOFF = {Duration.ofMinutes(5), Duration.ofMinutes(30), Duration.ofHours(2)};
    private static final Logger log = LoggerFactory.getLogger(ReminderSender.class);

    public enum Outcome { ACCEPTED, FAILED, CLOSED, DEFERRED, SKIPPED }

    private record Work(Long reminderId, String objectId, Map<String, Object> message) {
    }

    private final WalletReminderRepository reminders;
    private final NotificationSettingsRepository settings;
    private final LoyaltyCardRepository cards;
    private final WalletPassRepository passes;
    private final ReminderSnapshots snapshots;
    private final PolicyService policies;
    private final GoogleWalletApi google;
    private final TransactionTemplate tx;
    private final Clock clock;
    private final int windowStartHour;
    private final int windowEndHour;

    public ReminderSender(WalletReminderRepository reminders, NotificationSettingsRepository settings, LoyaltyCardRepository cards,
                          WalletPassRepository passes, ReminderSnapshots snapshots, PolicyService policies, GoogleWalletApi google,
                          PlatformTransactionManager transactionManager, Clock clock,
                          @Value("${shaminatech.notifications.send-window-start-hour:9}") int windowStartHour,
                          @Value("${shaminatech.notifications.send-window-end-hour:20}") int windowEndHour) {
        this.reminders = reminders;
        this.settings = settings;
        this.cards = cards;
        this.passes = passes;
        this.snapshots = snapshots;
        this.policies = policies;
        this.google = google;
        this.tx = new TransactionTemplate(transactionManager);
        this.tx.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        this.clock = clock;
        this.windowStartHour = windowStartHour;
        this.windowEndHour = windowEndHour;
    }

    /** Envia os lembretes devidos (até 50 por rodada). */
    public int dispatchDue() {
        if (!google.configured()) {
            return 0;
        }
        int accepted = 0;
        for (Long id : reminders.findDueIds(clock.instant(), PageRequest.of(0, 50))) {
            if (process(id) == Outcome.ACCEPTED) {
                accepted++;
            }
        }
        return accepted;
    }

    public Outcome process(Long reminderId) {
        Work work = tx.execute(s -> reserve(reminderId));
        if (work == null) {
            return Outcome.SKIPPED;
        }
        if (work.objectId() == null) {
            return Outcome.CLOSED; // cancelado ou adiado na reserva (resultado já gravado)
        }
        try {
            google.addObjectMessage(work.objectId(), work.message());
            return confirm(reminderId, null);
        } catch (WalletApiException e) {
            if (e.status() == 409) {
                return confirmConflict(reminderId, work, e);
            }
            return confirm(reminderId, e);
        } catch (RuntimeException e) {
            log.error("Falha inesperada ao enviar o lembrete {}", reminderId, e);
            return confirm(reminderId, new WalletApiException(0, "Falha inesperada ao enviar.", true));
        }
    }

    private Work reserve(Long reminderId) {
        Instant now = clock.instant();
        WalletReminder r = reminders.lockById(reminderId).orElse(null);
        if (r == null || !r.isDue(now)) {
            return null;
        }
        Work closed = new Work(reminderId, null, null);
        if (r.getAcceptedAt() == null && r.getPlannedAt().plus(MAX_AGE).isBefore(now)) {
            r.cancel("Não enviado em até 48 h (fora da janela de envio ou falhas); descartado para não chegar atrasado.");
            return closed;
        }
        ZoneId zone = policies.of(r.getEstablishmentId()).zone();
        Instant nextWindow = nextWindowStart(now, zone);
        if (nextWindow != null) {
            r.defer(nextWindow);
            return closed;
        }
        NotificationSettings s = settings.findByEstablishmentId(r.getEstablishmentId()).orElse(null);
        LoyaltyCard card = cards.findInEstablishment(r.getEstablishmentId(), r.getCardId()).orElse(null);
        WalletPass pass = passes.findById(r.getWalletPassId()).orElse(null);
        if (s == null || card == null || pass == null || pass.getSyncStatus() == WalletPass.SyncStatus.INVALIDATED
                || pass.getRemoteState() == null || !card.getProgram().isActive() || !card.getProgram().getEstablishment().isActive()) {
            r.cancel("Cartão, programa ou carteira não estão mais aptos a receber o aviso.");
            return closed;
        }
        // Reavalia agora: a situação pode ter mudado desde o planejamento (compra, resgate, bloqueio, nova configuração).
        Optional<ReminderRules.Candidate> current = ReminderRules.evaluate(r.getCategory(),
                snapshots.of(card, snapshots.cheapestRewards(r.getEstablishmentId()), now), s, zone, now);
        if (current.isEmpty() || !current.get().dedupKey().equals(r.getDedupKey())) {
            r.cancel("A situação do cartão mudou antes do envio (aviso obsoleto).");
            return closed;
        }
        ReminderRules.Candidate c = current.get();
        r.refreshText(ReminderPlanner.limit(c.header(), 80), ReminderPlanner.limit(c.body(), 300), c.displayUntil());
        r.reserve(now, LEASE);
        return new Work(reminderId, pass.getExternalId(), message(r, now));
    }

    private Outcome confirm(Long reminderId, WalletApiException error) {
        Outcome outcome = tx.execute(s -> {
            WalletReminder r = reminders.lockById(reminderId).orElseThrow();
            Instant now = clock.instant();
            if (error == null) {
                r.accepted(now, null);
                return Outcome.ACCEPTED;
            }
            if (error.status() == 429 && error.getMessage().toLowerCase(Locale.ROOT).contains("quota")) {
                r.close(WalletReminder.Status.QUOTA_EXCEEDED, "Limite de avisos do Google para este cartão atingido; não será reenviado.",
                        error.status(), error.getMessage());
                return Outcome.CLOSED;
            }
            if (error.retryable() && r.getAttempts() < MAX_ATTEMPTS) {
                r.failed(now, error.status(), error.getMessage(), now.plus(BACKOFF[Math.min(r.getAttempts(), BACKOFF.length) - 1]));
                return Outcome.FAILED;
            }
            if (error.retryable()) {
                r.failed(now, error.status(), error.getMessage(), null);
                return Outcome.FAILED;
            }
            r.close(WalletReminder.Status.REJECTED, "O Google recusou o pedido.", error.status(), error.getMessage());
            return Outcome.CLOSED;
        });
        return outcome;
    }

    /**
     * HTTP 409 em addMessage: a documentação do Google não define o significado. Não se presume sucesso — o objeto é
     * lido e o aviso só conta como aceito se a mensagem com o mesmo id estiver gravada no cartão. Mensagem ausente =
     * recusa definitiva; falha ao consultar = tentativa que será repetida (a próxima tentativa verifica de novo).
     */
    @SuppressWarnings("unchecked")
    private Outcome confirmConflict(Long reminderId, Work work, WalletApiException conflict) {
        String messageId = String.valueOf(work.message().get("id"));
        boolean present;
        try {
            present = google.getObject(work.objectId())
                    .map(o -> (List<Map<String, Object>>) o.getOrDefault("messages", List.of()))
                    .orElse(List.of())
                    .stream()
                    .anyMatch(m -> messageId.equals(String.valueOf(m.get("id"))));
        } catch (WalletApiException e) {
            return confirm(reminderId, new WalletApiException(e.status(),
                    "Conflito 409 no Google não pôde ser verificado: " + e.getMessage(), true));
        } catch (RuntimeException e) {
            log.warn("Falha ao verificar o conflito 409 do lembrete {}", reminderId);
            return confirm(reminderId, new WalletApiException(0, "Conflito 409 no Google não pôde ser verificado.", true));
        }
        if (!present) {
            return tx.execute(s -> {
                WalletReminder r = reminders.lockById(reminderId).orElseThrow();
                r.close(WalletReminder.Status.REJECTED, "O Google respondeu conflito (409) e a mensagem não está gravada no cartão.",
                        conflict.status(), conflict.getMessage());
                return Outcome.CLOSED;
            });
        }
        return tx.execute(s -> {
            WalletReminder r = reminders.lockById(reminderId).orElseThrow();
            r.accepted(clock.instant(), "Verificado no Google: a mensagem já estava gravada no cartão (pedido anterior aceito).");
            return Outcome.ACCEPTED;
        });
    }

    /** Mensagem no formato da API (Message): aviso no celular + texto nos detalhes do cartão até {@code displayUntil}. */
    static Map<String, Object> message(WalletReminder r, Instant now) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", r.messageId());
        m.put("header", r.getHeader());
        m.put("body", r.getBody());
        m.put("messageType", "TEXT_AND_NOTIFY");
        m.put("displayInterval", Map.of(
                "start", Map.of("date", DateTimeFormatter.ISO_INSTANT.format(now)),
                "end", Map.of("date", DateTimeFormatter.ISO_INSTANT.format(r.getDisplayUntil()))));
        return m;
    }

    /** Null = dentro da janela de envio (horário local do estabelecimento); senão, o próximo início da janela. */
    Instant nextWindowStart(Instant now, ZoneId zone) {
        ZonedDateTime local = now.atZone(zone);
        int hour = local.getHour();
        if (hour >= windowStartHour && hour < windowEndHour) {
            return null;
        }
        ZonedDateTime start = local.with(LocalTime.of(windowStartHour, 0));
        if (hour >= windowEndHour) {
            start = start.plusDays(1);
        }
        return start.toInstant();
    }
}
