package com.shaminatech.pass.loyalty.program;

import java.math.RoundingMode;

import com.shaminatech.pass.common.persistence.EnumNameConverter;

import jakarta.persistence.Converter;

/** Enumerações das regras de programa (gravadas como texto, sem CHECK). */
public final class ProgramEnums {

    private ProgramEnums() {
    }

    /** ACTIVE: aceita emissões e movimentações. PAUSED: só consulta e estornos. ARCHIVED: encerrado (somente leitura). */
    public enum ProgramStatus {
        ACTIVE, PAUSED, ARCHIVED;

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<ProgramStatus> {
            public JpaConverter() {
                super(ProgramStatus.class);
            }
        }
    }

    /**
     * Como a validade é calculada a partir da última movimentação válida.
     * END_OF_DAY: vale até 23:59:59 do último dia, no fuso do estabelecimento.
     * EXACT_TIME: vence no mesmo horário da movimentação, N dias depois.
     */
    public enum ValidityMode {
        END_OF_DAY, EXACT_TIME;

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<ValidityMode> {
            public JpaConverter() {
                super(ValidityMode.class);
            }
        }
    }

    /** O que acontece com o saldo quando o CARTÃO expira por inatividade. */
    public enum ExpiredBalancePolicy {
        /** O saldo fica congelado; volta a valer se a empresa reativar o cartão. */
        KEEP,
        /** O saldo é zerado por uma movimentação compensatória registrada no histórico. */
        FORFEIT;

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<ExpiredBalancePolicy> {
            public JpaConverter() {
                super(ExpiredBalancePolicy.class);
            }
        }
    }

    /** Estorno de concessão quando o saldo atual não cobre o valor a estornar. */
    public enum ReversalPolicy {
        /** O estorno é recusado: o saldo nunca fica negativo. */
        REQUIRE_BALANCE,
        /** O estorno é aceito e o saldo pode ficar negativo até novas concessões compensarem. */
        ALLOW_NEGATIVE;

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<ReversalPolicy> {
            public JpaConverter() {
                super(ReversalPolicy.class);
            }
        }
    }

    /** Arredondamento de pontos/cashback calculados. */
    public enum Rounding {
        DOWN(RoundingMode.DOWN), HALF_UP(RoundingMode.HALF_UP), UP(RoundingMode.UP);

        private final RoundingMode mode;

        Rounding(RoundingMode mode) {
            this.mode = mode;
        }

        public RoundingMode mode() {
            return mode;
        }

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<Rounding> {
            public JpaConverter() {
                super(Rounding.class);
            }
        }
    }

    public enum StampCriterion {
        PURCHASE, PRODUCT, VISIT;

        @Converter(autoApply = true)
        public static class JpaConverter extends EnumNameConverter<StampCriterion> {
            public JpaConverter() {
                super(StampCriterion.class);
            }
        }
    }
}
