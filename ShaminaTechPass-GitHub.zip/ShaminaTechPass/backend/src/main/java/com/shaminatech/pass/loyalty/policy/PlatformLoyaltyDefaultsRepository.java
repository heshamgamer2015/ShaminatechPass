package com.shaminatech.pass.loyalty.policy;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PlatformLoyaltyDefaultsRepository extends JpaRepository<PlatformLoyaltyDefaults, Long> {

    Optional<PlatformLoyaltyDefaults> findFirstByOrderByIdAsc();
}
