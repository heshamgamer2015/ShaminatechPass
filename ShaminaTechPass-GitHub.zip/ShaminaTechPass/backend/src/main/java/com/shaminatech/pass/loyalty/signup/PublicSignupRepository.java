package com.shaminatech.pass.loyalty.signup;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface PublicSignupRepository extends JpaRepository<PublicSignup, Long> {

    Optional<PublicSignup> findByRequestKeyHash(String requestKeyHash);

    /** Por link: [linkId, total, último cadastro]. */
    @Query("""
            select s.linkId, count(s), max(s.signedUpAt) from PublicSignup s
            where s.establishmentId = :establishmentId group by s.linkId
            """)
    List<Object[]> statsByLink(@Param("establishmentId") Long establishmentId);

    @Query("""
            select count(s) from PublicSignup s where s.establishmentId = :establishmentId
              and s.signedUpAt >= :from and s.signedUpAt <= :to
            """)
    long countBetween(@Param("establishmentId") Long establishmentId, @Param("from") Instant from, @Param("to") Instant to);

    @Query("""
            select count(s) from PublicSignup s where s.establishmentId = :establishmentId and s.programId = :programId
              and s.signedUpAt >= :from and s.signedUpAt <= :to
            """)
    long countBetween(@Param("establishmentId") Long establishmentId, @Param("programId") Long programId,
                      @Param("from") Instant from, @Param("to") Instant to);
}
