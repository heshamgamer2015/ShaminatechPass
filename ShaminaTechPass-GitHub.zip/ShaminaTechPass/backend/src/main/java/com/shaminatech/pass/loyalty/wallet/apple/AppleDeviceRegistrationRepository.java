package com.shaminatech.pass.loyalty.wallet.apple;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface AppleDeviceRegistrationRepository extends JpaRepository<AppleDeviceRegistration, Long> {

    Optional<AppleDeviceRegistration> findByDeviceLibraryIdAndWalletPassId(String deviceLibraryId, Long walletPassId);

    List<AppleDeviceRegistration> findByWalletPassId(Long walletPassId);

    long countByWalletPassId(Long walletPassId);

    /** Seriais dos passes do aparelho alterados depois da marca informada (Instant.EPOCH = todos). */
    @Query("""
            select p.externalId, p.contentUpdatedAt from AppleDeviceRegistration r, com.shaminatech.pass.loyalty.wallet.WalletPass p
            where r.deviceLibraryId = :device and p.id = r.walletPassId
              and p.provider = com.shaminatech.pass.loyalty.wallet.WalletPass.Provider.APPLE_WALLET
              and p.contentUpdatedAt > :since
            """)
    List<Object[]> updatedSerials(@Param("device") String deviceLibraryId, @Param("since") Instant since);

    @Modifying
    @Query("delete from AppleDeviceRegistration r where r.id in :ids")
    int deleteByIds(@Param("ids") Collection<Long> ids);
}
