package com.shaminatech.pass.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Profile;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/**
 * Conferência de segurança ao iniciar em produção (perfil "prod"):
 * <ul>
 *   <li>cookie de sessão sem {@code Secure} → a aplicação NÃO sobe (sessão trafegaria fora do HTTPS);</li>
 *   <li>schema diferente de {@code validate} → não sobe (produção nunca altera o banco sozinha);</li>
 *   <li>proxy reverso sem lista de IPs confiáveis → aviso: o limite de tentativas tratará todos os clientes como o
 *       próprio proxy e o esquema HTTPS não será reconhecido.</li>
 * </ul>
 * Nenhum valor sensível é registrado.
 */
@Component
@Profile("prod")
public class ProductionSafetyCheck {

    private static final Logger log = LoggerFactory.getLogger(ProductionSafetyCheck.class);

    private final boolean secureCookie;
    private final String ddlAuto;
    private final String forwardHeaders;
    private final String trustedProxies;
    private final boolean appleOfflinePasses;

    public ProductionSafetyCheck(@Value("${server.servlet.session.cookie.secure:false}") boolean secureCookie,
                                 @Value("${spring.jpa.hibernate.ddl-auto:validate}") String ddlAuto,
                                 @Value("${server.forward-headers-strategy:none}") String forwardHeaders,
                                 @Value("${server.tomcat.remoteip.internal-proxies:}") String trustedProxies,
                                 @Value("${shaminatech.wallet.apple.offline-passes:false}") boolean appleOfflinePasses) {
        this.secureCookie = secureCookie;
        this.ddlAuto = ddlAuto;
        this.forwardHeaders = forwardHeaders;
        this.trustedProxies = trustedProxies;
        this.appleOfflinePasses = appleOfflinePasses;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void verify() {
        if (!secureCookie) {
            throw new IllegalStateException("Produção exige server.servlet.session.cookie.secure=true (HTTPS).");
        }
        if (!"validate".equalsIgnoreCase(ddlAuto) && !"none".equalsIgnoreCase(ddlAuto)) {
            throw new IllegalStateException("Produção exige spring.jpa.hibernate.ddl-auto=validate (ou none).");
        }
        if (appleOfflinePasses) {
            throw new IllegalStateException("shaminatech.wallet.apple.offline-passes é só para homologação local: em produção os "
                    + "passes Apple precisam do serviço de atualização (URL pública HTTPS).");
        }
        if ("native".equalsIgnoreCase(forwardHeaders) && (trustedProxies == null || trustedProxies.isBlank())) {
            log.warn("FORWARD_HEADERS_STRATEGY=native sem TRUSTED_PROXIES: nenhum proxy é confiável, o IP de todos os clientes "
                    + "será o do proxy (limites de tentativa compartilhados). Defina TRUSTED_PROXIES com a regex dos IPs do proxy.");
        }
    }
}
