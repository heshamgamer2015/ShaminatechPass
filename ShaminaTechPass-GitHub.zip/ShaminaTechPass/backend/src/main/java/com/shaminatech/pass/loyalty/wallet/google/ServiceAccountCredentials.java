package com.shaminatech.pass.loyalty.wallet.google;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.Map;

import tools.jackson.databind.json.JsonMapper;

/**
 * Credenciais da conta de serviço (arquivo JSON baixado do Google Cloud). A chave privada fica apenas em memória;
 * {@link #toString()} nunca a expõe e ela jamais é gravada em banco, log ou resposta da API.
 */
public final class ServiceAccountCredentials {

    private static final String DEFAULT_TOKEN_URI = "https://oauth2.googleapis.com/token";

    private final String clientEmail;
    private final String tokenUri;
    private final PrivateKey privateKey;

    private ServiceAccountCredentials(String clientEmail, String tokenUri, PrivateKey privateKey) {
        this.clientEmail = clientEmail;
        this.tokenUri = tokenUri;
        this.privateKey = privateKey;
    }

    @SuppressWarnings("unchecked")
    public static ServiceAccountCredentials load(Path file, JsonMapper json) {
        try {
            Map<String, Object> data = json.readValue(Files.readString(file), Map.class);
            String email = (String) data.get("client_email");
            String key = (String) data.get("private_key");
            if (email == null || key == null || !"service_account".equals(data.get("type"))) {
                throw new IllegalStateException("O arquivo informado não é uma chave JSON de conta de serviço.");
            }
            String tokenUri = data.get("token_uri") instanceof String uri && !uri.isBlank() ? uri : DEFAULT_TOKEN_URI;
            return new ServiceAccountCredentials(email, tokenUri, parsePrivateKey(key));
        } catch (IOException e) {
            throw new IllegalStateException("Não foi possível ler o arquivo da conta de serviço.", e);
        }
    }

    static PrivateKey parsePrivateKey(String pem) {
        try {
            String base64 = pem.replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "")
                    .replaceAll("\\s", "");
            return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64)));
        } catch (Exception e) {
            throw new IllegalStateException("Chave privada da conta de serviço inválida.");
        }
    }

    public String clientEmail() {
        return clientEmail;
    }

    public String tokenUri() {
        return tokenUri;
    }

    PrivateKey privateKey() {
        return privateKey;
    }

    @Override
    public String toString() {
        return "ServiceAccountCredentials[" + clientEmail + ", chave privada oculta]";
    }
}
