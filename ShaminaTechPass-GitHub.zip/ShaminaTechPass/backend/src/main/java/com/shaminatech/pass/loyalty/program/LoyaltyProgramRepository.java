package com.shaminatech.pass.loyalty.program;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface LoyaltyProgramRepository extends JpaRepository<LoyaltyProgram, Long> {

    @Query("select p from LoyaltyProgram p where p.id = :id and p.establishment.id = :establishmentId")
    Optional<LoyaltyProgram> findInEstablishment(@Param("establishmentId") Long establishmentId, @Param("id") Long id);

    @Query("select p from LoyaltyProgram p where p.establishment.id = :establishmentId order by p.status, p.name")
    List<LoyaltyProgram> findAllInEstablishment(@Param("establishmentId") Long establishmentId);

    @Query("select count(p) from LoyaltyProgram p where p.establishment.id = :establishmentId")
    long countInEstablishment(@Param("establishmentId") Long establishmentId);
}
