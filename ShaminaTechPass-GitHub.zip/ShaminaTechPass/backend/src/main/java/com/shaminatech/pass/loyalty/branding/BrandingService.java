package com.shaminatech.pass.loyalty.branding;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ProgramView;
import com.shaminatech.pass.loyalty.LoyaltyViews;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.ProgramService;
import com.shaminatech.pass.membership.Permission;
import com.shaminatech.pass.tenant.TenantAccessService;

/** Logotipo e imagem de destaque dos cartões. */
@Service
public class BrandingService {

    public enum Slot {
        LOGO, HERO;

        public static Slot parse(String value) {
            try {
                return Slot.valueOf(value.toUpperCase());
            } catch (IllegalArgumentException | NullPointerException e) {
                throw ApiException.badRequest("Tipo de imagem inválido (use logo ou hero).", "slot");
            }
        }
    }

    private final TenantAccessService tenantAccess;
    private final ProgramService programs;
    private final StoredImageRepository images;
    private final ImageValidator validator;
    private final PolicyService policies;
    private final LoyaltyViews views;
    private final AuditService audit;
    private final org.springframework.context.ApplicationEventPublisher events;

    public BrandingService(TenantAccessService tenantAccess, ProgramService programs, StoredImageRepository images,
                           ImageValidator validator, PolicyService policies, LoyaltyViews views, AuditService audit,
                           org.springframework.context.ApplicationEventPublisher events) {
        this.events = events;
        this.tenantAccess = tenantAccess;
        this.programs = programs;
        this.images = images;
        this.validator = validator;
        this.policies = policies;
        this.views = views;
        this.audit = audit;
    }

    @Transactional
    public ProgramView upload(Long establishmentId, Long programId, Slot slot, byte[] bytes) {
        tenantAccess.require(establishmentId, Permission.PROGRAMS_MANAGE);
        LoyaltyProgram program = programs.find(establishmentId, programId);
        var valid = validator.validate(bytes);
        StoredImage image = images.save(new StoredImage(establishmentId, valid.contentType(), valid.data(), valid.width(),
                valid.height(), valid.sha256()));
        Long previous = slot == Slot.LOGO ? program.getLogoImageId() : program.getHeroImageId();
        if (slot == Slot.LOGO) {
            program.setLogoImageId(image.getId());
        } else {
            program.setHeroImageId(image.getId());
        }
        // A imagem anterior deixa de ser usada pelo programa, mas é mantida (histórico/auditoria).
        audit.record(AuditAction.CARD_IMAGE_UPLOADED, establishmentId, "PROGRAM", programId,
                slot + " imagem=" + image.getId() + (previous == null ? "" : " substitui=" + previous) + " "
                        + valid.width() + "x" + valid.height());
        events.publishEvent(new com.shaminatech.pass.loyalty.wallet.ProgramChangedEvent(programId));
        return views.program(program, policies.of(establishmentId));
    }

    @Transactional
    public ProgramView remove(Long establishmentId, Long programId, Slot slot) {
        tenantAccess.require(establishmentId, Permission.PROGRAMS_MANAGE);
        LoyaltyProgram program = programs.find(establishmentId, programId);
        if (slot == Slot.LOGO) {
            program.setLogoImageId(null);
        } else {
            program.setHeroImageId(null);
        }
        audit.record(AuditAction.CARD_IMAGE_REMOVED, establishmentId, "PROGRAM", programId, slot.name());
        events.publishEvent(new com.shaminatech.pass.loyalty.wallet.ProgramChangedEvent(programId));
        return views.program(program, policies.of(establishmentId));
    }

    @Transactional(readOnly = true)
    public StoredImage get(Long establishmentId, Long imageId) {
        tenantAccess.require(establishmentId, Permission.ESTABLISHMENT_VIEW);
        return images.findInEstablishment(establishmentId, imageId).orElseThrow(() -> ApiException.notFound("Imagem não encontrada."));
    }
}
