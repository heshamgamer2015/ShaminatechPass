package com.shaminatech.pass.loyalty.card;

import java.time.Clock;
import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import com.shaminatech.pass.loyalty.policy.LoyaltyProperties;

/**
 * Processamento de expiração, seguro para rodar repetidamente e em paralelo (mais de uma instância):
 * cada cartão é tratado em transação própria, travado (FOR UPDATE) e reavaliado antes de qualquer alteração.
 * Rodar duas vezes no mesmo instante não gera registros duplicados.
 * <ol>
 *   <li>lotes de benefícios vencidos pela validade própria → BENEFIT_EXPIRED;</li>
 *   <li>cartões vencidos por inatividade → EXPIRED (e BALANCE_FORFEITED se o programa usar FORFEIT).</li>
 * </ol>
 * Independentemente deste processamento, toda operação já recusa cartões e lotes vencidos pela data.
 */
@Service
public class ExpirationProcessor {

    private static final Logger log = LoggerFactory.getLogger(ExpirationProcessor.class);

    private final LoyaltyCardRepository cards;
    private final BenefitLotRepository lots;
    private final CardEngine engine;
    private final TransactionTemplate perCard;
    private final Clock clock;
    private final int batchSize;

    public record Summary(int cardsExpired, int cardsWithExpiredBenefits, int failures) {
    }

    public ExpirationProcessor(LoyaltyCardRepository cards, BenefitLotRepository lots, CardEngine engine,
                               PlatformTransactionManager transactionManager, Clock clock, LoyaltyProperties properties) {
        this.cards = cards;
        this.lots = lots;
        this.engine = engine;
        this.perCard = new TransactionTemplate(transactionManager);
        this.perCard.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        this.clock = clock;
        this.batchSize = properties.expiration().batchSize();
    }

    public Summary run() {
        Instant now = clock.instant();
        int[] failures = {0};
        int benefits = process(page -> lots.findCardIdsWithDueLots(now, page),
                card -> engine.expireLots(card, now).signum() > 0, failures);
        int expired = process(page -> cards.findOverdueIds(now, page), card -> engine.expireCard(card, now), failures);
        if (expired + benefits + failures[0] > 0) {
            log.info("Expiração: {} cartão(ões) expirado(s), {} com benefícios vencidos, {} falha(s).", expired, benefits, failures[0]);
        }
        return new Summary(expired, benefits, failures[0]);
    }

    private int process(Function<Pageable, List<Long>> findIds, Function<LoyaltyCard, Boolean> action, int[] failures) {
        Set<Long> seen = new HashSet<>();
        int changed = 0;
        while (true) {
            List<Long> ids = findIds.apply(PageRequest.of(0, batchSize));
            List<Long> fresh = ids.stream().filter(seen::add).toList();
            if (fresh.isEmpty()) {
                return changed;
            }
            for (Long id : fresh) {
                try {
                    Boolean result = perCard.execute(status -> cards.lockById(id).map(action).orElse(false));
                    if (Boolean.TRUE.equals(result)) {
                        changed++;
                    }
                } catch (RuntimeException e) {
                    failures[0]++;
                    log.error("Falha ao processar expiração do cartão {}", id, e);
                }
            }
        }
    }
}
