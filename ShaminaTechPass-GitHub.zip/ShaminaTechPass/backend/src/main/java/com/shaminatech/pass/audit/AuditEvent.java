package com.shaminatech.pass.audit;

import java.time.Instant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

/**
 * Registro imutável de auditoria. Guarda apenas identificadores (sem FKs) para que o
 * histórico nunca impeça manutenção de outras tabelas. Nunca armazena senhas ou tokens.
 */
@Entity
@Table(name = "audit_event", indexes = {
        @Index(name = "idx_audit_event_establishment", columnList = "establishment_id, occurred_at"),
        @Index(name = "idx_audit_event_occurred", columnList = "occurred_at")})
public class AuditEvent {

    public static final int DETAILS_MAX = 1000;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "occurred_at", nullable = false, updatable = false)
    private Instant occurredAt;

    @Column(name = "actor_user_id", updatable = false)
    private Long actorUserId;

    @Column(name = "actor_email", length = 254, updatable = false)
    private String actorEmail;

    @Column(name = "establishment_id", updatable = false)
    private Long establishmentId;

    @Column(nullable = false, length = 60, updatable = false)
    private AuditAction action;

    @Column(name = "target_type", length = 40, updatable = false)
    private String targetType;

    @Column(name = "target_id", length = 64, updatable = false)
    private String targetId;

    @Column(length = DETAILS_MAX, updatable = false)
    private String details;

    @Column(name = "ip_address", length = 45, updatable = false)
    private String ipAddress;

    protected AuditEvent() {
    }

    public AuditEvent(AuditAction action, Long actorUserId, String actorEmail, Long establishmentId,
                      String targetType, String targetId, String details, String ipAddress) {
        this.occurredAt = Instant.now();
        this.action = action;
        this.actorUserId = actorUserId;
        this.actorEmail = actorEmail;
        this.establishmentId = establishmentId;
        this.targetType = targetType;
        this.targetId = targetId;
        this.details = details == null || details.length() <= DETAILS_MAX ? details : details.substring(0, DETAILS_MAX);
        this.ipAddress = ipAddress;
    }

    public Long getId() {
        return id;
    }

    public Instant getOccurredAt() {
        return occurredAt;
    }

    public Long getActorUserId() {
        return actorUserId;
    }

    public String getActorEmail() {
        return actorEmail;
    }

    public Long getEstablishmentId() {
        return establishmentId;
    }

    public AuditAction getAction() {
        return action;
    }

    public String getTargetType() {
        return targetType;
    }

    public String getTargetId() {
        return targetId;
    }

    public String getDetails() {
        return details;
    }

    public String getIpAddress() {
        return ipAddress;
    }
}
