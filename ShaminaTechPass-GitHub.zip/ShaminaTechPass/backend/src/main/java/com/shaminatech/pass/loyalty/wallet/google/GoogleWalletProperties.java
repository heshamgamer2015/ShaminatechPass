package com.shaminatech.pass.loyalty.wallet.google;

import java.time.Duration;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Configuração da integração Google Wallet. <b>Nenhum valor secreto fica aqui</b>: a chave da conta de serviço
 * é um arquivo JSON fora do repositório, indicado por {@code service-account-key-file}
 * (em application-credentials.yml, ignorado pelo Git, ou variável de ambiente GOOGLE_WALLET_KEY_FILE).
 *
 * @param enabled             liga a integração (padrão: desligada)
 * @param issuerId            ID do emissor no Google Pay & Wallet Console (numérico)
 * @param serviceAccountKeyFile caminho do JSON da conta de serviço
 * @param origins             origens autorizadas a exibir o botão "Adicionar ao Google Wallet" (claim origins do JWT)
 * @param publicBaseUrl       URL pública HTTPS do backend, usada para o Google buscar logotipos e imagens
 * @param fallbackLogoUri     logotipo público usado quando o programa não tem logotipo (ou não há URL pública)
 * @param countryCode         código do país dos programas (padrão BR)
 * @param apiBaseUrl          endereço da API (padrão oficial; substituído nos testes simulados)
 * @param tokenUri            endpoint OAuth (padrão: o do JSON da conta de serviço)
 * @param connectTimeout      tempo máximo para conectar
 * @param requestTimeout      tempo máximo de cada chamada
 * @param linkValidity        validade dos links de distribuição enviados ao consumidor
 * @param maxAttempts         tentativas automáticas antes de exigir reenvio manual
 * @param asyncDispatch       envia as sincronizações em segundo plano após o commit (desligado nos testes)
 */
@ConfigurationProperties(prefix = "shaminatech.wallet.google")
public record GoogleWalletProperties(Boolean enabled, String issuerId, String serviceAccountKeyFile, List<String> origins,
                                     String publicBaseUrl, String fallbackLogoUri, String countryCode, String apiBaseUrl,
                                     String tokenUri, Duration connectTimeout, Duration requestTimeout, Duration linkValidity,
                                     Integer maxAttempts, Boolean asyncDispatch) {

    public GoogleWalletProperties {
        enabled = enabled != null && enabled;
        issuerId = blankToNull(issuerId);
        serviceAccountKeyFile = blankToNull(serviceAccountKeyFile);
        origins = origins == null ? List.of() : origins.stream().filter(o -> o != null && !o.isBlank()).toList();
        publicBaseUrl = blankToNull(publicBaseUrl);
        fallbackLogoUri = blankToNull(fallbackLogoUri);
        countryCode = countryCode == null || countryCode.isBlank() ? "BR" : countryCode;
        apiBaseUrl = apiBaseUrl == null || apiBaseUrl.isBlank() ? "https://walletobjects.googleapis.com" : apiBaseUrl;
        tokenUri = blankToNull(tokenUri);
        connectTimeout = connectTimeout == null ? Duration.ofSeconds(5) : connectTimeout;
        requestTimeout = requestTimeout == null ? Duration.ofSeconds(15) : requestTimeout;
        linkValidity = linkValidity == null ? Duration.ofDays(3) : linkValidity;
        maxAttempts = maxAttempts == null ? 8 : maxAttempts;
        asyncDispatch = asyncDispatch == null || asyncDispatch;
    }

    /** Itens que faltam para a integração funcionar (vazio = configurada). */
    public List<String> missing() {
        var list = new java.util.ArrayList<String>();
        if (!enabled) {
            list.add("Integração desligada (shaminatech.wallet.google.enabled=false).");
        }
        if (issuerId == null) {
            list.add("ID do emissor do Google Pay & Wallet Console não configurado.");
        }
        if (serviceAccountKeyFile == null) {
            list.add("Arquivo da chave da conta de serviço não configurado.");
        }
        if (origins.isEmpty()) {
            list.add("Origens autorizadas do botão Adicionar ao Google Wallet não configuradas.");
        }
        if (publicBaseUrl == null && fallbackLogoUri == null) {
            list.add("Sem URL pública para imagens: o Google exige logotipo acessível pela internet.");
        }
        return list;
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
