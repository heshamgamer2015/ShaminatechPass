package com.shaminatech.pass.user;

import com.shaminatech.pass.common.persistence.EnumNameConverter;

import jakarta.persistence.Converter;

/** Papel global na plataforma. Usuários de estabelecimentos não possuem papel de plataforma (null). */
public enum PlatformRole {
    PLATFORM_ADMIN;

    @Converter(autoApply = true)
    public static class JpaConverter extends EnumNameConverter<PlatformRole> {
        public JpaConverter() {
            super(PlatformRole.class);
        }
    }
}
