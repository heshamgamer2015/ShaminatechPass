package com.shaminatech.pass.loyalty.program;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface LoyaltyRewardRepository extends JpaRepository<LoyaltyReward, Long> {

    @Query("select r from LoyaltyReward r where r.id = :id and r.establishmentId = :establishmentId")
    Optional<LoyaltyReward> findInEstablishment(@Param("establishmentId") Long establishmentId, @Param("id") Long id);

    @Query("select r from LoyaltyReward r where r.program.id = :programId and r.establishmentId = :establishmentId order by r.active desc, r.cost")
    List<LoyaltyReward> findByProgram(@Param("establishmentId") Long establishmentId, @Param("programId") Long programId);

    @Query("select r from LoyaltyReward r join fetch r.program where r.establishmentId = :establishmentId order by r.program.name, r.cost")
    List<LoyaltyReward> findAllInEstablishment(@Param("establishmentId") Long establishmentId);
}
