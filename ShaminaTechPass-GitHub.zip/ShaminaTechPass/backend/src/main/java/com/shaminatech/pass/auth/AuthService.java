package com.shaminatech.pass.auth;

import java.time.Clock;
import java.time.Instant;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.auth.AuthDtos.MeResponse;
import com.shaminatech.pass.auth.AuthDtos.MembershipSummary;
import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.membership.MembershipRepository;
import com.shaminatech.pass.security.AuthenticatedUser;
import com.shaminatech.pass.security.SecurityProperties;
import com.shaminatech.pass.user.AppUser;
import com.shaminatech.pass.user.AppUserRepository;
import com.shaminatech.pass.user.EmailNormalizer;

@Service
public class AuthService {

    /** Mesma mensagem para e-mail inexistente, senha errada, conta bloqueada ou desativada (evita enumeração). */
    static final String INVALID_CREDENTIALS = "E-mail ou senha inválidos.";

    private final AuthenticationManager authenticationManager;
    private final AppUserRepository users;
    private final MembershipRepository memberships;
    private final PasswordEncoder passwordEncoder;
    private final AuditService audit;
    private final SecurityProperties securityProperties;
    private final Clock clock;

    public AuthService(AuthenticationManager authenticationManager, AppUserRepository users, MembershipRepository memberships,
                       PasswordEncoder passwordEncoder, AuditService audit, SecurityProperties securityProperties, Clock clock) {
        this.authenticationManager = authenticationManager;
        this.users = users;
        this.memberships = memberships;
        this.passwordEncoder = passwordEncoder;
        this.audit = audit;
        this.securityProperties = securityProperties;
        this.clock = clock;
    }

    /**
     * Valida as credenciais e aplica o bloqueio temporário após falhas consecutivas.
     * {@code noRollbackFor}: a contagem de falhas precisa ser gravada mesmo quando o login é recusado.
     */
    @Transactional(noRollbackFor = ApiException.class)
    public AuthenticatedUser authenticate(String rawEmail, String password) {
        String email = EmailNormalizer.normalize(rawEmail);
        Instant now = clock.instant();
        Optional<AppUser> user = users.findByEmail(email);

        if (user.isPresent() && user.get().isLocked(now)) {
            audit.recordAs(user.get().getId(), email, AuditAction.LOGIN_BLOCKED, null, "USER", user.get().getId(),
                    "Tentativa durante bloqueio temporário");
            throw invalidCredentials();
        }
        try {
            var authentication = authenticationManager.authenticate(
                    UsernamePasswordAuthenticationToken.unauthenticated(email, password));
            AppUser account = user.orElseThrow();
            account.registerSuccessfulLogin(now);
            audit.recordAs(account.getId(), email, AuditAction.LOGIN_SUCCEEDED, null, "USER", account.getId(), null);
            return (AuthenticatedUser) authentication.getPrincipal();
        } catch (AuthenticationException ex) {
            if (user.isPresent()) {
                AppUser account = user.get();
                boolean locked = account.registerFailedLogin(securityProperties.maxFailedLogins(),
                        now.plus(securityProperties.lockDuration()));
                audit.recordAs(account.getId(), email, AuditAction.LOGIN_FAILED, null, "USER", account.getId(),
                        locked ? "Conta bloqueada temporariamente após falhas consecutivas" : null);
            } else {
                audit.recordAs(null, email, AuditAction.LOGIN_FAILED, null, null, null, "E-mail não cadastrado");
            }
            throw invalidCredentials();
        }
    }

    @Transactional(readOnly = true)
    public MeResponse me(Long userId) {
        AppUser user = users.findById(userId).orElseThrow(() -> ApiException.notFound("Usuário não encontrado."));
        var summaries = memberships.findActiveBusinessAccountsByUser(userId).stream()
                .map(m -> new MembershipSummary(m.getEstablishment().getId(), m.getEstablishment().getName(),
                        m.getEstablishment().getSlug(), m.getEstablishment().getStatus(), m.getRole()))
                .toList();
        return new MeResponse(user.getId(), user.getEmail(), user.getFullName(), user.getPlatformRole(),
                user.isPasswordChangeRequired(), summaries);
    }

    @Transactional
    public void changePassword(Long userId, String currentPassword, String newPassword) {
        AppUser user = users.findById(userId).orElseThrow(() -> ApiException.notFound("Usuário não encontrado."));
        if (!passwordEncoder.matches(currentPassword, user.getPasswordHash())) {
            throw ApiException.badRequest("Senha atual incorreta.", "currentPassword");
        }
        if (currentPassword.equals(newPassword)) {
            throw ApiException.badRequest("A nova senha deve ser diferente da atual.", "newPassword");
        }
        user.changePassword(passwordEncoder.encode(newPassword), false);
        audit.recordAs(user.getId(), user.getEmail(), AuditAction.PASSWORD_CHANGED, null, "USER", user.getId(), null);
    }

    /** Principal atualizado (nova marca de credencial) para a sessão que acabou de trocar a senha. */
    @Transactional(readOnly = true)
    public AuthenticatedUser principalOf(Long userId) {
        AppUser user = users.findById(userId).orElseThrow(() -> ApiException.notFound("Usuário não encontrado."));
        AuthenticatedUser principal = AuthenticatedUser.from(user, clock.instant());
        principal.eraseCredentials();
        return principal;
    }

    private static ApiException invalidCredentials() {
        return new ApiException(HttpStatus.UNAUTHORIZED, "INVALID_CREDENTIALS", INVALID_CREDENTIALS);
    }
}
