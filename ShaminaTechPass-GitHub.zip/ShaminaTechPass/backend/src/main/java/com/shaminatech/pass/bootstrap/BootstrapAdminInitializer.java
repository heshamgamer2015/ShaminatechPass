package com.shaminatech.pass.bootstrap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.security.PasswordPolicy;
import com.shaminatech.pass.user.AppUser;
import com.shaminatech.pass.user.AppUserRepository;
import com.shaminatech.pass.user.EmailNormalizer;
import com.shaminatech.pass.user.PlatformRole;

/**
 * Cria o primeiro administrador da plataforma a partir de shaminatech.bootstrap.admin.*,
 * somente se ainda não existir nenhum administrador. Nunca altera contas existentes.
 * O administrador criado precisa trocar a senha no primeiro acesso.
 */
@Component
@Order(2)
public class BootstrapAdminInitializer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(BootstrapAdminInitializer.class);

    private final BootstrapAdminProperties properties;
    private final AppUserRepository users;
    private final PasswordEncoder passwordEncoder;
    private final AuditService audit;

    public BootstrapAdminInitializer(BootstrapAdminProperties properties, AppUserRepository users,
                                     PasswordEncoder passwordEncoder, AuditService audit) {
        this.properties = properties;
        this.users = users;
        this.passwordEncoder = passwordEncoder;
        this.audit = audit;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        if (users.existsByPlatformRole(PlatformRole.PLATFORM_ADMIN)) {
            return;
        }
        if (!properties.isConfigured()) {
            log.warn("Nenhum administrador da plataforma cadastrado. Defina shaminatech.bootstrap.admin.email/password "
                    + "em application-credentials.yml para criar o primeiro.");
            return;
        }
        var violation = PasswordPolicy.violation(properties.password());
        if (violation.isPresent()) {
            log.error("Senha do administrador inicial recusada: {}", violation.get());
            return;
        }
        String email = EmailNormalizer.normalize(properties.email());
        if (users.findByEmail(email).isPresent()) {
            log.error("O e-mail do administrador inicial já pertence a outra conta; nada foi alterado.");
            return;
        }
        String name = properties.name() == null || properties.name().isBlank() ? "Administrador ShaminaTech" : properties.name();
        AppUser admin = new AppUser(email, name, passwordEncoder.encode(properties.password()), true);
        admin.setPlatformRole(PlatformRole.PLATFORM_ADMIN);
        admin = users.save(admin);
        audit.recordAs(null, null, AuditAction.PLATFORM_ADMIN_BOOTSTRAPPED, null, "USER", admin.getId(), null);
        log.info("Administrador inicial da plataforma criado (troca de senha obrigatória no primeiro acesso).");
    }
}
