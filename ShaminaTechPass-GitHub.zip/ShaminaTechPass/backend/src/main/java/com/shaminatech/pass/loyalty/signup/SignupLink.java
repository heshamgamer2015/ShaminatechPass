package com.shaminatech.pass.loyalty.signup;

import java.time.Instant;

import com.shaminatech.pass.common.persistence.BaseEntity;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Link público de cadastro de um programa (conteúdo do QR Code do balcão). Reutilizável por qualquer consumidor.
 * <p>
 * O token (128 bits aleatórios) é o único identificador na URL — ids internos nunca aparecem. Ele fica gravado em
 * texto porque a empresa precisa baixar e imprimir o QR Code de novo; não é segredo (fica impresso no balcão) e não dá
 * acesso a nenhum cartão. "Gerar novo código" troca o token e invalida o QR Code anterior. Um link por programa.
 */
@Entity
@Table(name = "public_signup_link",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_public_signup_link_token", columnNames = "token"),
                @UniqueConstraint(name = "uk_public_signup_link_program", columnNames = "program_id")},
        indexes = @Index(name = "idx_public_signup_link_establishment", columnList = "establishment_id"))
public class SignupLink extends BaseEntity {

    @Column(name = "establishment_id", nullable = false, updatable = false)
    private Long establishmentId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "program_id", nullable = false, updatable = false,
            foreignKey = @ForeignKey(name = "fk_public_signup_link_program"))
    private LoyaltyProgram program;

    @Column(nullable = false, length = 32)
    private String token;

    @Column(nullable = false)
    private boolean active = true;

    @Column(name = "status_changed_at")
    private Instant statusChangedAt;

    @Column(name = "token_created_at", nullable = false)
    private Instant tokenCreatedAt;

    @Column(name = "created_by")
    private Long createdBy;

    protected SignupLink() {
    }

    public SignupLink(LoyaltyProgram program, String token, Instant now, Long createdBy) {
        this.establishmentId = program.getEstablishmentId();
        this.program = program;
        this.token = token;
        this.tokenCreatedAt = now;
        this.createdBy = createdBy;
    }

    public void changeActive(boolean active, Instant now) {
        this.active = active;
        this.statusChangedAt = now;
    }

    public void replaceToken(String token, Instant now) {
        this.token = token;
        this.tokenCreatedAt = now;
    }

    public Long getEstablishmentId() { return establishmentId; }
    public LoyaltyProgram getProgram() { return program; }
    public String getToken() { return token; }
    public boolean isActive() { return active; }
    public Instant getStatusChangedAt() { return statusChangedAt; }
    public Instant getTokenCreatedAt() { return tokenCreatedAt; }
}
