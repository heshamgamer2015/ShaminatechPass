package com.shaminatech.pass.loyalty.wallet.apple;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Cliente do Apple Push Notification service para passes: HTTP/2 com TLS autenticado pelo próprio certificado
 * Pass Type ID, tópico = Pass Type ID e corpo JSON vazio ({@code {}}). A notificação só avisa o aparelho de que há
 * uma versão nova; o Wallet então busca o passe no web service. O push token nunca é registrado em log.
 */
public class ApnsClient {

    private static final Logger log = LoggerFactory.getLogger(ApnsClient.class);

    /** Resultado de uma notificação. {@code unregistered}: o aparelho não aceita mais (remover o registro). */
    public record Result(int status, boolean ok, boolean unregistered, boolean retryable, String reason) {
    }

    private final HttpClient http;
    private final AppleWalletProperties properties;

    public ApnsClient(AppleWalletProperties properties, AppleCredentials credentials) {
        this.properties = properties;
        try {
            KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(credentials.keyStore(), credentials.password());
            SSLContext ssl = SSLContext.getInstance("TLS");
            ssl.init(kmf.getKeyManagers(), null, null);
            this.http = HttpClient.newBuilder().version(HttpClient.Version.HTTP_2).sslContext(ssl)
                    .connectTimeout(properties.connectTimeout()).build();
        } catch (Exception e) {
            throw new AppleWalletException(0, "Não foi possível preparar a conexão segura com o APNs.", false);
        }
    }

    public Result notify(String pushToken) {
        HttpRequest request = HttpRequest.newBuilder(URI.create(properties.apnsBaseUrl() + "/3/device/" + pushToken))
                .timeout(properties.requestTimeout())
                .header("apns-topic", properties.passTypeIdentifier())
                .header("content-type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString("{}", StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response;
        try {
            response = http.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (HttpTimeoutException e) {
            return new Result(0, false, false, true, "Tempo esgotado ao notificar o aparelho.");
        } catch (IOException e) {
            return new Result(0, false, false, true, "Falha de comunicação com o APNs.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return new Result(0, false, false, true, "Notificação interrompida.");
        }
        int status = response.statusCode();
        if (status == 200) {
            return new Result(status, true, false, false, null);
        }
        String reason = reason(response.body());
        boolean unregistered = status == 410 || (status == 400 && ("BadDeviceToken".equals(reason) || "DeviceTokenNotForTopic".equals(reason)));
        boolean retryable = status == 429 || status >= 500;
        log.warn("APNs respondeu {} ({}) ao notificar um passe Apple Wallet", status, reason);
        return new Result(status, false, unregistered, retryable, "APNs " + status + (reason == null ? "" : ": " + reason));
    }

    /** Corpo de erro do APNs: {"reason":"..."}. */
    static String reason(String body) {
        if (body == null) {
            return null;
        }
        int i = body.indexOf("\"reason\"");
        if (i < 0) {
            return null;
        }
        int start = body.indexOf('"', body.indexOf(':', i) + 1);
        int end = start < 0 ? -1 : body.indexOf('"', start + 1);
        return start < 0 || end < 0 ? null : body.substring(start + 1, Math.min(end, start + 1 + 60));
    }
}
