package com.shaminatech.pass.loyalty.notify;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.BenefitLot;
import com.shaminatech.pass.loyalty.card.BenefitLotRepository;
import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.LoyaltyReward;
import com.shaminatech.pass.loyalty.program.LoyaltyRewardRepository;

/** Monta a fotografia de um cartão para as regras de lembrete (saldo disponível = benefícios válidos agora). */
@Component
class ReminderSnapshots {

    private final BenefitLotRepository lots;
    private final LoyaltyRewardRepository rewards;

    ReminderSnapshots(BenefitLotRepository lots, LoyaltyRewardRepository rewards) {
        this.lots = lots;
        this.rewards = rewards;
    }

    /** Recompensa ativa mais barata de cada programa de pontos do estabelecimento. */
    Map<Long, LoyaltyReward> cheapestRewards(Long establishmentId) {
        Map<Long, LoyaltyReward> result = new HashMap<>();
        for (LoyaltyReward r : rewards.findAllInEstablishment(establishmentId)) {
            if (!r.isActive()) {
                continue;
            }
            result.merge(r.getProgram().getId(), r, (a, b) -> Comparator.comparing(LoyaltyReward::getCost).compare(a, b) <= 0 ? a : b);
        }
        return result;
    }

    ReminderRules.CardSnapshot of(LoyaltyCard card, Map<Long, LoyaltyReward> cheapest, Instant now) {
        LoyaltyProgram program = card.getProgram();
        BigDecimal available = lots.findOpenByCard(card.getId()).stream().filter(l -> l.isUsable(now)).map(BenefitLot::getRemaining)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        LoyaltyReward reward = program.getType() == ProgramType.POINTS ? cheapest.get(program.getId()) : null;
        return new ReminderRules.CardSnapshot(card.getId(), card.effectiveStatus(now), program.getType(), program.getName(),
                program.getEstablishment().getName(), available, program.getStampsRequired(), program.getStampReward(),
                card.getCompletedCycles(), card.getExpiresAt(), card.getLastMovementAt(), card.getIssuedAt(),
                card.getConsumer().isActive(), card.getConsumer().isMarketingOptIn(), reward == null ? null : reward.getCost(),
                reward == null ? null : reward.getName());
    }
}
