package com.shaminatech.pass.loyalty.notify;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * Agenda o planejamento e o envio de lembretes. Desligável com {@code shaminatech.notifications.scheduler.enabled=false}
 * (os testes chamam o planejador e o envio diretamente, com relógio controlado). Execuções repetidas são seguras: a
 * chave de situação, o intervalo mínimo e a reserva com prazo impedem duplicidade.
 */
@Configuration
@EnableScheduling
@ConditionalOnProperty(prefix = "shaminatech.notifications.scheduler", name = "enabled", havingValue = "true", matchIfMissing = true)
public class ReminderScheduler {

    private final ReminderPlanner planner;
    private final ReminderSender sender;

    public ReminderScheduler(ReminderPlanner planner, ReminderSender sender) {
        this.planner = planner;
        this.sender = sender;
    }

    @Scheduled(initialDelayString = "${shaminatech.notifications.scheduler.initial-delay:PT2M}",
            fixedDelayString = "${shaminatech.notifications.scheduler.interval:PT15M}")
    public void run() {
        planner.planAll();
        sender.dispatchDue();
    }
}
