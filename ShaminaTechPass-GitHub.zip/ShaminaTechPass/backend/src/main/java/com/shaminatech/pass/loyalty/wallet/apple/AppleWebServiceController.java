package com.shaminatech.pass.loyalty.wallet.apple;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Web service oficial do Apple Wallet (chamado pelo próprio iPhone; base = webServiceURL do passe):
 * <ul>
 *   <li>POST/DELETE {@code /v1/devices/{device}/registrations/{passType}/{serial}}: registra/remove o aparelho;</li>
 *   <li>GET {@code /v1/devices/{device}/registrations/{passType}?passesUpdatedSince=}: seriais alterados;</li>
 *   <li>GET {@code /v1/passes/{passType}/{serial}}: versão atual do passe (304 se não mudou);</li>
 *   <li>POST {@code /v1/log}: mensagens de erro do aparelho.</li>
 * </ul>
 * Autenticação: {@code Authorization: ApplePass <token>} do próprio passe (401 se não confere). Nenhuma resposta
 * revela se um serial existe para quem não tem o token. Limite por IP em {@code /api/public/**}.
 */
@RestController
@RequestMapping(AppleWalletProperties.WEB_SERVICE_PATH + "/v1")
public class AppleWebServiceController {

    private static final Logger log = LoggerFactory.getLogger(AppleWebServiceController.class);
    private static final String DEVICE = "[A-Za-z0-9._-]{1,128}";
    private static final String SERIAL = "[A-Za-z0-9._-]{1,100}";
    private static final String PUSH_TOKEN = "[A-Fa-f0-9]{16,200}";

    private final AppleWebService service;
    private final ApplePassService passes;
    private final AppleWalletGateway gateway;

    public AppleWebServiceController(AppleWebService service, ApplePassService passes, AppleWalletGateway gateway) {
        this.service = service;
        this.passes = passes;
        this.gateway = gateway;
    }

    @PostMapping("/devices/{device}/registrations/{passType}/{serial}")
    public ResponseEntity<Void> register(@PathVariable String device, @PathVariable String passType, @PathVariable String serial,
                                         @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authorization,
                                         @RequestBody(required = false) Map<String, Object> body) {
        if (!valid(device, passType, serial) || !gateway.authorized(serial, authorization)) {
            return unauthorized();
        }
        Object token = body == null ? null : body.get("pushToken");
        if (!(token instanceof String pushToken) || !pushToken.matches(PUSH_TOKEN)) {
            return ResponseEntity.badRequest().build();
        }
        return switch (service.register(device, serial, pushToken)) {
            case CREATED -> ResponseEntity.status(HttpStatus.CREATED).build();
            case UPDATED -> ResponseEntity.ok().build();
            case LIMIT -> ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
            case NOT_FOUND -> unauthorized();
        };
    }

    @DeleteMapping("/devices/{device}/registrations/{passType}/{serial}")
    public ResponseEntity<Void> unregister(@PathVariable String device, @PathVariable String passType, @PathVariable String serial,
                                           @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authorization) {
        if (!valid(device, passType, serial) || !gateway.authorized(serial, authorization)) {
            return unauthorized();
        }
        service.unregister(device, serial);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/devices/{device}/registrations/{passType}")
    public ResponseEntity<Map<String, Object>> updatedPasses(@PathVariable String device, @PathVariable String passType,
                                                             @RequestParam(required = false) String passesUpdatedSince) {
        if (!gateway.configured() || !device.matches(DEVICE) || !gateway.properties().passTypeIdentifier().equals(passType)) {
            return ResponseEntity.notFound().build();
        }
        Instant since = Instant.EPOCH;
        if (passesUpdatedSince != null && !passesUpdatedSince.isBlank()) {
            if (!passesUpdatedSince.matches("\\d{1,12}")) {
                return ResponseEntity.badRequest().build();
            }
            since = Instant.ofEpochSecond(Long.parseLong(passesUpdatedSince));
        }
        AppleWebService.Updated updated = service.updatedSerials(device, since);
        if (updated.serials().isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok().cacheControl(CacheControl.noStore())
                .body(Map.of("serialNumbers", updated.serials(), "lastUpdated", Long.toString(updated.lastUpdated().getEpochSecond())));
    }

    @GetMapping("/passes/{passType}/{serial}")
    public ResponseEntity<byte[]> latest(@PathVariable String passType, @PathVariable String serial,
                                         @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authorization,
                                         @RequestHeader(value = HttpHeaders.IF_MODIFIED_SINCE, required = false) String ifModifiedSince) {
        if (!valid("x", passType, serial) || !gateway.authorized(serial, authorization)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        Instant modified = passes.lastModified(serial);
        if (modified == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        Instant since = parseHttpDate(ifModifiedSince);
        if (since != null && !modified.isAfter(since)) {
            return ResponseEntity.status(HttpStatus.NOT_MODIFIED).lastModified(modified).build();
        }
        ApplePassService.Pkpass pkpass = passes.bySerial(serial).orElse(null);
        if (pkpass == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(PkpassBuilder.CONTENT_TYPE))
                .lastModified(pkpass.lastModified())
                .cacheControl(CacheControl.noCache())
                .body(pkpass.data());
    }

    @PostMapping("/log")
    public ResponseEntity<Void> logMessages(@RequestBody(required = false) Map<String, Object> body) {
        if (body != null && body.get("logs") instanceof List<?> logs) {
            logs.stream().limit(10).forEach(m -> log.info("Apple Wallet (aparelho): {}",
                    String.valueOf(m).replaceAll("[\\r\\n]", " ").substring(0, Math.min(300, String.valueOf(m).length()))));
        }
        return ResponseEntity.ok().build();
    }

    private boolean valid(String device, String passType, String serial) {
        return gateway.configured() && device.matches(DEVICE) && serial.matches(SERIAL)
                && gateway.properties().passTypeIdentifier().equals(passType);
    }

    private static ResponseEntity<Void> unauthorized() {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    private static Instant parseHttpDate(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return ZonedDateTime.parse(value.trim(), DateTimeFormatter.RFC_1123_DATE_TIME).toInstant();
        } catch (Exception e) {
            return null;
        }
    }
}
