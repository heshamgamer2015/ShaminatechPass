package com.shaminatech.pass.membership;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Garante que o catálogo de permissões exista no banco. Apenas INSERE permissões novas
 * (com seus papéis padrão); nunca altera ou remove concessões existentes, preservando
 * qualquer ajuste feito manualmente.
 */
@Component
@Order(1)
public class PermissionCatalogInitializer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(PermissionCatalogInitializer.class);

    private final PermissionRepository permissions;
    private final RolePermissionRepository rolePermissions;

    public PermissionCatalogInitializer(PermissionRepository permissions, RolePermissionRepository rolePermissions) {
        this.permissions = permissions;
        this.rolePermissions = rolePermissions;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        for (Permission permission : Permission.values()) {
            if (permissions.existsById(permission.name())) {
                continue;
            }
            PermissionEntity entity = permissions.save(new PermissionEntity(permission.name(), permission.description()));
            for (MembershipRole role : permission.defaultRoles()) {
                rolePermissions.save(new RolePermission(role, entity));
            }
            log.info("Permissão cadastrada: {} -> {}", permission, permission.defaultRoles());
        }
    }
}
