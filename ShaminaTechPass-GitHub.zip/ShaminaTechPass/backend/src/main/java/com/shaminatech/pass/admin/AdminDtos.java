package com.shaminatech.pass.admin;

import java.time.Instant;
import java.util.Map;
import java.util.Set;

import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.establishment.EstablishmentStatus;
import com.shaminatech.pass.loyalty.LoyaltyDtos.PolicyView;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.membership.MemberResponse;
import com.shaminatech.pass.security.StrongPassword;
import com.shaminatech.pass.user.AppUser;
import com.shaminatech.pass.user.PlatformRole;
import com.shaminatech.pass.user.UserStatus;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public final class AdminDtos {

    private AdminDtos() {
    }

    public record OwnerRequest(
            @NotBlank(message = "Informe o e-mail de acesso da empresa.") @Email(message = "E-mail inválido.") @Size(max = 254) String email,
            @NotBlank(message = "Informe o nome do responsável.") @Size(max = 150, message = "Máximo de 150 caracteres.") String fullName,
            @StrongPassword String temporaryPassword) {
    }

    public record CreateEstablishmentRequest(
            @NotBlank(message = "Informe o nome.") @Size(max = 150, message = "Máximo de 150 caracteres.") String name,
            @NotBlank(message = "Informe o identificador.") @Size(min = 3, max = 80, message = "Entre 3 e 80 caracteres.")
            @Pattern(regexp = "^[a-z0-9]+(-[a-z0-9]+)*$", message = "Use apenas letras minúsculas, números e hífens.") String slug,
            @Email(message = "E-mail inválido.") @Size(max = 254) String contactEmail,
            @Size(max = 30, message = "Máximo de 30 caracteres.")
            @Pattern(regexp = "^[0-9+()\\-\\s]*$", message = "Telefone inválido.") String contactPhone,
            @NotNull(message = "Informe a conta de acesso da empresa.") @Valid OwnerRequest owner) {
    }

    public record ChangeEstablishmentStatusRequest(@NotNull(message = "Informe a situação.") EstablishmentStatus status) {
    }

    public record ChangeUserStatusRequest(@NotNull(message = "Informe a situação.") UserStatus status) {
    }

    /** Utilização (somente contagens: nenhum dado pessoal de consumidores é exposto à plataforma). */
    public record Usage(long activeConsumers, long totalConsumers, int maxActiveConsumers, long activeCards, long totalCards) {
    }

    /** {@code plan}: plano escolhido (null = estabelecimento com limites definidos pela ShaminaTech). */
    public record EstablishmentSummary(Long id, String name, String slug, EstablishmentStatus status,
                                       String contactEmail, Instant createdAt, Usage usage,
                                       com.shaminatech.pass.plan.PlanService.PlanBadge plan) {
        public static EstablishmentSummary from(Establishment e, Usage usage, com.shaminatech.pass.plan.PlanService.PlanBadge plan) {
            return new EstablishmentSummary(e.getId(), e.getName(), e.getSlug(), e.getStatus(), e.getContactEmail(),
                    e.getCreatedAt(), usage, plan);
        }
    }

    /** {@code account}: a conta empresarial ativa (única); nulo se o estabelecimento ainda não tiver uma. */
    public record EstablishmentDetail(Long id, String name, String slug, EstablishmentStatus status, String contactEmail,
                                      String contactPhone, Instant createdAt, Instant updatedAt, MemberResponse account,
                                      PolicyView policy, Usage usage, Map<ProgramType, Long> programsByType,
                                      com.shaminatech.pass.plan.PlanService.PlanBadge plan) {
    }

    public record PolicyRequest(
            @NotNull(message = "Informe o limite de clientes.") @Min(value = 0, message = "Mínimo de 0.")
            @Max(value = 1_000_000, message = "Máximo de 1.000.000.") Integer maxActiveConsumers,
            @NotNull(message = "Informe os tipos permitidos.") Set<ProgramType> allowedProgramTypes,
            @NotNull(message = "Informe o prazo de inatividade.") @Min(value = 1, message = "Mínimo de 1 dia.")
            @Max(value = 3650, message = "Máximo de 3650 dias.") Integer defaultInactivityDays,
            @NotBlank(message = "Informe o fuso horário.") @Size(max = 60) String timeZone) {
    }

    public record ResetPasswordRequest(@NotBlank(message = "Informe a senha temporária.") @StrongPassword String temporaryPassword) {
    }

    public record UserSummary(Long id, String email, String fullName, PlatformRole platformRole, UserStatus status,
                              boolean locked, Instant lastLoginAt, Instant createdAt) {
        public static UserSummary from(AppUser u, Instant now) {
            return new UserSummary(u.getId(), u.getEmail(), u.getFullName(), u.getPlatformRole(), u.getStatus(),
                    u.isLocked(now), u.getLastLoginAt(), u.getCreatedAt());
        }
    }
}
