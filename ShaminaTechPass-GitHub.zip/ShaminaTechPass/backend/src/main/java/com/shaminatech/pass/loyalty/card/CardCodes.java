package com.shaminatech.pass.loyalty.card;

import java.security.SecureRandom;
import java.util.Locale;

/**
 * Identificador público do cartão: 16 caracteres do alfabeto Crockford Base32 (80 bits aleatórios via
 * SecureRandom). É o conteúdo do QR Code / código de barras. Conhecer o código não autoriza nada:
 * toda operação exige a sessão autenticada da conta empresarial do mesmo estabelecimento.
 */
public final class CardCodes {

    private static final char[] ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ".toCharArray();
    private static final SecureRandom RANDOM = new SecureRandom();
    public static final int LENGTH = 16;

    private CardCodes() {
    }

    public static String generate() {
        char[] out = new char[LENGTH];
        for (int i = 0; i < LENGTH; i++) {
            out[i] = ALPHABET[RANDOM.nextInt(ALPHABET.length)];
        }
        return new String(out);
    }

    /** Normaliza o que foi lido/digitado: maiúsculas, sem espaços/hífens, O→0, I/L→1. Nulo se inválido. */
    public static String normalize(String raw) {
        if (raw == null) {
            return null;
        }
        String value = raw.trim().toUpperCase(Locale.ROOT).replaceAll("[\\s-]", "")
                .replace('O', '0').replace('I', '1').replace('L', '1');
        if (value.length() != LENGTH) {
            return null;
        }
        for (char c : value.toCharArray()) {
            if (new String(ALPHABET).indexOf(c) < 0) {
                return null;
            }
        }
        return value;
    }

    /** Formato de exibição: XXXX-XXXX-XXXX-XXXX. */
    public static String format(String code) {
        return code.substring(0, 4) + "-" + code.substring(4, 8) + "-" + code.substring(8, 12) + "-" + code.substring(12);
    }
}
