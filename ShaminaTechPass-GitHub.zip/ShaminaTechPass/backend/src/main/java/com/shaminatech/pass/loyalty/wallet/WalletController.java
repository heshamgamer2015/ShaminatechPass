package com.shaminatech.pass.loyalty.wallet;

import org.springframework.data.domain.Sort;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.common.web.PageResponse;
import com.shaminatech.pass.common.web.Paging;
import com.shaminatech.pass.loyalty.branding.StoredImage;
import com.shaminatech.pass.loyalty.branding.StoredImageRepository;
import com.shaminatech.pass.loyalty.wallet.WalletPass.SyncStatus;
import com.shaminatech.pass.loyalty.wallet.apple.ApplePassService;
import com.shaminatech.pass.loyalty.wallet.apple.AppleWalletException;
import com.shaminatech.pass.loyalty.wallet.apple.PkpassBuilder;

/** Endpoints de carteira digital: painel (autenticado, por tenant) e público (link do consumidor e imagens para o Google). */
@RestController
public class WalletController {

    private final WalletService wallet;
    private final StoredImageRepository images;
    private final ApplePassService applePasses;

    public WalletController(WalletService wallet, StoredImageRepository images, ApplePassService applePasses) {
        this.wallet = wallet;
        this.images = images;
        this.applePasses = applePasses;
    }

    // ---------------- Painel do estabelecimento ----------------

    @GetMapping("/api/establishments/{establishmentId}/wallet")
    public WalletService.IntegrationStatus status(@PathVariable Long establishmentId) {
        return wallet.status(establishmentId);
    }

    @GetMapping("/api/establishments/{establishmentId}/wallet/passes")
    public PageResponse<WalletService.PassView> passes(@PathVariable Long establishmentId,
                                                       @RequestParam(required = false) SyncStatus status,
                                                       @RequestParam(defaultValue = "0") int page,
                                                       @RequestParam(defaultValue = "20") int size) {
        return wallet.list(establishmentId, status, Paging.of(page, size, Sort.by(Sort.Direction.DESC, "updatedAt", "id")));
    }

    @GetMapping("/api/establishments/{establishmentId}/cards/{cardId}/wallet")
    public WalletService.CardWallet cardWallet(@PathVariable Long establishmentId, @PathVariable Long cardId) {
        return wallet.cardWallet(establishmentId, cardId);
    }

    /** Link de distribuição para as carteiras configuradas (Google e/ou Apple). O caminho "google" é mantido da Etapa 3. */
    @PostMapping({"/api/establishments/{establishmentId}/cards/{cardId}/wallet/links",
            "/api/establishments/{establishmentId}/cards/{cardId}/wallet/google/links"})
    public ResponseEntity<WalletService.CreatedLink> createLink(@PathVariable Long establishmentId, @PathVariable Long cardId) {
        return ResponseEntity.status(HttpStatus.CREATED).cacheControl(CacheControl.noStore())
                .body(wallet.createLink(establishmentId, cardId));
    }

    @PostMapping("/api/establishments/{establishmentId}/wallet/passes/{passId}/retry")
    public WalletService.CardWallet retry(@PathVariable Long establishmentId, @PathVariable Long passId) {
        return wallet.retry(establishmentId, passId);
    }

    @PostMapping("/api/establishments/{establishmentId}/wallet/links/{linkId}/revoke")
    public WalletService.CardWallet revoke(@PathVariable Long establishmentId, @PathVariable Long linkId) {
        return wallet.revokeLink(establishmentId, linkId);
    }

    // ---------------- Público ----------------

    @GetMapping("/api/public/wallet-links/{token}")
    public ResponseEntity<WalletService.PublicPass> openLink(@PathVariable String token) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).header("Referrer-Policy", "no-referrer")
                .body(wallet.openLink(token));
    }

    /** Cartão Apple Wallet (.pkpass) a partir do link do consumidor. O Safari do iPhone abre direto a tela "Adicionar". */
    @GetMapping("/api/public/wallet-links/{token}/apple")
    public ResponseEntity<byte[]> applePass(@PathVariable String token) {
        Long passId = wallet.appleDownload(token);
        ApplePassService.Pkpass pkpass;
        try {
            pkpass = applePasses.build(passId);
        } catch (AppleWalletException e) {
            throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE, "APPLE_WALLET_UNAVAILABLE",
                    "Não foi possível gerar o cartão Apple Wallet agora. Tente novamente em instantes.");
        }
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(PkpassBuilder.CONTENT_TYPE))
                .header("Content-Disposition", "attachment; filename=\"cartao-fidelidade.pkpass\"")
                .header("X-Content-Type-Options", "nosniff")
                .header("Referrer-Policy", "no-referrer")
                .cacheControl(CacheControl.noStore())
                .lastModified(pkpass.lastModified())
                .body(pkpass.data());
    }

    /** Imagem pública (logotipo/destaque) buscada pelo Google Wallet. Só existe com o token aleatório da imagem. */
    /**
     * QR Code (SVG) do link do cartão: o cliente escaneia com o celular em que quer guardar o cartão (no balcão, na
     * troca de aparelho, ou quando abriu o link no computador). Só existe para link válido.
     */
    @GetMapping("/api/public/wallet-links/{token}/qr")
    public ResponseEntity<byte[]> linkQr(@PathVariable String token) {
        String url = wallet.publicLinkUrl(token);
        return ResponseEntity.ok().contentType(MediaType.parseMediaType("image/svg+xml"))
                .cacheControl(CacheControl.noStore())
                .header("X-Content-Type-Options", "nosniff")
                .header("Referrer-Policy", "no-referrer")
                .body(com.shaminatech.pass.loyalty.signup.QrCodes.svg(url).getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    @GetMapping("/api/public/images/{token}")
    public ResponseEntity<byte[]> publicImage(@PathVariable String token) {
        if (!token.matches("^[0-9a-f]{32}$")) {
            throw ApiException.notFound("Imagem não encontrada.");
        }
        StoredImage image = images.findByPublicToken(token).orElseThrow(() -> ApiException.notFound("Imagem não encontrada."));
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(image.getContentType()))
                .cacheControl(CacheControl.maxAge(java.time.Duration.ofHours(12)).cachePublic())
                .header("X-Content-Type-Options", "nosniff")
                .eTag(image.getSha256())
                .body(image.getData());
    }
}
