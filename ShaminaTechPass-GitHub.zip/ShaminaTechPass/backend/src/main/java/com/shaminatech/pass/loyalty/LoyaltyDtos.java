package com.shaminatech.pass.loyalty;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.CardEnums.Channel;
import com.shaminatech.pass.loyalty.card.CardEnums.LotStatus;
import com.shaminatech.pass.loyalty.card.CardEnums.TransactionType;
import com.shaminatech.pass.loyalty.consumer.Consumer;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ExpiredBalancePolicy;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ProgramStatus;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ReversalPolicy;
import com.shaminatech.pass.loyalty.program.ProgramEnums.Rounding;
import com.shaminatech.pass.loyalty.program.ProgramEnums.StampCriterion;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ValidityMode;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** Contratos (requisições e respostas) da API de fidelidade do painel do estabelecimento. */
public final class LoyaltyDtos {

    private LoyaltyDtos() {
    }

    // ---------------- Consumidores ----------------

    public record ConsumerRequest(
            @NotBlank(message = "Informe o nome.") @Size(max = 150, message = "Máximo de 150 caracteres.") String fullName,
            @NotBlank(message = "Informe o telefone.") @Size(max = 25)
            @Pattern(regexp = "^[0-9+()\\-\\s]*$", message = "Telefone inválido.") String phone,
            @Email(message = "E-mail inválido.") @Size(max = 254) String email,
            @Size(max = 40, message = "Máximo de 40 caracteres.")
            @Pattern(regexp = "^[A-Za-z0-9._\\-/]*$", message = "Use letras, números, ponto, hífen ou barra.") String externalRef,
            Boolean marketingOptIn,
            /** A empresa confirma que informou o cliente sobre o programa e o uso dos dados (LGPD). */
            @NotNull(message = "Confirme que o cliente foi informado sobre o programa e o uso dos dados.")
            @AssertTrue(message = "Confirme que o cliente foi informado sobre o programa e o uso dos dados.") Boolean privacyAcknowledged) {
    }

    public record ConsumerUpdateRequest(
            @NotBlank(message = "Informe o nome.") @Size(max = 150, message = "Máximo de 150 caracteres.") String fullName,
            @NotBlank(message = "Informe o telefone.") @Size(max = 25)
            @Pattern(regexp = "^[0-9+()\\-\\s]*$", message = "Telefone inválido.") String phone,
            @Email(message = "E-mail inválido.") @Size(max = 254) String email,
            @Size(max = 40, message = "Máximo de 40 caracteres.")
            @Pattern(regexp = "^[A-Za-z0-9._\\-/]*$", message = "Use letras, números, ponto, hífen ou barra.") String externalRef,
            Boolean marketingOptIn) {
    }

    public record StatusRequest(@NotNull(message = "Informe a situação.") Consumer.Status status) {
    }

    public record ConsumerView(Long id, String fullName, String phone, String email, String externalRef,
                               Consumer.Status status, Consumer.Source source, boolean marketingOptIn,
                               Instant privacyAcknowledgedAt, Instant createdAt, Instant statusChangedAt,
                               int activeCards) {
    }

    public record ConsumerDetail(ConsumerView consumer, List<CardView> cards) {
    }

    // ---------------- Programas ----------------

    public record ProgramRequest(
            @NotNull(message = "Informe o tipo.") ProgramType type,
            @NotBlank(message = "Informe o nome.") @Size(max = 80, message = "Máximo de 80 caracteres.") String name,
            @Size(max = 500, message = "Máximo de 500 caracteres.") String description,
            @NotNull(message = "Informe o prazo de inatividade.") @Min(value = 1, message = "Mínimo de 1 dia.")
            @Max(value = 3650, message = "Máximo de 3650 dias.") Integer inactivityDays,
            @NotNull(message = "Escolha até quando o cartão vale.") ValidityMode validityMode,
            @NotNull(message = "Escolha o que acontece com o saldo na expiração.") ExpiredBalancePolicy expiredBalancePolicy,
            @NotNull(message = "Escolha a regra de estorno.") ReversalPolicy reversalPolicy,
            @Min(value = 1, message = "Mínimo de 1 dia.") @Max(value = 3650, message = "Máximo de 3650 dias.") Integer benefitValidityDays,
            @DecimalMin(value = "0.01", message = "Informe um valor positivo.") @Digits(integer = 10, fraction = 2) BigDecimal minPurchaseAmount,
            Rounding rounding,
            // pontos
            @Min(value = 1, message = "Mínimo de 1 ponto.") @Max(value = 100000) Integer pointsPerUnit,
            @DecimalMin(value = "0.01", message = "Informe um valor positivo.") @Digits(integer = 10, fraction = 2) BigDecimal spendUnit,
            // cashback
            @DecimalMin(value = "0.01", message = "Mínimo de 0,01%.") @DecimalMax(value = "100.00", message = "Máximo de 100%.")
            @Digits(integer = 3, fraction = 2) BigDecimal cashbackPercent,
            @DecimalMin(value = "0.01", message = "Informe um valor positivo.") @Digits(integer = 10, fraction = 2) BigDecimal maxCreditPerPurchase,
            @DecimalMin(value = "0.01", message = "Informe um valor positivo.") @Digits(integer = 10, fraction = 2) BigDecimal minRedeemBalance,
            @DecimalMin(value = "0.01", message = "Mínimo de 0,01%.") @DecimalMax(value = "100.00", message = "Máximo de 100%.")
            @Digits(integer = 3, fraction = 2) BigDecimal maxRedeemPercent,
            // carimbos
            @Min(value = 2, message = "Mínimo de 2 carimbos.") @Max(value = 100, message = "Máximo de 100 carimbos.") Integer stampsRequired,
            StampCriterion stampCriterion,
            @Size(max = 200, message = "Máximo de 200 caracteres.") String stampReward,
            Boolean restartAfterRedeem) {
    }

    public record ProgramStatusRequest(@NotNull(message = "Informe a situação.") ProgramStatus status) {
    }

    public record ProgramView(Long id, ProgramType type, boolean typeAllowed, boolean operational, String name, String description,
                              ProgramStatus status, int inactivityDays, ValidityMode validityMode,
                              ExpiredBalancePolicy expiredBalancePolicy, ReversalPolicy reversalPolicy,
                              Integer benefitValidityDays, BigDecimal minPurchaseAmount, Rounding rounding,
                              Integer pointsPerUnit, BigDecimal spendUnit, BigDecimal cashbackPercent,
                              BigDecimal maxCreditPerPurchase, BigDecimal minRedeemBalance, BigDecimal maxRedeemPercent,
                              Integer stampsRequired, StampCriterion stampCriterion, String stampReward, Boolean restartAfterRedeem,
                              DesignView design, Instant createdAt) {
    }

    public record RewardRequest(
            @NotBlank(message = "Informe o nome.") @Size(max = 80, message = "Máximo de 80 caracteres.") String name,
            @Size(max = 300, message = "Máximo de 300 caracteres.") String description,
            @NotNull(message = "Informe o custo em pontos.") @Min(value = 1, message = "Mínimo de 1 ponto.")
            @Max(value = 10_000_000) Integer cost,
            Boolean active) {
    }

    public record RewardView(Long id, Long programId, String programName, String name, String description, BigDecimal cost,
                             boolean active) {
    }

    public record VipTierRequest(
            @NotBlank(message = "Informe o nome.") @Size(max = 40, message = "Máximo de 40 caracteres.") String name,
            @NotNull(message = "Informe a ordem.") @Min(1) @Max(20) Integer rankOrder,
            @DecimalMin(value = "0.00") @Digits(integer = 10, fraction = 2) BigDecimal minSpend,
            @Min(0) @Max(100000) Integer minVisits,
            @Min(1) @Max(3650) Integer periodDays,
            @Size(max = 500, message = "Máximo de 500 caracteres.") String benefits) {
    }

    public record VipTierView(Long id, String name, int rankOrder, BigDecimal minSpend, Integer minVisits, Integer periodDays,
                              String benefits) {
    }

    // ---------------- Personalização ----------------

    public record DesignRequest(
            @NotBlank(message = "Informe a cor principal.") @Pattern(regexp = "^#[0-9A-Fa-f]{6}$", message = "Use o formato #RRGGBB.") String brandColor,
            @NotBlank(message = "Informe a cor do texto.") @Pattern(regexp = "^#[0-9A-Fa-f]{6}$", message = "Use o formato #RRGGBB.") String textColor,
            @Size(max = 200, message = "Máximo de 200 caracteres.") String cardMessage,
            @Size(max = 300, message = "Máximo de 300 caracteres.") String rewardInfo) {
    }

    public record DesignView(String brandColor, String textColor, String cardMessage, String rewardInfo, String logoUrl,
                             String heroUrl, List<String> walletNotes) {
    }

    // ---------------- Cartões ----------------

    public record IssueCardRequest(
            @NotNull(message = "Informe o cliente.") Long consumerId,
            @NotNull(message = "Informe o programa.") Long programId,
            @Min(value = 1, message = "Mínimo de 1 dia.") @Max(value = 3650, message = "Máximo de 3650 dias.") Integer inactivityDaysOverride) {
    }

    public record CardActionRequest(@Size(max = 200, message = "Máximo de 200 caracteres.") String reason) {
    }

    public record NextBenefitExpiry(BigDecimal amount, Instant expiresAt) {
    }

    public record CardView(Long id, String code, String displayCode, CardStatus status, CardStatus storedStatus,
                           BigDecimal balance, BigDecimal availableBalance, Long programId, String programName,
                           ProgramType programType, Long consumerId, String consumerName, Instant issuedAt,
                           Instant lastMovementAt, Instant expiresAt, LocalDateTime validUntil, String timeZone,
                           int inactivityDays, String statusReason, int completedCycles, Integer stampsRequired,
                           boolean rewardAvailable, NextBenefitExpiry nextBenefitExpiry) {
    }

    public record LotView(Long id, BigDecimal originalAmount, BigDecimal remaining, BigDecimal expiredAmount, Instant expiresAt,
                          LotStatus status, Instant createdAt) {
    }

    public record CardDetail(CardView card, List<LotView> lots, List<RewardView> rewards, DesignView design,
                             String programDescription) {
    }

    // ---------------- Movimentações ----------------

    public record EarnRequest(
            @DecimalMin(value = "0.01", message = "Informe um valor positivo.") @Digits(integer = 7, fraction = 2, message = "Valor inválido.")
            BigDecimal purchaseAmount,
            @Min(value = 1, message = "Mínimo de 1.") @Max(value = 50, message = "Máximo de 50.") Integer quantity,
            Channel channel,
            @Size(max = 200, message = "Máximo de 200 caracteres.") String note) {
    }

    public record RedeemRequest(
            Long rewardId,
            @DecimalMin(value = "0.01", message = "Informe um valor positivo.") @Digits(integer = 7, fraction = 2, message = "Valor inválido.")
            BigDecimal amount,
            @DecimalMin(value = "0.01", message = "Informe um valor positivo.") @Digits(integer = 7, fraction = 2, message = "Valor inválido.")
            BigDecimal purchaseAmount,
            Channel channel,
            @Size(max = 200, message = "Máximo de 200 caracteres.") String note) {
    }

    public record ReverseRequest(
            @NotBlank(message = "Informe o motivo do estorno.") @Size(max = 200, message = "Máximo de 200 caracteres.") String reason) {
    }

    public record TransactionView(Long id, TransactionType type, Channel channel, BigDecimal amount, BigDecimal balanceAfter,
                                  BigDecimal purchaseAmount, String description, String note, Instant occurredAt,
                                  Long reversesId, boolean reversed, boolean reversible, Long cardId, String cardCode,
                                  Long consumerId, String consumerName, Long programId, String programName,
                                  ProgramType programType, CardStatus cardStatusAfter, Instant cardExpiresAtAfter) {
    }

    public record OperationResult(TransactionView transaction, CardView card, boolean replayed, BigDecimal notRestored) {
    }

    // ---------------- Painel / indicadores ----------------

    public record PolicyView(int maxActiveConsumers, Set<ProgramType> allowedProgramTypes, int defaultInactivityDays,
                             String timeZone) {
    }
}
