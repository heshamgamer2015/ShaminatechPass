package com.shaminatech.pass.loyalty.card;

import java.math.BigDecimal;
import java.time.Instant;

import com.shaminatech.pass.common.persistence.BaseEntity;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.consumer.Consumer;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Cartão de fidelidade: associa um consumidor a um programa. O saldo oficial fica aqui (e nos lotes);
 * carteiras digitais futuras apenas refletem este valor. Cartões nunca são apagados.
 * <p>
 * {@code expiresAt} é o instante (exclusivo) em que o cartão deixa de valer por inatividade: o cartão vale
 * enquanto {@code agora < expiresAt}. É renovado somente por movimentação legítima (concessão ou resgate
 * aceito), na mesma transação que grava a movimentação.
 */
@Entity
@Table(name = "loyalty_card",
        uniqueConstraints = @UniqueConstraint(name = "uk_loyalty_card_code", columnNames = "code"),
        indexes = {
                @Index(name = "idx_loyalty_card_establishment_status", columnList = "establishment_id, status"),
                @Index(name = "idx_loyalty_card_consumer", columnList = "consumer_id"),
                @Index(name = "idx_loyalty_card_expiration", columnList = "status, expires_at")})
public class LoyaltyCard extends BaseEntity {

    @Column(name = "establishment_id", nullable = false, updatable = false)
    private Long establishmentId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "consumer_id", nullable = false, updatable = false, foreignKey = @ForeignKey(name = "fk_loyalty_card_consumer"))
    private Consumer consumer;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "program_id", nullable = false, updatable = false, foreignKey = @ForeignKey(name = "fk_loyalty_card_program"))
    private LoyaltyProgram program;

    /** Identificador público do cartão (conteúdo do QR Code / código de barras). Aleatório, 80 bits. */
    @Column(nullable = false, length = 16, updatable = false)
    private String code;

    @Column(nullable = false, length = 20)
    private CardStatus status = CardStatus.ACTIVE;

    /** Saldo atual (pontos, carimbos ou R$ de cashback). */
    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal balance = BigDecimal.ZERO;

    @Column(name = "issued_at", nullable = false, updatable = false)
    private Instant issuedAt;

    @Column(name = "last_movement_at")
    private Instant lastMovementAt;

    @Column(name = "expires_at", nullable = false)
    private Instant expiresAt;

    /** Prazo próprio do cartão; nulo = usa o prazo do programa. */
    @Column(name = "inactivity_days_override")
    private Integer inactivityDaysOverride;

    @Column(name = "status_changed_at")
    private Instant statusChangedAt;

    @Column(name = "status_reason", length = 200)
    private String statusReason;

    @Column(name = "completed_cycles", nullable = false)
    private int completedCycles;

    protected LoyaltyCard() {
    }

    public LoyaltyCard(Consumer consumer, LoyaltyProgram program, String code, Instant issuedAt, Instant expiresAt,
                       Integer inactivityDaysOverride) {
        this.establishmentId = program.getEstablishmentId();
        this.consumer = consumer;
        this.program = program;
        this.code = code;
        this.issuedAt = issuedAt;
        this.expiresAt = expiresAt;
        this.inactivityDaysOverride = inactivityDaysOverride;
    }

    /** Venceu por inatividade (ainda que o processamento periódico não tenha marcado EXPIRED). */
    public boolean isOverdue(Instant now) {
        return (status == CardStatus.ACTIVE || status == CardStatus.SUSPENDED) && !now.isBefore(expiresAt);
    }

    /** Estado considerando a data atual (para exibição). */
    public CardStatus effectiveStatus(Instant now) {
        return isOverdue(now) ? CardStatus.EXPIRED : status;
    }

    public int inactivityDays() {
        return inactivityDaysOverride != null ? inactivityDaysOverride : program.getInactivityDays();
    }

    public void changeStatus(CardStatus status, Instant now, String reason) {
        this.status = status;
        this.statusChangedAt = now;
        this.statusReason = reason;
    }

    /** Renovação da validade — chamada apenas pelo motor de movimentações, dentro da transação da movimentação. */
    void renew(Instant movementAt, Instant newExpiresAt) {
        this.lastMovementAt = movementAt;
        this.expiresAt = newExpiresAt;
    }

    void reactivateUntil(Instant newExpiresAt) {
        this.expiresAt = newExpiresAt;
    }

    void applyDelta(BigDecimal delta) {
        this.balance = this.balance.add(delta);
    }

    void completeCycle() {
        this.completedCycles++;
    }

    void undoCycle() {
        if (completedCycles > 0) {
            completedCycles--;
        }
    }

    public Long getEstablishmentId() { return establishmentId; }
    public Consumer getConsumer() { return consumer; }
    public LoyaltyProgram getProgram() { return program; }
    public String getCode() { return code; }
    public CardStatus getStatus() { return status; }
    public BigDecimal getBalance() { return balance; }
    public Instant getIssuedAt() { return issuedAt; }
    public Instant getLastMovementAt() { return lastMovementAt; }
    public Instant getExpiresAt() { return expiresAt; }
    public Integer getInactivityDaysOverride() { return inactivityDaysOverride; }
    public void setInactivityDaysOverride(Integer v) { this.inactivityDaysOverride = v; }
    public Instant getStatusChangedAt() { return statusChangedAt; }
    public String getStatusReason() { return statusReason; }
    public int getCompletedCycles() { return completedCycles; }
}
