package com.shaminatech.pass.plan;

/**
 * Planos comerciais do ShaminaTech Pass. O preço é o <b>preço comercial previsto</b> (em centavos), apenas informativo:
 * não existe cobrança, assinatura financeira ou meio de pagamento no sistema.
 * <p>
 * {@code null} = sem limite comercial. Clientes do Pro ficam sujeitos só ao teto técnico da plataforma
 * ({@link com.shaminatech.pass.loyalty.policy.PolicyService#MAX_CONSUMER_LIMIT}), proteção contra abuso, não regra comercial.
 */
public enum Plan {

    FREE("Free", 0, 10, 1, 1),
    GROWTH("Growth", 5900, 150, 2, 2),
    PRO("Pro", 12900, null, null, 4);

    private final String displayName;
    private final int listPriceCents;
    private final Integer maxActiveConsumers;
    private final Integer maxPrograms;
    private final int maxProgramTypes;

    Plan(String displayName, int listPriceCents, Integer maxActiveConsumers, Integer maxPrograms, int maxProgramTypes) {
        this.displayName = displayName;
        this.listPriceCents = listPriceCents;
        this.maxActiveConsumers = maxActiveConsumers;
        this.maxPrograms = maxPrograms;
        this.maxProgramTypes = maxProgramTypes;
    }

    public String displayName() {
        return displayName;
    }

    public int listPriceCents() {
        return listPriceCents;
    }

    /** Null = ilimitado comercialmente. */
    public Integer maxActiveConsumers() {
        return maxActiveConsumers;
    }

    /** Null = ilimitado comercialmente (conta programas não encerrados). */
    public Integer maxPrograms() {
        return maxPrograms;
    }

    /** Tipos de fidelidade diferentes entre os programas não encerrados (Pro: os 4). */
    public int maxProgramTypes() {
        return maxProgramTypes;
    }

    public boolean isPaid() {
        return listPriceCents > 0;
    }

    /** Gravado como texto, sem CHECK no banco (padrão do projeto, ver EnumCheckFreeTypeContributor). */
    @jakarta.persistence.Converter(autoApply = true)
    public static class JpaConverter extends com.shaminatech.pass.common.persistence.EnumNameConverter<Plan> {
        public JpaConverter() {
            super(Plan.class);
        }
    }
}
