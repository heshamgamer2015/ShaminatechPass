package com.shaminatech.pass.loyalty.program;

import java.math.BigDecimal;

import com.shaminatech.pass.common.persistence.BaseEntity;
import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ExpiredBalancePolicy;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ProgramStatus;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ReversalPolicy;
import com.shaminatech.pass.loyalty.program.ProgramEnums.Rounding;
import com.shaminatech.pass.loyalty.program.ProgramEnums.StampCriterion;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ValidityMode;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * Programa de fidelidade de um estabelecimento. Tabela única para os quatro tipos: as colunas
 * específicas de cada tipo ficam nulas nos demais (modelo simples de consultar e de estender).
 * <p>
 * Regras comuns escolhidas pela empresa:
 * <ul>
 *   <li>{@code inactivityDays} + {@code validityMode}: validade do cartão por inatividade;</li>
 *   <li>{@code expiredBalancePolicy}: o que acontece com o saldo quando o cartão expira;</li>
 *   <li>{@code reversalPolicy}: estorno quando o saldo atual não cobre o valor a estornar;</li>
 *   <li>{@code benefitValidityDays}: validade própria dos pontos/créditos/carimbos (independente da do cartão).</li>
 * </ul>
 * Alterações de regra valem para as próximas movimentações; o histórico guarda os valores calculados.
 */
@Entity
@Table(name = "loyalty_program", indexes = @Index(name = "idx_loyalty_program_establishment", columnList = "establishment_id, status"))
public class LoyaltyProgram extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "establishment_id", nullable = false, foreignKey = @ForeignKey(name = "fk_loyalty_program_establishment"))
    private Establishment establishment;

    @Column(nullable = false, length = 20, updatable = false)
    private ProgramType type;

    @Column(nullable = false, length = 80)
    private String name;

    @Column(length = 500)
    private String description;

    @Column(nullable = false, length = 20)
    private ProgramStatus status = ProgramStatus.ACTIVE;

    // ---------- Regras comuns ----------
    @Column(name = "inactivity_days", nullable = false)
    private int inactivityDays;

    @Column(name = "validity_mode", nullable = false, length = 20)
    private ValidityMode validityMode = ValidityMode.END_OF_DAY;

    @Column(name = "expired_balance_policy", nullable = false, length = 20)
    private ExpiredBalancePolicy expiredBalancePolicy = ExpiredBalancePolicy.KEEP;

    @Column(name = "reversal_policy", nullable = false, length = 30)
    private ReversalPolicy reversalPolicy = ReversalPolicy.REQUIRE_BALANCE;

    /** Validade de cada concessão (pontos, crédito, carimbos), em dias. Nulo = sem validade própria. */
    @Column(name = "benefit_validity_days")
    private Integer benefitValidityDays;

    @Column(name = "min_purchase_amount", precision = 12, scale = 2)
    private BigDecimal minPurchaseAmount;

    @Column(name = "rounding", length = 20)
    private Rounding rounding;

    // ---------- Pontos ----------
    /** Pontos concedidos a cada {@code spendUnit} gasto (ex.: 1 ponto a cada R$ 1,00). */
    @Column(name = "points_per_unit")
    private Integer pointsPerUnit;

    @Column(name = "spend_unit", precision = 12, scale = 2)
    private BigDecimal spendUnit;

    // ---------- Cashback ----------
    @Column(name = "cashback_percent", precision = 5, scale = 2)
    private BigDecimal cashbackPercent;

    @Column(name = "max_credit_per_purchase", precision = 12, scale = 2)
    private BigDecimal maxCreditPerPurchase;

    @Column(name = "min_redeem_balance", precision = 12, scale = 2)
    private BigDecimal minRedeemBalance;

    /** Percentual máximo de uma compra que pode ser abatido com cashback (nulo = sem limite). */
    @Column(name = "max_redeem_percent", precision = 5, scale = 2)
    private BigDecimal maxRedeemPercent;

    // ---------- Carimbos ----------
    @Column(name = "stamps_required")
    private Integer stampsRequired;

    @Column(name = "stamp_criterion", length = 20)
    private StampCriterion stampCriterion;

    @Column(name = "stamp_reward", length = 200)
    private String stampReward;

    @Column(name = "restart_after_redeem")
    private Boolean restartAfterRedeem;

    // ---------- Personalização (prévia interna; Wallet ainda não integrado) ----------
    @Column(name = "brand_color", length = 7)
    private String brandColor;

    @Column(name = "text_color", length = 7)
    private String textColor;

    @Column(name = "card_message", length = 200)
    private String cardMessage;

    @Column(name = "reward_info", length = 300)
    private String rewardInfo;

    @Column(name = "logo_image_id")
    private Long logoImageId;

    @Column(name = "hero_image_id")
    private Long heroImageId;

    protected LoyaltyProgram() {
    }

    public LoyaltyProgram(Establishment establishment, ProgramType type, String name, int inactivityDays) {
        this.establishment = establishment;
        this.type = type;
        this.name = name;
        this.inactivityDays = inactivityDays;
    }

    public boolean isActive() {
        return status == ProgramStatus.ACTIVE;
    }

    public Long getEstablishmentId() {
        return establishment.getId();
    }

    // ---------- getters / setters ----------
    public Establishment getEstablishment() { return establishment; }
    public ProgramType getType() { return type; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public ProgramStatus getStatus() { return status; }
    public void setStatus(ProgramStatus status) { this.status = status; }
    public int getInactivityDays() { return inactivityDays; }
    public void setInactivityDays(int inactivityDays) { this.inactivityDays = inactivityDays; }
    public ValidityMode getValidityMode() { return validityMode; }
    public void setValidityMode(ValidityMode validityMode) { this.validityMode = validityMode; }
    public ExpiredBalancePolicy getExpiredBalancePolicy() { return expiredBalancePolicy; }
    public void setExpiredBalancePolicy(ExpiredBalancePolicy p) { this.expiredBalancePolicy = p; }
    public ReversalPolicy getReversalPolicy() { return reversalPolicy; }
    public void setReversalPolicy(ReversalPolicy reversalPolicy) { this.reversalPolicy = reversalPolicy; }
    public Integer getBenefitValidityDays() { return benefitValidityDays; }
    public void setBenefitValidityDays(Integer benefitValidityDays) { this.benefitValidityDays = benefitValidityDays; }
    public BigDecimal getMinPurchaseAmount() { return minPurchaseAmount; }
    public void setMinPurchaseAmount(BigDecimal minPurchaseAmount) { this.minPurchaseAmount = minPurchaseAmount; }
    public Rounding getRounding() { return rounding; }
    public void setRounding(Rounding rounding) { this.rounding = rounding; }
    public Integer getPointsPerUnit() { return pointsPerUnit; }
    public void setPointsPerUnit(Integer pointsPerUnit) { this.pointsPerUnit = pointsPerUnit; }
    public BigDecimal getSpendUnit() { return spendUnit; }
    public void setSpendUnit(BigDecimal spendUnit) { this.spendUnit = spendUnit; }
    public BigDecimal getCashbackPercent() { return cashbackPercent; }
    public void setCashbackPercent(BigDecimal cashbackPercent) { this.cashbackPercent = cashbackPercent; }
    public BigDecimal getMaxCreditPerPurchase() { return maxCreditPerPurchase; }
    public void setMaxCreditPerPurchase(BigDecimal v) { this.maxCreditPerPurchase = v; }
    public BigDecimal getMinRedeemBalance() { return minRedeemBalance; }
    public void setMinRedeemBalance(BigDecimal minRedeemBalance) { this.minRedeemBalance = minRedeemBalance; }
    public BigDecimal getMaxRedeemPercent() { return maxRedeemPercent; }
    public void setMaxRedeemPercent(BigDecimal maxRedeemPercent) { this.maxRedeemPercent = maxRedeemPercent; }
    public Integer getStampsRequired() { return stampsRequired; }
    public void setStampsRequired(Integer stampsRequired) { this.stampsRequired = stampsRequired; }
    public StampCriterion getStampCriterion() { return stampCriterion; }
    public void setStampCriterion(StampCriterion stampCriterion) { this.stampCriterion = stampCriterion; }
    public String getStampReward() { return stampReward; }
    public void setStampReward(String stampReward) { this.stampReward = stampReward; }
    public Boolean getRestartAfterRedeem() { return restartAfterRedeem; }
    public void setRestartAfterRedeem(Boolean restartAfterRedeem) { this.restartAfterRedeem = restartAfterRedeem; }
    public String getBrandColor() { return brandColor; }
    public void setBrandColor(String brandColor) { this.brandColor = brandColor; }
    public String getTextColor() { return textColor; }
    public void setTextColor(String textColor) { this.textColor = textColor; }
    public String getCardMessage() { return cardMessage; }
    public void setCardMessage(String cardMessage) { this.cardMessage = cardMessage; }
    public String getRewardInfo() { return rewardInfo; }
    public void setRewardInfo(String rewardInfo) { this.rewardInfo = rewardInfo; }
    public Long getLogoImageId() { return logoImageId; }
    public void setLogoImageId(Long logoImageId) { this.logoImageId = logoImageId; }
    public Long getHeroImageId() { return heroImageId; }
    public void setHeroImageId(Long heroImageId) { this.heroImageId = heroImageId; }
}
