package com.shaminatech.pass.auth;

import java.util.List;

import com.shaminatech.pass.establishment.EstablishmentStatus;
import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.security.StrongPassword;
import com.shaminatech.pass.user.PlatformRole;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public final class AuthDtos {

    private AuthDtos() {
    }

    public record LoginRequest(
            @NotBlank(message = "Informe o e-mail.") @Email(message = "E-mail inválido.") @Size(max = 254) String email,
            @NotBlank(message = "Informe a senha.") @Size(max = 200) String password) {
    }

    public record ChangePasswordRequest(
            @NotBlank(message = "Informe a senha atual.") @Size(max = 200) String currentPassword,
            @NotBlank(message = "Informe a nova senha.") @StrongPassword String newPassword) {
    }

    public record MembershipSummary(Long establishmentId, String establishmentName, String establishmentSlug,
                                    EstablishmentStatus establishmentStatus, MembershipRole role) {
    }

    public record MeResponse(Long id, String email, String fullName, PlatformRole platformRole,
                             boolean passwordChangeRequired, List<MembershipSummary> memberships) {
    }
}
