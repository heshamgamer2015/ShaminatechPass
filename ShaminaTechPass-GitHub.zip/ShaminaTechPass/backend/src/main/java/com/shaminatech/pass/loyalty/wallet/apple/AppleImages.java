package com.shaminatech.pass.loyalty.wallet.apple;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.imageio.ImageIO;

import org.springframework.stereotype.Component;

/**
 * Converte as imagens do estabelecimento para os tamanhos do Apple Wallet (PNG, em 1x, 2x e 3x):
 * <ul>
 *   <li>icon (29 × 29 pt): obrigatório; vem do logotipo (ou do ícone padrão da ShaminaTech);</li>
 *   <li>logo (até 160 × 50 pt): o logotipo quadrado é ajustado à altura de 50 pt;</li>
 *   <li>strip (375 × 123 pt, cartão de fidelidade): recorte central da imagem de destaque, se houver.</li>
 * </ul>
 * O resultado é guardado em memória por conteúdo (SHA-256 da imagem original).
 */
@Component
public class AppleImages {

    private static final int[] SCALES = {1, 2, 3};
    private static final String DEFAULT_ICON = "/wallet/shaminatech-icon.png";
    private static final int CACHE_LIMIT = 300;

    private final Map<String, byte[]> cache = new ConcurrentHashMap<>();

    /** Arquivos de imagem do pacote (nome → PNG). logo/hero podem ser nulos. */
    public Map<String, byte[]> passImages(byte[] logo, String logoKey, byte[] hero, String heroKey) {
        byte[] source = logo;
        String key = logoKey;
        if (source == null) {
            source = defaultIcon();
            key = "default";
        }
        Map<String, byte[]> files = new LinkedHashMap<>();
        for (int scale : SCALES) {
            String suffix = scale == 1 ? "" : "@" + scale + "x";
            files.put("icon" + suffix + ".png", variant(source, key, "icon", 29 * scale, 29 * scale, false));
            files.put("logo" + suffix + ".png", variant(source, key, "logo", 160 * scale, 50 * scale, false));
            if (hero != null) {
                files.put("strip" + suffix + ".png", variant(hero, heroKey, "strip", 375 * scale, 123 * scale, true));
            }
        }
        return files;
    }

    private byte[] variant(byte[] source, String key, String kind, int width, int height, boolean crop) {
        String cacheKey = key + ":" + kind + ":" + width + "x" + height;
        byte[] cached = cache.get(cacheKey);
        if (cached != null) {
            return cached;
        }
        byte[] result = crop ? cover(read(source), width, height) : fit(read(source), width, height);
        if (cache.size() > CACHE_LIMIT) {
            cache.clear();
        }
        cache.put(cacheKey, result);
        return result;
    }

    /** Cabe na caixa mantendo a proporção (sem ampliar além do original). */
    static byte[] fit(BufferedImage image, int maxWidth, int maxHeight) {
        double ratio = Math.min(1.0, Math.min((double) maxWidth / image.getWidth(), (double) maxHeight / image.getHeight()));
        int w = Math.max(1, (int) Math.round(image.getWidth() * ratio));
        int h = Math.max(1, (int) Math.round(image.getHeight() * ratio));
        return png(scale(image, w, h, 0, 0, image.getWidth(), image.getHeight()));
    }

    /** Preenche a caixa recortando o centro (usado na faixa do cartão). */
    static byte[] cover(BufferedImage image, int width, int height) {
        double target = (double) width / height;
        int sw = image.getWidth();
        int sh = image.getHeight();
        int cw = sw;
        int ch = (int) Math.round(sw / target);
        if (ch > sh) {
            ch = sh;
            cw = (int) Math.round(sh * target);
        }
        int x = (sw - cw) / 2;
        int y = (sh - ch) / 2;
        return png(scale(image, width, height, x, y, cw, ch));
    }

    private static BufferedImage scale(BufferedImage source, int width, int height, int sx, int sy, int sw, int sh) {
        BufferedImage out = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.drawImage(source, 0, 0, width, height, sx, sy, sx + sw, sy + sh, null);
        } finally {
            g.dispose();
        }
        return out;
    }

    private static BufferedImage read(byte[] data) {
        try {
            BufferedImage image = ImageIO.read(new ByteArrayInputStream(data));
            if (image == null) {
                throw new AppleWalletException(0, "Imagem do cartão em formato não suportado.", false);
            }
            return image;
        } catch (IOException e) {
            throw new AppleWalletException(0, "Imagem do cartão ilegível.", false);
        }
    }

    private static byte[] png(BufferedImage image) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ImageIO.write(image, "png", out);
            return out.toByteArray();
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    private static byte[] defaultIcon() {
        try (InputStream in = AppleImages.class.getResourceAsStream(DEFAULT_ICON)) {
            if (in == null) {
                throw new IllegalStateException("Ícone padrão ausente: " + DEFAULT_ICON);
            }
            return in.readAllBytes();
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }
}
