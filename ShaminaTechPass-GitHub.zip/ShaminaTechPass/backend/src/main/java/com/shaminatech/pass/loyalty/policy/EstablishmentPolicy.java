package com.shaminatech.pass.loyalty.policy;

import java.time.ZoneId;
import java.util.Set;

import com.shaminatech.pass.common.persistence.BaseEntity;
import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.loyalty.ProgramType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Limites individuais de um estabelecimento, atribuídos manualmente pela ShaminaTech
 * (ainda não há planos comerciais). Fica em tabela própria para não exigir colunas NOT NULL
 * novas na tabela {@code establishment}, que já tem dados.
 */
@Entity
@Table(name = "establishment_policy",
        uniqueConstraints = @UniqueConstraint(name = "uk_establishment_policy_establishment", columnNames = "establishment_id"))
public class EstablishmentPolicy extends BaseEntity {

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "establishment_id", nullable = false,
            foreignKey = @ForeignKey(name = "fk_establishment_policy_establishment"))
    private Establishment establishment;

    /** Máximo de consumidores com cadastro ATIVO (não é contado por cartões). */
    @Column(name = "max_active_consumers", nullable = false)
    private int maxActiveConsumers;

    /** Prazo de inatividade sugerido para novos programas. */
    @Column(name = "default_inactivity_days", nullable = false)
    private int defaultInactivityDays;

    /** Fuso do estabelecimento (usado nas regras de validade "até o fim do dia"). */
    @Column(name = "time_zone", nullable = false, length = 60)
    private String timeZone;

    @Column(name = "allowed_program_types", nullable = false, length = 100)
    private String allowedProgramTypes;

    protected EstablishmentPolicy() {
    }

    public EstablishmentPolicy(Establishment establishment, PlatformLoyaltyDefaults defaults) {
        this.establishment = establishment;
        update(defaults.getMaxActiveConsumers(), defaults.getDefaultInactivityDays(), defaults.getTimeZone(),
                defaults.getAllowedProgramTypes());
    }

    public final void update(int maxActiveConsumers, int defaultInactivityDays, String timeZone, Set<ProgramType> types) {
        this.maxActiveConsumers = maxActiveConsumers;
        this.defaultInactivityDays = defaultInactivityDays;
        this.timeZone = timeZone;
        this.allowedProgramTypes = ProgramType.join(types);
    }

    public boolean allows(ProgramType type) {
        return getAllowedProgramTypes().contains(type);
    }

    public ZoneId zone() {
        return ZoneId.of(timeZone);
    }

    public Establishment getEstablishment() {
        return establishment;
    }

    public int getMaxActiveConsumers() {
        return maxActiveConsumers;
    }

    public int getDefaultInactivityDays() {
        return defaultInactivityDays;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public Set<ProgramType> getAllowedProgramTypes() {
        return ProgramType.parse(allowedProgramTypes);
    }

    /** Descrição curta para auditoria. */
    public String describe() {
        return "limite=" + maxActiveConsumers + ", tipos=" + allowedProgramTypes + ", inatividade="
                + defaultInactivityDays + "d, fuso=" + timeZone;
    }
}
