package com.shaminatech.pass.common.error;

import org.springframework.http.HttpStatus;

/**
 * Erro de negócio com status HTTP e código estável (para o frontend).
 * A mensagem é exibida ao usuário, portanto nunca deve conter dados sensíveis.
 */
public class ApiException extends RuntimeException {

    private final HttpStatus status;
    private final String code;
    private final String field;

    public ApiException(HttpStatus status, String code, String message) {
        this(status, code, message, null);
    }

    public ApiException(HttpStatus status, String code, String message, String field) {
        super(message);
        this.status = status;
        this.code = code;
        this.field = field;
    }

    public static ApiException notFound(String message) {
        return new ApiException(HttpStatus.NOT_FOUND, "NOT_FOUND", message);
    }

    public static ApiException conflict(String message, String field) {
        return new ApiException(HttpStatus.CONFLICT, "CONFLICT", message, field);
    }

    public static ApiException badRequest(String message, String field) {
        return new ApiException(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR", message, field);
    }

    /** Estado atual impede a operação (ex.: cartão cancelado). */
    public static ApiException state(String code, String message) {
        return new ApiException(HttpStatus.CONFLICT, code, message);
    }

    /** Regra de negócio não atendida pelos dados informados (HTTP 422). */
    public static ApiException rule(String code, String message, String field) {
        return new ApiException(HttpStatus.UNPROCESSABLE_CONTENT, code, message, field);
    }

    public static ApiException forbidden(String message) {
        return new ApiException(HttpStatus.FORBIDDEN, "FORBIDDEN", message);
    }

    public HttpStatus getStatus() {
        return status;
    }

    public String getCode() {
        return code;
    }

    public String getField() {
        return field;
    }
}
