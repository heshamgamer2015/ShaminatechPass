package com.shaminatech.pass.tenant;

import java.util.Set;

import com.shaminatech.pass.establishment.EstablishmentStatus;
import com.shaminatech.pass.loyalty.LoyaltyDtos.PolicyView;
import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.membership.Permission;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public final class TenantDtos {

    private TenantDtos() {
    }

    /** Dados do estabelecimento + papel e permissões do usuário logado (o frontend usa só para exibir/ocultar). */
    public record EstablishmentPanelResponse(Long id, String name, String slug, EstablishmentStatus status,
                                             String contactEmail, String contactPhone, MembershipRole myRole,
                                             Set<Permission> permissions, PolicyView policy) {
    }

    public record UpdateEstablishmentRequest(
            @NotBlank(message = "Informe o nome.") @Size(max = 150, message = "Máximo de 150 caracteres.") String name,
            @Email(message = "E-mail inválido.") @Size(max = 254) String contactEmail,
            @Size(max = 30, message = "Máximo de 30 caracteres.")
            @Pattern(regexp = "^[0-9+()\\-\\s]*$", message = "Telefone inválido.") String contactPhone) {
    }
}
