package com.shaminatech.pass.membership;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * Toda consulta de vínculo exige o estabelecimento (tenant). Não existe busca de vínculo
 * só pelo id, o que impede acessar vínculos de outro estabelecimento trocando o identificador.
 */
public interface MembershipRepository extends JpaRepository<Membership, Long> {

    @Query("""
            select m from Membership m join fetch m.establishment
            where m.establishment.id = :establishmentId and m.user.id = :userId
            """)
    Optional<Membership> findForUser(@Param("establishmentId") Long establishmentId, @Param("userId") Long userId);

    @Query("""
            select m from Membership m join fetch m.user
            where m.id = :membershipId and m.establishment.id = :establishmentId
            """)
    Optional<Membership> findInEstablishment(@Param("establishmentId") Long establishmentId,
                                             @Param("membershipId") Long membershipId);

    @Query("""
            select m from Membership m join fetch m.user u
            where m.establishment.id = :establishmentId
            order by m.role, u.fullName
            """)
    List<Membership> findAllInEstablishment(@Param("establishmentId") Long establishmentId);

    @Query("""
            select m from Membership m join fetch m.establishment e
            where m.user.id = :userId and m.status = com.shaminatech.pass.membership.MembershipStatus.ACTIVE
              and m.role = com.shaminatech.pass.membership.MembershipRole.OWNER
            order by e.name
            """)
    List<Membership> findActiveBusinessAccountsByUser(@Param("userId") Long userId);

    /** Conta empresarial ativa do estabelecimento (no máximo uma, garantido por uk_membership_account_slot). */
    @Query("""
            select m from Membership m join fetch m.user
            where m.establishment.id = :establishmentId and m.accountSlot = :establishmentId
            """)
    Optional<Membership> findBusinessAccount(@Param("establishmentId") Long establishmentId);

    boolean existsByEstablishmentIdAndUserId(Long establishmentId, Long userId);
}
