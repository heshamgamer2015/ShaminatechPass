package com.shaminatech.pass.loyalty.wallet;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface WalletLinkRepository extends JpaRepository<WalletLink, Long> {

    Optional<WalletLink> findByTokenHash(String tokenHash);

    @Query("select l from WalletLink l where l.id = :id and l.establishmentId = :establishmentId")
    Optional<WalletLink> findInEstablishment(@Param("establishmentId") Long establishmentId, @Param("id") Long id);

    @Query("select l from WalletLink l where l.cardId = :cardId and l.establishmentId = :establishmentId order by l.createdAt desc")
    List<WalletLink> findByCard(@Param("establishmentId") Long establishmentId, @Param("cardId") Long cardId);
}
