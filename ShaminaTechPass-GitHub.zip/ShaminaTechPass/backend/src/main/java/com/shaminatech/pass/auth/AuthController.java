package com.shaminatech.pass.auth;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shaminatech.pass.auth.AuthDtos.ChangePasswordRequest;
import com.shaminatech.pass.auth.AuthDtos.LoginRequest;
import com.shaminatech.pass.auth.AuthDtos.MeResponse;
import com.shaminatech.pass.security.AuthenticatedUser;
import com.shaminatech.pass.security.CurrentUser;

/** Login por sessão. O logout (POST /api/auth/logout) é tratado pelo Spring Security. */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final SecurityContextRepository securityContextRepository;
    private final CsrfTokenRepository csrfTokenRepository;

    private final SessionLogin sessionLogin;

    public AuthController(AuthService authService, SecurityContextRepository securityContextRepository,
                          CsrfTokenRepository csrfTokenRepository, SessionLogin sessionLogin) {
        this.authService = authService;
        this.securityContextRepository = securityContextRepository;
        this.csrfTokenRepository = csrfTokenRepository;
        this.sessionLogin = sessionLogin;
    }

    /** Garante que o cookie XSRF-TOKEN exista antes da primeira requisição que altera dados. */
    @GetMapping("/csrf")
    public ResponseEntity<Void> csrf(HttpServletRequest request) {
        CsrfToken token = (CsrfToken) request.getAttribute(CsrfToken.class.getName());
        if (token != null) {
            token.getToken();
        }
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/login")
    public MeResponse login(@Valid @RequestBody LoginRequest body, HttpServletRequest request, HttpServletResponse response) {
        return sessionLogin.login(body.email(), body.password(), request, response);
    }

    @GetMapping("/me")
    public MeResponse me() {
        return authService.me(CurrentUser.require().getId());
    }

    @PostMapping("/change-password")
    public ResponseEntity<Void> changePassword(@Valid @RequestBody ChangePasswordRequest body, HttpServletRequest request,
                                               HttpServletResponse response) {
        Long userId = CurrentUser.require().getId();
        authService.changePassword(userId, body.currentPassword(), body.newPassword());
        request.changeSessionId();
        // Esta sessão continua válida com a nova marca de credencial; as demais sessões do usuário são encerradas.
        AuthenticatedUser principal = authService.principalOf(userId);
        SecurityContext context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(UsernamePasswordAuthenticationToken.authenticated(principal, null, principal.getAuthorities()));
        SecurityContextHolder.setContext(context);
        securityContextRepository.saveContext(context, request, response);
        return ResponseEntity.noContent().build();
    }
}
