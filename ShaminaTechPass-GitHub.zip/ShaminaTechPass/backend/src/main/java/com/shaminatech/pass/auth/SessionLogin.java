package com.shaminatech.pass.auth;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.stereotype.Component;

import com.shaminatech.pass.auth.AuthDtos.MeResponse;
import com.shaminatech.pass.security.AuthenticatedUser;

/**
 * Abertura da sessão autenticada (o único mecanismo de login da plataforma): usado pelo login e pelo autocadastro do
 * estabelecimento, que entra logo depois de criar a conta.
 */
@Component
public class SessionLogin {

    private final AuthService authService;
    private final SecurityContextRepository securityContextRepository;
    private final CsrfTokenRepository csrfTokenRepository;

    public SessionLogin(AuthService authService, SecurityContextRepository securityContextRepository,
                        CsrfTokenRepository csrfTokenRepository) {
        this.authService = authService;
        this.securityContextRepository = securityContextRepository;
        this.csrfTokenRepository = csrfTokenRepository;
    }

    /** Confere e-mail e senha (com as mesmas proteções de tentativas) e abre a sessão. */
    public MeResponse login(String email, String password, HttpServletRequest request, HttpServletResponse response) {
        AuthenticatedUser principal = authService.authenticate(email, password);
        principal.eraseCredentials(); // a sessão guarda só a marca da credencial, nunca o hash da senha

        // Proteção contra fixação de sessão: novo identificador de sessão após autenticar.
        if (request.getSession(false) != null) {
            request.changeSessionId();
        } else {
            request.getSession(true);
        }
        SecurityContext context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(UsernamePasswordAuthenticationToken.authenticated(principal, null, principal.getAuthorities()));
        SecurityContextHolder.setContext(context);
        securityContextRepository.saveContext(context, request, response);

        // Novo token CSRF para a sessão autenticada.
        csrfTokenRepository.saveToken(csrfTokenRepository.generateToken(request), request, response);
        return authService.me(principal.getId());
    }
}
