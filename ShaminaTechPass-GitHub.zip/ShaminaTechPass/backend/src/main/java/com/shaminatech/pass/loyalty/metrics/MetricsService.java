package com.shaminatech.pass.loyalty.metrics;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.loyalty.LoyaltyDtos.CardView;
import com.shaminatech.pass.loyalty.LoyaltyDtos.TransactionView;
import com.shaminatech.pass.loyalty.LoyaltyViews;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.card.CardEnums.TransactionType;
import com.shaminatech.pass.loyalty.card.CardTransaction;
import com.shaminatech.pass.loyalty.card.CardTransactionRepository;
import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.card.LoyaltyCardRepository;
import com.shaminatech.pass.loyalty.consumer.Consumer;
import com.shaminatech.pass.loyalty.consumer.ConsumerRepository;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicy;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.LoyaltyProgramRepository;
import com.shaminatech.pass.loyalty.program.LoyaltyReward;
import com.shaminatech.pass.loyalty.program.LoyaltyRewardRepository;
import com.shaminatech.pass.loyalty.program.ProgramEnums.ProgramStatus;
import com.shaminatech.pass.loyalty.signup.PublicSignupRepository;
import com.shaminatech.pass.loyalty.signup.SignupLinkRepository;
import com.shaminatech.pass.membership.Permission;
import com.shaminatech.pass.tenant.TenantAccessService;

/**
 * Visão geral e indicadores do estabelecimento, calculados somente a partir de dados registrados.
 * <p>
 * Definições (documentadas também na tela):
 * <ul>
 *   <li><b>Visita registrada</b>: concessão (EARN) não estornada;</li>
 *   <li><b>Compra registrada</b>: concessão com valor de compra informado;</li>
 *   <li><b>Cliente recorrente</b>: 2 ou mais visitas no período;</li>
 *   <li><b>Cliente que voltou</b>: teve no período uma visita que não foi a primeira dele (houve visita antes, no período
 *       ou antes dele);</li>
 *   <li><b>Tempo entre visitas</b>: média dos intervalos entre visitas consecutivas do mesmo cliente no período;</li>
 *   <li><b>Cliente recuperado</b>: cliente com visita no período cuja visita anterior tinha ocorrido havia
 *       {@value #RECOVERY_GAP_DAYS} dias ou mais;</li>
 *   <li><b>Cliente inativo</b>: cadastro ativo há {@value #RECOVERY_GAP_DAYS} dias ou mais e nenhuma visita nos últimos
 *       {@value #RECOVERY_GAP_DAYS} dias;</li>
 *   <li><b>Perto da recompensa</b>: cartão ativo com ao menos {@value #NEAR_REWARD_PERCENT}% dos carimbos exigidos ou dos
 *       pontos da recompensa mais barata (inclui quem já pode resgatar).</li>
 * </ul>
 * "Valor das compras informadas" é a soma dos valores digitados pela empresa: não é lucro, e o Pass não afirma
 * que a receita foi gerada pelo programa (não há grupo de comparação).
 */
@Service
public class MetricsService {

    public static final int RECOVERY_GAP_DAYS = 60;
    public static final int NEAR_REWARD_PERCENT = 80;
    static final int MIN_VISITS = 10;
    static final int MIN_CONSUMERS = 3;
    private static final int NEAR_REWARD_LIMIT = 8;

    private final TenantAccessService tenantAccess;
    private final ConsumerRepository consumers;
    private final LoyaltyCardRepository cards;
    private final CardTransactionRepository transactions;
    private final LoyaltyProgramRepository programs;
    private final LoyaltyRewardRepository rewards;
    private final SignupLinkRepository signupLinks;
    private final PublicSignupRepository signups;
    private final PolicyService policies;
    private final LoyaltyViews views;
    private final Clock clock;

    public MetricsService(TenantAccessService tenantAccess, ConsumerRepository consumers, LoyaltyCardRepository cards,
                          CardTransactionRepository transactions, LoyaltyProgramRepository programs,
                          LoyaltyRewardRepository rewards, SignupLinkRepository signupLinks, PublicSignupRepository signups,
                          PolicyService policies, LoyaltyViews views, Clock clock) {
        this.tenantAccess = tenantAccess;
        this.consumers = consumers;
        this.cards = cards;
        this.transactions = transactions;
        this.programs = programs;
        this.rewards = rewards;
        this.signupLinks = signupLinks;
        this.signups = signups;
        this.policies = policies;
        this.views = views;
        this.clock = clock;
    }

    public record CardCounts(long active, long suspended, long expired, long completed, long cancelled) {
    }

    public record BenefitTotals(ProgramType type, long operations, BigDecimal amount) {
    }

    /** Cartão perto (ou já em condição) de resgatar: {@code target} carimbos ou pontos da recompensa mais barata. */
    public record NearReward(Long cardId, Long consumerId, String consumerName, String programName, ProgramType programType,
                             BigDecimal available, BigDecimal target, BigDecimal remaining, boolean ready, String rewardName) {
    }

    public record Overview(long activeConsumers, long totalConsumers, int maxActiveConsumers, int limitUsedPercent,
                           boolean limitReached, CardCounts cards, int periodDays, List<BenefitTotals> benefitsGranted,
                           long rewardsRedeemed, List<TransactionView> recentTransactions, long activePrograms,
                           long totalPrograms, long activeSignupLinks, long selfSignups, List<NearReward> nearReward) {
    }

    public record WeekPoint(Instant start, long visits, long consumers) {
    }

    public record Indicators(int periodDays, Instant from, Instant to, long visits, long purchases, BigDecimal totalPurchaseAmount,
                             long consumersWithVisits, long recurringConsumers, BigDecimal visitsPerConsumer,
                             BigDecimal averageDaysBetweenVisits, long recoveredConsumers, long rewardsRedeemed,
                             boolean sufficientData, List<String> notes, Long programId, Long newConsumers, long selfSignups,
                             long cardsIssued, long returningConsumers, Integer returnRatePercent, long inactiveConsumers,
                             List<BenefitTotals> benefitsGranted, List<BenefitTotals> benefitsRedeemed,
                             List<WeekPoint> weekly) {
    }

    @Transactional(readOnly = true)
    public Overview overview(Long establishmentId) {
        tenantAccess.require(establishmentId, Permission.ESTABLISHMENT_VIEW);
        Instant now = clock.instant();
        EstablishmentPolicy policy = policies.of(establishmentId);
        long active = consumers.countByStatus(establishmentId, Consumer.Status.ACTIVE);
        long total = consumers.countAll(establishmentId);
        int max = policy.getMaxActiveConsumers();
        int percent = max == 0 ? 100 : (int) Math.min(100, Math.round(active * 100.0 / max));

        Map<CardStatus, Long> byStatus = new EnumMap<>(CardStatus.class);
        for (Object[] row : cards.countByStatus(establishmentId)) {
            byStatus.put((CardStatus) row[0], (Long) row[1]);
        }
        long overdue = cards.countOverdueActive(establishmentId, now);
        CardCounts counts = new CardCounts(byStatus.getOrDefault(CardStatus.ACTIVE, 0L) - overdue,
                byStatus.getOrDefault(CardStatus.SUSPENDED, 0L), byStatus.getOrDefault(CardStatus.EXPIRED, 0L) + overdue,
                byStatus.getOrDefault(CardStatus.COMPLETED, 0L), byStatus.getOrDefault(CardStatus.CANCELLED, 0L));

        int days = 30;
        Instant from = now.minus(Duration.ofDays(days));
        List<LoyaltyProgram> programList = programs.findAllInEstablishment(establishmentId);
        Map<Long, ProgramType> typeOf = programList.stream().collect(Collectors.toMap(LoyaltyProgram::getId, LoyaltyProgram::getType));
        List<CardTransaction> earns = transactions.findOfTypeBetween(establishmentId, TransactionType.EARN, from, now);
        List<CardTransaction> redeems = transactions.findOfTypeBetween(establishmentId, TransactionType.REDEEM, from, now);
        var recent = transactions.findInEstablishment(establishmentId, EnumSet.of(TransactionType.EARN, TransactionType.REDEEM,
                        TransactionType.REVERSAL), PageRequest.of(0, 8, Sort.by(Sort.Direction.DESC, "occurredAt", "id")))
                .getContent();
        long activePrograms = programList.stream().filter(LoyaltyProgram::isActive).count();
        long livePrograms = programList.stream().filter(p -> p.getStatus() != ProgramStatus.ARCHIVED).count();
        return new Overview(active, total, max, percent, active >= max, counts, days, totals(earns, typeOf, false), redeems.size(),
                views.transactions(recent), activePrograms, livePrograms, signupLinks.countActive(establishmentId),
                signups.countBetween(establishmentId, from, now), nearReward(establishmentId, programList, now));
    }

    /** Até {@value #NEAR_REWARD_LIMIT} cartões mais perto de resgatar, nos programas de carimbos e pontos ativos. */
    private List<NearReward> nearReward(Long establishmentId, List<LoyaltyProgram> programList, Instant now) {
        var zone = policies.of(establishmentId).zone();
        Map<Long, List<LoyaltyReward>> rewardsByProgram = rewards.findAllInEstablishment(establishmentId).stream()
                .filter(LoyaltyReward::isActive).collect(Collectors.groupingBy(r -> r.getProgram().getId()));
        List<NearReward> result = new ArrayList<>();
        for (LoyaltyProgram p : programList) {
            if (!p.isActive()) {
                continue;
            }
            BigDecimal target;
            String rewardName;
            if (p.getType() == ProgramType.STAMPS && p.getStampsRequired() != null) {
                target = BigDecimal.valueOf(p.getStampsRequired());
                rewardName = p.getStampReward();
            } else if (p.getType() == ProgramType.POINTS && rewardsByProgram.containsKey(p.getId())) {
                LoyaltyReward cheapest = rewardsByProgram.get(p.getId()).stream().min(Comparator.comparing(LoyaltyReward::getCost))
                        .orElseThrow();
                target = cheapest.getCost();
                rewardName = cheapest.getName();
            } else {
                continue;
            }
            BigDecimal threshold = target.multiply(BigDecimal.valueOf(NEAR_REWARD_PERCENT))
                    .divide(BigDecimal.valueOf(100), 2, RoundingMode.CEILING);
            for (LoyaltyCard card : cards.findWithBalanceAtLeast(establishmentId, p.getId(), threshold, now,
                    PageRequest.of(0, 20))) {
                CardView view = views.card(card, zone);
                if (view.status() != CardStatus.ACTIVE || view.availableBalance().compareTo(threshold) < 0) {
                    continue; // saldo inclui benefícios vencidos ainda não processados
                }
                BigDecimal remaining = target.subtract(view.availableBalance()).max(BigDecimal.ZERO);
                result.add(new NearReward(card.getId(), card.getConsumer().getId(), card.getConsumer().getFullName(), p.getName(),
                        p.getType(), view.availableBalance(), target, remaining, remaining.signum() == 0, rewardName));
            }
        }
        result.sort(Comparator.comparing((NearReward n) -> n.remaining().divide(n.target(), 4, RoundingMode.HALF_UP))
                .thenComparing(NearReward::cardId));
        return result.size() > NEAR_REWARD_LIMIT ? List.copyOf(result.subList(0, NEAR_REWARD_LIMIT)) : result;
    }

    @Transactional(readOnly = true)
    public Indicators indicators(Long establishmentId, int periodDays) {
        return indicators(establishmentId, periodDays, null);
    }

    /** {@code programId} opcional: restringe visitas, resgates, cartões e clientes inativos a um programa. */
    @Transactional(readOnly = true)
    public Indicators indicators(Long establishmentId, int periodDays, Long programId) {
        tenantAccess.require(establishmentId, Permission.REPORTS_VIEW);
        if (periodDays < 7 || periodDays > 365) {
            throw ApiException.badRequest("Escolha um período entre 7 e 365 dias.", "days");
        }
        List<LoyaltyProgram> programList = programs.findAllInEstablishment(establishmentId);
        if (programId != null && programList.stream().noneMatch(p -> p.getId().equals(programId))) {
            throw ApiException.notFound("Programa não encontrado.");
        }
        Map<Long, ProgramType> typeOf = programList.stream().collect(Collectors.toMap(LoyaltyProgram::getId, LoyaltyProgram::getType));
        Instant to = clock.instant();
        Instant from = to.minus(Duration.ofDays(periodDays));
        List<CardTransaction> visits = filter(transactions.findOfTypeBetween(establishmentId, TransactionType.EARN, from, to), programId);
        List<CardTransaction> redeems = filter(transactions.findOfTypeBetween(establishmentId, TransactionType.REDEEM, from, to), programId);

        List<CardTransaction> purchases = visits.stream().filter(t -> t.getPurchaseAmount() != null).toList();
        BigDecimal totalAmount = purchases.stream().map(CardTransaction::getPurchaseAmount).reduce(BigDecimal.ZERO, BigDecimal::add);

        Map<Long, List<Instant>> byConsumer = new HashMap<>();
        for (CardTransaction t : visits) {
            byConsumer.computeIfAbsent(t.getConsumerId(), k -> new ArrayList<>()).add(t.getOccurredAt());
        }
        long recurring = byConsumer.values().stream().filter(list -> list.size() >= 2).count();
        long gapCount = 0;
        long gapSeconds = 0;
        for (List<Instant> list : byConsumer.values()) {
            list.sort(Comparator.naturalOrder());
            for (int i = 1; i < list.size(); i++) {
                gapSeconds += Duration.between(list.get(i - 1), list.get(i)).getSeconds();
                gapCount++;
            }
        }

        long recovered = 0;
        long returning = 0;
        if (!byConsumer.isEmpty()) {
            Map<Long, Instant> previousBefore = new HashMap<>();
            for (Object[] row : transactions.lastEarnBefore(establishmentId, programId, from, byConsumer.keySet())) {
                previousBefore.put((Long) row[0], (Instant) row[1]);
            }
            for (var entry : byConsumer.entrySet()) {
                List<Instant> list = entry.getValue();
                Instant previous = previousBefore.get(entry.getKey());
                if (previous != null || list.size() >= 2) {
                    returning++;
                }
                if (isRecovery(previous, list.get(0))) {
                    recovered++;
                    continue;
                }
                for (int i = 1; i < list.size(); i++) {
                    if (isRecovery(list.get(i - 1), list.get(i))) {
                        recovered++;
                        break;
                    }
                }
            }
        }

        Instant inactiveCut = to.minus(Duration.ofDays(RECOVERY_GAP_DAYS));
        long inactive = programId == null ? consumers.countInactiveSince(establishmentId, inactiveCut)
                : consumers.countInactiveSince(establishmentId, programId, inactiveCut);
        Long newConsumers = null;
        if (programId == null) {
            newConsumers = consumers.countRegisteredBetween(establishmentId, from, to).stream().mapToLong(r -> (Long) r[1]).sum();
        }
        long selfSignups = programId == null ? signups.countBetween(establishmentId, from, to)
                : signups.countBetween(establishmentId, programId, from, to);
        long issued = transactions.countIssuedBetween(establishmentId, programId, from, to);

        boolean sufficient = visits.size() >= MIN_VISITS && byConsumer.size() >= MIN_CONSUMERS;
        List<String> notes = new ArrayList<>();
        notes.add("Indicadores calculados apenas com movimentações registradas no Pass (estornos excluídos).");
        notes.add("Valor das compras é o informado manualmente pela empresa ao registrar cada compra: representa faturamento "
                + "informado, não lucro. Compras registradas sem valor não entram na soma.");
        notes.add("O Pass não estima receita incremental: não há grupo de comparação para isolar o efeito do programa.");
        notes.add("Cliente que voltou: teve no período uma visita que não foi a primeira dele.");
        notes.add("Cliente recuperado: voltou após " + RECOVERY_GAP_DAYS + " dias ou mais sem visitas registradas.");
        notes.add("Cliente inativo: cadastro ativo há " + RECOVERY_GAP_DAYS + " dias ou mais sem nenhuma visita nos últimos "
                + RECOVERY_GAP_DAYS + " dias (independe do período escolhido).");
        if (!sufficient) {
            notes.add(0, "Dados insuficientes: são necessárias ao menos " + MIN_VISITS + " visitas de " + MIN_CONSUMERS
                    + " clientes no período para exibir médias, frequência e taxa de retorno.");
        }
        BigDecimal perConsumer = sufficient && !byConsumer.isEmpty()
                ? BigDecimal.valueOf(visits.size()).divide(BigDecimal.valueOf(byConsumer.size()), 2, RoundingMode.HALF_UP) : null;
        BigDecimal avgDays = sufficient && gapCount > 0
                ? BigDecimal.valueOf(gapSeconds).divide(BigDecimal.valueOf(gapCount * 86_400L), 1, RoundingMode.HALF_UP) : null;
        Integer returnRate = sufficient ? (int) Math.round(returning * 100.0 / byConsumer.size()) : null;
        return new Indicators(periodDays, from, to, visits.size(), purchases.size(), totalAmount, byConsumer.size(), recurring,
                perConsumer, avgDays, recovered, redeems.size(), sufficient, notes, programId, newConsumers, selfSignups, issued,
                returning, returnRate, inactive, totals(visits, typeOf, false), totals(redeems, typeOf, true),
                weekly(visits, from, to));
    }

    private static List<CardTransaction> filter(List<CardTransaction> list, Long programId) {
        return programId == null ? list : list.stream().filter(t -> programId.equals(t.getProgramId())).toList();
    }

    /** Totais por tipo de programa. Resgates têm valor negativo no histórico: {@code negate} mostra o valor positivo. */
    private static List<BenefitTotals> totals(List<CardTransaction> list, Map<Long, ProgramType> typeOf, boolean negate) {
        Map<ProgramType, long[]> ops = new EnumMap<>(ProgramType.class);
        Map<ProgramType, BigDecimal> sums = new EnumMap<>(ProgramType.class);
        for (CardTransaction t : list) {
            ProgramType type = typeOf.get(t.getProgramId());
            if (type == null) {
                continue;
            }
            ops.computeIfAbsent(type, k -> new long[1])[0]++;
            sums.merge(type, negate ? t.getAmount().negate() : t.getAmount(), BigDecimal::add);
        }
        List<BenefitTotals> result = new ArrayList<>();
        for (ProgramType type : EnumSet.of(ProgramType.STAMPS, ProgramType.POINTS, ProgramType.CASHBACK)) {
            if (ops.containsKey(type)) {
                result.add(new BenefitTotals(type, ops.get(type)[0], sums.get(type)));
            }
        }
        return result;
    }

    /** Visitas e clientes distintos por semana (blocos de 7 dias a partir do início do período). */
    private static List<WeekPoint> weekly(List<CardTransaction> visits, Instant from, Instant to) {
        List<WeekPoint> points = new ArrayList<>();
        for (Instant start = from; start.isBefore(to); start = start.plus(Duration.ofDays(7))) {
            Instant end = start.plus(Duration.ofDays(7));
            final Instant s = start;
            List<CardTransaction> inWeek = visits.stream()
                    .filter(t -> !t.getOccurredAt().isBefore(s) && t.getOccurredAt().isBefore(end)).toList();
            Set<Long> distinct = new HashSet<>();
            inWeek.forEach(t -> distinct.add(t.getConsumerId()));
            points.add(new WeekPoint(start, inWeek.size(), distinct.size()));
        }
        return points;
    }

    private static boolean isRecovery(Instant previous, Instant current) {
        return previous != null && Duration.between(previous, current).toDays() >= RECOVERY_GAP_DAYS;
    }
}
