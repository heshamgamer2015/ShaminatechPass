package com.shaminatech.pass.loyalty.notify;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.audit.AuditAction;
import com.shaminatech.pass.audit.AuditService;
import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.common.web.PageResponse;
import com.shaminatech.pass.establishment.EstablishmentRepository;
import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.card.LoyaltyCardRepository;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.Capability;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.IntegrationView;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.LocationRequest;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.LocationView;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.Overview;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.ReminderView;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.SettingsRequest;
import com.shaminatech.pass.loyalty.notify.NotificationDtos.SettingsView;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.LoyaltyProgramRepository;
import com.shaminatech.pass.loyalty.wallet.ProgramChangedEvent;
import com.shaminatech.pass.loyalty.wallet.WalletSyncService;
import com.shaminatech.pass.loyalty.wallet.apple.AppleWalletGateway;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletApi;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletProperties;
import com.shaminatech.pass.membership.Permission;
import com.shaminatech.pass.tenant.TenantAccessService;

/**
 * Painel "Notificações e Proximidade": configurações de lembretes, localizações da loja e histórico de pedidos.
 * Localizações também podem ser mantidas pela ShaminaTech (painel administrativo), sem passar pelo tenant.
 */
@Service
public class NotificationService {

    static final Set<Integer> POINTS_PERCENTS = Set.of(5, 10, 20);
    static final Set<Integer> EXPIRY_DAYS = Set.of(2, 3, 5, 7);
    private static final Set<String> UFS = Set.of("AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA",
            "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO");
    private static final Sort NEWEST = Sort.by(Sort.Direction.DESC, "plannedAt", "id");

    private final TenantAccessService tenantAccess;
    private final NotificationSettingsRepository settings;
    private final EstablishmentLocationRepository locations;
    private final WalletReminderRepository reminders;
    private final LoyaltyCardRepository cards;
    private final LoyaltyProgramRepository programs;
    private final EstablishmentRepository establishments;
    private final GoogleWalletApi google;
    private final GoogleWalletProperties googleProperties;
    private final AppleWalletGateway apple;
    private final ApplicationEventPublisher events;
    private final AuditService audit;
    private final Clock clock;

    public NotificationService(TenantAccessService tenantAccess, NotificationSettingsRepository settings,
                               EstablishmentLocationRepository locations, WalletReminderRepository reminders, LoyaltyCardRepository cards,
                               LoyaltyProgramRepository programs, EstablishmentRepository establishments, GoogleWalletApi google,
                               GoogleWalletProperties googleProperties, AppleWalletGateway apple, ApplicationEventPublisher events,
                               AuditService audit, Clock clock) {
        this.tenantAccess = tenantAccess;
        this.settings = settings;
        this.locations = locations;
        this.reminders = reminders;
        this.cards = cards;
        this.programs = programs;
        this.establishments = establishments;
        this.google = google;
        this.googleProperties = googleProperties;
        this.apple = apple;
        this.events = events;
        this.audit = audit;
        this.clock = clock;
    }

    // ---------------- Painel do estabelecimento ----------------

    @Transactional
    public Overview overview(Long establishmentId) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        NotificationSettings s = settingsFor(establishmentId);
        Instant since = clock.instant().minus(Duration.ofDays(30));
        Map<WalletReminder.Status, Long> counts = new EnumMap<>(WalletReminder.Status.class);
        for (Object[] row : reminders.countByStatusSince(establishmentId, since)) {
            counts.put((WalletReminder.Status) row[0], (Long) row[1]);
        }
        List<ReminderView> failures = reminders.findInEstablishment(establishmentId,
                        EnumSet.of(WalletReminder.Status.FAILED, WalletReminder.Status.REJECTED, WalletReminder.Status.QUOTA_EXCEEDED),
                        PageRequest.of(0, 5, NEWEST)).getContent().stream().map(this::view).toList();
        List<LocationView> locationViews = locations.findByEstablishment(establishmentId).stream().map(NotificationService::view).toList();
        boolean googleOk = google.configured();
        return new Overview(view(s), locationViews, EstablishmentLocation.MAX_PER_ESTABLISHMENT,
                new IntegrationView(googleOk, googleProperties.missing(), apple.configured()),
                capabilities(googleOk, apple.configured(), s, locationViews.size()), counts, failures, notes());
    }

    @Transactional
    public SettingsView updateSettings(Long establishmentId, SettingsRequest r) {
        tenantAccess.require(establishmentId, Permission.PROGRAMS_MANAGE);
        if (!POINTS_PERCENTS.contains(r.nearRewardPointsPercent())) {
            throw ApiException.badRequest("Escolha 5%, 10% ou 20%.", "nearRewardPointsPercent");
        }
        if (!EXPIRY_DAYS.contains(r.expiryDaysBefore())) {
            throw ApiException.badRequest("Escolha 2, 3, 5 ou 7 dias.", "expiryDaysBefore");
        }
        if (r.proximityEnabled() && locations.countByEstablishment(establishmentId) == 0) {
            throw ApiException.rule("LOCATION_REQUIRED", "Cadastre ao menos uma localização da loja antes de ativar a proximidade.",
                    "proximityEnabled");
        }
        NotificationSettings s = settingsFor(establishmentId);
        String text = r.proximityText() == null || r.proximityText().isBlank() ? null : r.proximityText().trim();
        boolean proximityChanged = s.isProximityEnabled() != r.proximityEnabled() || !Objects.equals(s.getProximityText(), text);
        s.update(r.nearRewardEnabled(), r.nearRewardStamps(), r.nearRewardPointsPercent(), r.expiryEnabled(), r.expiryDaysBefore(),
                r.inactivityEnabled(), r.inactivityDays(), r.minIntervalDays(), r.proximityEnabled(), text);
        audit.record(AuditAction.NOTIFICATION_SETTINGS_CHANGED, establishmentId, "NOTIFICATION_SETTINGS", s.getId(),
                "recompensa=" + r.nearRewardEnabled() + " vencimento=" + r.expiryEnabled() + " inatividade=" + r.inactivityEnabled()
                        + " proximidade=" + r.proximityEnabled() + " intervalo=" + r.minIntervalDays() + "d");
        if (proximityChanged) {
            resyncPrograms(establishmentId);
        }
        return view(s);
    }

    @Transactional(readOnly = true)
    public PageResponse<ReminderView> history(Long establishmentId, WalletReminder.Status status, Pageable pageable) {
        tenantAccess.require(establishmentId, Permission.CONSUMERS_VIEW);
        Set<WalletReminder.Status> filter = status == null ? EnumSet.allOf(WalletReminder.Status.class) : EnumSet.of(status);
        return PageResponse.of(reminders.findInEstablishment(establishmentId, filter, pageable), this::view);
    }

    @Transactional
    public LocationView saveLocation(Long establishmentId, Long locationId, LocationRequest r) {
        tenantAccess.require(establishmentId, Permission.ESTABLISHMENT_EDIT);
        return save(establishmentId, locationId, r);
    }

    @Transactional
    public void deleteLocation(Long establishmentId, Long locationId) {
        tenantAccess.require(establishmentId, Permission.ESTABLISHMENT_EDIT);
        delete(establishmentId, locationId);
    }

    // ---------------- Administração ShaminaTech (/api/admin/**) ----------------

    @Transactional(readOnly = true)
    public List<LocationView> adminLocations(Long establishmentId) {
        requireEstablishment(establishmentId);
        return locations.findByEstablishment(establishmentId).stream().map(NotificationService::view).toList();
    }

    @Transactional
    public LocationView adminSaveLocation(Long establishmentId, Long locationId, LocationRequest r) {
        requireEstablishment(establishmentId);
        return save(establishmentId, locationId, r);
    }

    @Transactional
    public void adminDeleteLocation(Long establishmentId, Long locationId) {
        requireEstablishment(establishmentId);
        delete(establishmentId, locationId);
    }

    // ---------------- Apoio ----------------

    private LocationView save(Long establishmentId, Long locationId, LocationRequest r) {
        validateCoordinates(r.latitude(), r.longitude());
        String uf = r.state().trim().toUpperCase(Locale.ROOT);
        if (!UFS.contains(uf)) {
            throw ApiException.badRequest("UF inválida.", "state");
        }
        EstablishmentLocation location;
        if (locationId == null) {
            if (locations.countByEstablishment(establishmentId) >= EstablishmentLocation.MAX_PER_ESTABLISHMENT) {
                throw ApiException.rule("LOCATION_LIMIT", "O limite é de " + EstablishmentLocation.MAX_PER_ESTABLISHMENT
                        + " localizações (limite das carteiras digitais).", null);
            }
            location = new EstablishmentLocation(establishmentId);
        } else {
            location = locations.findInEstablishment(establishmentId, locationId)
                    .orElseThrow(() -> ApiException.notFound("Localização não encontrada."));
        }
        location.update(r.name().trim(), r.addressLine().trim(), r.city().trim(), uf, r.postalCode().replaceAll("\\D", ""),
                round(r.latitude()), round(r.longitude()));
        locations.save(location);
        audit.record(AuditAction.ESTABLISHMENT_LOCATION_SAVED, establishmentId, "ESTABLISHMENT_LOCATION", location.getId(), null);
        resyncIfProximity(establishmentId);
        return view(location);
    }

    private void delete(Long establishmentId, Long locationId) {
        EstablishmentLocation location = locations.findInEstablishment(establishmentId, locationId)
                .orElseThrow(() -> ApiException.notFound("Localização não encontrada."));
        locations.delete(location);
        locations.flush();
        audit.record(AuditAction.ESTABLISHMENT_LOCATION_REMOVED, establishmentId, "ESTABLISHMENT_LOCATION", locationId, null);
        NotificationSettings s = settings.findByEstablishmentId(establishmentId).orElse(null);
        if (s != null && s.isProximityEnabled() && locations.countByEstablishment(establishmentId) == 0) {
            // Sem nenhuma localização, a proximidade é desligada (a lista vazia remove os pontos das carteiras).
            s.update(s.isNearRewardEnabled(), s.getNearRewardStamps(), s.getNearRewardPointsPercent(), s.isExpiryEnabled(),
                    s.getExpiryDaysBefore(), s.isInactivityEnabled(), s.getInactivityDays(), s.getMinIntervalDays(), false,
                    s.getProximityText());
        }
        resyncIfProximity(establishmentId);
    }

    /**
     * Coordenadas: faixa válida, não (0, 0) — valor típico de campo não preenchido — e dentro do território brasileiro
     * (endereço com CEP e UF). Até 6 casas decimais (~10 cm).
     */
    static void validateCoordinates(Double latitude, Double longitude) {
        if (latitude == null || longitude == null || latitude.isNaN() || longitude.isNaN()) {
            throw ApiException.badRequest("Informe latitude e longitude.", "latitude");
        }
        if (latitude < -90 || latitude > 90) {
            throw ApiException.badRequest("Latitude entre -90 e 90.", "latitude");
        }
        if (longitude < -180 || longitude > 180) {
            throw ApiException.badRequest("Longitude entre -180 e 180.", "longitude");
        }
        if (latitude == 0 && longitude == 0) {
            throw ApiException.badRequest("Coordenadas (0, 0) não são de um endereço: confira os valores.", "latitude");
        }
        if (latitude < -34.0 || latitude > 5.5 || longitude < -74.1 || longitude > -28.6) {
            throw ApiException.badRequest("As coordenadas estão fora do Brasil. Confira se latitude e longitude não estão trocadas.",
                    "latitude");
        }
    }

    private static double round(double v) {
        return Math.round(v * 1_000_000d) / 1_000_000d;
    }

    private void resyncIfProximity(Long establishmentId) {
        NotificationSettings s = settings.findByEstablishmentId(establishmentId).orElse(null);
        if (s != null && s.isProximityPublished()) {
            resyncPrograms(establishmentId);
        }
    }

    /** Reenvia classes e passes do estabelecimento (só dados de exibição; saldo e validade não mudam). */
    private void resyncPrograms(Long establishmentId) {
        for (LoyaltyProgram p : programs.findAllInEstablishment(establishmentId)) {
            events.publishEvent(new ProgramChangedEvent(p.getId()));
        }
    }

    private NotificationSettings settingsFor(Long establishmentId) {
        return settings.findByEstablishmentId(establishmentId).orElseGet(() -> settings.save(new NotificationSettings(establishmentId)));
    }

    private void requireEstablishment(Long establishmentId) {
        if (!establishments.existsById(establishmentId)) {
            throw ApiException.notFound("Estabelecimento não encontrado.");
        }
    }

    private static List<Capability> capabilities(boolean google, boolean apple, NotificationSettings s, int locationCount) {
        List<Capability> list = new ArrayList<>();
        list.add(new Capability("GOOGLE_MESSAGES", "Avisos no Google Wallet (mensagem com notificação)", google, google
                ? "O Pass pede ao Google que grave a mensagem no cartão e avise o celular (até 3 avisos por cartão a cada 24 h, "
                + "regra do Google). O Google não informa se o aviso apareceu ou foi lido."
                : "Indisponível: a integração Google Wallet não está configurada pela ShaminaTech."));
        list.add(new Capability("GOOGLE_PROXIMITY", "Proximidade no Google Wallet (merchantLocations)", google && locationCount > 0,
                locationCount == 0 ? "Cadastre ao menos uma localização da loja."
                        : "O Google decide a distância, o tempo de permanência e o texto do aviso; exige que o cliente tenha "
                        + "notificações e localização precisa sempre ativas para o app Google Wallet."));
        list.add(new Capability("APPLE_PROXIMITY", "Proximidade no Apple Wallet (locations do cartão)", apple && locationCount > 0,
                apple ? "O iPhone decide quando mostrar o cartão na tela de bloqueio perto da loja."
                        : "Preparado no Pass, mas depende da conta Apple Developer, do certificado e de HTTPS (Etapa 4)."));
        list.add(new Capability("APPLE_MESSAGES", "Mensagens promocionais no Apple Wallet", false,
                "Não disponível: o aviso da Apple apenas pede ao iPhone que baixe o cartão atualizado; não é um canal de campanhas."));
        list.add(new Capability("CUSTOM_RADIUS", "Raio de proximidade configurável", false,
                "Não existe: o Google e a Apple definem a distância."));
        return list;
    }

    private static List<String> notes() {
        return List.of(
                "Atualizar o saldo no cartão, pedir um aviso ao Google, o aviso aparecer no celular e o cliente estar perto da loja "
                        + "são coisas diferentes: o Pass só registra o que faz (o pedido) e a resposta do Google (aceito ou recusado).",
                "\"Aceito\" significa que o Google gravou a mensagem no cartão. Entrega e leitura não são informadas pelo Google.",
                "Avisos são enviados só entre 9h e 20h (horário do estabelecimento), no máximo 1 por cartão a cada 24 h.",
                "Se o cliente fizer uma compra antes do envio, o aviso pendente é descartado; avisos já gravados que ficaram "
                        + "desatualizados são retirados do cartão na próxima sincronização.",
                "Lembretes de inatividade vão só para clientes que aceitaram receber comunicações do estabelecimento.",
                "Lembretes e proximidade não renovam a validade: só compras ou resgates confirmados renovam.",
                "O Pass não recebe nem guarda a localização dos clientes: publica apenas o endereço da loja no cartão.");
    }

    private static SettingsView view(NotificationSettings s) {
        return new SettingsView(s.isNearRewardEnabled(), s.getNearRewardStamps(), s.getNearRewardPointsPercent(), s.isExpiryEnabled(),
                s.getExpiryDaysBefore(), s.isInactivityEnabled(), s.getInactivityDays(), s.getMinIntervalDays(), s.isProximityEnabled(),
                s.getProximityText());
    }

    private static LocationView view(EstablishmentLocation l) {
        return new LocationView(l.getId(), l.getName(), l.getAddressLine(), l.getCity(), l.getState(), l.getPostalCode(),
                l.getLatitude(), l.getLongitude());
    }

    private ReminderView view(WalletReminder r) {
        LoyaltyCard card = cards.findInEstablishment(r.getEstablishmentId(), r.getCardId()).orElse(null);
        return new ReminderView(r.getId(), r.getCategory(), r.getStatus(), r.getHeader(), r.getBody(), r.getCardId(),
                card == null ? null : WalletSyncService.firstName(card.getConsumer().getFullName()),
                card == null ? null : card.getProgram().getName(), r.getPlannedAt(), r.getLastAttemptAt(), r.getAcceptedAt(),
                r.getWithdrawnAt(), r.getAttempts(), r.getNextAttemptAt(), r.getClosedReason(), r.getLastError(), r.getLastErrorStatus());
    }
}
