package com.shaminatech.pass.loyalty.card;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * Agenda o {@link ExpirationProcessor}. Desligável com {@code shaminatech.loyalty.expiration.enabled=false}
 * (os testes desligam e chamam o processador diretamente com um relógio controlado).
 */
@Configuration
@EnableScheduling
@ConditionalOnProperty(prefix = "shaminatech.loyalty.expiration", name = "enabled", havingValue = "true", matchIfMissing = true)
public class ExpirationScheduler {

    private final ExpirationProcessor processor;

    public ExpirationScheduler(ExpirationProcessor processor) {
        this.processor = processor;
    }

    @Scheduled(initialDelayString = "PT1M", fixedDelayString = "${shaminatech.loyalty.expiration.interval:PT10M}")
    public void run() {
        processor.run();
    }
}
