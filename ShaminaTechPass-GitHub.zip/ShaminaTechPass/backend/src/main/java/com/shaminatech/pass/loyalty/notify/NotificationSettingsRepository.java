package com.shaminatech.pass.loyalty.notify;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import jakarta.persistence.LockModeType;

public interface NotificationSettingsRepository extends JpaRepository<NotificationSettings, Long> {

    Optional<NotificationSettings> findByEstablishmentId(Long establishmentId);

    /** Serializa o planejamento de lembretes do estabelecimento (dois processos não planejam ao mesmo tempo). */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select s from NotificationSettings s where s.establishmentId = :establishmentId")
    Optional<NotificationSettings> lockByEstablishmentId(@Param("establishmentId") Long establishmentId);

    @Query("""
            select s.establishmentId from NotificationSettings s
            where s.nearRewardEnabled = true or s.expiryEnabled = true or s.inactivityEnabled = true
            order by s.establishmentId
            """)
    List<Long> findEstablishmentsWithReminders();
}
