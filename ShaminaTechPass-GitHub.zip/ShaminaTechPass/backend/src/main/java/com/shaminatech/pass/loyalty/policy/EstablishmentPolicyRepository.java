package com.shaminatech.pass.loyalty.policy;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import jakarta.persistence.LockModeType;

public interface EstablishmentPolicyRepository extends JpaRepository<EstablishmentPolicy, Long> {

    @Query("select p from EstablishmentPolicy p where p.establishment.id = :establishmentId")
    Optional<EstablishmentPolicy> findByEstablishmentId(@Param("establishmentId") Long establishmentId);

    /**
     * Trava a linha da política (SELECT ... FOR UPDATE). Serializa as ativações de consumidores do
     * mesmo estabelecimento, impedindo que requisições concorrentes ultrapassem o limite.
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select p from EstablishmentPolicy p where p.establishment.id = :establishmentId")
    Optional<EstablishmentPolicy> lockByEstablishmentId(@Param("establishmentId") Long establishmentId);

    @Query("select p from EstablishmentPolicy p where p.establishment.id in :ids")
    List<EstablishmentPolicy> findByEstablishmentIds(@Param("ids") Collection<Long> ids);

    @Query("select e.id from Establishment e where not exists (select 1 from EstablishmentPolicy p where p.establishment = e)")
    List<Long> findEstablishmentIdsWithoutPolicy();
}
