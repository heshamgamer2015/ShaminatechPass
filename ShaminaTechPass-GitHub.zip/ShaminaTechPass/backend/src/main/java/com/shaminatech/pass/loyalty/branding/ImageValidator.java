package com.shaminatech.pass.loyalty.branding;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

import org.springframework.stereotype.Component;

import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.loyalty.policy.LoyaltyProperties;

/**
 * Validação de imagens enviadas:
 * <ol>
 *   <li>tamanho máximo do arquivo;</li>
 *   <li>tipo detectado pelos bytes iniciais (assinatura), nunca pela extensão ou pelo Content-Type do navegador;
 *       apenas PNG e JPEG (SVG é recusado por poder conter scripts);</li>
 *   <li>dimensões lidas do cabeçalho <b>antes</b> de decodificar (evita "bombas" de descompressão);</li>
 *   <li>decodificação completa e recodificação: o arquivo armazenado é gerado pelo servidor, sem metadados.</li>
 * </ol>
 */
@Component
public class ImageValidator {

    public record ValidImage(String contentType, byte[] data, int width, int height, String sha256) {
    }

    private final LoyaltyProperties.Images limits;

    public ImageValidator(LoyaltyProperties properties) {
        this.limits = properties.images();
    }

    public ValidImage validate(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            throw ApiException.badRequest("Selecione uma imagem.", "file");
        }
        if (bytes.length > limits.maxBytes()) {
            throw ApiException.badRequest("A imagem deve ter no máximo " + (limits.maxBytes() / 1024) + " KB.", "file");
        }
        String format = sniff(bytes);
        if (format == null) {
            throw ApiException.badRequest("Formato não permitido. Envie PNG ou JPEG.", "file");
        }
        int[] size = readDimensions(bytes);
        int width = size[0];
        int height = size[1];
        if (width < limits.minDimension() || height < limits.minDimension()) {
            throw ApiException.badRequest("A imagem deve ter pelo menos " + limits.minDimension() + " px de largura e altura.", "file");
        }
        if (width > limits.maxDimension() || height > limits.maxDimension()) {
            throw ApiException.badRequest("A imagem deve ter no máximo " + limits.maxDimension() + " px de largura e altura.", "file");
        }
        BufferedImage image;
        try {
            image = ImageIO.read(new ByteArrayInputStream(bytes));
        } catch (IOException | RuntimeException e) {
            image = null;
        }
        if (image == null) {
            throw ApiException.badRequest("Não foi possível ler a imagem. O arquivo pode estar corrompido.", "file");
        }
        byte[] reencoded = reencode(image, format);
        return new ValidImage(format.equals("png") ? "image/png" : "image/jpeg", reencoded, width, height, sha256(reencoded));
    }

    /** Assinaturas: PNG = 89 50 4E 47 0D 0A 1A 0A; JPEG = FF D8 FF. */
    static String sniff(byte[] b) {
        if (b.length >= 8 && (b[0] & 0xFF) == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G'
                && b[4] == 0x0D && b[5] == 0x0A && b[6] == 0x1A && b[7] == 0x0A) {
            return "png";
        }
        if (b.length >= 3 && (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xD8 && (b[2] & 0xFF) == 0xFF) {
            return "jpeg";
        }
        return null;
    }

    private static int[] readDimensions(byte[] bytes) {
        try (ImageInputStream in = ImageIO.createImageInputStream(new ByteArrayInputStream(bytes))) {
            Iterator<ImageReader> readers = ImageIO.getImageReaders(in);
            if (!readers.hasNext()) {
                throw ApiException.badRequest("Formato não permitido. Envie PNG ou JPEG.", "file");
            }
            ImageReader reader = readers.next();
            try {
                reader.setInput(in, true, true);
                return new int[] {reader.getWidth(0), reader.getHeight(0)};
            } finally {
                reader.dispose();
            }
        } catch (IOException e) {
            throw ApiException.badRequest("Não foi possível ler a imagem. O arquivo pode estar corrompido.", "file");
        }
    }

    private static byte[] reencode(BufferedImage source, String format) {
        BufferedImage target = source;
        if (format.equals("jpeg") && source.getType() != BufferedImage.TYPE_INT_RGB) {
            target = new BufferedImage(source.getWidth(), source.getHeight(), BufferedImage.TYPE_INT_RGB);
            Graphics2D g = target.createGraphics();
            g.drawImage(source, 0, 0, java.awt.Color.WHITE, null);
            g.dispose();
        }
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (!ImageIO.write(target, format, out)) {
                throw ApiException.badRequest("Não foi possível processar a imagem.", "file");
            }
            return out.toByteArray();
        } catch (IOException e) {
            throw ApiException.badRequest("Não foi possível processar a imagem.", "file");
        }
    }

    private static String sha256(byte[] data) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
