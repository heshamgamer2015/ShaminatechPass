package com.shaminatech.pass.loyalty.policy;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.establishment.EstablishmentRepository;

/**
 * Ajustes de dados da Etapa 2, sempre aditivos e seguros para rodar a cada inicialização:
 * <ul>
 *   <li>cria as regras padrão da plataforma, se não existirem;</li>
 *   <li>cria a política (limites) dos estabelecimentos que ainda não têm uma, usando as regras padrão;</li>
 *   <li>preenche {@code membership.account_slot} da conta empresarial de cada estabelecimento que tenha
 *       exatamente um vínculo OWNER ativo. Estabelecimentos com mais de um são só registrados em log:
 *       nenhum vínculo é apagado ou alterado automaticamente.</li>
 * </ul>
 */
@Component
@Order(2)
public class LoyaltyStartupInitializer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(LoyaltyStartupInitializer.class);

    private final PolicyService policyService;
    private final EstablishmentPolicyRepository policies;
    private final EstablishmentRepository establishments;
    private final JdbcTemplate jdbc;

    public LoyaltyStartupInitializer(PolicyService policyService, EstablishmentPolicyRepository policies,
                                     EstablishmentRepository establishments, JdbcTemplate jdbc) {
        this.policyService = policyService;
        this.policies = policies;
        this.establishments = establishments;
        this.jdbc = jdbc;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        policyService.defaults();
        for (Long id : policies.findEstablishmentIdsWithoutPolicy()) {
            policyService.createFor(establishments.getReferenceById(id));
            log.info("Política de fidelidade criada com as regras padrão para o estabelecimento {}", id);
        }
        int filled = jdbc.update("""
                update membership set account_slot = establishment_id
                where role = 'OWNER' and status = 'ACTIVE' and account_slot is null
                  and (select count(*) from membership o
                       where o.establishment_id = membership.establishment_id
                         and o.role = 'OWNER' and o.status = 'ACTIVE') = 1
                  and not exists (select 1 from membership x where x.account_slot = membership.establishment_id)
                """);
        if (filled > 0) {
            log.info("Conta empresarial marcada em {} estabelecimento(s).", filled);
        }
        List<Long> ambiguous = jdbc.queryForList("""
                select establishment_id from membership where role = 'OWNER' and status = 'ACTIVE'
                group by establishment_id having count(*) > 1
                """, Long.class);
        if (!ambiguous.isEmpty()) {
            log.warn("Estabelecimentos com mais de uma conta OWNER ativa (revisar manualmente): {}", ambiguous);
        }
    }
}
