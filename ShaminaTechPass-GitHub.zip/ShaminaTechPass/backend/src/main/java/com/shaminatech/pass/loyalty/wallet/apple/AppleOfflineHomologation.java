package com.shaminatech.pass.loyalty.wallet.apple;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Clock;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;

import tools.jackson.databind.json.JsonMapper;

/**
 * <b>Homologação local</b>: gera um único passe Apple Wallet <i>offline</i> de demonstração da própria ShaminaTech,
 * assinado com o certificado oficial, para testar instalação e aparência no iPhone.
 * <p>
 * Isolado do fluxo normal: só existe no perfil {@code local}. Usado pela página de homologação do painel ShaminaTech
 * ({@link AppleHomologationController}, arquivo em memória) e, se {@code shaminatech.wallet.apple.homologation.output-dir}
 * for informada explicitamente, também gera um arquivo nessa pasta ao iniciar. Não lê nem grava o banco
 * (nenhum cartão, saldo ou movimentação é tocado), não registra o passe e não usa o web service. O passe sai
 * <b>sem</b> {@code webServiceURL} e {@code authenticationToken} — por isso nunca é atualizado remotamente.
 * Os passes atualizáveis continuam exigindo {@link AppleWalletProperties#missing()} completo (HTTPS público e segredo).
 */
@Component
@Profile("local")
public class AppleOfflineHomologation implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(AppleOfflineHomologation.class);
    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyyMMddHHmmss").withZone(ZoneOffset.UTC);

    private final AppleWalletProperties properties;
    private final AppleImages images;
    private final JsonMapper json;
    private final Clock clock;
    private final Path outputDir;

    /** Passe gerado em memória. */
    public record Generated(String serialNumber, byte[] data, String sha256) {
    }

    public AppleOfflineHomologation(AppleWalletProperties properties, AppleImages images, JsonMapper json, Clock clock,
                                    @Value("${shaminatech.wallet.apple.homologation.output-dir:}") String outputDir) {
        this.properties = properties;
        this.images = images;
        this.json = json;
        this.clock = clock;
        this.outputDir = outputDir == null || outputDir.isBlank() ? null : Path.of(outputDir);
    }

    @Override
    public void run(ApplicationArguments args) {
        if (outputDir == null) {
            return; // sem pasta informada: só a página de homologação gera passes
        }
        try {
            Path file = generate();
            log.info("Homologação Apple Wallet: passe offline de demonstração gerado em {}", file);
        } catch (RuntimeException e) {
            // Só a mensagem: nunca o conteúdo de credenciais.
            log.error("Homologação Apple Wallet: passe offline não gerado — {}", e.getMessage());
        }
    }

    /** Gera o passe em memória. Falha (sem gerar nada) se faltar certificado, identificadores ou suporte. */
    public Generated build() {
        List<String> missing = properties.missingForOfflinePass();
        if (!missing.isEmpty()) {
            throw new AppleWalletException(0, "Configuração incompleta para o passe offline: " + String.join(" ", missing), false);
        }
        AppleCredentials credentials = AppleCredentials.load(properties);
        String serial = serial();
        Map<String, Object> passJson = ApplePassMapper.passJson(demoData(properties, serial));
        Map<String, byte[]> files = images.passImages(null, null, null, null); // marca ShaminaTech (ícone padrão)
        byte[] pkpass = PkpassBuilder.build(passJson, files, credentials, json);
        Generated generated = new Generated(serial, pkpass, sha256(pkpass));
        log.info("Homologação Apple Wallet: serial {}, {} bytes, SHA-256 {}", serial, pkpass.length, generated.sha256());
        return generated;
    }

    /** Gera o passe e grava na pasta configurada; devolve o caminho. */
    public Path generate() {
        if (outputDir == null) {
            throw new AppleWalletException(0, "Pasta de saída da homologação não configurada.", false);
        }
        Generated generated = build();
        try {
            Files.createDirectories(outputDir);
            Path file = outputDir.resolve("shaminatech-pass-demo-" + generated.serialNumber() + ".pkpass");
            Files.write(file, generated.data());
            return file;
        } catch (IOException e) {
            throw new AppleWalletException(0, "Não foi possível gravar o passe em " + outputDir + ".", false);
        }
    }

    /** Dados de demonstração da própria ShaminaTech — nenhum consumidor nem estabelecimento real. */
    static ApplePassMapper.PassData demoData(AppleWalletProperties p, String serial) {
        String code = "DEMO-" + serial.substring(serial.length() - 8).toUpperCase();
        return new ApplePassMapper.PassData(serial, p.passTypeIdentifier(), p.teamIdentifier(), null, null,
                "ShaminaTech Pass", "Demonstração", "#F43F5E", "#FFFFFF", CardStatus.ACTIVE, ProgramType.POINTS,
                new BigDecimal("120"), null, "Demonstração", code, "SHAMINATECH-" + code, null, null, null,
                "Cartão de demonstração para homologação técnica do Apple Wallet. Sem valor comercial.", null,
                "Programa de demonstração da própria ShaminaTech; não pertence a nenhum estabelecimento.",
                p.supportEmail(), null, p.supportName(), p.supportEmail(), p.supportPhone(), p.supportAddress());
    }

    /** Único por geração: data/hora UTC + 8 bytes aleatórios. */
    private String serial() {
        byte[] random = new byte[8];
        new SecureRandom().nextBytes(random);
        return "stp-homolog-" + STAMP.format(clock.instant()) + "-" + HexFormat.of().formatHex(random);
    }

    private static String sha256(byte[] data) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
