package com.shaminatech.pass.loyalty.signup;

import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.loyalty.signup.SignupDtos.SignupInfo;
import com.shaminatech.pass.loyalty.signup.SignupDtos.SignupRequest;
import com.shaminatech.pass.loyalty.signup.SignupDtos.SignupResult;

import jakarta.validation.Valid;

/** QR Code de cadastro: painel (autenticado, por tenant) e página pública do consumidor. */
@RestController
public class SignupController {

    private final SignupLinkService links;
    private final PublicSignupService signup;

    public SignupController(SignupLinkService links, PublicSignupService signup) {
        this.links = links;
        this.signup = signup;
    }

    public record ActiveRequest(boolean active) {
    }

    // ---------------- Painel ----------------

    @GetMapping("/api/establishments/{establishmentId}/signup-links")
    public SignupLinkService.Overview list(@PathVariable Long establishmentId) {
        return links.list(establishmentId);
    }

    @PostMapping("/api/establishments/{establishmentId}/programs/{programId}/signup-link")
    public ResponseEntity<SignupLinkService.LinkView> create(@PathVariable Long establishmentId, @PathVariable Long programId) {
        return ResponseEntity.status(HttpStatus.CREATED).body(links.create(establishmentId, programId));
    }

    @PostMapping("/api/establishments/{establishmentId}/signup-links/{linkId}/status")
    public SignupLinkService.LinkView status(@PathVariable Long establishmentId, @PathVariable Long linkId,
                                             @RequestBody ActiveRequest body) {
        return links.setActive(establishmentId, linkId, body.active());
    }

    @PostMapping("/api/establishments/{establishmentId}/signup-links/{linkId}/regenerate")
    public SignupLinkService.LinkView regenerate(@PathVariable Long establishmentId, @PathVariable Long linkId) {
        return links.regenerate(establishmentId, linkId);
    }

    /** Imagem do QR Code (SVG para impressão nítida, PNG para compartilhar). {@code download=true} baixa o arquivo. */
    @GetMapping("/api/establishments/{establishmentId}/signup-links/{linkId}/qr")
    public ResponseEntity<byte[]> qr(@PathVariable Long establishmentId, @PathVariable Long linkId,
                                     @RequestParam(defaultValue = "svg") String format,
                                     @RequestParam(defaultValue = "false") boolean download) {
        String url = links.url(establishmentId, linkId);
        boolean png = switch (format) {
            case "png" -> true;
            case "svg" -> false;
            default -> throw ApiException.badRequest("Formato inválido (use svg ou png).", "format");
        };
        byte[] body = png ? QrCodes.png(url, 1024) : QrCodes.svg(url).getBytes(java.nio.charset.StandardCharsets.UTF_8);
        return ResponseEntity.ok()
                .contentType(png ? MediaType.IMAGE_PNG : MediaType.parseMediaType("image/svg+xml"))
                .cacheControl(CacheControl.noStore())
                .header("X-Content-Type-Options", "nosniff")
                .header(HttpHeaders.CONTENT_DISPOSITION, (download ? "attachment" : "inline")
                        + "; filename=\"qr-cadastro." + (png ? "png" : "svg") + "\"")
                .body(body);
    }

    // ---------------- Público ----------------

    @GetMapping("/api/public/signup/{token}")
    public ResponseEntity<SignupInfo> info(@PathVariable String token) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).header("Referrer-Policy", "no-referrer")
                .body(signup.info(token));
    }

    @PostMapping("/api/public/signup/{token}")
    public ResponseEntity<SignupResult> register(@PathVariable String token, @Valid @RequestBody SignupRequest body) {
        return ResponseEntity.status(HttpStatus.CREATED).cacheControl(CacheControl.noStore())
                .header("Referrer-Policy", "no-referrer").body(signup.register(token, body));
    }
}
