package com.shaminatech.pass.user;

import com.shaminatech.pass.common.persistence.EnumNameConverter;

import jakarta.persistence.Converter;

public enum UserStatus {
    ACTIVE,
    DISABLED;

    @Converter(autoApply = true)
    public static class JpaConverter extends EnumNameConverter<UserStatus> {
        public JpaConverter() {
            super(UserStatus.class);
        }
    }
}
