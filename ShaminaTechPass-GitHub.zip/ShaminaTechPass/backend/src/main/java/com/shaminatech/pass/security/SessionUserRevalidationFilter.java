package com.shaminatech.pass.security;

import java.io.IOException;
import java.util.Optional;
import java.util.Set;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import com.shaminatech.pass.user.AppUser;
import com.shaminatech.pass.user.AppUserRepository;

/**
 * A cada requisição autenticada, confere o usuário no banco:
 * <ul>
 *   <li>conta removida, desativada, com papel de plataforma alterado ou com senha trocada em outra sessão → encerra a
 *       sessão (401);</li>
 *   <li>troca de senha obrigatória → bloqueia tudo exceto os endpoints necessários para trocá-la (403).</li>
 * </ul>
 * Assim, desativações e mudanças de papel valem imediatamente, sem esperar a sessão expirar.
 */
public class SessionUserRevalidationFilter extends OncePerRequestFilter {

    private static final Set<String> ALLOWED_WHILE_PASSWORD_CHANGE_REQUIRED = Set.of(
            "/api/auth/me", "/api/auth/change-password", "/api/auth/logout", "/api/auth/csrf", "/api/health");

    private final AppUserRepository users;

    public SessionUserRevalidationFilter(AppUserRepository users) {
        this.users = users;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        Optional<AuthenticatedUser> principal = CurrentUser.optional();
        if (principal.isPresent()) {
            Optional<AppUser> user = users.findById(principal.get().getId());
            if (user.isEmpty() || !user.get().isActive() || user.get().getPlatformRole() != principal.get().getPlatformRole()
                    || !credentialStillValid(principal.get(), user.get())) {
                SecurityContextHolder.clearContext();
                HttpSession session = request.getSession(false);
                if (session != null) {
                    session.invalidate();
                }
                ProblemResponses.write(response, HttpStatus.UNAUTHORIZED, "SESSION_REVOKED", "Sua sessão foi encerrada. Faça login novamente.");
                return;
            }
            String path = request.getRequestURI().substring(request.getContextPath().length());
            if (user.get().isPasswordChangeRequired() && !ALLOWED_WHILE_PASSWORD_CHANGE_REQUIRED.contains(path)) {
                ProblemResponses.write(response, HttpStatus.FORBIDDEN, "PASSWORD_CHANGE_REQUIRED", "Altere sua senha para continuar.");
                return;
            }
        }
        chain.doFilter(request, response);
    }

    /** A senha mudou depois do login desta sessão (troca pelo usuário, nova senha temporária ou recuperação)? */
    private static boolean credentialStillValid(AuthenticatedUser principal, AppUser user) {
        String stamp = principal.getCredentialStamp();
        return stamp != null && stamp.equals(AuthenticatedUser.stampOf(user.getPasswordHash()));
    }
}
