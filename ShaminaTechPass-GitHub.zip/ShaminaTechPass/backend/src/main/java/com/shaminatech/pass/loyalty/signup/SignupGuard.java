package com.shaminatech.pass.loyalty.signup;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Clock;
import java.util.HexFormat;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.shaminatech.pass.common.error.ApiException;

/**
 * Proteções do formulário público de cadastro, sem serviço externo (não há CAPTCHA):
 * <ul>
 *   <li><b>Formulário assinado</b>: a página recebe um token com o instante de abertura assinado por HMAC-SHA256.
 *       Envios sem token válido, enviados rápido demais (robôs) ou com o formulário aberto há muito tempo são recusados;</li>
 *   <li><b>Campo isca</b> ({@code website}): invisível para pessoas; preenchido = robô;</li>
 *   <li><b>Tentativas por IP</b>: janela fixa de 1 hora, além do limite geral por minuto de {@code /api/public/**}.</li>
 * </ul>
 * A chave do HMAC vem da configuração ou é sorteada a cada inicialização (formulários abertos antes de reiniciar
 * pedem para recarregar a página). Contadores em memória: suficiente para uma instância.
 */
@Component
public class SignupGuard {

    private record Window(long hour, int count) {
    }

    private final Clock clock;
    private final byte[] secret;
    private final long minFillMillis;
    private final long validityMillis;
    private final int maxAttemptsPerHour;
    private final Map<String, Window> attempts = new ConcurrentHashMap<>();

    public SignupGuard(Clock clock,
                       @Value("${shaminatech.public.signup.form-secret:}") String configuredSecret,
                       @Value("${shaminatech.public.signup.min-fill-seconds:3}") int minFillSeconds,
                       @Value("${shaminatech.public.signup.form-validity-minutes:120}") int validityMinutes,
                       @Value("${shaminatech.public.signup.max-attempts-per-ip-per-hour:20}") int maxAttemptsPerHour) {
        this.clock = clock;
        if (configuredSecret != null && configuredSecret.length() >= 32) {
            this.secret = configuredSecret.getBytes(StandardCharsets.UTF_8);
        } else {
            this.secret = new byte[32];
            new SecureRandom().nextBytes(this.secret);
        }
        this.minFillMillis = minFillSeconds * 1000L;
        this.validityMillis = validityMinutes * 60_000L;
        this.maxAttemptsPerHour = maxAttemptsPerHour;
    }

    /** Token do formulário para o link: "instante.assinatura". */
    public String issueFormToken(String linkToken) {
        long now = clock.millis();
        return now + "." + sign(linkToken + "|" + now);
    }

    public void verifyFormToken(String linkToken, String formToken) {
        if (formToken == null || !formToken.matches("^\\d{10,15}\\.[0-9a-f]{64}$")) {
            throw expired();
        }
        String[] parts = formToken.split("\\.");
        long issued = Long.parseLong(parts[0]);
        String expected = sign(linkToken + "|" + issued);
        if (!MessageDigest.isEqual(expected.getBytes(StandardCharsets.US_ASCII), parts[1].getBytes(StandardCharsets.US_ASCII))) {
            throw expired();
        }
        long age = clock.millis() - issued;
        if (age < 0 || age > validityMillis) {
            throw expired();
        }
        if (age < minFillMillis) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "SIGNUP_TOO_FAST",
                    "Confira seus dados e toque em confirmar novamente.");
        }
    }

    /** Conta uma tentativa de envio do IP; acima do limite, recusa (429). */
    public void countAttempt(String ip) {
        long hour = clock.millis() / 3_600_000L;
        String key = ip == null ? "?" : ip;
        Window window = attempts.merge(key, new Window(hour, 1),
                (old, fresh) -> old.hour() == hour ? new Window(hour, old.count() + 1) : fresh);
        if (attempts.size() > 10_000) {
            attempts.entrySet().removeIf(e -> e.getValue().hour() < hour);
        }
        if (window.count() > maxAttemptsPerHour) {
            throw new ApiException(HttpStatus.TOO_MANY_REQUESTS, "RATE_LIMITED",
                    "Muitas tentativas a partir desta conexão. Aguarde um pouco ou peça ajuda no balcão.");
        }
    }

    private String sign(String value) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret, "HmacSHA256"));
            return HexFormat.of().formatHex(mac.doFinal(value.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private static ApiException expired() {
        return new ApiException(HttpStatus.BAD_REQUEST, "SIGNUP_FORM_EXPIRED",
                "O formulário expirou. Recarregue a página e preencha novamente.");
    }
}
