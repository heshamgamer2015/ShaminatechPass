package com.shaminatech.pass.loyalty.policy;

import java.util.Set;

import com.shaminatech.pass.common.persistence.BaseEntity;
import com.shaminatech.pass.loyalty.ProgramType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

/** Regras padrão da plataforma, aplicadas a cada novo estabelecimento (registro único). */
@Entity
@Table(name = "platform_loyalty_defaults")
public class PlatformLoyaltyDefaults extends BaseEntity {

    @Column(name = "max_active_consumers", nullable = false)
    private int maxActiveConsumers;

    @Column(name = "default_inactivity_days", nullable = false)
    private int defaultInactivityDays;

    @Column(name = "time_zone", nullable = false, length = 60)
    private String timeZone;

    @Column(name = "allowed_program_types", nullable = false, length = 100)
    private String allowedProgramTypes;

    protected PlatformLoyaltyDefaults() {
    }

    public PlatformLoyaltyDefaults(int maxActiveConsumers, int defaultInactivityDays, String timeZone, Set<ProgramType> types) {
        update(maxActiveConsumers, defaultInactivityDays, timeZone, types);
    }

    public final void update(int maxActiveConsumers, int defaultInactivityDays, String timeZone, Set<ProgramType> types) {
        this.maxActiveConsumers = maxActiveConsumers;
        this.defaultInactivityDays = defaultInactivityDays;
        this.timeZone = timeZone;
        this.allowedProgramTypes = ProgramType.join(types);
    }

    public int getMaxActiveConsumers() {
        return maxActiveConsumers;
    }

    public int getDefaultInactivityDays() {
        return defaultInactivityDays;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public Set<ProgramType> getAllowedProgramTypes() {
        return ProgramType.parse(allowedProgramTypes);
    }

    public String describe() {
        return "limite=" + maxActiveConsumers + ", tipos=" + allowedProgramTypes + ", inatividade="
                + defaultInactivityDays + "d, fuso=" + timeZone;
    }
}
