package com.shaminatech.pass.loyalty.wallet.google;

/**
 * Falha em chamada ao Google. {@code retryable}: falha temporária (rede, tempo esgotado, 408/429/5xx) que o
 * processamento tenta de novo sozinho; as demais (400/401/403/404...) exigem correção e reenvio manual.
 * A mensagem é curta e não contém credenciais.
 */
public class WalletApiException extends RuntimeException {

    private final int status;
    private final boolean retryable;

    public WalletApiException(int status, String message, boolean retryable) {
        super(message);
        this.status = status;
        this.retryable = retryable;
    }

    public static boolean isRetryableStatus(int status) {
        return status == 408 || status == 429 || status >= 500;
    }

    /** 0 = sem resposta HTTP (rede/tempo esgotado). */
    public int status() {
        return status;
    }

    public boolean retryable() {
        return retryable;
    }
}
