package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.time.Instant;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletMapper;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletMapper.ObjectData;
import com.shaminatech.pass.loyalty.wallet.google.ServiceAccountCredentials;

import tools.jackson.databind.json.JsonMapper;

/** Mapeamento para o formato do Google Wallet e manuseio seguro da chave (sem rede). */
class GoogleWalletUnitTest {

    private static ObjectData data(ProgramType type, String balance, CardStatus status) {
        return new ObjectData("1.obj", "1.cls", status, "Ana", "ABCD-EFGH-JKMN-PQRS", "ABCDEFGHJKMNPQRS", type,
                new BigDecimal(balance), 10, Instant.parse("2026-12-06T02:59:59Z"), "05/12/2026 23:59", null, null);
    }

    @Test
    @SuppressWarnings("unchecked")
    void balancesUseTheRightGoogleTypes() {
        Map<String, Object> points = (Map<String, Object>) GoogleWalletMapper.loyaltyObject(data(ProgramType.POINTS, "120.00",
                CardStatus.ACTIVE)).get("loyaltyPoints");
        assertThat(points).containsEntry("label", "Pontos").containsEntry("balance", Map.of("int", 120));

        Map<String, Object> cashback = (Map<String, Object>) GoogleWalletMapper.loyaltyObject(data(ProgramType.CASHBACK, "5.99",
                CardStatus.ACTIVE)).get("loyaltyPoints");
        assertThat(cashback.get("balance")).isEqualTo(Map.of("money", Map.of("micros", 5_990_000L, "currencyCode", "BRL")));

        Map<String, Object> stamps = (Map<String, Object>) GoogleWalletMapper.loyaltyObject(data(ProgramType.STAMPS, "3.00",
                CardStatus.ACTIVE)).get("loyaltyPoints");
        assertThat(stamps.get("balance")).isEqualTo(Map.of("string", "3 de 10"));
    }

    @Test
    void cardStatesAreNotConfusedWithEachOther() {
        assertThat(GoogleWalletMapper.state(CardStatus.ACTIVE)).isEqualTo("ACTIVE");
        // Desativado continua visível no Google Wallet (ACTIVE), marcado como "Bloqueado".
        assertThat(GoogleWalletMapper.state(CardStatus.SUSPENDED)).isEqualTo("ACTIVE");
        Map<String, Object> blocked = GoogleWalletMapper.loyaltyObject(data(ProgramType.POINTS, "1", CardStatus.SUSPENDED));
        assertThat(blocked.get("secondaryLoyaltyPoints").toString()).contains("Situação", "Bloqueado");
        assertThat(blocked.get("textModulesData").toString()).contains("Cartão bloqueado");
        Map<String, Object> active = GoogleWalletMapper.loyaltyObject(data(ProgramType.POINTS, "1", CardStatus.ACTIVE));
        assertThat(active.get("secondaryLoyaltyPoints").toString()).contains("Ativo");
        assertThat(active.get("textModulesData").toString()).doesNotContain("Cartão bloqueado");
        assertThat(GoogleWalletMapper.state(CardStatus.EXPIRED)).isEqualTo("EXPIRED");
        assertThat(GoogleWalletMapper.state(CardStatus.COMPLETED)).isEqualTo("COMPLETED");
        assertThat(GoogleWalletMapper.state(CardStatus.CANCELLED)).isEqualTo("INACTIVE");
        // Validade por inatividade vai como validTimeInterval; cartão concluído/cancelado não tem validade a exibir.
        assertThat(GoogleWalletMapper.loyaltyObject(data(ProgramType.POINTS, "1", CardStatus.ACTIVE))).containsKey("validTimeInterval");
        assertThat(GoogleWalletMapper.loyaltyObject(data(ProgramType.POINTS, "1", CardStatus.CANCELLED))).doesNotContainKey("validTimeInterval");
    }

    @Test
    void privateKeyNeverAppearsInToString() throws Exception {
        FakeGoogleWallet fake = FakeGoogleWallet.get();
        ServiceAccountCredentials creds = ServiceAccountCredentials.load(fake.keyFile(), JsonMapper.builder().build());
        assertThat(creds.clientEmail()).isEqualTo(FakeGoogleWallet.CLIENT_EMAIL);
        assertThat(creds.toString()).doesNotContain("PRIVATE").contains("oculta");
        assertThat(Files.readString(fake.keyFile())).contains("PRIVATE KEY"); // o arquivo de teste é temporário
    }
}
