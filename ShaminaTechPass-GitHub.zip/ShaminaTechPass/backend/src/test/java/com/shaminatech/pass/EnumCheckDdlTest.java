package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataBuilder;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.dialect.PostgreSQLDialect;
import org.hibernate.tool.schema.spi.SchemaManagementToolCoordinator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.util.ClassUtils;

import com.shaminatech.pass.common.persistence.EnumCheckFreeTypeContributor;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEnums;

import jakarta.persistence.Converter;
import jakarta.persistence.Entity;

/**
 * Gera o DDL de criação de TODAS as tabelas para PostgreSQL (sem banco, só o script), como aconteceria com uma
 * tabela nova. Prova a causa (sem o contribuidor o Hibernate gera CHECK de enum) e a correção (com ele, não gera).
 */
class EnumCheckDdlTest {

    @TempDir
    Path dir;

    private String postgresDdl(boolean withContributor) throws Exception {
        StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .applySetting("hibernate.dialect", PostgreSQLDialect.class.getName())
                .applySetting("hibernate.boot.allow_jdbc_metadata_access", false)
                .build();
        try {
            MetadataSources sources = new MetadataSources(registry);
            var scanner = new ClassPathScanningCandidateComponentProvider(false);
            scanner.addIncludeFilter(new AnnotationTypeFilter(Entity.class));
            scanner.addIncludeFilter(new AnnotationTypeFilter(Converter.class));
            for (var candidate : scanner.findCandidateComponents("com.shaminatech.pass")) {
                sources.addAnnotatedClass(ClassUtils.resolveClassName(candidate.getBeanClassName(), getClass().getClassLoader()));
            }
            MetadataBuilder builder = sources.getMetadataBuilder();
            if (withContributor) {
                builder.applyTypes(new EnumCheckFreeTypeContributor());
            }
            Metadata metadata = builder.build();
            Path file = dir.resolve(withContributor ? "com.sql" : "sem.sql");
            Map<String, Object> settings = new HashMap<>(registry.getService(
                    org.hibernate.engine.config.spi.ConfigurationService.class).getSettings());
            settings.put("jakarta.persistence.schema-generation.database.action", "none");
            settings.put("jakarta.persistence.schema-generation.scripts.action", "create");
            settings.put("jakarta.persistence.schema-generation.scripts.create-target", file.toString());
            settings.put("hibernate.hbm2ddl.delimiter", ";");
            SchemaManagementToolCoordinator.process(metadata, registry, settings, action -> { });
            return Files.readString(file).toLowerCase(Locale.ROOT);
        } finally {
            StandardServiceRegistryBuilder.destroy(registry);
        }
    }

    @Test
    void withoutTheContributorHibernateGeneratesEnumChecks() throws Exception {
        String ddl = postgresDdl(false);
        assertThat(ddl).contains("check (").contains("'login_succeeded'");
    }

    @Test
    void enumColumnsAreGeneratedWithoutChecksForNewTables() throws Exception {
        String ddl = postgresDdl(true);
        assertThat(ddl).doesNotContain("check (").doesNotContain("check(");
        // Enums continuam como texto legível.
        assertThat(ddl).containsPattern("create table audit_event \\([^;]*action varchar\\(60\\) not null");
        assertThat(ddl).containsPattern("create table loyalty_card \\([^;]*status varchar\\(20\\) not null");
        // Restrições de integridade que importam continuam sendo geradas.
        assertThat(ddl).contains("uk_card_tx_idempotency", "uk_card_tx_reverses", "uk_membership_account_slot",
                "uk_consumer_establishment_phone", "fk_loyalty_card_consumer", "numeric(14,2) not null");
    }

    @Test
    void everyPersistedEnumIsCovered() {
        var covered = new EnumCheckFreeTypeContributor().enums();
        assertThat(covered).contains(ProgramType.class, CardEnums.CardStatus.class, CardEnums.TransactionType.class,
                com.shaminatech.pass.audit.AuditAction.class, com.shaminatech.pass.membership.MembershipRole.class);
        assertThat(covered).hasSize(26); // 26 enums distintos (MembershipRole e CardStatus aparecem em duas tabelas cada; Etapa 6: ReminderCategory e WalletReminder.Status; autocadastro: Plan, EstablishmentPlan.Origin e AccessStatus)
    }
}
