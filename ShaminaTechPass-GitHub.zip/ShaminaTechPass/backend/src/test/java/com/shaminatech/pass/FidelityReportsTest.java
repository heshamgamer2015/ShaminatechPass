package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.jayway.jsonpath.JsonPath;

/** Indicadores de fidelização (Etapa 5): filtro por programa, retorno, recuperados, inativos, perto da recompensa. */
class FidelityReportsTest extends LoyaltyTestSupport {

    @Test
    void returnRecoveryAndProgramFilterUseOnlyRecordedVisits() throws Exception {
        long stamps = stampsProgram(a, ownerA, 10, true);
        long points = pointsProgram(a, ownerA, "");
        long ana = consumer(ownerA, a, "Ana", "11910000001");
        long bia = consumer(ownerA, a, "Bia", "11910000002");
        long caio = consumer(ownerA, a, "Caio", "11910000003");
        long anaStamps = card(ownerA, a, ana, stamps);
        long biaStamps = card(ownerA, a, bia, stamps);
        long caioPoints = card(ownerA, a, caio, points);

        // Ana: visita antiga (há 70 dias) e volta agora -> recuperada e "voltou".
        earn(ownerA, a, anaStamps, "{}", key()).andExpect(status().isCreated());
        clock.advance(Duration.ofDays(70));
        // o cartão venceu por inatividade (30 dias): reativa antes de registrar
        postJson(ownerA, base(a) + "/cards/" + anaStamps + "/reactivate", "{}").andExpect(status().isOk());
        postJson(ownerA, base(a) + "/cards/" + biaStamps + "/reactivate", "{}").andExpect(status().isOk());
        postJson(ownerA, base(a) + "/cards/" + caioPoints + "/reactivate", "{}").andExpect(status().isOk());
        earn(ownerA, a, anaStamps, "{}", key()).andExpect(status().isCreated());
        // Bia: primeira visita no período -> não "voltou".
        earn(ownerA, a, biaStamps, "{}", key()).andExpect(status().isCreated());
        // Caio: duas compras no programa de pontos, uma estornada.
        earn(ownerA, a, caioPoints, "{\"purchaseAmount\":40.00}", key()).andExpect(status().isCreated());
        long reversed = ((Number) read(earn(ownerA, a, caioPoints, "{\"purchaseAmount\":99.00}", key()), "$.transaction.id")).longValue();
        postJson(ownerA, base(a) + "/transactions/" + reversed + "/reverse", "{\"reason\":\"erro\"}", key()).andExpect(status().isCreated());

        String all = getJson(ownerA, base(a) + "/indicators?days=30");
        assertThat((Integer) JsonPath.read(all, "$.visits")).isEqualTo(3);
        assertThat((Integer) JsonPath.read(all, "$.consumersWithVisits")).isEqualTo(3);
        assertThat((Integer) JsonPath.read(all, "$.returningConsumers")).isEqualTo(1);
        assertThat((Integer) JsonPath.read(all, "$.recoveredConsumers")).isEqualTo(1);
        assertThat((Object) JsonPath.read(all, "$.returnRatePercent")).isNull(); // poucos dados: sem taxa
        assertThat(JsonPath.read(all, "$.totalPurchaseAmount").toString()).isEqualTo("40.0");
        assertThat((Integer) JsonPath.read(all, "$.newConsumers")).isZero(); // cadastrados há 70 dias
        List<Map<String, Object>> weekly = JsonPath.read(all, "$.weekly");
        assertThat(weekly.stream().mapToInt(w -> ((Number) w.get("visits")).intValue()).sum()).isEqualTo(3);
        List<Map<String, Object>> granted = JsonPath.read(all, "$.benefitsGranted");
        assertThat(granted).extracting(m -> m.get("type")).containsExactlyInAnyOrder("STAMPS", "POINTS");
        assertThat(all).contains("informado manualmente");

        String onlyStamps = getJson(ownerA, base(a) + "/indicators?days=30&programId=" + stamps);
        assertThat((Integer) JsonPath.read(onlyStamps, "$.visits")).isEqualTo(2);
        assertThat((Integer) JsonPath.read(onlyStamps, "$.consumersWithVisits")).isEqualTo(2);
        assertThat((Integer) JsonPath.read(onlyStamps, "$.returningConsumers")).isEqualTo(1);
        assertThat((Object) JsonPath.read(onlyStamps, "$.newConsumers")).isNull();
        // Em 365 dias as duas visitas da Ana estão no período: o intervalo de 70 dias entre elas a torna recuperada.
        String year = getJson(ownerA, base(a) + "/indicators?days=365&programId=" + stamps);
        assertThat((Integer) JsonPath.read(year, "$.visits")).isEqualTo(3);
        assertThat((Integer) JsonPath.read(year, "$.recoveredConsumers")).isEqualTo(1);
        assertThat((Integer) JsonPath.read(year, "$.cardsIssued")).isEqualTo(2);

        // Programa de outro estabelecimento e período inválido.
        long other = stampsProgram(b, ownerB, 5, true);
        mvc.perform(get(base(a) + "/indicators?days=30&programId=" + other).session(ownerA)).andExpect(status().isNotFound());
        mvc.perform(get(base(a) + "/indicators?days=3").session(ownerA)).andExpect(status().isBadRequest());
    }

    @Test
    void inactiveConsumersAndNearRewardAreReported() throws Exception {
        long stamps = stampsProgram(a, ownerA, 5, true);
        long quiet = consumer(ownerA, a, "Silencioso", "11920000001");
        card(ownerA, a, quiet, stamps);
        clock.advance(Duration.ofDays(61));
        long near = card(ownerA, a, consumer(ownerA, a, "Quase Lá", "11920000002"), stamps);
        long far = card(ownerA, a, consumer(ownerA, a, "Longe", "11920000003"), stamps);
        earn(ownerA, a, near, "{\"quantity\":4}", key()).andExpect(status().isCreated());
        earn(ownerA, a, far, "{\"quantity\":1}", key()).andExpect(status().isCreated());

        String indicators = getJson(ownerA, base(a) + "/indicators?days=30");
        assertThat((Integer) JsonPath.read(indicators, "$.inactiveConsumers")).isEqualTo(1);
        assertThat((Integer) JsonPath.read(indicators, "$.newConsumers")).isEqualTo(2);

        String overview = getJson(ownerA, base(a) + "/overview");
        List<Map<String, Object>> list = JsonPath.read(overview, "$.nearReward");
        assertThat(list).hasSize(1);
        assertThat(list.get(0).get("consumerName")).isEqualTo("Quase Lá");
        assertThat(list.get(0).get("remaining").toString()).isEqualTo("1.0");
        assertThat((Integer) JsonPath.read(overview, "$.activePrograms")).isEqualTo(1);

        // Completo: aparece como pronto para resgatar.
        earn(ownerA, a, near, "{\"quantity\":1}", key()).andExpect(status().isCreated());
        List<Map<String, Object>> after = JsonPath.read(getJson(ownerA, base(a) + "/overview"), "$.nearReward");
        assertThat(after.get(0).get("ready")).isEqualTo(true);
        // Isolamento: B não vê nada de A.
        assertThat((List<?>) JsonPath.read(getJson(ownerB, base(b) + "/overview"), "$.nearReward")).isEmpty();
    }
}
