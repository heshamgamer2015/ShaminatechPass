package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Duration;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;

import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletApi;
import com.shaminatech.pass.loyalty.wallet.google.GoogleWalletProperties;

import tools.jackson.databind.json.JsonMapper;

/**
 * Teste REAL (opcional) contra a API oficial do Google Wallet: autentica com a conta de serviço e faz uma consulta
 * somente leitura de um objeto que não existe. Não cria classes nem objetos.
 * <ul>
 *   <li>sucesso = token OAuth obtido e emissor acessível (listagem de classes respondeu 200);</li>
 *   <li>401/403 = credencial recusada ou conta de serviço sem permissão no Wallet Console;</li>
 *   <li>404 "Issuer ... not found" = ID do emissor incorreto ou ainda não vinculado à Google Wallet API.</li>
 * </ul>
 * Nenhum valor fica no repositório; o caminho da chave e o emissor vêm da linha de comando:
 * <pre>mvn test -Dtest=GoogleWalletRealIT -Dpass.google-real=true -Dpass.google.key-file=C:\caminho\chave.json -Dpass.google.issuer-id=123</pre>
 */
@EnabledIfSystemProperty(named = "pass.google-real", matches = "true")
class GoogleWalletRealIT {

    @Test
    void authenticatesAndReadsWithoutCreatingAnything() {
        String keyFile = System.getProperty("pass.google.key-file");
        String issuerId = System.getProperty("pass.google.issuer-id");
        assertThat(keyFile).as("-Dpass.google.key-file").isNotBlank();
        assertThat(issuerId).as("-Dpass.google.issuer-id").matches("\\d+");
        assertThat(Files.isRegularFile(Path.of(keyFile))).as("arquivo da chave existe").isTrue();

        GoogleWalletProperties properties = new GoogleWalletProperties(true, issuerId, keyFile,
                List.of("http://localhost:4203"), null, null, "BR", null, null, Duration.ofSeconds(10),
                Duration.ofSeconds(20), null, null, false);
        GoogleWalletApi api = new GoogleWalletApi(properties, JsonMapper.builder().build(), Clock.systemUTC());

        // 1) Emissor acessível: lista as classes (pode ser vazia). Lança WalletApiException em 401/403/404.
        var classes = api.listClasses();
        System.out.println("[GoogleWalletRealIT] emissor acessível; classes existentes: " + classes.size());

        // 2) Objeto inexistente responde 404 (leitura; nada é criado).
        assertThat(api.getObject(issuerId + ".connectivity-check-nao-existe")).isEmpty();

        // 3) Opcional: mostra o estado de um objeto já emitido (-Dpass.google.object-id=...), só leitura.
        String objectId = System.getProperty("pass.google.object-id");
        if (objectId != null && !objectId.isBlank()) {
            var object = api.getObject(objectId).orElseThrow();
            System.out.println("[GoogleWalletRealIT] objeto " + objectId + ": state=" + object.get("state")
                    + " hasUsers=" + object.get("hasUsers") + " validTimeInterval=" + object.get("validTimeInterval")
                    + " loyaltyPoints=" + object.get("loyaltyPoints"));
        }
    }
    /**
     * Envio REAL de UM aviso (addMessage + TEXT_AND_NOTIFY) a um objeto já existente, só com autorização explícita:
     * <pre>-Dpass.google.send-test-message=true -Dpass.google.object-id=EMISSOR.objeto</pre>
     * A mensagem é marcada como teste, não altera saldo nem validade e some dos detalhes do cartão após 24 h.
     * Sucesso significa apenas que o Google ACEITOU o pedido; a exibição do aviso só é confirmada no celular.
     */
    @Test
    @EnabledIfSystemProperty(named = "pass.google.send-test-message", matches = "true")
    void sendsOneAuthorizedTestMessage() {
        String keyFile = System.getProperty("pass.google.key-file");
        String issuerId = System.getProperty("pass.google.issuer-id");
        String objectId = System.getProperty("pass.google.object-id");
        assertThat(objectId).as("-Dpass.google.object-id").startsWith(issuerId + ".");
        GoogleWalletProperties properties = new GoogleWalletProperties(true, issuerId, keyFile,
                List.of("http://localhost:4203"), null, null, "BR", null, null, Duration.ofSeconds(10),
                Duration.ofSeconds(20), null, null, false);
        GoogleWalletApi api = new GoogleWalletApi(properties, JsonMapper.builder().build(), Clock.systemUTC());
        java.time.Instant now = java.time.Instant.now();
        java.util.Map<String, Object> message = new java.util.LinkedHashMap<>();
        message.put("id", "stp_test_" + now.getEpochSecond());
        message.put("header", "Teste ShaminaTech Pass");
        message.put("body", "Aviso de teste autorizado pelo estabelecimento. Nenhuma ação é necessária.");
        message.put("messageType", "TEXT_AND_NOTIFY");
        message.put("displayInterval", java.util.Map.of(
                "start", java.util.Map.of("date", now.toString()),
                "end", java.util.Map.of("date", now.plus(Duration.ofHours(24)).toString())));
        api.addObjectMessage(objectId, message);
        System.out.println("[GoogleWalletRealIT] pedido de aviso ACEITO pelo Google para " + objectId + " (id " + message.get("id")
                + "). Confirme no celular se o aviso apareceu.");
    }
}
