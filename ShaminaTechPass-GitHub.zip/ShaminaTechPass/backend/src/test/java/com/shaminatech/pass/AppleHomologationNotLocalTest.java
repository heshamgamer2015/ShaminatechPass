package com.shaminatech.pass;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpSession;

/** Fora do perfil local a homologação Apple Wallet não existe: nem página do painel nem link público. */
class AppleHomologationNotLocalTest extends IntegrationTestSupport {

    @Test
    void homologationEndpointsDoNotExistOutsideTheLocalProfile() throws Exception {
        platformAdmin("admin@teste.local");
        MockHttpSession admin = login("admin@teste.local");
        mvc.perform(get("/api/admin/apple-wallet/homologation").session(admin)).andExpect(status().isNotFound());
        mvc.perform(post("/api/admin/apple-wallet/homologation/passes").session(admin).with(csrf())).andExpect(status().isNotFound());
        mvc.perform(get("/api/public/apple-wallet-homologation/" + "A".repeat(43))).andExpect(status().isNotFound());
    }
}
