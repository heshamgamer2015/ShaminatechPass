package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.ResultActions;

import com.jayway.jsonpath.JsonPath;
import com.shaminatech.pass.loyalty.notify.ProximityService;
import com.shaminatech.pass.loyalty.notify.ReminderPlanner;
import com.shaminatech.pass.loyalty.notify.ReminderSender;
import com.shaminatech.pass.loyalty.wallet.WalletPass;
import com.shaminatech.pass.loyalty.wallet.WalletPassRepository;

/**
 * Lembretes (Google Wallet SIMULADO) e proximidade: elegibilidade, vencimento, renovação antes/depois do envio,
 * frequência, duplicidade, concorrência, falhas da API, consentimento, isolamento, coordenadas e localizações.
 * Nenhuma chamada real ao Google.
 */
class NotificationRemindersTest extends LoyaltyTestSupport {

    @DynamicPropertySource
    static void wallet(DynamicPropertyRegistry registry) {
        FakeGoogleWallet fake = FakeGoogleWallet.get();
        registry.add("shaminatech.wallet.google.enabled", () -> "true");
        registry.add("shaminatech.wallet.google.issuer-id", () -> FakeGoogleWallet.ISSUER_ID);
        registry.add("shaminatech.wallet.google.service-account-key-file", () -> fake.keyFile().toString());
        registry.add("shaminatech.wallet.google.origins", () -> "http://localhost:4203");
        registry.add("shaminatech.wallet.google.api-base-url", fake::baseUrl);
        registry.add("shaminatech.wallet.google.fallback-logo-uri", () -> "https://example.test/logo-padrao.png");
        registry.add("shaminatech.wallet.google.public-base-url", () -> "https://pass.example.test");
        registry.add("shaminatech.wallet.google.async-dispatch", () -> "false");
        registry.add("shaminatech.wallet.google.request-timeout", () -> "PT1S");
        registry.add("shaminatech.wallet.google.max-attempts", () -> "3");
    }

    @Autowired
    private ReminderPlanner planner;
    @Autowired
    private ReminderSender sender;
    @Autowired
    private WalletPassRepository passes;
    @Autowired
    private ProximityService proximity;

    private final FakeGoogleWallet google = FakeGoogleWallet.get();
    private long program;
    private long card;

    @BeforeEach
    void setUpCard() throws Exception {
        google.reset();
        program = stampsProgram(a, ownerA, 10, true); // 30 dias de validade, fim do dia
        card = card(ownerA, a, consumer(ownerA, a, "Joana Prado", "11977771111"), program);
        createLink(card);
    }

    // ---------------- apoio ----------------

    private void createLink(long cardId) throws Exception {
        postJson(ownerA, base(a) + "/cards/" + cardId + "/wallet/links", "{}").andExpect(status().isCreated());
    }

    private ResultActions settings(MockHttpSession session, String eBase, String json) throws Exception {
        return mvc.perform(put(eBase + "/notifications/settings").session(session).with(csrf())
                .contentType(MediaType.APPLICATION_JSON).content(json));
    }

    private static String settingsJson(boolean nearReward, int stamps, boolean expiry, int expiryDays, boolean inactivity,
                                       int inactivityDays, int interval, boolean proximity) {
        return "{\"nearRewardEnabled\":" + nearReward + ",\"nearRewardStamps\":" + stamps + ",\"nearRewardPointsPercent\":10,"
                + "\"expiryEnabled\":" + expiry + ",\"expiryDaysBefore\":" + expiryDays + ",\"inactivityEnabled\":" + inactivity
                + ",\"inactivityDays\":" + inactivityDays + ",\"minIntervalDays\":" + interval + ",\"proximityEnabled\":" + proximity
                + ",\"proximityText\":\"Loja aqui perto\"}";
    }

    private String objectId(long cardId) {
        return passes.findByCardIdAndProvider(cardId, WalletPass.Provider.GOOGLE_WALLET).orElseThrow().getExternalId();
    }

    private List<Map<String, Object>> reminders() {
        return jdbc.queryForList("select * from wallet_reminder order by id");
    }

    private String reminderStatus() {
        return jdbc.queryForObject("select status from wallet_reminder order by id desc limit 1", String.class);
    }

    private static String location(String name, double lat, double lon) {
        return "{\"name\":\"" + name + "\",\"addressLine\":\"Av. Paulista, 1000\",\"city\":\"São Paulo\",\"state\":\"sp\","
                + "\"postalCode\":\"01310-100\",\"latitude\":" + lat + ",\"longitude\":" + lon + "}";
    }

    // ---------------- recompensa próxima ----------------

    @Test
    void nearRewardIsRequestedOnceWithTruthfulText() throws Exception {
        settings(ownerA, base(a), settingsJson(true, 1, false, 3, false, 60, 7, false)).andExpect(status().isOk());
        earn(ownerA, a, card, "{\"quantity\":8}", key()).andExpect(status().isCreated());
        assertThat(planner.planAll()).isZero(); // faltam 2: fora do critério (1)
        earn(ownerA, a, card, "{\"quantity\":1}", key()).andExpect(status().isCreated());
        Instant expiresBefore = jdbc.queryForObject("select expires_at from loyalty_card where id = ?", Instant.class, card);

        assertThat(planner.planAll()).isEqualTo(1);
        assertThat(sender.dispatchDue()).isEqualTo(1);
        List<Map<String, Object>> messages = google.messages(objectId(card));
        assertThat(messages).hasSize(1);
        assertThat(messages.get(0).get("messageType")).isEqualTo("TEXT_AND_NOTIFY");
        assertThat(messages.get(0).get("body")).isEqualTo("Falta apenas 1 carimbo para completar seu cartão e ganhar: Um café grátis!");
        assertThat(reminderStatus()).isEqualTo("ACCEPTED"); // aceito pelo Google, não "entregue"

        // Mesma situação: nada novo, mesmo em execuções repetidas.
        assertThat(planner.planAll()).isZero();
        clock.advance(Duration.ofDays(10));
        assertThat(planner.planAll()).isZero();
        assertThat(sender.dispatchDue()).isZero();
        assertThat(google.messages(objectId(card))).hasSize(1);
        // Lembrete não renova validade.
        assertThat(jdbc.queryForObject("select expires_at from loyalty_card where id = ?", Instant.class, card)).isEqualTo(expiresBefore);

        String history = getJson(ownerA, base(a) + "/notifications/history");
        assertThat((String) JsonPath.read(history, "$.content[0].status")).isEqualTo("ACCEPTED");
        assertThat(history).doesNotContain("DELIVERED").doesNotContain("11977771111");
    }

    // ---------------- vencimento ----------------

    @Test
    void expiryReminderUsesTheRealValidityAndTheEstablishmentTimeZone() throws Exception {
        settings(ownerA, base(a), settingsJson(false, 1, true, 3, false, 60, 7, false)).andExpect(status().isOk());
        // Emitido em 05/11 12:00 (São Paulo), 30 dias, fim do dia: vale até 05/12 23:59:59.
        clock.set(Instant.parse("2026-12-01T15:00:00Z")); // 01/12 12:00 -> faltam 4 dias
        assertThat(planner.planAll()).isZero();
        clock.set(Instant.parse("2026-12-02T15:00:00Z")); // 02/12 -> faltam 3 dias
        assertThat(planner.planAll()).isEqualTo(1);
        sender.dispatchDue();
        String body = (String) google.messages(objectId(card)).get(0).get("body");
        assertThat(body).isEqualTo("Seu cartão Café vence em 3 dias (05/12). Uma compra registrada em Estabelecimento loja-a renova a validade.");
    }

    @Test
    void purchaseBeforeSendingCancelsTheReminderAndOutsideTheWindowItWaits() throws Exception {
        settings(ownerA, base(a), settingsJson(false, 1, true, 3, false, 60, 7, false)).andExpect(status().isOk());
        clock.set(Instant.parse("2026-12-03T01:30:00Z")); // 02/12 22:30 em São Paulo: fora da janela 9h-20h
        assertThat(planner.planAll()).isEqualTo(1);
        assertThat(sender.dispatchDue()).isZero();
        assertThat(reminderStatus()).isEqualTo("PENDING");
        assertThat(google.messages(objectId(card))).isEmpty();
        // Compra antes do envio: renova a validade e descarta o aviso.
        earn(ownerA, a, card, "{}", key()).andExpect(status().isCreated());
        assertThat(reminderStatus()).isEqualTo("CANCELLED");
        clock.set(Instant.parse("2026-12-03T13:00:00Z"));
        assertThat(sender.dispatchDue()).isZero();
        assertThat(planner.planAll()).isZero(); // nova validade: fora do prazo de aviso
        assertThat(google.messages(objectId(card))).isEmpty();
    }

    @Test
    void obsoleteMessagesAlreadyAcceptedAreRemovedFromTheCard() throws Exception {
        settings(ownerA, base(a), settingsJson(false, 1, true, 3, false, 60, 7, false)).andExpect(status().isOk());
        clock.set(Instant.parse("2026-12-02T15:00:00Z"));
        planner.planAll();
        sender.dispatchDue();
        assertThat(google.messages(objectId(card))).hasSize(1);
        earn(ownerA, a, card, "{}", key()).andExpect(status().isCreated());
        // A sincronização do passe (após a compra) envia "messages" sem o aviso desatualizado.
        assertThat(google.messages(objectId(card))).isEmpty();
        assertThat(jdbc.queryForObject("select withdrawn_at from wallet_reminder", Instant.class)).isNotNull();
    }

    @Test
    void suspendedCancelledAndExpiredCardsAreNotReminded() throws Exception {
        settings(ownerA, base(a), settingsJson(true, 1, true, 7, false, 60, 7, false)).andExpect(status().isOk());
        earn(ownerA, a, card, "{\"quantity\":9}", key()).andExpect(status().isCreated());
        postJson(ownerA, base(a) + "/cards/" + card + "/suspend", "{}").andExpect(status().isOk());
        assertThat(planner.planAll()).isZero();
        postJson(ownerA, base(a) + "/cards/" + card + "/cancel", "{\"reason\":\"teste\"}").andExpect(status().isOk());
        assertThat(planner.planAll()).isZero();

        long other = card(ownerA, a, consumer(ownerA, a, "Outra Pessoa", "11977772222"), program);
        createLink(other);
        clock.advance(Duration.ofDays(40)); // venceu por inatividade
        assertThat(planner.planAll()).isZero();
        assertThat(reminders()).isEmpty();
    }

    // ---------------- frequência e duplicidade ----------------

    @Test
    void frequencyLimitsPerCategoryAndPerCard() throws Exception {
        settings(ownerA, base(a), settingsJson(true, 3, true, 7, false, 60, 7, false)).andExpect(status().isOk());
        earn(ownerA, a, card, "{\"quantity\":7}", key()).andExpect(status().isCreated()); // faltam 3
        assertThat(planner.planAll()).isEqualTo(1);
        sender.dispatchDue();
        clock.advance(Duration.ofDays(1));
        earn(ownerA, a, card, "{\"quantity\":1}", key()).andExpect(status().isCreated()); // faltam 2: situação nova
        assertThat(planner.planAll()).isZero(); // dentro do intervalo mínimo (7 dias) da categoria
        clock.advance(Duration.ofDays(7));
        assertThat(planner.planAll()).isEqualTo(1);
        assertThat(jdbc.queryForObject("select count(*) from wallet_reminder", Integer.class)).isEqualTo(2);
        // Logo depois, outra situação do mesmo cartão espera 24 h desde o último aviso (todas as categorias).
        sender.dispatchDue();
        clock.advance(Duration.ofHours(2));
        earn(ownerA, a, card, "{\"quantity\":1}", key()).andExpect(status().isCreated()); // faltam 1: situação nova
        settings(ownerA, base(a), settingsJson(true, 3, true, 7, false, 60, 3, false)).andExpect(status().isOk());
        assertThat(planner.planAll()).isZero();
    }

    @Test
    void concurrentPlanningAndSendingNeverDuplicate() throws Exception {
        settings(ownerA, base(a), settingsJson(true, 1, false, 3, false, 60, 7, false)).andExpect(status().isOk());
        earn(ownerA, a, card, "{\"quantity\":9}", key()).andExpect(status().isCreated());
        concurrently(4, () -> planner.planAll());
        assertThat(reminders()).hasSize(1);
        Long id = ((Number) reminders().get(0).get("id")).longValue();
        concurrently(4, () -> sender.process(id));
        assertThat(google.messages(objectId(card))).hasSize(1);
        assertThat(google.calls.stream().filter(c -> c.contains("addMessage")).count()).isEqualTo(1);
    }

    // ---------------- falhas do Google ----------------

    @Test
    void temporaryFailuresAreRetriedAndPermanentOnesAreClosed() throws Exception {
        settings(ownerA, base(a), settingsJson(true, 1, false, 3, false, 60, 7, false)).andExpect(status().isOk());
        earn(ownerA, a, card, "{\"quantity\":9}", key()).andExpect(status().isCreated());
        planner.planAll();
        google.failNext(503, 1);
        assertThat(sender.dispatchDue()).isZero();
        assertThat(reminderStatus()).isEqualTo("FAILED");
        assertThat(sender.dispatchDue()).isZero(); // antes do prazo de nova tentativa
        clock.advance(Duration.ofMinutes(6));
        assertThat(sender.dispatchDue()).isEqualTo(1);
        assertThat(reminderStatus()).isEqualTo("ACCEPTED");
        // O cartão continua com saldo e validade intactos.
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo("9");

        String overview = getJson(ownerA, base(a) + "/notifications");
        assertThat((Integer) JsonPath.read(overview, "$.last30Days.ACCEPTED")).isEqualTo(1);
    }

    @Test
    void rejectedAndQuotaExceededAreNotRetried() throws Exception {
        settings(ownerA, base(a), settingsJson(true, 1, false, 3, false, 60, 3, false)).andExpect(status().isOk());
        earn(ownerA, a, card, "{\"quantity\":9}", key()).andExpect(status().isCreated());
        planner.planAll();
        google.failNext(400, 1);
        sender.dispatchDue();
        assertThat(reminderStatus()).isEqualTo("REJECTED");
        clock.advance(Duration.ofHours(5));
        assertThat(sender.dispatchDue()).isZero();

        // Limite do Google (3 avisos/24 h) já atingido por este passe.
        long other = card(ownerA, a, consumer(ownerA, a, "Outra Pessoa", "11977772222"), program);
        createLink(other);
        earn(ownerA, a, other, "{\"quantity\":9}", key()).andExpect(status().isCreated());
        google.notifications.put(objectId(other), 3);
        planner.planAll();
        sender.dispatchDue();
        assertThat(reminderStatus()).isEqualTo("QUOTA_EXCEEDED");
        clock.advance(Duration.ofHours(5));
        assertThat(sender.dispatchDue()).isZero();
        assertThat(google.messages(objectId(other))).isEmpty();
    }

    // ---------------- HTTP 409 em addMessage (Etapa 8) ----------------

    /** 409 só conta como aceito quando a mensagem com o mesmo id está de fato gravada no cartão (resposta anterior perdida). */
    @Test
    @SuppressWarnings("unchecked")
    void conflict409IsAcceptedOnlyWhenTheMessageIsVerifiedOnTheCard() throws Exception {
        settings(ownerA, base(a), settingsJson(true, 1, false, 3, false, 60, 7, false)).andExpect(status().isOk());
        earn(ownerA, a, card, "{\"quantity\":9}", key()).andExpect(status().isCreated());
        assertThat(planner.planAll()).isEqualTo(1);
        long reminderId = jdbc.queryForObject("select id from wallet_reminder order by id desc limit 1", Long.class);
        // Simula: o pedido anterior foi gravado pelo Google, mas a resposta se perdeu.
        Map<String, Object> object = google.objects.get(objectId(card));
        object.put("messages", new java.util.ArrayList<>(List.of(Map.of("id", "stp_reminder_" + reminderId, "header", "x", "body", "y"))));

        assertThat(sender.dispatchDue()).isEqualTo(1);
        assertThat(reminderStatus()).isEqualTo("ACCEPTED");
        assertThat(jdbc.queryForObject("select closed_reason from wallet_reminder where id = ?", String.class, reminderId))
                .contains("Verificado no Google");
        assertThat(google.calls).anyMatch(c -> c.startsWith("GET loyaltyObject"));
        assertThat(google.messages(objectId(card))).hasSize(1); // nada duplicado
    }

    @Test
    void conflict409WithoutTheMessageOnTheCardIsRejectedNotAccepted() throws Exception {
        settings(ownerA, base(a), settingsJson(true, 1, false, 3, false, 60, 7, false)).andExpect(status().isOk());
        earn(ownerA, a, card, "{\"quantity\":9}", key()).andExpect(status().isCreated());
        planner.planAll();
        google.failNext(409, 1); // só o addMessage responde 409; a leitura do objeto funciona e não tem a mensagem
        assertThat(sender.dispatchDue()).isZero();
        assertThat(reminderStatus()).isEqualTo("REJECTED");
        clock.advance(Duration.ofHours(5));
        assertThat(sender.dispatchDue()).isZero(); // recusa definitiva: sem reenvio
        assertThat(google.messages(objectId(card))).isEmpty();
    }

    @Test
    void conflict409ThatCannotBeVerifiedIsRetriedLater() throws Exception {
        settings(ownerA, base(a), settingsJson(true, 1, false, 3, false, 60, 7, false)).andExpect(status().isOk());
        earn(ownerA, a, card, "{\"quantity\":9}", key()).andExpect(status().isCreated());
        planner.planAll();
        google.failNext(409, 2); // addMessage e a leitura de verificação falham
        assertThat(sender.dispatchDue()).isZero();
        assertThat(reminderStatus()).isEqualTo("FAILED"); // não foi presumido como aceito
        clock.advance(Duration.ofMinutes(6));
        assertThat(sender.dispatchDue()).isEqualTo(1); // nova tentativa: o Google aceita
        assertThat(reminderStatus()).isEqualTo("ACCEPTED");
        assertThat(google.messages(objectId(card))).hasSize(1);
    }

    // ---------------- consentimento ----------------

    @Test
    void inactivityRemindersRequireMarketingConsent() throws Exception {
        settings(ownerA, base(a), settingsJson(false, 1, false, 3, true, 15, 7, false)).andExpect(status().isOk());
        long consented = id(postJson(ownerA, base(a) + "/consumers",
                "{\"fullName\":\"Com Consentimento\",\"phone\":\"11966660000\",\"privacyAcknowledged\":true,\"marketingOptIn\":true}"));
        long consentedCard = card(ownerA, a, consented, program);
        createLink(consentedCard);
        clock.advance(Duration.ofDays(20));
        assertThat(planner.planAll()).isEqualTo(1); // só quem consentiu
        assertThat(((Number) reminders().get(0).get("card_id")).longValue()).isEqualTo(consentedCard);
        sender.dispatchDue();
        assertThat((String) google.messages(objectId(consentedCard)).get(0).get("body")).startsWith("Faz 20 dias desde sua última visita");
        assertThat(google.messages(objectId(card))).isEmpty();
    }

    // ---------------- configurações, isolamento e localização ----------------

    @Test
    void settingsAreValidatedAndIsolatedPerEstablishment() throws Exception {
        settings(ownerA, base(a), settingsJson(true, 4, false, 3, false, 60, 7, false)).andExpect(status().isBadRequest());
        settings(ownerA, base(a), settingsJson(true, 1, false, 4, false, 60, 7, false)).andExpect(status().isBadRequest());
        settings(ownerA, base(a), settingsJson(true, 1, false, 3, false, 60, 1, false)).andExpect(status().isBadRequest());
        settings(ownerA, base(a), settingsJson(true, 1, false, 3, false, 60, 7, true)).andExpect(status().isUnprocessableContent());
        settings(ownerB, base(a), settingsJson(true, 1, false, 3, false, 60, 7, false)).andExpect(status().isForbidden());
        mvc.perform(get(base(a) + "/notifications").session(ownerB)).andExpect(status().isForbidden());
        mvc.perform(get(base(a) + "/notifications/history").session(ownerB)).andExpect(status().isForbidden());
        // Padrões conservadores: tudo desligado.
        String overview = getJson(ownerA, base(a) + "/notifications");
        assertThat((Boolean) JsonPath.read(overview, "$.settings.nearRewardEnabled")).isFalse();
        assertThat((Boolean) JsonPath.read(overview, "$.settings.proximityEnabled")).isFalse();
        assertThat((Boolean) JsonPath.read(overview, "$.integration.googleConfigured")).isTrue();
    }

    @Test
    void invalidCoordinatesAreRejected() throws Exception {
        postJson(ownerA, base(a) + "/locations", location("Loja", 95, -46.6)).andExpect(status().isBadRequest());
        postJson(ownerA, base(a) + "/locations", location("Loja", 0, 0)).andExpect(status().isBadRequest());
        postJson(ownerA, base(a) + "/locations", location("Loja", 48.85, 2.35)).andExpect(status().isBadRequest()); // Paris
        postJson(ownerA, base(a) + "/locations", location("Loja", -46.65, -23.56)).andExpect(status().isBadRequest()); // trocadas
        postJson(ownerA, base(a) + "/locations", location("Loja", -23.561414, -46.655881)).andExpect(status().isCreated());
        for (int i = 0; i < 9; i++) {
            postJson(ownerA, base(a) + "/locations", location("Loja " + i, -23.5 - i / 100.0, -46.6)).andExpect(status().isCreated());
        }
        postJson(ownerA, base(a) + "/locations", location("Loja 11", -23.4, -46.6)).andExpect(status().isUnprocessableContent());
    }

    @Test
    void locationsArePublishedToTheWalletsAndIsolated() throws Exception {
        String classBefore = google.classes.keySet().iterator().next();
        assertThat(google.classes.get(classBefore)).doesNotContainKey("merchantLocations"); // comportamento anterior preservado
        Instant expiresBefore = jdbc.queryForObject("select expires_at from loyalty_card where id = ?", Instant.class, card);

        long loc = id(postJson(ownerA, base(a) + "/locations", location("Loja Paulista", -23.561414, -46.655881))
                .andExpect(status().isCreated()));
        settings(ownerA, base(a), settingsJson(false, 1, false, 3, false, 60, 7, true)).andExpect(status().isOk());
        assertThat(merchantLocations(classBefore)).containsExactly(Map.of("latitude", -23.561414, "longitude", -46.655881));
        assertThat(proximity.appleLocations(a.getId())).containsExactly(
                Map.of("latitude", -23.561414, "longitude", -46.655881, "relevantText", "Loja aqui perto"));

        // Mudança da localização: a classe é atualizada; saldo e validade não mudam.
        mvc.perform(put(base(a) + "/locations/" + loc).session(ownerA).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content(location("Loja Paulista", -23.5, -46.6))).andExpect(status().isOk());
        assertThat(merchantLocations(classBefore)).containsExactly(Map.of("latitude", -23.5, "longitude", -46.6));
        assertThat(jdbc.queryForObject("select expires_at from loyalty_card where id = ?", Instant.class, card)).isEqualTo(expiresBefore);
        assertThat(countTransactions(card, "EARN")).isZero();

        // Outra empresa não altera nem remove a localização de A.
        mvc.perform(put(base(b) + "/locations/" + loc).session(ownerB).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content(location("Invasor", -23.5, -46.6))).andExpect(status().isNotFound());
        mvc.perform(delete(base(b) + "/locations/" + loc).session(ownerB).with(csrf())).andExpect(status().isNotFound());
        mvc.perform(delete(base(a) + "/locations/" + loc).session(ownerB).with(csrf())).andExpect(status().isForbidden());

        // Desligar a proximidade remove os pontos (lista vazia).
        settings(ownerA, base(a), settingsJson(false, 1, false, 3, false, 60, 7, false)).andExpect(status().isOk());
        assertThat(merchantLocations(classBefore)).isEmpty();
        assertThat(proximity.appleLocations(a.getId())).isEmpty();
    }

    @Test
    void platformAdminCanMaintainLocations() throws Exception {
        platformAdmin("admin@teste.local");
        MockHttpSession admin = login("admin@teste.local");
        long loc = id(postJson(admin, "/api/admin/establishments/" + a.getId() + "/locations", location("Loja", -23.5, -46.6))
                .andExpect(status().isCreated()));
        assertThat((List<?>) JsonPath.read(getJson(ownerA, base(a) + "/notifications"), "$.locations")).hasSize(1);
        postJson(ownerA, "/api/admin/establishments/" + a.getId() + "/locations", location("Loja", -23.5, -46.6))
                .andExpect(status().isForbidden());
        mvc.perform(delete("/api/admin/establishments/" + a.getId() + "/locations/" + loc).session(admin).with(csrf()))
                .andExpect(status().isNoContent());
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> merchantLocations(String classId) {
        Object value = google.classes.get(classId).get("merchantLocations");
        return value == null ? null : (List<Map<String, Object>>) value;
    }

    private void concurrently(int threads, ThrowingRunnable task) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch start = new CountDownLatch(1);
        List<java.util.concurrent.Future<?>> futures = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            futures.add(pool.submit(() -> {
                start.await();
                task.run();
                return null;
            }));
        }
        start.countDown();
        pool.shutdown();
        assertThat(pool.awaitTermination(60, TimeUnit.SECONDS)).isTrue();
        for (var f : futures) {
            f.get();
        }
    }

    private interface ThrowingRunnable {
        void run() throws Exception;
    }
}
