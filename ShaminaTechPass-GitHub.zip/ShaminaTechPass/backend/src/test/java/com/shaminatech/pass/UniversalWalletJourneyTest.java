package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoVerifierBuilder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.ResultActions;

import com.jayway.jsonpath.JsonPath;
import com.shaminatech.pass.loyalty.wallet.WalletPass;
import com.shaminatech.pass.loyalty.wallet.WalletPass.Provider;
import com.shaminatech.pass.loyalty.wallet.WalletPassRepository;

import tools.jackson.databind.json.JsonMapper;

/**
 * Jornada do QR Code universal: o mesmo QR Code permanente do programa leva ao cadastro, e o cartão (único) pode ir
 * para o Google Wallet (simulado, {@link FakeGoogleWallet}) e para o Apple Wallet (modo offline de homologação, com o
 * certificado de teste {@link FakeApple}). Nenhum serviço real é chamado.
 */
class UniversalWalletJourneyTest extends LoyaltyTestSupport {

    @DynamicPropertySource
    static void wallets(DynamicPropertyRegistry registry) {
        FakeGoogleWallet google = FakeGoogleWallet.get();
        registry.add("shaminatech.wallet.google.enabled", () -> "true");
        registry.add("shaminatech.wallet.google.issuer-id", () -> FakeGoogleWallet.ISSUER_ID);
        registry.add("shaminatech.wallet.google.service-account-key-file", () -> google.keyFile().toString());
        registry.add("shaminatech.wallet.google.origins", () -> "http://localhost:4203");
        registry.add("shaminatech.wallet.google.api-base-url", google::baseUrl);
        registry.add("shaminatech.wallet.google.fallback-logo-uri", () -> "https://example.test/logo-padrao.png");
        registry.add("shaminatech.wallet.google.public-base-url", () -> "https://pass.example.test");
        registry.add("shaminatech.wallet.google.async-dispatch", () -> "false");
        FakeApple apple = FakeApple.get();
        registry.add("shaminatech.wallet.apple.enabled", () -> "true");
        registry.add("shaminatech.wallet.apple.offline-passes", () -> "true");
        registry.add("shaminatech.wallet.apple.pass-type-identifier", () -> FakeApple.PASS_TYPE_ID);
        registry.add("shaminatech.wallet.apple.team-identifier", () -> FakeApple.TEAM_ID);
        registry.add("shaminatech.wallet.apple.certificate-file", () -> apple.p12().toString());
        registry.add("shaminatech.wallet.apple.certificate-password", () -> FakeApple.P12_PASSWORD);
        registry.add("shaminatech.wallet.apple.wwdr-certificate-file", () -> apple.wwdrFile().toString());
        registry.add("shaminatech.wallet.apple.support-name", () -> "ShaminaTech");
        registry.add("shaminatech.wallet.apple.support-email", () -> "shaminatech@gmail.com");
    }

    @Autowired
    private WalletPassRepository passes;
    @Autowired
    private JsonMapper json;

    private final FakeGoogleWallet google = FakeGoogleWallet.get();
    private long program;
    private long linkId;
    private String qrUrl;
    private String token;

    @BeforeEach
    void setUpProgramQr() throws Exception {
        google.reset();
        program = pointsProgram(a, ownerA, "");
        qrUrl = read(postJson(ownerA, base(a) + "/programs/" + program + "/signup-link", "{}").andExpect(status().isCreated()), "$.url");
        token = qrUrl.substring(qrUrl.lastIndexOf('/') + 1);
        linkId = ((Number) JsonPath.read(getJson(ownerA, base(a) + "/signup-links"), "$.programs[0].link.id")).longValue();
    }

    private String info() throws Exception {
        return mvc.perform(get("/api/public/signup/" + token)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
    }

    private ResultActions signup(String phone) throws Exception {
        String formToken = JsonPath.read(info(), "$.formToken");
        clock.advance(Duration.ofSeconds(5));
        return mvc.perform(post("/api/public/signup/" + token).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content("{\"fullName\":\"Bruna Costa Reis\",\"phone\":\"" + phone + "\",\"privacyAccepted\":true,"
                        + "\"requestId\":\"" + UUID.randomUUID() + "\",\"formToken\":\"" + formToken + "\"}"));
    }

    private String currentQrUrl() throws Exception {
        return JsonPath.read(getJson(ownerA, base(a) + "/signup-links"), "$.programs[0].link.url");
    }

    private String walletPage(String linkToken) throws Exception {
        return mvc.perform(get("/api/public/wallet-links/" + linkToken)).andExpect(status().isOk()).andReturn().getResponse()
                .getContentAsString();
    }

    private byte[] pkpass(String linkToken) throws Exception {
        return mvc.perform(get("/api/public/wallet-links/" + linkToken + "/apple")).andExpect(status().isOk())
                .andExpect(header().string("Content-Type", "application/vnd.apple.pkpass"))
                .andReturn().getResponse().getContentAsByteArray();
    }

    private static Map<String, byte[]> unzip(byte[] data) throws Exception {
        Map<String, byte[]> files = new HashMap<>();
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(data))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                files.put(entry.getName(), zip.readAllBytes());
            }
        }
        return files;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> passJson(byte[] pkpass) throws Exception {
        return json.readValue(unzip(pkpass).get("pass.json"), Map.class);
    }

    @SuppressWarnings("unchecked")
    private static Object fieldValue(Map<String, Object> pass, String group, String key) {
        List<Map<String, Object>> fields = (List<Map<String, Object>>) ((Map<String, Object>) pass.get("storeCard")).get(group);
        return fields.stream().filter(f -> key.equals(f.get("key"))).map(f -> f.get("value")).findFirst().orElse(null);
    }

    private long cardId() {
        return jdbc.queryForObject("select id from loyalty_card", Long.class);
    }

    @Test
    void oneQrForBothWalletsSignupIssuesARealCardForGoogleAndApple() throws Exception {
        String page = info();
        assertThat((List<String>) JsonPath.read(page, "$.wallets")).containsExactly("GOOGLE_WALLET", "APPLE_WALLET");
        assertThat(page).doesNotContain("Bruna").doesNotContain(token.substring(0, 8) + "x");

        ResultActions result = signup("11955554444").andExpect(status().isCreated());
        String walletPath = read(result, "$.walletPath");
        String linkToken = walletPath.substring("/carteira/".length());
        String wallet = walletPage(linkToken);
        assertThat((String) JsonPath.read(wallet, "$.google.status")).isEqualTo("READY");
        assertThat((String) JsonPath.read(wallet, "$.apple.status")).isEqualTo("READY");

        // Um cartão lógico, dois passes (um por carteira), sem pontos concedidos pelo cadastro.
        long card = cardId();
        assertThat(passes.findByCardId(card)).extracting(WalletPass::getProvider)
                .containsExactlyInAnyOrder(Provider.GOOGLE_WALLET, Provider.APPLE_WALLET);
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo(BigDecimal.ZERO);
        assertThat(countTransactions(card, "EARN")).isZero(); // a emissão não concede pontos

        // .pkpass oficial do cartão REAL (dados do PostgreSQL), sem serviço de atualização no modo offline.
        byte[] file = pkpass(linkToken);
        Map<String, byte[]> files = unzip(file);
        Map<String, Object> pass = passJson(file);
        WalletPass applePass = passes.findByCardIdAndProvider(card, Provider.APPLE_WALLET).orElseThrow();
        assertThat(applePass.getSyncStatus()).isEqualTo(WalletPass.SyncStatus.SYNCED);
        assertThat(pass).containsEntry("serialNumber", applePass.getExternalId()).containsEntry("passTypeIdentifier", FakeApple.PASS_TYPE_ID)
                .containsEntry("teamIdentifier", FakeApple.TEAM_ID).containsEntry("organizationName", "Estabelecimento loja-a")
                .doesNotContainKey("webServiceURL").doesNotContainKey("authenticationToken");
        assertThat((String) pass.get("serialNumber")).matches("stp[0-9a-f]{32}");
        assertThat(fieldValue(pass, "secondaryFields", "cliente")).isEqualTo("Bruna");
        assertThat(fieldValue(pass, "primaryFields", "saldo")).isEqualTo(0);
        assertThat((String) fieldValue(pass, "backFields", "atualizacao")).contains("não se atualiza sozinho");
        String code = cardField(ownerA, a, card, "code");
        assertThat(((List<Map<String, Object>>) pass.get("barcodes")).get(0)).containsEntry("message", code);
        CMSSignedData signed = new CMSSignedData(new CMSProcessableByteArray(files.get("manifest.json")), files.get("signature"));
        SignerInformation signer = signed.getSignerInfos().getSigners().iterator().next();
        assertThat(signer.verify(new JcaSimpleSignerInfoVerifierBuilder().build(FakeApple.get().leaf()))).isTrue();
    }

    @Test
    void switchingPhonesKeepsTheSameCardBalanceAndSerial() throws Exception {
        String firstLink = ((String) read(signup("11955553333").andExpect(status().isCreated()), "$.walletPath")).substring(10);
        long card = cardId();
        String serial = passes.findByCardIdAndProvider(card, Provider.APPLE_WALLET).orElseThrow().getExternalId();
        long googleWrites = google.objectWrites();
        earn(ownerA, a, card, "{\"purchaseAmount\":30.00}", key()).andExpect(status().isCreated());

        // Mesmo QR Code: a pessoa não consegue pegar o cartão sozinha (sem enumeração) e não cria um segundo cartão.
        signup("11955553333").andExpect(status().isConflict());
        assertThat(jdbc.queryForObject("select count(*) from loyalty_card", Integer.class)).isEqualTo(1);

        // No balcão, a empresa gera o link do cartão; o novo celular (iPhone) escaneia o QR Code do link.
        String url = read(postJson(ownerA, base(a) + "/cards/" + card + "/wallet/links", "{}").andExpect(status().isCreated()), "$.url");
        String newLink = url.substring(url.lastIndexOf('/') + 1);
        mvc.perform(get("/api/public/wallet-links/" + newLink + "/qr")).andExpect(status().isOk())
                .andExpect(header().string("Content-Type", "image/svg+xml"));
        Map<String, Object> pass = passJson(pkpass(newLink));
        assertThat(pass).containsEntry("serialNumber", serial); // mesmo passe Apple: o iPhone substitui, não duplica
        assertThat(fieldValue(pass, "primaryFields", "saldo")).isEqualTo(30);
        assertThat(passes.findByCardId(card)).hasSize(2);
        assertThat(walletPage(newLink)).contains("pay.google.com");
        assertThat(google.objectWrites()).isGreaterThanOrEqualTo(googleWrites); // o mesmo objeto, atualizado
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo("30");
        // O link antigo continua sendo do mesmo cartão (nada foi duplicado).
        assertThat(passJson(pkpass(firstLink))).containsEntry("serialNumber", serial);
    }

    @Test
    void theProgramQrIsPermanentAndShowsTheRealProgramState() throws Exception {
        String before = currentQrUrl();
        assertThat(before).isEqualTo(qrUrl);
        signup("11955552222").andExpect(status().isCreated());
        earn(ownerA, a, cardId(), "{\"purchaseAmount\":12.00}", key()).andExpect(status().isCreated());
        mvc.perform(patch(base(a) + "/programs/" + program).session(ownerA).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content("{\"description\":\"Nova descrição\"}"));
        clock.advance(Duration.ofDays(400));
        assertThat(currentQrUrl()).isEqualTo(before); // sem expiração, sem troca automática
        assertThat(jdbc.queryForObject("select token from public_signup_link where id = ?", String.class, linkId)).isEqualTo(token);

        mvc.perform(patch(base(a) + "/programs/" + program + "/status").session(ownerA).with(csrf())
                .contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"PAUSED\"}")).andExpect(status().isOk());
        String paused = info();
        assertThat((String) JsonPath.read(paused, "$.status")).isEqualTo("UNAVAILABLE");
        assertThat(paused).doesNotContain("loja-a"); // sem dados do estabelecimento quando indisponível
        assertThat(currentQrUrl()).isEqualTo(before);

        mvc.perform(get("/api/public/signup/" + "0".repeat(32))).andExpect(status().isNotFound());
        mvc.perform(get("/api/public/signup/nao-existe")).andExpect(status().isNotFound());
        // Outro estabelecimento não enxerga nem gera a imagem do QR Code deste programa.
        mvc.perform(get(base(a) + "/signup-links/" + linkId + "/qr").session(ownerB)).andExpect(status().isForbidden());
        mvc.perform(get(base(b) + "/signup-links/" + linkId + "/qr").session(ownerB)).andExpect(status().isNotFound());
        byte[] png = mvc.perform(get(base(a) + "/signup-links/" + linkId + "/qr").param("format", "png").param("download", "true")
                        .session(ownerA)).andExpect(status().isOk())
                .andExpect(header().string("Content-Disposition", "attachment; filename=\"qr-cadastro.png\""))
                .andReturn().getResponse().getContentAsByteArray();
        assertThat(javax.imageio.ImageIO.read(new ByteArrayInputStream(png)).getWidth()).isGreaterThanOrEqualTo(900); // impressão
    }

    @Test
    void theCardLinkQrOnlyExistsForAValidLink() throws Exception {
        String linkToken = ((String) read(signup("11955551111").andExpect(status().isCreated()), "$.walletPath")).substring(10);
        String svg = mvc.perform(get("/api/public/wallet-links/" + linkToken + "/qr")).andExpect(status().isOk())
                .andExpect(header().string("Cache-Control", "no-store")).andReturn().getResponse().getContentAsString();
        assertThat(svg).startsWith("<svg").doesNotContain("Bruna");
        mvc.perform(get("/api/public/wallet-links/" + "0".repeat(32) + "/qr")).andExpect(status().isNotFound());
        mvc.perform(get("/api/public/wallet-links/xyz/qr")).andExpect(status().isNotFound());
        long walletLinkId = ((Number) JsonPath.read(getJson(ownerA, base(a) + "/cards/" + cardId() + "/wallet"), "$.links[0].id")).longValue();
        postJson(ownerA, base(a) + "/wallet/links/" + walletLinkId + "/revoke", "{}").andExpect(status().isOk());
        mvc.perform(get("/api/public/wallet-links/" + linkToken + "/qr")).andExpect(status().isNotFound());
        mvc.perform(get("/api/public/wallet-links/" + linkToken + "/apple")).andExpect(status().isNotFound());
    }
}
