package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.reset;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;

import com.jayway.jsonpath.JsonPath;
import com.shaminatech.pass.plan.PlanService;

/**
 * Autocadastro fora da fase de testes (sem cobrança implementada, só o Free) e falha no meio da transação (nada fica
 * gravado: nem estabelecimento órfão, nem usuário sem vínculo).
 */
@TestPropertySource(properties = "shaminatech.plans.trial-free=false")
class EstablishmentSignupSafetyTest extends IntegrationTestSupport {

    @MockitoSpyBean
    private PlanService plans;

    @AfterEach
    void resetSpy() {
        reset(plans);
    }

    private static String body(String plan, String email) {
        return "{\"plan\":\"" + plan + "\",\"establishmentName\":\"Café Seguro\",\"ownerName\":\"Responsável\",\"email\":\"" + email
                + "\",\"password\":\"Senha-forte-2026\",\"passwordConfirmation\":\"Senha-forte-2026\",\"termsAccepted\":true}";
    }

    private org.springframework.test.web.servlet.ResultActions signup(String json) throws Exception {
        return mvc.perform(post("/api/public/establishment-signup").with(csrf()).contentType(MediaType.APPLICATION_JSON).content(json));
    }

    @Test
    void withoutTheTestPhasePaidPlansAreNotSelectableAndNothingIsCharged() throws Exception {
        String catalog = mvc.perform(get("/api/public/plans")).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat((Boolean) JsonPath.read(catalog, "$.trialFree")).isFalse();
        assertThat((Object) JsonPath.read(catalog, "$.trialMessage")).isNull();
        assertThat((List<Boolean>) JsonPath.read(catalog, "$.plans[*].selectable")).containsExactly(true, false, false);
        signup(body("GROWTH", "growth@teste.local")).andExpect(status().isBadRequest()).andExpect(jsonPath("$.errors[0].field").value("plan"));
        signup(body("PRO", "pro@teste.local")).andExpect(status().isBadRequest());
        signup(body("FREE", "free@teste.local")).andExpect(status().isCreated()).andExpect(jsonPath("$.plan").value("FREE"));
        assertThat(jdbc.queryForObject("select count(*) from establishment", Integer.class)).isEqualTo(1);
        assertThat(jdbc.queryForObject("select list_price_cents from establishment_plan", Integer.class)).isZero();
    }

    @Test
    void aFailureInTheMiddleRollsBackEverything() throws Exception {
        doThrow(new IllegalStateException("falha simulada")).when(plans).assign(any(), any(), any(), any());
        int code = signup(body("FREE", "falha@teste.local")).andReturn().getResponse().getStatus();
        assertThat(code).isGreaterThanOrEqualTo(500);
        for (String table : new String[] {"establishment", "establishment_policy", "app_user", "membership", "establishment_plan"}) {
            assertThat(jdbc.queryForObject("select count(*) from " + table, Integer.class)).as(table).isZero();
        }
        reset(plans);
        signup(body("FREE", "falha@teste.local")).andExpect(status().isCreated()); // o mesmo e-mail continua livre
    }
}
