package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;

import javax.imageio.ImageIO;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.ResultActions;

import com.jayway.jsonpath.JsonPath;

/** Personalização (upload de imagens), painel ShaminaTech (limites, padrões, uso, auditoria) e indicadores. */
class BrandingAndAdminTest extends LoyaltyTestSupport {

    private static byte[] image(String format, int width, int height) throws Exception {
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        img.setRGB(1, 1, 0xF43F5E);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(img, format, out);
        return out.toByteArray();
    }

    private ResultActions upload(MockHttpSession session, long program, String slot, String filename, String type, byte[] data)
            throws Exception {
        return mvc.perform(multipart(base(a) + "/programs/" + program + "/images/" + slot)
                .file(new MockMultipartFile("file", filename, type, data)).session(session).with(csrf()));
    }

    // ---------------- Personalização ----------------

    @Test
    void validImagesAreStoredReencodedAndServedSafely() throws Exception {
        long program = stampsProgram(a, ownerA, 8, true);
        String logoUrl = read(upload(ownerA, program, "logo", "logo.png", "image/png", image("png", 200, 200))
                .andExpect(status().isOk()), "$.design.logoUrl");
        upload(ownerA, program, "hero", "hero.jpg", "image/jpeg", image("jpg", 1032, 336)).andExpect(status().isOk())
                .andExpect(jsonPath("$.design.heroUrl").isNotEmpty());

        mvc.perform(get(logoUrl).session(ownerA)).andExpect(status().isOk())
                .andExpect(content().contentType("image/png"))
                .andExpect(header().string("X-Content-Type-Options", "nosniff"));
        // Outro estabelecimento não lê a imagem.
        mvc.perform(get(logoUrl).session(ownerB)).andExpect(status().isForbidden());
        mvc.perform(get(logoUrl.replace(base(a), base(b))).session(ownerB)).andExpect(status().isNotFound());
        List<String> actions = JsonPath.read(getJson(ownerA, base(a) + "/audit"), "$.content[*].action");
        assertThat(actions).contains("CARD_IMAGE_UPLOADED");
    }

    @Test
    void invalidFilesAreRejected() throws Exception {
        long program = stampsProgram(a, ownerA, 8, true);
        upload(ownerA, program, "logo", "falso.png", "image/png", "não sou imagem".getBytes(StandardCharsets.UTF_8))
                .andExpect(status().isBadRequest());
        upload(ownerA, program, "logo", "logo.svg", "image/svg+xml",
                "<svg xmlns=\"http://www.w3.org/2000/svg\"><script>alert(1)</script></svg>".getBytes(StandardCharsets.UTF_8))
                .andExpect(status().isBadRequest());
        upload(ownerA, program, "logo", "gif.gif", "image/gif", image("gif", 100, 100)).andExpect(status().isBadRequest());
        upload(ownerA, program, "logo", "mini.png", "image/png", image("png", 10, 10)).andExpect(status().isBadRequest());
        byte[] big = new byte[1_100_000];
        System.arraycopy(image("png", 100, 100), 0, big, 0, 8);
        upload(ownerA, program, "logo", "grande.png", "image/png", big).andExpect(status().isBadRequest());
        upload(ownerA, program, "outro", "logo.png", "image/png", image("png", 100, 100)).andExpect(status().isBadRequest());
        upload(ownerB, program, "logo", "logo.png", "image/png", image("png", 100, 100)).andExpect(status().isForbidden());
        assertThat(jdbc.queryForObject("select count(*) from stored_image", Integer.class)).isZero();
    }

    @Test
    void designColorsAreValidated() throws Exception {
        long program = stampsProgram(a, ownerA, 8, true);
        mvc.perform(put(base(a) + "/programs/" + program + "/design").session(ownerA).with(csrf())
                        .contentType(MediaType.APPLICATION_JSON).content("{\"brandColor\":\"red\",\"textColor\":\"#FFFFFF\"}"))
                .andExpect(status().isBadRequest());
        mvc.perform(put(base(a) + "/programs/" + program + "/design").session(ownerA).with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"brandColor\":\"#0f766e\",\"textColor\":\"#ffffff\",\"cardMessage\":\"Obrigado!\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.design.brandColor").value("#0F766E"))
                .andExpect(jsonPath("$.design.walletNotes[0]").value(org.hamcrest.Matchers.containsString("só é confirmada no celular")));
    }

    // ---------------- Painel ShaminaTech ----------------

    private MockHttpSession admin() throws Exception {
        platformAdmin("admin@teste.local");
        return login("admin@teste.local");
    }

    @Test
    void onlyPlatformAdminConfiguresLimitsAndChangesAreAudited() throws Exception {
        String body = "{\"maxActiveConsumers\":1000,\"allowedProgramTypes\":[\"STAMPS\",\"CASHBACK\"],"
                + "\"defaultInactivityDays\":60,\"timeZone\":\"America/Manaus\"}";
        mvc.perform(put("/api/admin/establishments/" + a.getId() + "/policy").session(ownerA).with(csrf())
                .contentType(MediaType.APPLICATION_JSON).content(body)).andExpect(status().isForbidden());

        MockHttpSession admin = admin();
        mvc.perform(put("/api/admin/establishments/" + a.getId() + "/policy").session(admin).with(csrf())
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.policy.maxActiveConsumers").value(1000))
                .andExpect(jsonPath("$.policy.allowedProgramTypes.length()").value(2));
        mvc.perform(put("/api/admin/establishments/" + a.getId() + "/policy").session(admin).with(csrf())
                        .contentType(MediaType.APPLICATION_JSON).content(body.replace("America/Manaus", "Lugar/Nenhum")))
                .andExpect(status().isBadRequest());
        List<String> details = JsonPath.read(getJson(admin, "/api/admin/audit?establishmentId=" + a.getId()),
                "$.content[?(@.action == 'ESTABLISHMENT_POLICY_CHANGED')].details");
        assertThat(details).hasSize(1);
        assertThat(details.get(0)).contains("limite=100").contains("limite=1000");

        mvc.perform(put("/api/admin/loyalty-defaults").session(admin).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content(body)).andExpect(status().isOk()).andExpect(jsonPath("$.maxActiveConsumers").value(1000));
        assertThat((Integer) JsonPath.read(getJson(admin, "/api/admin/loyalty-defaults"), "$.defaultInactivityDays")).isEqualTo(60);
    }

    @Test
    void adminSeesUsageCountsButNoConsumerData() throws Exception {
        long consumer = consumer(ownerA, a, "Pessoa Sigilosa", "11955554444");
        card(ownerA, a, consumer, stampsProgram(a, ownerA, 5, true));
        MockHttpSession admin = admin();
        String detail = getJson(admin, "/api/admin/establishments/" + a.getId());
        assertThat((Integer) JsonPath.read(detail, "$.usage.activeConsumers")).isEqualTo(1);
        assertThat((Integer) JsonPath.read(detail, "$.usage.activeCards")).isEqualTo(1);
        assertThat((Integer) JsonPath.read(detail, "$.programsByType.STAMPS")).isEqualTo(1);
        assertThat(detail).doesNotContain("Pessoa Sigilosa").doesNotContain("11955554444");
        String list = getJson(admin, "/api/admin/establishments");
        assertThat(list).doesNotContain("Pessoa Sigilosa");
        assertThat((List<Integer>) JsonPath.read(list, "$.content[?(@.slug == 'loja-a')].usage.activeConsumers")).containsExactly(1);
    }

    @Test
    void adminCreatesEstablishmentWithSingleAccountAndPolicyFromDefaults() throws Exception {
        MockHttpSession admin = admin();
        String create = "{\"name\":\"Nova\",\"slug\":\"nova\",\"owner\":{\"email\":\"%s\",\"fullName\":\"Resp\","
                + "\"temporaryPassword\":\"Senha-temp-123\"}}";
        postJson(admin, "/api/admin/establishments", create.formatted("admin@teste.local")).andExpect(status().isBadRequest());
        postJson(admin, "/api/admin/establishments", create.formatted("resp@nova.local")).andExpect(status().isCreated())
                .andExpect(jsonPath("$.account.email").value("resp@nova.local"))
                .andExpect(jsonPath("$.policy.maxActiveConsumers").value(100));
        // Estabelecimentos só pelo administrador: a conta empresarial não cria.
        postJson(ownerA, "/api/admin/establishments", create.formatted("x@nova.local").replace("nova\"", "nova-2\""))
                .andExpect(status().isForbidden());
    }

    @Test
    void adminResetsTheBusinessAccountPassword() throws Exception {
        MockHttpSession admin = admin();
        postJson(admin, "/api/admin/establishments/" + a.getId() + "/account/reset-password", "{\"temporaryPassword\":\"curta\"}")
                .andExpect(status().isBadRequest());
        postJson(admin, "/api/admin/establishments/" + a.getId() + "/account/reset-password",
                "{\"temporaryPassword\":\"Nova-senha-temp-1\"}").andExpect(status().isOk());
        MockHttpSession session = login("dono.a@teste.local", "Nova-senha-temp-1");
        mvc.perform(get(base(a)).session(session)).andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("PASSWORD_CHANGE_REQUIRED"));
    }

    // ---------------- Indicadores ----------------

    @Test
    void indicatorsOnlyUseRecordedDataAndFlagInsufficientData() throws Exception {
        long program = pointsProgram(a, ownerA, "");
        long c1 = card(ownerA, a, consumer(ownerA, a, "Um", "11911110001"), program);
        long c2 = card(ownerA, a, consumer(ownerA, a, "Dois", "11911110002"), program);
        earn(ownerA, a, c1, "{\"purchaseAmount\":10.00}", key());
        clock.advance(Duration.ofDays(2));
        earn(ownerA, a, c1, "{\"purchaseAmount\":20.50}", key());
        long reversed = ((Number) read(earn(ownerA, a, c2, "{\"purchaseAmount\":99.00}", key()), "$.transaction.id")).longValue();
        postJson(ownerA, base(a) + "/transactions/" + reversed + "/reverse", "{\"reason\":\"erro\"}", key());

        String json = getJson(ownerA, base(a) + "/indicators?days=30");
        assertThat((Integer) JsonPath.read(json, "$.visits")).isEqualTo(2);
        assertThat(JsonPath.read(json, "$.totalPurchaseAmount").toString()).isEqualTo("30.5");
        assertThat((Integer) JsonPath.read(json, "$.recurringConsumers")).isEqualTo(1);
        assertThat((Boolean) JsonPath.read(json, "$.sufficientData")).isFalse();
        assertThat((Object) JsonPath.read(json, "$.averageDaysBetweenVisits")).isNull();
        assertThat(json).contains("não lucro");

        String overview = getJson(ownerA, base(a) + "/overview");
        assertThat((Integer) JsonPath.read(overview, "$.cards.active")).isEqualTo(2);
        assertThat((List<?>) JsonPath.read(overview, "$.recentTransactions")).hasSize(4);
    }
}
