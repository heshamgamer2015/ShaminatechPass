package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.ResultActions;

import com.shaminatech.pass.auth.reset.PasswordResetController;
import com.shaminatech.pass.auth.reset.PasswordResetSender;

/**
 * Etapa 8 — recuperação de senha (fundação). O canal de entrega real não existe; aqui um canal de teste captura o
 * token para comprovar: resposta genérica, token de uso único só com hash no banco, validade curta, invalidação por
 * pedido novo, limite por e-mail, encerramento das sessões e auditoria sem segredos.
 */
@Import(PasswordResetTest.CapturingSender.class)
class PasswordResetTest extends IntegrationTestSupport {

    @TestConfiguration
    static class CapturingSender {
        static final List<String[]> SENT = new CopyOnWriteArrayList<>();

        @Bean
        @Primary
        PasswordResetSender capturingPasswordResetSender() {
            return new PasswordResetSender() {
                @Override
                public boolean available() {
                    return true;
                }

                @Override
                public void send(String email, String fullName, String token) {
                    SENT.add(new String[] {email, token});
                }
            };
        }
    }

    @Autowired
    private org.springframework.jdbc.core.JdbcTemplate jdbcTemplate;

    private static final String NEW_PASSWORD = "Recuperada-2026x";

    @BeforeEach
    void clearOutbox() {
        CapturingSender.SENT.clear();
    }

    private ResultActions request(String email) throws Exception {
        return mvc.perform(post("/api/auth/password-reset/request").with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"" + email + "\"}"));
    }

    private ResultActions confirm(String token, String password) throws Exception {
        return mvc.perform(post("/api/auth/password-reset/confirm").with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content("{\"token\":\"" + token + "\",\"newPassword\":\"" + password + "\"}"));
    }

    private String lastToken() {
        return CapturingSender.SENT.get(CapturingSender.SENT.size() - 1)[1];
    }

    @Test
    void theAnswerIsTheSameForExistingUnknownAndDisabledAccounts() throws Exception {
        user("existe@reset.local");
        AppUserDisabler.disable(users, user("desativado@reset.local"));
        String existing = request("existe@reset.local").andExpect(status().isAccepted()).andReturn().getResponse().getContentAsString();
        String unknown = request("nao-existe@reset.local").andExpect(status().isAccepted()).andReturn().getResponse().getContentAsString();
        String disabled = request("desativado@reset.local").andExpect(status().isAccepted()).andReturn().getResponse().getContentAsString();
        assertThat(existing).isEqualTo(unknown).isEqualTo(disabled).contains(PasswordResetController.GENERIC_ANSWER);
        assertThat(CapturingSender.SENT).hasSize(1); // só a conta ativa recebe
    }

    @Test
    void aValidLinkResetsThePasswordOnceAndEndsAllOpenSessions() throws Exception {
        user("dono@reset.local");
        MockHttpSession openSession = login("dono@reset.local");
        request("dono@reset.local").andExpect(status().isAccepted());
        String token = lastToken();

        // Só o hash fica no banco.
        String stored = jdbcTemplate.queryForObject("select token_hash from password_reset_token", String.class);
        assertThat(stored).hasSize(64).isNotEqualTo(token).doesNotContain(token);

        confirm(token, NEW_PASSWORD).andExpect(status().isNoContent());
        mvc.perform(get("/api/auth/me").session(openSession)).andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("SESSION_REVOKED"));
        login("dono@reset.local", NEW_PASSWORD);

        // Uso único.
        confirm(token, "OutraSenha-2026y").andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("RESET_LINK_INVALID"));

        // Auditoria sem token nem senha.
        List<String> details = jdbcTemplate.queryForList("select coalesce(details, '') from audit_event where action like 'PASSWORD_RESET%'", String.class);
        assertThat(details).hasSize(2).noneMatch(d -> d.contains(token) || d.contains(stored) || d.contains(NEW_PASSWORD));
    }

    @Test
    void linksExpireAndANewRequestInvalidatesTheOldOne() throws Exception {
        user("expira@reset.local");
        request("expira@reset.local");
        String first = lastToken();
        request("expira@reset.local");
        String second = lastToken();
        confirm(first, NEW_PASSWORD).andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("RESET_LINK_INVALID"));

        clock.advance(Duration.ofMinutes(31));
        confirm(second, NEW_PASSWORD).andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("RESET_LINK_INVALID"));
        login("expira@reset.local"); // senha original continua valendo
    }

    @Test
    void malformedOrForgedTokensGetTheSameGenericError() throws Exception {
        user("forjado@reset.local");
        confirm("curto", NEW_PASSWORD).andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("RESET_LINK_INVALID"));
        confirm("A".repeat(43), NEW_PASSWORD).andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("RESET_LINK_INVALID"));
    }

    @Test
    void weakPasswordsAreRejectedAndTheLinkStaysUsable() throws Exception {
        user("fraca@reset.local");
        request("fraca@reset.local");
        String token = lastToken();
        confirm(token, "curta").andExpect(status().isBadRequest());
        confirm(token, NEW_PASSWORD).andExpect(status().isNoContent());
    }

    @Test
    void requestsPerEmailAreLimitedWithoutRevealingIt() throws Exception {
        user("limite@reset.local");
        for (int i = 0; i < 6; i++) {
            request("limite@reset.local").andExpect(status().isAccepted());
        }
        assertThat(CapturingSender.SENT).hasSize(3); // limite por e-mail: 3 por hora, resposta sempre igual
    }

    @Test
    void lockedAccountsAreUnlockedByASuccessfulReset() throws Exception {
        user("bloqueada@reset.local");
        for (int i = 0; i < 5; i++) {
            mvc.perform(post("/api/auth/login").with(csrf()).contentType(MediaType.APPLICATION_JSON)
                    .content(loginJson("bloqueada@reset.local", "errada-123456")));
        }
        request("bloqueada@reset.local");
        confirm(lastToken(), NEW_PASSWORD).andExpect(status().isNoContent());
        login("bloqueada@reset.local", NEW_PASSWORD);
    }

    @Test
    void theEndpointsRequireCsrf() throws Exception {
        mvc.perform(post("/api/auth/password-reset/request").contentType(MediaType.APPLICATION_JSON).content("{\"email\":\"x@y.z\"}"))
                .andExpect(status().isForbidden());
    }

    /** Pequeno atalho de teste para desativar uma conta. */
    static final class AppUserDisabler {
        static void disable(com.shaminatech.pass.user.AppUserRepository users, com.shaminatech.pass.user.AppUser user) {
            user.setStatus(com.shaminatech.pass.user.UserStatus.DISABLED);
            users.save(user);
        }
    }
}
