package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.time.Clock;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.establishment.EstablishmentRepository;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ConsumerRequest;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEngine;
import com.shaminatech.pass.loyalty.card.CardEnums.Channel;
import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.consumer.Consumer;
import com.shaminatech.pass.loyalty.consumer.ConsumerRepository;
import com.shaminatech.pass.loyalty.consumer.ConsumerService;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicyRepository;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.LoyaltyProgramRepository;
import com.shaminatech.pass.loyalty.program.LoyaltyReward;
import com.shaminatech.pass.loyalty.program.LoyaltyRewardRepository;
import com.shaminatech.pass.loyalty.signup.PublicSignupService;
import com.shaminatech.pass.loyalty.signup.SignupDtos.SignupRequest;
import com.shaminatech.pass.loyalty.signup.SignupLinkService;
import com.shaminatech.pass.membership.Membership;
import com.shaminatech.pass.membership.MembershipRepository;
import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.security.AuthenticatedUser;
import com.shaminatech.pass.user.AppUser;
import com.shaminatech.pass.user.AppUserRepository;

/**
 * Etapa 8 — concorrência REAL no PostgreSQL, num banco DESCARTÁVEL e isolado.
 * <p>
 * Antes do contexto Spring, o teste cria um ESQUEMA novo e exclusivo ({@code stpass_it_<aleatório>}) com as mesmas
 * credenciais da aplicação (o usuário não tem permissão CREATEDB), gera as tabelas a partir das entidades e, ao final,
 * apaga o esquema inteiro. As tabelas do esquema principal não são lidas nem alteradas. Opcional:
 * <pre>mvn test -Dtest=PostgresIsolatedConcurrencyIT -Dpass.pg-it=true</pre>
 * Invariante verificada em todos os cenários: saldo do cartão = soma do histórico = soma dos lotes restantes, e nunca
 * negativo.
 */
@SpringBootTest(properties = {
        "spring.jpa.hibernate.ddl-auto=create",
        "shaminatech.bootstrap.admin.email=",
        "shaminatech.bootstrap.admin.password=",
        "shaminatech.loyalty.expiration.enabled=false",
        "shaminatech.notifications.scheduler.enabled=false",
        "shaminatech.wallet.google.enabled=false",
        "shaminatech.wallet.google.api-base-url=http://127.0.0.1:9"
})
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
@EnabledIfSystemProperty(named = "pass.pg-it", matches = "true")
class PostgresIsolatedConcurrencyIT {

    private static final String DB = "stpass_it_" + UUID.randomUUID().toString().replace("-", "").substring(0, 12).toLowerCase(Locale.ROOT);
    private static String adminUrl;
    private static String username;
    private static String password;

    @DynamicPropertySource
    static void disposableDatabase(DynamicPropertyRegistry registry) throws Exception {
        Properties p = new Properties();
        ClassPathResource credentials = new ClassPathResource("application-credentials.yml");
        if (credentials.exists()) {
            YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean();
            yaml.setResources(credentials);
            p = yaml.getObject();
        }
        String url = System.getenv().getOrDefault("DB_URL", p.getProperty("spring.datasource.url", "jdbc:postgresql://localhost:5432/shaminatech_pass"));
        username = System.getenv().getOrDefault("DB_USERNAME", p.getProperty("spring.datasource.username", "postgres"));
        password = System.getenv().getOrDefault("DB_PASSWORD", p.getProperty("spring.datasource.password", ""));
        adminUrl = url.contains("?") ? url.substring(0, url.indexOf('?')) : url;
        // O usuário da aplicação não tem CREATEDB: o isolamento é feito por um ESQUEMA descartável próprio. Nenhuma
        // tabela do esquema principal é lida ou escrita; o esquema inteiro é apagado ao final.
        try (Connection c = DriverManager.getConnection(adminUrl, username, password); Statement s = c.createStatement()) {
            s.execute("CREATE SCHEMA " + DB);
        }
        registry.add("spring.datasource.url", () -> adminUrl + "?currentSchema=" + DB);
        registry.add("spring.jpa.properties.hibernate.default_schema", () -> DB);
        registry.add("spring.datasource.username", () -> username);
        registry.add("spring.datasource.password", () -> password);
    }

    @AfterAll
    static void dropDisposableDatabase() throws Exception {
        if (adminUrl == null) return;
        try (Connection c = DriverManager.getConnection(adminUrl, username, password); Statement s = c.createStatement()) {
            s.execute("DROP SCHEMA IF EXISTS " + DB + " CASCADE");
        }
    }

    @Autowired private JdbcTemplate jdbc;
    @Autowired private EstablishmentRepository establishments;
    @Autowired private EstablishmentPolicyRepository policies;
    @Autowired private PolicyService policyService;
    @Autowired private AppUserRepository users;
    @Autowired private MembershipRepository memberships;
    @Autowired private ConsumerRepository consumers;
    @Autowired private LoyaltyProgramRepository programs;
    @Autowired private LoyaltyRewardRepository rewards;
    @Autowired private CardEngine engine;
    @Autowired private ConsumerService consumerService;
    @Autowired private SignupLinkService signupLinks;
    @Autowired private PublicSignupService publicSignup;
    @Autowired private Clock clock;

    private Long establishmentId;
    private Long userId;
    private LoyaltyProgram program;
    private Long cardId;

    @BeforeEach
    void setUp() {
        assertThat(jdbc.queryForObject("select current_schema()", String.class)).isEqualTo(DB);
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        Establishment e = establishments.save(new Establishment("IT isolado", "it-" + suffix));
        establishmentId = e.getId();
        var policy = policyService.createFor(e);
        policy.update(1000, 30, "America/Sao_Paulo", EnumSet.of(ProgramType.POINTS, ProgramType.STAMPS));
        policies.save(policy);
        AppUser user = users.save(new AppUser("it-" + suffix + "@teste.local", "IT", "{noop}nao-usada", false));
        userId = user.getId();
        memberships.save(new Membership(e, user, MembershipRole.OWNER));
        program = new LoyaltyProgram(e, ProgramType.POINTS, "Pontos IT", 30);
        program.setPointsPerUnit(1);
        program.setSpendUnit(new BigDecimal("1.00"));
        program = programs.save(program);
        Consumer consumer = consumers.save(new Consumer(e, "Cliente IT", "1190000" + (1000 + (int) (Math.random() * 8999)), clock.instant()));
        LoyaltyCard card = engine.issue(consumers.findById(consumer.getId()).orElseThrow(), program, null, userId);
        cardId = card.getId();
    }

    // ----------------------------------------------------------------------------------------------------------

    private <T> List<Future<T>> concurrently(int threads, Callable<T> task) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch start = new CountDownLatch(1);
        List<Future<T>> futures = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            futures.add(pool.submit(() -> {
                start.await();
                return task.call();
            }));
        }
        start.countDown();
        pool.shutdown();
        assertThat(pool.awaitTermination(90, TimeUnit.SECONDS)).isTrue();
        return futures;
    }

    private CardEngine.Result earn(String amount) {
        return engine.earn(establishmentId, cardId, new CardEngine.EarnCommand(new BigDecimal(amount), null, Channel.MANUAL, null),
                UUID.randomUUID().toString(), userId);
    }

    private Long reward(String cost) {
        return rewards.save(new LoyaltyReward(program, "Brinde " + cost, new BigDecimal(cost))).getId();
    }

    private BigDecimal balance() {
        return jdbc.queryForObject("select balance from loyalty_card where id = ?", BigDecimal.class, cardId);
    }

    /** Saldo = soma do histórico = soma dos lotes, e nunca negativo. */
    private void assertLedgerIsConsistent() {
        BigDecimal balance = balance();
        BigDecimal history = jdbc.queryForObject("select coalesce(sum(amount), 0) from card_transaction where card_id = ?",
                BigDecimal.class, cardId);
        BigDecimal lots = jdbc.queryForObject("select coalesce(sum(remaining), 0) from benefit_lot where card_id = ?",
                BigDecimal.class, cardId);
        BigDecimal lastBalanceAfter = jdbc.queryForObject(
                "select balance_after from card_transaction where card_id = ? order by id desc limit 1", BigDecimal.class, cardId);
        assertThat(balance).isGreaterThanOrEqualTo(BigDecimal.ZERO);
        assertThat(history).isEqualByComparingTo(balance);
        assertThat(lots).isEqualByComparingTo(balance);
        assertThat(lastBalanceAfter).isEqualByComparingTo(balance);
    }

    private static int count(List<? extends Future<?>> futures) {
        int ok = 0;
        for (Future<?> f : futures) {
            try {
                f.get();
                ok++;
            } catch (java.util.concurrent.ExecutionException e) {
                assertThat(e.getCause()).isInstanceOf(ApiException.class); // recusa de negócio, nunca erro inesperado
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        return ok;
    }

    // ----------------------------------------------------------------------------------------------------------

    @Test
    void concurrentRedemptionsNeverSpendTheSameBalanceTwice() throws Exception {
        earn("100.00");
        Long reward = reward("60");
        int ok = count(concurrently(10, () -> engine.redeem(establishmentId, cardId,
                new CardEngine.RedeemCommand(reward, null, null, Channel.MANUAL, null), UUID.randomUUID().toString(), userId)));
        assertThat(ok).isEqualTo(1);
        assertThat(balance()).isEqualByComparingTo("40");
        assertLedgerIsConsistent();
    }

    @Test
    void purchasesAndRedemptionsAtTheSameTimeKeepTheLedgerConsistent() throws Exception {
        earn("50.00");
        Long reward = reward("30");
        AtomicInteger n = new AtomicInteger();
        List<Future<Object>> futures = concurrently(12, () -> n.incrementAndGet() % 2 == 0
                ? earn("10.00")
                : engine.redeem(establishmentId, cardId, new CardEngine.RedeemCommand(reward, null, null, Channel.MANUAL, null),
                        UUID.randomUUID().toString(), userId));
        count(futures);
        int earns = jdbc.queryForObject("select count(*) from card_transaction where card_id = ? and type = 'EARN'", Integer.class, cardId);
        int redeems = jdbc.queryForObject("select count(*) from card_transaction where card_id = ? and type = 'REDEEM'", Integer.class, cardId);
        assertThat(earns).isEqualTo(7); // 1 inicial + 6 concorrentes
        assertThat(balance()).isEqualByComparingTo(new BigDecimal(50 + 60 - 30 * redeems));
        assertLedgerIsConsistent();
    }

    @Test
    void concurrentReversalsOfTheSamePurchaseReverseItOnlyOnce() throws Exception {
        Long tx = earn("40.00").transaction().getId();
        int ok = count(concurrently(6, () -> engine.reverse(establishmentId, tx, "teste concorrente", UUID.randomUUID().toString(), userId)));
        assertThat(ok).isEqualTo(1);
        assertThat(jdbc.queryForObject("select count(*) from card_transaction where reverses_id = ?", Integer.class, tx)).isEqualTo(1);
        assertThat(balance()).isEqualByComparingTo("0");
        assertLedgerIsConsistent();
    }

    @Test
    void theSameIdempotencyKeyRedeemsOnceEvenWhenSentInParallel() throws Exception {
        earn("100.00");
        Long reward = reward("25");
        String key = UUID.randomUUID().toString();
        int replays = 0;
        for (var f : concurrently(8, () -> engine.redeem(establishmentId, cardId,
                new CardEngine.RedeemCommand(reward, null, null, Channel.QR_CODE, null), key, userId).replayed())) {
            replays += f.get() ? 1 : 0;
        }
        assertThat(replays).isEqualTo(7);
        assertThat(jdbc.queryForObject("select count(*) from card_transaction where card_id = ? and type = 'REDEEM'", Integer.class, cardId))
                .isEqualTo(1);
        assertThat(balance()).isEqualByComparingTo("75");
        assertLedgerIsConsistent();
    }

    @Test
    void theLastConsumerSlotIsTakenOnlyOnce() throws Exception {
        var policy = policies.findByEstablishmentId(establishmentId).orElseThrow();
        policy.update(3, 30, "America/Sao_Paulo", EnumSet.of(ProgramType.POINTS));
        policies.save(policy); // já existe 1 cliente ativo: restam 2 vagas
        var auth = new UsernamePasswordAuthenticationToken(AuthenticatedUser.from(users.findById(userId).orElseThrow(), clock.instant()), null, List.of());
        AtomicInteger seq = new AtomicInteger();
        int created = count(concurrently(10, () -> {
            SecurityContextHolder.getContext().setAuthentication(auth);
            int k = seq.incrementAndGet();
            try {
                return consumerService.create(establishmentId, new ConsumerRequest("Concorrente " + k,
                        "1195555" + String.format("%04d", k), null, null, false, true));
            } finally {
                SecurityContextHolder.clearContext();
            }
        }));
        assertThat(created).isEqualTo(2);
        assertThat(jdbc.queryForObject("select count(*) from consumer where establishment_id = ? and status = 'ACTIVE'",
                Integer.class, establishmentId)).isEqualTo(3);
    }

    @Test
    void concurrentPublicSignupsRespectTheLimitAndNeverDuplicateAPhone() throws Exception {
        var policy = policies.findByEstablishmentId(establishmentId).orElseThrow();
        policy.update(4, 30, "America/Sao_Paulo", EnumSet.of(ProgramType.POINTS));
        policies.save(policy); // 1 ativo: restam 3 vagas
        var auth = new UsernamePasswordAuthenticationToken(AuthenticatedUser.from(users.findById(userId).orElseThrow(), clock.instant()), null, List.of());
        SecurityContextHolder.getContext().setAuthentication(auth);
        String url = signupLinks.create(establishmentId, program.getId()).url();
        SecurityContextHolder.clearContext();
        String token = url.substring(url.lastIndexOf('/') + 1);
        String formToken = publicSignup.info(token).formToken();
        Thread.sleep(3_200); // tempo mínimo de preenchimento exigido pelo formulário

        // 6 pessoas diferentes ao mesmo tempo (só 3 vagas) + 4 envios simultâneos do MESMO telefone.
        AtomicInteger seq = new AtomicInteger();
        java.util.Set<String> codes = java.util.concurrent.ConcurrentHashMap.newKeySet();
        int ok = count(concurrently(6, () -> {
            int k = seq.incrementAndGet();
            try {
                return publicSignup.register(token, new SignupRequest("Pessoa " + k, "1197777" + String.format("%04d", k), null, true, false,
                        UUID.randomUUID().toString().replace("-", ""), formToken, null));
            } catch (ApiException e) {
                codes.add(e.getCode());
                throw e;
            }
        }));
        System.out.println("[IT] recusas do cadastro público concorrente: " + codes);
        assertThat(ok).isEqualTo(3);
        assertThat(jdbc.queryForObject("select count(*) from consumer where establishment_id = ? and status = 'ACTIVE'",
                Integer.class, establishmentId)).isEqualTo(4);

        policy = policies.findByEstablishmentId(establishmentId).orElseThrow();
        policy.update(100, 30, "America/Sao_Paulo", EnumSet.of(ProgramType.POINTS));
        policies.save(policy);
        int same = count(concurrently(4, () -> publicSignup.register(token, new SignupRequest("Mesma Pessoa", "11966661234", null, true, false,
                UUID.randomUUID().toString().replace("-", ""), formToken, null))));
        assertThat(same).isLessThanOrEqualTo(1);
        assertThat(jdbc.queryForObject("select count(*) from consumer where establishment_id = ? and phone like '%966661234'",
                Integer.class, establishmentId)).isEqualTo(1);
    }
}
