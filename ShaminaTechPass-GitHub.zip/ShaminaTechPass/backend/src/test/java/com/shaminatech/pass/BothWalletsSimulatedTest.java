package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import com.jayway.jsonpath.JsonPath;
import com.shaminatech.pass.loyalty.wallet.WalletPass;
import com.shaminatech.pass.loyalty.wallet.WalletPass.Provider;
import com.shaminatech.pass.loyalty.wallet.WalletPassRepository;

/**
 * Google e Apple ligados ao mesmo tempo (ambos SIMULADOS): um link oferece as duas carteiras, cada passe vai só para
 * o seu provedor e o fluxo do Google (Etapa 3) continua igual.
 */
class BothWalletsSimulatedTest extends LoyaltyTestSupport {

    @DynamicPropertySource
    static void wallets(DynamicPropertyRegistry registry) {
        FakeGoogleWallet google = FakeGoogleWallet.get();
        registry.add("shaminatech.wallet.google.enabled", () -> "true");
        registry.add("shaminatech.wallet.google.issuer-id", () -> FakeGoogleWallet.ISSUER_ID);
        registry.add("shaminatech.wallet.google.service-account-key-file", () -> google.keyFile().toString());
        registry.add("shaminatech.wallet.google.api-base-url", google::baseUrl);
        registry.add("shaminatech.wallet.google.fallback-logo-uri", () -> "https://example.test/logo-padrao.png");
        registry.add("shaminatech.wallet.google.async-dispatch", () -> "false");
        FakeApple apple = FakeApple.get();
        registry.add("shaminatech.wallet.apple.enabled", () -> "true");
        registry.add("shaminatech.wallet.apple.pass-type-identifier", () -> FakeApple.PASS_TYPE_ID);
        registry.add("shaminatech.wallet.apple.team-identifier", () -> FakeApple.TEAM_ID);
        registry.add("shaminatech.wallet.apple.certificate-file", () -> apple.p12().toString());
        registry.add("shaminatech.wallet.apple.certificate-password", () -> FakeApple.P12_PASSWORD);
        registry.add("shaminatech.wallet.apple.wwdr-certificate-file", () -> apple.wwdrFile().toString());
        registry.add("shaminatech.wallet.apple.web-service-base-url", () -> "https://pass.example.test");
        registry.add("shaminatech.wallet.apple.auth-secret", () -> "segredo-de-teste-com-mais-de-32-caracteres!");
        registry.add("shaminatech.wallet.apple.apns-base-url", apple::apnsUrl);
        registry.add("shaminatech.wallet.apple.support-name", () -> "ShaminaTech (teste)");
        registry.add("shaminatech.wallet.apple.support-email", () -> "suporte@example.test");
    }

    @Autowired
    private WalletPassRepository passes;

    private final FakeGoogleWallet google = FakeGoogleWallet.get();
    private long card;

    @BeforeEach
    void setUpCard() throws Exception {
        google.reset();
        FakeApple.get().reset();
        long program = pointsProgram(a, ownerA, "");
        long consumer = consumer(ownerA, a, "Joana Prado Lima", "11977771111");
        card = card(ownerA, a, consumer, program);
    }

    @Test
    void oneLinkOffersBothWalletsAndEachPassGoesToItsOwnProvider() throws Exception {
        // Caminho antigo (Etapa 3) continua funcionando e agora também prepara o passe Apple.
        String body = postJson(ownerA, base(a) + "/cards/" + card + "/wallet/google/links", "{}")
                .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString();
        String url = JsonPath.read(body, "$.url");
        String token = url.substring(url.lastIndexOf('/') + 1);

        WalletPass googlePass = passes.findByCardIdAndProvider(card, Provider.GOOGLE_WALLET).orElseThrow();
        WalletPass applePass = passes.findByCardIdAndProvider(card, Provider.APPLE_WALLET).orElseThrow();
        assertThat(googlePass.getSyncStatus()).isEqualTo(WalletPass.SyncStatus.SYNCED);
        assertThat(applePass.getSyncStatus()).isEqualTo(WalletPass.SyncStatus.SYNCED);
        // O Google recebeu só o objeto do passe Google (nunca o serial Apple).
        assertThat(google.objects).containsOnlyKeys(googlePass.getExternalId());

        mvc.perform(get("/api/public/wallet-links/" + token)).andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("READY"))
                .andExpect(jsonPath("$.saveUrl").exists())
                .andExpect(jsonPath("$.google.status").value("READY"))
                .andExpect(jsonPath("$.apple.status").value("READY"));
        mvc.perform(get("/api/public/wallet-links/" + token + "/apple")).andExpect(status().isOk());

        // Uma compra atualiza as duas carteiras.
        earn(ownerA, a, card, "{\"purchaseAmount\":20.00}", key()).andExpect(status().isCreated());
        assertThat(google.objects.get(googlePass.getExternalId()).get("loyaltyPoints").toString()).contains("20");
        assertThat(passes.findById(applePass.getId()).orElseThrow().getContentUpdatedAt())
                .isAfterOrEqualTo(applePass.getContentUpdatedAt());
        assertThat(passes.findByCardId(card)).hasSize(2);
    }
}
