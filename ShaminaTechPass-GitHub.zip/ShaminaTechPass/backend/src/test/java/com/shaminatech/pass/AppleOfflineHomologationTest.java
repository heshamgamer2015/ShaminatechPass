package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.ByteArrayInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoVerifierBuilder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import com.shaminatech.pass.loyalty.wallet.apple.AppleImages;
import com.shaminatech.pass.loyalty.wallet.apple.AppleOfflineHomologation;
import com.shaminatech.pass.loyalty.wallet.apple.AppleWalletException;
import com.shaminatech.pass.loyalty.wallet.apple.AppleWalletProperties;

import tools.jackson.databind.json.JsonMapper;

/** Passe offline de homologação local: sem web service, assinado, isolado do fluxo de passes atualizáveis. */
class AppleOfflineHomologationTest {

    private final JsonMapper json = JsonMapper.builder().build();
    private final Clock clock = Clock.fixed(Instant.parse("2026-11-25T12:00:00Z"), ZoneOffset.UTC);

    private static AppleWalletProperties props(String passType, String team, String p12, String password, String wwdr,
                                               String supportName, String supportEmail) {
        return new AppleWalletProperties(false, passType, team, p12, password, wwdr, null, false, null, null, supportName,
                supportEmail, null, null, null, null, null);
    }

    private static AppleWalletProperties valid() {
        FakeApple fake = FakeApple.get();
        return props(FakeApple.PASS_TYPE_ID, FakeApple.TEAM_ID, fake.p12().toString(), FakeApple.P12_PASSWORD,
                fake.wwdrFile().toString(), "ShaminaTech", "shaminatech@gmail.com");
    }

    private AppleOfflineHomologation generator(AppleWalletProperties p, Path dir) {
        return new AppleOfflineHomologation(p, new AppleImages(), json, clock, dir.toString());
    }

    @Test
    void offlineRequirementsDoNotRelaxTheUpdatablePassRequirements() {
        AppleWalletProperties p = valid();
        assertThat(p.missingForOfflinePass()).isEmpty();
        // Sem URL pública HTTPS e sem segredo, o fluxo normal continua indisponível.
        assertThat(p.missing()).anyMatch(m -> m.contains("URL pública")).anyMatch(m -> m.contains("Segredo"));
        assertThat(props(null, null, null, null, null, null, null).missingForOfflinePass()).hasSize(5);
        assertThat(props(FakeApple.PASS_TYPE_ID, FakeApple.TEAM_ID, "a.p12", "", "w.cer", "ShaminaTech", null)
                .missingForOfflinePass()).singleElement().asString().contains("suporte");
    }

    @Test
    @SuppressWarnings("unchecked")
    void generatesASignedOfflinePassWithoutWebService(@TempDir Path dir) throws Exception {
        Path file = generator(valid(), dir).generate();
        assertThat(file.getFileName().toString()).startsWith("shaminatech-pass-demo-stp-homolog-20261125120000-").endsWith(".pkpass");
        Map<String, byte[]> files = unzip(Files.readAllBytes(file));
        assertThat(files.keySet()).contains("pass.json", "manifest.json", "signature", "icon.png", "icon@2x.png", "icon@3x.png",
                "logo.png", "logo@2x.png", "logo@3x.png");

        Map<String, Object> pass = json.readValue(files.get("pass.json"), Map.class);
        assertThat(pass).containsEntry("formatVersion", 1).containsEntry("passTypeIdentifier", FakeApple.PASS_TYPE_ID)
                .containsEntry("teamIdentifier", FakeApple.TEAM_ID).containsEntry("organizationName", "ShaminaTech Pass")
                .containsEntry("backgroundColor", "rgb(244, 63, 94)").containsKey("storeCard").containsKey("barcodes")
                .doesNotContainKey("webServiceURL").doesNotContainKey("authenticationToken")
                .doesNotContainKey("expirationDate").doesNotContainKey("voided").doesNotContainKey("locations");
        assertThat((String) pass.get("serialNumber")).matches("stp-homolog-20261125120000-[0-9a-f]{16}");
        assertThat(new String(files.get("pass.json"), "UTF-8")).contains("shaminatech@gmail.com").contains("Sem valor comercial");

        Map<String, String> manifest = json.readValue(files.get("manifest.json"), Map.class);
        assertThat(manifest.keySet()).containsExactlyInAnyOrderElementsOf(files.keySet().stream()
                .filter(n -> !n.equals("manifest.json") && !n.equals("signature")).toList());
        for (Map.Entry<String, String> e : manifest.entrySet()) {
            assertThat(e.getValue()).isEqualTo(HexFormat.of().formatHex(MessageDigest.getInstance("SHA-1").digest(files.get(e.getKey()))));
        }
        CMSSignedData signed = new CMSSignedData(new CMSProcessableByteArray(files.get("manifest.json")), files.get("signature"));
        SignerInformation signer = signed.getSignerInfos().getSigners().iterator().next();
        assertThat(signer.verify(new JcaSimpleSignerInfoVerifierBuilder().build(FakeApple.get().leaf()))).isTrue();
        assertThat(signed.isDetachedSignature()).isTrue();
    }

    /** A Apple exige chave única por campo em todo o passe; chave repetida torna o passe inválido no iPhone. */
    @Test
    @SuppressWarnings("unchecked")
    void fieldKeysAreUniqueAcrossThePass() {
        for (com.shaminatech.pass.loyalty.card.CardEnums.CardStatus status : com.shaminatech.pass.loyalty.card.CardEnums.CardStatus.values()) {
            Map<String, Object> pass = com.shaminatech.pass.loyalty.wallet.apple.ApplePassMapper.passJson(withStatus(status));
            Map<String, Object> card = (Map<String, Object>) pass.get("storeCard");
            List<String> keys = card.values().stream().flatMap(g -> ((List<Map<String, Object>>) g).stream())
                    .map(f -> (String) f.get("key")).toList();
            assertThat(keys).as(status.name()).doesNotHaveDuplicates();
        }
    }

    private static com.shaminatech.pass.loyalty.wallet.apple.ApplePassMapper.PassData withStatus(
            com.shaminatech.pass.loyalty.card.CardEnums.CardStatus status) {
        return new com.shaminatech.pass.loyalty.wallet.apple.ApplePassMapper.PassData("stp1", "pass.x.y", "TESTTEAM12", null, null,
                "Loja", "Programa", "#F43F5E", "#FFFFFF", status, com.shaminatech.pass.loyalty.ProgramType.STAMPS,
                java.math.BigDecimal.ONE, 10, "Ana", "CODE", "CODE", Instant.parse("2027-01-01T00:00:00Z"), "01/01/2027 00:00",
                "1 carimbo(s) em 01/01/2027", "Mensagem", "Recompensa", "Descrição do programa", "loja@x.test", "4599999",
                "ShaminaTech", "s@x.test", null, null);
    }

    @Test
    void everyGenerationHasAUniqueSerial(@TempDir Path dir) {
        AppleOfflineHomologation g = generator(valid(), dir);
        assertThat(g.generate()).isNotEqualTo(g.generate());
    }

    @Test
    void certificateAndConfigurationErrorsStopTheGenerationWithoutLeakingTheSecret(@TempDir Path dir) throws Exception {
        FakeApple fake = FakeApple.get();
        String wrong = "senha-errada-123";
        List<AppleWalletProperties> broken = List.of(
                props(FakeApple.PASS_TYPE_ID, FakeApple.TEAM_ID, fake.p12().toString(), wrong, fake.wwdrFile().toString(), "ShaminaTech", "s@x.test"),
                props("pass.outro.id", FakeApple.TEAM_ID, fake.p12().toString(), FakeApple.P12_PASSWORD, fake.wwdrFile().toString(), "ShaminaTech", "s@x.test"),
                props(FakeApple.PASS_TYPE_ID, "OUTROTEAM1", fake.p12().toString(), FakeApple.P12_PASSWORD, fake.wwdrFile().toString(), "ShaminaTech", "s@x.test"),
                props(FakeApple.PASS_TYPE_ID, FakeApple.TEAM_ID, dir.resolve("ausente.p12").toString(), FakeApple.P12_PASSWORD, fake.wwdrFile().toString(), "ShaminaTech", "s@x.test"),
                props(FakeApple.PASS_TYPE_ID, FakeApple.TEAM_ID, fake.p12().toString(), FakeApple.P12_PASSWORD, dir.resolve("ausente.cer").toString(), "ShaminaTech", "s@x.test"),
                props(FakeApple.PASS_TYPE_ID, FakeApple.TEAM_ID, fake.p12().toString(), FakeApple.P12_PASSWORD, fake.wwdrFile().toString(), null, null));
        for (AppleWalletProperties p : broken) {
            assertThatThrownBy(() -> generator(p, dir).generate()).isInstanceOf(AppleWalletException.class)
                    .satisfies(e -> assertThat(e.getMessage()).doesNotContain(wrong).doesNotContain(FakeApple.P12_PASSWORD));
        }
        try (var list = Files.list(dir)) {
            assertThat(list.filter(f -> f.toString().endsWith(".pkpass"))).isEmpty();
        }
        assertThat(valid().toString()).doesNotContain(FakeApple.P12_PASSWORD).as("a senha não aparece em toString");
    }

    private static Map<String, byte[]> unzip(byte[] data) throws Exception {
        Map<String, byte[]> files = new LinkedHashMap<>();
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(data))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                assertThat(entry.getName()).doesNotContain("/");
                files.put(entry.getName(), zip.readAllBytes());
            }
        }
        return files;
    }
}
