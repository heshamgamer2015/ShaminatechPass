package com.shaminatech.pass;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.EnumSet;

import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.establishment.EstablishmentRepository;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicy;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicyRepository;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.membership.Membership;
import com.shaminatech.pass.membership.MembershipRepository;
import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.user.AppUser;
import com.shaminatech.pass.user.AppUserRepository;
import com.shaminatech.pass.user.PlatformRole;

/**
 * Base dos testes de integração: aplicação completa + MockMvc sobre H2 em memória
 * (modo PostgreSQL). Nenhum teste toca o banco de desenvolvimento nem usa credenciais reais.
 */
@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(properties = {
        "spring.datasource.url=jdbc:h2:mem:pass-test;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DEFAULT_NULL_ORDERING=HIGH;DB_CLOSE_DELAY=-1",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.hibernate.ddl-auto=create-drop",
        "shaminatech.bootstrap.admin.email=",
        "shaminatech.bootstrap.admin.password=",
        "shaminatech.security.max-failed-logins=3",
        "shaminatech.loyalty.expiration.enabled=false",
        "shaminatech.public.rate-limit-per-minute=100000",
        "shaminatech.public.signup.max-attempts-per-ip-per-hour=100000",
        "shaminatech.notifications.scheduler.enabled=false",
        // Isola os testes do application-credentials.yml local: nunca chamam o Google real.
        "shaminatech.wallet.google.enabled=false",
        "shaminatech.wallet.google.issuer-id=",
        "shaminatech.wallet.google.service-account-key-file=",
        "shaminatech.wallet.google.api-base-url=http://127.0.0.1:9",
        "shaminatech.wallet.google.origins=http://localhost:4203",
        "shaminatech.wallet.google.fallback-logo-uri=",
        "shaminatech.wallet.google.public-base-url=",
        "shaminatech.wallet.public-page-base-url=http://localhost:4203",
        "shaminatech.wallet.apple.enabled=false",
        "shaminatech.wallet.apple.certificate-file=",
        "shaminatech.wallet.apple.web-service-base-url=",
        "shaminatech.wallet.apple.apns-base-url=http://127.0.0.1:9",
        "shaminatech.wallet.google.sweep-interval=PT1H",
        "shaminatech.wallet.google.sweep-initial-delay=PT1H"
})
@Import(TestClockConfig.class)
public abstract class IntegrationTestSupport {

    /** Senha fictícia usada apenas nos testes. */
    protected static final String PASSWORD = "Senha-de-teste-123";
    private static String passwordHash;

    @Autowired
    protected MockMvc mvc;
    @Autowired
    protected AppUserRepository users;
    @Autowired
    protected EstablishmentRepository establishments;
    @Autowired
    protected MembershipRepository memberships;
    @Autowired
    protected JdbcTemplate jdbc;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    protected PolicyService policyService;
    @Autowired
    protected EstablishmentPolicyRepository policies;
    @Autowired
    protected MutableClock clock;

    @BeforeEach
    void cleanDatabase() {
        clock.reset();
        for (String table : new String[] {"establishment_plan", "password_reset_token", "benefit_lot_usage", "benefit_lot", "wallet_reminder", "notification_settings", "establishment_location", "public_signup", "public_signup_link", "apple_device_registration", "wallet_link", "wallet_pass", "wallet_class", "card_transaction", "loyalty_card",
                "loyalty_reward", "vip_tier", "stored_image", "loyalty_program", "consumer", "establishment_policy",
                "platform_loyalty_defaults"}) {
            jdbc.update("delete from " + table);
        }
        jdbc.update("delete from audit_event");
        jdbc.update("delete from membership");
        jdbc.update("delete from app_user");
        jdbc.update("delete from establishment");
    }

    protected AppUser user(String email) {
        return user(email, false);
    }

    protected AppUser user(String email, boolean passwordChangeRequired) {
        if (passwordHash == null) {
            passwordHash = passwordEncoder.encode(PASSWORD);
        }
        return users.save(new AppUser(email, "Usuário " + email, passwordHash, passwordChangeRequired));
    }

    protected AppUser platformAdmin(String email) {
        AppUser admin = user(email);
        admin.setPlatformRole(PlatformRole.PLATFORM_ADMIN);
        return users.save(admin);
    }

    /** Estabelecimento com política criada a partir das regras padrão (limite 100; STAMPS e POINTS). */
    protected Establishment establishment(String slug) {
        Establishment establishment = establishments.save(new Establishment("Estabelecimento " + slug, slug));
        policyService.createFor(establishment);
        return establishment;
    }

    /** Ajusta os limites diretamente (atalho de teste; o fluxo real passa pelo painel ShaminaTech). */
    protected void policy(Establishment establishment, int maxActiveConsumers, ProgramType... types) {
        EstablishmentPolicy policy = policies.findByEstablishmentId(establishment.getId()).orElseThrow();
        policy.update(maxActiveConsumers, policy.getDefaultInactivityDays(), policy.getTimeZone(),
                types.length == 0 ? EnumSet.noneOf(ProgramType.class) : EnumSet.copyOf(Arrays.asList(types)));
        policies.save(policy);
    }

    protected Membership member(Establishment establishment, AppUser user, MembershipRole role) {
        return memberships.save(new Membership(establishment, user, role));
    }

    protected MockHttpSession login(String email) throws Exception {
        return login(email, PASSWORD);
    }

    protected MockHttpSession login(String email, String password) throws Exception {
        MvcResult result = mvc.perform(post("/api/auth/login").with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(loginJson(email, password)))
                .andExpect(status().isOk())
                .andReturn();
        return (MockHttpSession) result.getRequest().getSession(false);
    }

    protected static String loginJson(String email, String password) {
        return "{\"email\":\"" + email + "\",\"password\":\"" + password + "\"}";
    }
}
