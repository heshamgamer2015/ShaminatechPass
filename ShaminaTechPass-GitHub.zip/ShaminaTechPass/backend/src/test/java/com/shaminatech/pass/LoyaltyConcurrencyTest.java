package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.shaminatech.pass.loyalty.card.CardEngine;
import com.shaminatech.pass.loyalty.card.CardEnums.Channel;

/** Operações simultâneas: nenhuma concessão se perde, nada é duplicado e o limite de clientes não é ultrapassado. */
class LoyaltyConcurrencyTest extends LoyaltyTestSupport {

    @Autowired
    private CardEngine engine;

    private <T> List<Future<T>> runConcurrently(int threads, Callable<T> task) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch start = new CountDownLatch(1);
        List<Future<T>> futures = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            futures.add(pool.submit(() -> {
                start.await();
                return task.call();
            }));
        }
        start.countDown();
        pool.shutdown();
        assertThat(pool.awaitTermination(60, TimeUnit.SECONDS)).isTrue();
        return futures;
    }

    @Test
    void concurrentEarningsAreAllAppliedExactly() throws Exception {
        long card = card(ownerA, a, consumer(ownerA, a, "Ana", "11977776666"), pointsProgram(a, ownerA, ""));
        Long actor = users.findByEmail("dono.a@teste.local").orElseThrow().getId();
        var futures = runConcurrently(12, () -> engine.earn(a.getId(), card,
                new CardEngine.EarnCommand(new BigDecimal("7.00"), null, Channel.MANUAL, null), key(), actor));
        for (var f : futures) {
            f.get();
        }
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo("84");
        assertThat(countTransactions(card, "EARN")).isEqualTo(12);
    }

    @Test
    void concurrentDuplicatesWithTheSameKeyCreditOnce() throws Exception {
        long card = card(ownerA, a, consumer(ownerA, a, "Beto", "11977775555"), pointsProgram(a, ownerA, ""));
        Long actor = users.findByEmail("dono.a@teste.local").orElseThrow().getId();
        String sameKey = key();
        var futures = runConcurrently(8, () -> engine.earn(a.getId(), card,
                new CardEngine.EarnCommand(new BigDecimal("10.00"), null, Channel.MANUAL, null), sameKey, actor).replayed());
        int replays = 0;
        for (var f : futures) {
            if (f.get()) {
                replays++;
            }
        }
        assertThat(replays).isEqualTo(7);
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo("10");
        assertThat(countTransactions(card, "EARN")).isEqualTo(1);
    }

    @Test
    void concurrentRedemptionsNeverOverdrawTheBalance() throws Exception {
        long program = pointsProgram(a, ownerA, "");
        long reward = id(postJson(ownerA, base(a) + "/programs/" + program + "/rewards", "{\"name\":\"Brinde\",\"cost\":10}"));
        long card = card(ownerA, a, consumer(ownerA, a, "Caio", "11977774444"), program);
        earn(ownerA, a, card, "{\"purchaseAmount\":35.00}", key());
        Long actor = users.findByEmail("dono.a@teste.local").orElseThrow().getId();
        var futures = runConcurrently(8, () -> {
            try {
                engine.redeem(a.getId(), card, new CardEngine.RedeemCommand(reward, null, null, Channel.MANUAL, null), key(), actor);
                return true;
            } catch (RuntimeException e) {
                return false;
            }
        });
        int ok = 0;
        for (var f : futures) {
            if (f.get()) {
                ok++;
            }
        }
        assertThat(ok).isEqualTo(3);
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo("5");
    }

    @Test
    void concurrentRegistrationsDoNotExceedTheConsumerLimit() throws Exception {
        policy(a, 5, com.shaminatech.pass.loyalty.ProgramType.STAMPS);
        int[] counter = {0};
        var futures = runConcurrently(12, () -> {
            int n;
            synchronized (counter) {
                n = ++counter[0];
            }
            return postJson(ownerA, base(a) + "/consumers", "{\"fullName\":\"Cliente " + n + "\",\"phone\":\"119666600"
                    + String.format("%02d", n) + "\",\"privacyAcknowledged\":true}").andReturn().getResponse().getStatus();
        });
        int created = 0;
        int rejected = 0;
        for (var f : futures) {
            int status = f.get();
            if (status == 201) {
                created++;
            } else if (status == 409) {
                rejected++;
            }
        }
        assertThat(created).isEqualTo(5);
        assertThat(rejected).isEqualTo(7);
        assertThat(jdbc.queryForObject("select count(*) from consumer where establishment_id = ? and status = 'ACTIVE'",
                Integer.class, a.getId())).isEqualTo(5);
    }
}
