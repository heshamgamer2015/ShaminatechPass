package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import com.jayway.jsonpath.JsonPath;

/**
 * Etapa 8 — isolamento multiempresa com identificadores manipulados. A empresa A usa a PRÓPRIA rota
 * (/api/establishments/{A}/...) com identificadores de recursos da empresa B, e também tenta a rota de B diretamente.
 * Nenhuma tentativa pode responder 2xx nem alterar os dados de B.
 */
class CrossTenantAccessTest extends LoyaltyTestSupport {

    private static final String LOCATION = "{\"name\":\"Loja\",\"addressLine\":\"Av. Paulista, 1000\",\"city\":\"São Paulo\","
            + "\"state\":\"sp\",\"postalCode\":\"01310-100\",\"latitude\":-23.56,\"longitude\":-46.65}";

    private MockHttpServletRequestBuilder json(MockHttpServletRequestBuilder builder, String body) {
        return builder.session(ownerA).with(csrf()).header("Idempotency-Key", key()).contentType(MediaType.APPLICATION_JSON).content(body);
    }

    @Test
    void anEstablishmentCannotReadOrChangeAnotherEstablishmentsResources() throws Exception {
        // Recursos da empresa B.
        long bProgram = pointsProgram(b, ownerB, "");
        long bConsumer = consumer(ownerB, b, "Cliente B", "11911112222");
        long bCard = card(ownerB, b, bConsumer, bProgram);
        String bTxBody = earn(ownerB, b, bCard, "{\"purchaseAmount\":50.00}", key()).andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        long bTx = ((Number) JsonPath.read(bTxBody, "$.transaction.id")).longValue();
        long bReward = ((Number) JsonPath.read(postJson(ownerB, base(b) + "/programs/" + bProgram + "/rewards",
                "{\"name\":\"Brinde B\",\"cost\":10}").andExpect(status().isCreated()).andReturn().getResponse().getContentAsString(), "$.id"))
                .longValue();
        long bLink = ((Number) JsonPath.read(postJson(ownerB, base(b) + "/programs/" + bProgram + "/signup-link", "{}")
                .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString(), "$.id")).longValue();
        long bLocation = ((Number) JsonPath.read(postJson(ownerB, base(b) + "/locations", LOCATION)
                .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString(), "$.id")).longValue();
        String bCode = JsonPath.read(getJson(ownerB, base(b) + "/cards/" + bCard), "$.card.code");
        String balanceBefore = getJson(ownerB, base(b) + "/cards/" + bCard);

        String A = base(a);
        List<MockHttpServletRequestBuilder> attempts = new ArrayList<>(List.of(
                // Clientes
                get(A + "/consumers/" + bConsumer).session(ownerA),
                get(A + "/consumers/" + bConsumer + "/transactions").session(ownerA),
                json(put(A + "/consumers/" + bConsumer), "{\"fullName\":\"Invasor\",\"phone\":\"11911112222\",\"marketingOptIn\":false}"),
                json(patch(A + "/consumers/" + bConsumer + "/status"), "{\"status\":\"INACTIVE\"}"),
                // Programas, personalização e recompensas
                get(A + "/programs/" + bProgram).session(ownerA),
                json(patch(A + "/programs/" + bProgram + "/status"), "{\"status\":\"ARCHIVED\"}"),
                json(put(A + "/programs/" + bProgram + "/design"), "{\"brandColor\":\"#000000\",\"textColor\":\"#FFFFFF\"}"),
                json(post(A + "/programs/" + bProgram + "/rewards"), "{\"name\":\"X\",\"cost\":1}"),
                json(put(A + "/rewards/" + bReward), "{\"name\":\"X\",\"cost\":1,\"active\":false}"),
                // Cartões, saldos e movimentações
                get(A + "/cards/" + bCard).session(ownerA),
                get(A + "/cards/" + bCard + "/transactions").session(ownerA),
                get(A + "/cards/lookup?code=" + bCode).session(ownerA),
                json(post(A + "/cards/" + bCard + "/earn"), "{\"purchaseAmount\":1000.00}"),
                json(post(A + "/cards/" + bCard + "/redeem"), "{\"rewardId\":" + bReward + "}"),
                json(post(A + "/cards/" + bCard + "/suspend"), "{\"reason\":\"x\"}"),
                json(post(A + "/cards/" + bCard + "/cancel"), "{\"reason\":\"x\"}"),
                json(post(A + "/transactions/" + bTx + "/reverse"), "{\"reason\":\"x\"}"),
                json(post(A + "/cards"), "{\"consumerId\":" + bConsumer + ",\"programId\":" + bProgram + "}"),
                // QR Code de cadastro
                json(post(A + "/signup-links/" + bLink + "/status"), "{\"active\":false}"),
                json(post(A + "/signup-links/" + bLink + "/regenerate"), "{}"),
                get(A + "/signup-links/" + bLink + "/qr").session(ownerA),
                json(post(A + "/programs/" + bProgram + "/signup-link"), "{}"),
                // Carteiras, localizações e notificações
                get(A + "/cards/" + bCard + "/wallet").session(ownerA),
                json(post(A + "/cards/" + bCard + "/wallet/google/links"), "{}"),
                json(put(A + "/locations/" + bLocation), LOCATION),
                delete(A + "/locations/" + bLocation).session(ownerA).with(csrf()),
                // A rota da empresa B diretamente, com a sessão de A
                get(base(b)).session(ownerA),
                get(base(b) + "/consumers").session(ownerA),
                get(base(b) + "/cards").session(ownerA),
                get(base(b) + "/transactions").session(ownerA),
                get(base(b) + "/overview").session(ownerA),
                get(base(b) + "/indicators").session(ownerA),
                get(base(b) + "/notifications").session(ownerA),
                get(base(b) + "/signup-links").session(ownerA),
                get(base(b) + "/wallet").session(ownerA),
                get(base(b) + "/audit").session(ownerA),
                json(put(base(b) + "/notifications/settings"), "{}"),
                json(post(base(b) + "/cards/" + bCard + "/earn"), "{\"purchaseAmount\":1000.00}")));

        List<String> leaks = new ArrayList<>();
        for (MockHttpServletRequestBuilder attempt : attempts) {
            var response = mvc.perform(attempt).andReturn().getResponse();
            var request = attempt.buildRequest(new org.springframework.mock.web.MockServletContext());
            if (response.getStatus() < 400) {
                leaks.add(request.getMethod() + " " + request.getRequestURI() + " -> " + response.getStatus());
            }
        }
        assertThat(leaks).as("acessos indevidos entre empresas").isEmpty();

        // Os dados de B continuam intactos.
        assertThat(getJson(ownerB, base(b) + "/cards/" + bCard)).isEqualTo(balanceBefore);
        assertThat((String) JsonPath.read(getJson(ownerB, base(b) + "/consumers/" + bConsumer), "$.consumer.fullName")).isEqualTo("Cliente B");
        assertThat((String) JsonPath.read(getJson(ownerB, base(b) + "/programs/" + bProgram), "$.status")).isEqualTo("ACTIVE");
        assertThat(countTransactions(bCard, "REVERSAL")).isZero();
        assertThat(jdbc.queryForObject("select active from public_signup_link where id = ?", Boolean.class, bLink)).isTrue();
        assertThat(jdbc.queryForObject("select count(*) from establishment_location where id = ?", Integer.class, bLocation)).isEqualTo(1);
    }

    @Test
    void walletLinksAndPassesOfAnotherEstablishmentCannotBeRevokedOrRetried() throws Exception {
        long bProgram = pointsProgram(b, ownerB, "");
        long bCard = card(ownerB, b, consumer(ownerB, b, "Cliente B2", "11911113333"), bProgram);
        // IDs arbitrários (inclusive inexistentes) nunca podem ser manipulados pela empresa A.
        for (long id : new long[] {1, 2, 3, bCard}) {
            assertThat(mvc.perform(post(base(a) + "/wallet/links/" + id + "/revoke").session(ownerA).with(csrf()))
                    .andReturn().getResponse().getStatus()).isGreaterThanOrEqualTo(400);
            assertThat(mvc.perform(post(base(a) + "/wallet/passes/" + id + "/retry").session(ownerA).with(csrf()))
                    .andReturn().getResponse().getStatus()).isGreaterThanOrEqualTo(400);
        }
    }
}
