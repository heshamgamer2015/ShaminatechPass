package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Instant;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;

import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.user.AppUser;
import com.shaminatech.pass.user.UserStatus;

class AuthFlowTest extends IntegrationTestSupport {

    @Test
    void healthIsPublicAndReportsDatabase() throws Exception {
        mvc.perform(get("/api/health"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("UP"))
                .andExpect(jsonPath("$.database").value("UP"));
    }

    @Test
    void protectedEndpointsRequireAuthentication() throws Exception {
        mvc.perform(get("/api/auth/me"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("UNAUTHENTICATED"));
        mvc.perform(get("/api/establishments/1")).andExpect(status().isUnauthorized());
    }

    @Test
    void unmappedPathsAreDenied() throws Exception {
        mvc.perform(get("/qualquer-coisa")).andExpect(status().is4xxClientError());
    }

    @Test
    void loginCreatesSessionAndReturnsProfileWithoutSecrets() throws Exception {
        var establishment = establishment("padaria");
        AppUser owner = user("dono@teste.local");
        member(establishment, owner, MembershipRole.OWNER);

        mvc.perform(post("/api/auth/login").with(csrf()).contentType(MediaType.APPLICATION_JSON)
                        .content(loginJson("DONO@Teste.Local", PASSWORD)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("dono@teste.local"))
                .andExpect(jsonPath("$.memberships[0].establishmentId").value(establishment.getId()))
                .andExpect(jsonPath("$.memberships[0].role").value("OWNER"))
                .andExpect(content().string(not(containsString("password\""))))
                .andExpect(content().string(not(containsString("$2a$"))));

        MockHttpSession session = login("dono@teste.local");
        mvc.perform(get("/api/auth/me").session(session))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fullName").value("Usuário dono@teste.local"));
    }

    @Test
    void wrongPasswordAndUnknownEmailGetTheSameGenericAnswer() throws Exception {
        user("existe@teste.local");
        String expected = "E-mail ou senha inválidos.";

        mvc.perform(post("/api/auth/login").with(csrf()).contentType(MediaType.APPLICATION_JSON)
                        .content(loginJson("existe@teste.local", "senha-errada-1")))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.detail").value(expected));
        mvc.perform(post("/api/auth/login").with(csrf()).contentType(MediaType.APPLICATION_JSON)
                        .content(loginJson("nao-existe@teste.local", "senha-errada-1")))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.detail").value(expected));
    }

    @Test
    void loginWithoutCsrfTokenIsRejected() throws Exception {
        user("csrf@teste.local");
        mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
                        .content(loginJson("csrf@teste.local", PASSWORD)))
                .andExpect(status().isForbidden());
    }

    @Test
    void loginValidatesInput() throws Exception {
        mvc.perform(post("/api/auth/login").with(csrf()).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"nao-e-email\",\"password\":\"\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"))
                .andExpect(jsonPath("$.errors.length()").value(2));
        mvc.perform(post("/api/auth/login").with(csrf()).contentType(MediaType.APPLICATION_JSON).content("{quebrado"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("MALFORMED_REQUEST"));
    }

    @Test
    void accountIsLockedAfterConsecutiveFailures() throws Exception {
        user("bloqueio@teste.local");
        for (int i = 0; i < 3; i++) {
            mvc.perform(post("/api/auth/login").with(csrf()).contentType(MediaType.APPLICATION_JSON)
                            .content(loginJson("bloqueio@teste.local", "senha-errada-1")))
                    .andExpect(status().isUnauthorized());
        }
        // Mesmo com a senha correta, a conta permanece bloqueada temporariamente.
        mvc.perform(post("/api/auth/login").with(csrf()).contentType(MediaType.APPLICATION_JSON)
                        .content(loginJson("bloqueio@teste.local", PASSWORD)))
                .andExpect(status().isUnauthorized());
        AppUser locked = users.findByEmail("bloqueio@teste.local").orElseThrow();
        assertThat(locked.isLocked(clock.instant())).isTrue();
    }

    @Test
    void disabledUserCannotLogin() throws Exception {
        AppUser user = user("desativado@teste.local");
        user.setStatus(UserStatus.DISABLED);
        users.save(user);
        mvc.perform(post("/api/auth/login").with(csrf()).contentType(MediaType.APPLICATION_JSON)
                        .content(loginJson("desativado@teste.local", PASSWORD)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void disablingAUserRevokesTheirActiveSession() throws Exception {
        user("revogado@teste.local");
        MockHttpSession session = login("revogado@teste.local");
        AppUser user = users.findByEmail("revogado@teste.local").orElseThrow();
        user.setStatus(UserStatus.DISABLED);
        users.save(user);

        mvc.perform(get("/api/auth/me").session(session))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("SESSION_REVOKED"));
    }

    @Test
    void logoutEndsTheSession() throws Exception {
        user("sair@teste.local");
        MockHttpSession session = login("sair@teste.local");
        mvc.perform(post("/api/auth/logout").session(session).with(csrf())).andExpect(status().isNoContent());
        mvc.perform(get("/api/auth/me").session(session)).andExpect(status().isUnauthorized());
    }

    @Test
    void temporaryPasswordMustBeChangedBeforeUsingTheSystem() throws Exception {
        var establishment = establishment("troca-senha");
        member(establishment, user("novo@teste.local", true), MembershipRole.OWNER);
        MockHttpSession session = login("novo@teste.local");

        mvc.perform(get("/api/establishments/" + establishment.getId()).session(session))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("PASSWORD_CHANGE_REQUIRED"));

        mvc.perform(post("/api/auth/change-password").session(session).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"currentPassword\":\"" + PASSWORD + "\",\"newPassword\":\"curta\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].field").value("newPassword"));
        mvc.perform(post("/api/auth/change-password").session(session).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"currentPassword\":\"errada-123456\",\"newPassword\":\"NovaSenha-2026\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].field").value("currentPassword"));
        mvc.perform(post("/api/auth/change-password").session(session).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"currentPassword\":\"" + PASSWORD + "\",\"newPassword\":\"NovaSenha-2026\"}"))
                .andExpect(status().isNoContent());

        mvc.perform(get("/api/establishments/" + establishment.getId()).session(session)).andExpect(status().isOk());
        login("novo@teste.local", "NovaSenha-2026");
    }
}
