package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.ZoneId;

import org.junit.jupiter.api.Test;

import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.notify.NotificationSettings;
import com.shaminatech.pass.loyalty.notify.ReminderCategory;
import com.shaminatech.pass.loyalty.notify.ReminderRules;
import com.shaminatech.pass.loyalty.notify.ReminderRules.CardSnapshot;

/** Regras puras de lembrete: fusos horários, critérios por tipo de programa e textos com dados verdadeiros. */
class ReminderRulesUnitTest {

    private static final ZoneId SP = ZoneId.of("America/Sao_Paulo");
    private static final ZoneId TOKYO = ZoneId.of("Asia/Tokyo");

    private static NotificationSettings settings(int stamps, int pointsPercent, int expiryDays) {
        NotificationSettings s = new NotificationSettings(1L);
        s.update(true, stamps, pointsPercent, true, expiryDays, true, 30, 7, false, null);
        return s;
    }

    private static CardSnapshot snapshot(ProgramType type, String available, Instant expiresAt, BigDecimal rewardCost) {
        return new CardSnapshot(7L, CardStatus.ACTIVE, type, "Café", "Cafeteria", new BigDecimal(available), 10, "Um café", 0,
                expiresAt, null, Instant.parse("2026-11-01T12:00:00Z"), true, false, rewardCost, "Brinde");
    }

    @Test
    void expiryDaysAreCountedInTheEstablishmentTimeZone() {
        // Vale até 05/12 23:59:59 em São Paulo (06/12 03:00 UTC).
        Instant expires = Instant.parse("2026-12-06T03:00:00Z");
        Instant now = Instant.parse("2026-12-03T02:30:00Z"); // 02/12 23:30 em SP; 03/12 11:30 em Tóquio
        CardSnapshot c = snapshot(ProgramType.STAMPS, "1", expires, null);
        var sp = ReminderRules.evaluate(ReminderCategory.EXPIRY, c, settings(1, 10, 3), SP, now);
        assertThat(sp).isPresent();
        assertThat(sp.get().body()).contains("vence em 3 dias (05/12)");
        // Em Tóquio o último dia é 06/12 12:59 e hoje já é 03/12: também 3 dias, mas a data exibida muda.
        var tokyo = ReminderRules.evaluate(ReminderCategory.EXPIRY, c, settings(1, 10, 3), TOKYO, now);
        assertThat(tokyo.get().body()).contains("(06/12)");
        // Com aviso de 2 dias, em SP ainda não é hora.
        assertThat(ReminderRules.evaluate(ReminderCategory.EXPIRY, c, settings(1, 10, 2), SP, now)).isEmpty();
        // Último dia: "vence hoje".
        var today = ReminderRules.evaluate(ReminderCategory.EXPIRY, c, settings(1, 10, 2), SP, Instant.parse("2026-12-05T20:00:00Z"));
        assertThat(today.get().body()).contains("vence hoje");
    }

    @Test
    void nearRewardFollowsTheProgramType() {
        Instant expires = Instant.parse("2027-01-01T03:00:00Z");
        Instant now = Instant.parse("2026-12-01T15:00:00Z");
        assertThat(ReminderRules.evaluate(ReminderCategory.NEAR_REWARD, snapshot(ProgramType.STAMPS, "8", expires, null),
                settings(2, 10, 3), SP, now).get().body()).isEqualTo("Faltam apenas 2 carimbos para completar seu cartão e ganhar: Um café!");
        assertThat(ReminderRules.evaluate(ReminderCategory.NEAR_REWARD, snapshot(ProgramType.STAMPS, "10", expires, null),
                settings(3, 10, 3), SP, now)).isEmpty(); // completo: não é "perto"
        var points = ReminderRules.evaluate(ReminderCategory.NEAR_REWARD, snapshot(ProgramType.POINTS, "95", expires,
                new BigDecimal("100")), settings(1, 10, 3), SP, now);
        assertThat(points.get().body()).isEqualTo("Faltam apenas 5 pontos para trocar por: Brinde!");
        assertThat(ReminderRules.evaluate(ReminderCategory.NEAR_REWARD, snapshot(ProgramType.POINTS, "80", expires,
                new BigDecimal("100")), settings(1, 10, 3), SP, now)).isEmpty();
        assertThat(ReminderRules.evaluate(ReminderCategory.NEAR_REWARD, snapshot(ProgramType.CASHBACK, "50", expires, null),
                settings(1, 10, 3), SP, now)).isEmpty();
    }

    @Test
    void inactivityNeedsConsentAndTheDedupKeyFollowsTheSituation() {
        Instant expires = Instant.parse("2027-01-01T03:00:00Z");
        Instant now = Instant.parse("2026-12-15T15:00:00Z");
        CardSnapshot noConsent = snapshot(ProgramType.STAMPS, "1", expires, null);
        assertThat(ReminderRules.evaluate(ReminderCategory.INACTIVITY, noConsent, settings(1, 10, 3), SP, now)).isEmpty();
        CardSnapshot consent = new CardSnapshot(7L, CardStatus.ACTIVE, ProgramType.STAMPS, "Café", "Cafeteria", BigDecimal.ONE, 10,
                "Um café", 0, expires, null, Instant.parse("2026-11-01T12:00:00Z"), true, true, null, null);
        var c = ReminderRules.evaluate(ReminderCategory.INACTIVITY, consent, settings(1, 10, 3), SP, now);
        assertThat(c.get().body()).startsWith("Faz 44 dias desde sua última visita a Cafeteria.");
        CardSnapshot blocked = new CardSnapshot(7L, CardStatus.SUSPENDED, ProgramType.STAMPS, "Café", "Cafeteria", BigDecimal.ONE, 10,
                "Um café", 0, expires, null, Instant.parse("2026-11-01T12:00:00Z"), true, true, null, null);
        assertThat(ReminderRules.evaluate(ReminderCategory.INACTIVITY, blocked, settings(1, 10, 3), SP, now)).isEmpty();
    }
}
