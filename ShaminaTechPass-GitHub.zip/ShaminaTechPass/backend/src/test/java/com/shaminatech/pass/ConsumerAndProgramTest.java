package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;

import com.jayway.jsonpath.JsonPath;
import com.shaminatech.pass.loyalty.ProgramType;

/** Cadastro de consumidores, limite de clientes ativos e tipos de programa permitidos. */
class ConsumerAndProgramTest extends LoyaltyTestSupport {

    private int setStatus(long consumerId, String status) throws Exception {
        return mvc.perform(patch(base(a) + "/consumers/" + consumerId + "/status").session(ownerA).with(csrf())
                .contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"" + status + "\"}")).andReturn().getResponse().getStatus();
    }

    @Test
    void consumerRegistrationValidatesInputAndPreventsDuplicates() throws Exception {
        postJson(ownerA, base(a) + "/consumers", "{\"fullName\":\"Ana\",\"phone\":\"123\",\"privacyAcknowledged\":true}")
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.errors[0].field").value("phone"));
        postJson(ownerA, base(a) + "/consumers", "{\"fullName\":\"Ana\",\"phone\":\"11999998888\"}")
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.errors[0].field").value("privacyAcknowledged"));
        postJson(ownerA, base(a) + "/consumers", "{\"fullName\":\"Ana\",\"phone\":\"11999998888\",\"privacyAcknowledged\":false}")
                .andExpect(status().isBadRequest());
        postJson(ownerA, base(a) + "/consumers", "{\"fullName\":\"\",\"phone\":\"11999998888\",\"email\":\"x\",\"privacyAcknowledged\":true}")
                .andExpect(status().isBadRequest());

        consumer(ownerA, a, "Ana Souza", "(11) 99999-8888");
        postJson(ownerA, base(a) + "/consumers", "{\"fullName\":\"Outra\",\"phone\":\"11 999998888\",\"privacyAcknowledged\":true}")
                .andExpect(status().isConflict()).andExpect(jsonPath("$.errors[0].field").value("phone"));
        // O mesmo telefone em outro estabelecimento é outro cadastro (isolamento).
        consumer(ownerB, b, "Ana Souza", "11999998888");
    }

    @Test
    void searchFindsByNamePhoneIdAndCardCodeWithinTheTenantOnly() throws Exception {
        long ana = consumer(ownerA, a, "Ana Souza", "11999998888");
        consumer(ownerA, a, "Bruno Lima", "21988887777");
        consumer(ownerB, b, "Ana Pereira", "31977776666");
        long card = card(ownerA, a, ana, stampsProgram(a, ownerA, 5, true));
        String code = cardField(ownerA, a, card, "displayCode");

        assertThat(names("ana")).containsExactly("Ana Souza");
        assertThat(names("99998888")).containsExactly("Ana Souza");
        assertThat(names("#" + ana)).containsExactly("Ana Souza");
        assertThat(names(code)).containsExactly("Ana Souza");
        assertThat(names("bruno")).containsExactly("Bruno Lima");
        String detail = getJson(ownerA, base(a) + "/consumers/" + ana);
        assertThat((List<?>) JsonPath.read(detail, "$.cards")).hasSize(1);
        mvc.perform(get(base(b) + "/consumers/" + ana).session(ownerB)).andExpect(status().isNotFound());
    }

    private List<String> names(String q) throws Exception {
        return JsonPath.read(mvc.perform(get(base(a) + "/consumers").param("q", q).session(ownerA)).andReturn().getResponse()
                .getContentAsString(), "$.content[*].fullName");
    }

    @Test
    void consumerLimitCountsUniqueActiveConsumersNotCards() throws Exception {
        policy(a, 2, ProgramType.STAMPS, ProgramType.POINTS);
        long first = consumer(ownerA, a, "Um", "11900000001");
        long second = consumer(ownerA, a, "Dois", "11900000002");
        // Dois cartões do mesmo cliente ocupam uma única vaga.
        card(ownerA, a, first, stampsProgram(a, ownerA, 5, true));
        card(ownerA, a, first, pointsProgram(a, ownerA, ""));
        postJson(ownerA, base(a) + "/consumers", "{\"fullName\":\"Três\",\"phone\":\"11900000003\",\"privacyAcknowledged\":true}")
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("CONSUMER_LIMIT_REACHED"));

        assertThat(setStatus(second, "INACTIVE")).isEqualTo(200);
        long third = consumer(ownerA, a, "Três", "11900000003");
        assertThat(setStatus(second, "ACTIVE")).isEqualTo(409); // sem vaga para reativar

        // Limite reduzido abaixo do uso: registros preservados, novas ativações bloqueadas.
        policy(a, 1, ProgramType.STAMPS, ProgramType.POINTS);
        assertThat(jdbc.queryForObject("select count(*) from consumer where establishment_id = ? and status = 'ACTIVE'",
                Integer.class, a.getId())).isEqualTo(2);
        postJson(ownerA, base(a) + "/consumers", "{\"fullName\":\"Quatro\",\"phone\":\"11900000004\",\"privacyAcknowledged\":true}")
                .andExpect(status().isConflict());
        assertThat(setStatus(third, "INACTIVE")).isEqualTo(200);
        assertThat(setStatus(third, "ACTIVE")).isEqualTo(409); // 1 ativo = limite 1
        String overview = getJson(ownerA, base(a) + "/overview");
        assertThat((Integer) JsonPath.read(overview, "$.activeConsumers")).isEqualTo(1);
        assertThat((Boolean) JsonPath.read(overview, "$.limitReached")).isTrue();
    }

    @Test
    void inactiveConsumerCardsCannotBeMoved() throws Exception {
        long consumer = consumer(ownerA, a, "Inativo", "11900000009");
        long card = card(ownerA, a, consumer, pointsProgram(a, ownerA, ""));
        setStatus(consumer, "INACTIVE");
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key()).andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("CONSUMER_INACTIVE"));
        postJson(ownerA, base(a) + "/cards", "{\"consumerId\":" + consumer + ",\"programId\":" + pointsProgram(a, ownerA, "") + "}")
                .andExpect(status().isConflict());
    }

    @Test
    void oneOpenCardPerConsumerAndProgram() throws Exception {
        long consumer = consumer(ownerA, a, "Duplo", "11900000010");
        long program = stampsProgram(a, ownerA, 5, true);
        card(ownerA, a, consumer, program);
        postJson(ownerA, base(a) + "/cards", "{\"consumerId\":" + consumer + ",\"programId\":" + program + "}")
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("CARD_ALREADY_EXISTS"));
    }

    @Test
    void programTypesAreAuthorizedByTheBackend() throws Exception {
        policy(a, 100, ProgramType.STAMPS);
        postJson(ownerA, base(a) + "/programs", "{\"type\":\"POINTS\",\"name\":\"P\"," + COMMON + ",\"pointsPerUnit\":1,\"spendUnit\":1}")
                .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("PROGRAM_TYPE_NOT_ALLOWED"));

        // Tipo desabilitado depois: programa e cartões preservados, movimentações bloqueadas.
        policy(a, 100, ProgramType.STAMPS, ProgramType.POINTS);
        long points = pointsProgram(a, ownerA, "");
        long card = card(ownerA, a, consumer(ownerA, a, "Tipo", "11900000011"), points);
        policy(a, 100, ProgramType.STAMPS);
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key()).andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("PROGRAM_TYPE_NOT_ALLOWED"));
        String programs = getJson(ownerA, base(a) + "/programs");
        assertThat((List<Boolean>) JsonPath.read(programs, "$[?(@.type == 'POINTS')].typeAllowed")).containsExactly(false);
    }

    @Test
    void programRulesAreValidatedPerType() throws Exception {
        postJson(ownerA, base(a) + "/programs", "{\"type\":\"STAMPS\",\"name\":\"S\"," + COMMON + ",\"stampsRequired\":1,"
                + "\"stampCriterion\":\"VISIT\",\"stampReward\":\"x\"}").andExpect(status().isBadRequest());
        postJson(ownerA, base(a) + "/programs", "{\"type\":\"STAMPS\",\"name\":\"S\"," + COMMON + ",\"stampsRequired\":8}")
                .andExpect(status().isBadRequest());
        postJson(ownerA, base(a) + "/programs", "{\"type\":\"CASHBACK\",\"name\":\"C\"," + COMMON + ",\"cashbackPercent\":150}")
                .andExpect(status().isBadRequest());
        postJson(ownerA, base(a) + "/programs", "{\"type\":\"POINTS\",\"name\":\"P\",\"inactivityDays\":30}")
                .andExpect(status().isBadRequest());
        // Quantidade de carimbos configurável (não fixa em 10).
        long twelve = stampsProgram(a, ownerA, 12, true);
        assertThat((Integer) JsonPath.read(getJson(ownerA, base(a) + "/programs/" + twelve), "$.stampsRequired")).isEqualTo(12);
    }

    @Test
    void vipIsModeledButNotOperational() throws Exception {
        long vip = program(ownerA, a, "{\"type\":\"VIP\",\"name\":\"Clube\"," + COMMON + "}");
        List<String> tiers = JsonPath.read(getJson(ownerA, base(a) + "/programs/" + vip + "/tiers"), "$[*].name");
        assertThat(tiers).containsExactly("Bronze", "Prata", "Ouro", "Diamante");
        postJson(ownerA, base(a) + "/programs/" + vip + "/tiers", "{\"name\":\"Platina\",\"rankOrder\":5,\"benefits\":\"Frete grátis\"}")
                .andExpect(status().isCreated());
        postJson(ownerA, base(a) + "/programs/" + vip + "/tiers", "{\"name\":\"Repetido\",\"rankOrder\":5}")
                .andExpect(status().isConflict());
        postJson(ownerA, base(a) + "/cards", "{\"consumerId\":" + consumer(ownerA, a, "Vip", "11900000012") + ",\"programId\":" + vip + "}")
                .andExpect(status().isUnprocessableContent()).andExpect(jsonPath("$.code").value("PROGRAM_NOT_OPERATIONAL"));
    }

    @Test
    void pausedProgramBlocksMovementsAndArchivedIsFinal() throws Exception {
        long program = pointsProgram(a, ownerA, "");
        long card = card(ownerA, a, consumer(ownerA, a, "Pausa", "11900000013"), program);
        mvc.perform(patch(base(a) + "/programs/" + program + "/status").session(ownerA).with(csrf())
                .contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"PAUSED\"}")).andExpect(status().isOk());
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key()).andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("PROGRAM_NOT_ACTIVE"));
        mvc.perform(patch(base(a) + "/programs/" + program + "/status").session(ownerA).with(csrf())
                .contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"ARCHIVED\"}")).andExpect(status().isOk());
        mvc.perform(patch(base(a) + "/programs/" + program + "/status").session(ownerA).with(csrf())
                .contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"ACTIVE\"}")).andExpect(status().isConflict());
    }

    @Test
    void consumerChangesAreAudited() throws Exception {
        long consumer = consumer(ownerA, a, "Audit", "11900000014");
        setStatus(consumer, "INACTIVE");
        List<String> actions = JsonPath.read(getJson(ownerA, base(a) + "/audit"), "$.content[*].action");
        assertThat(actions).contains("CONSUMER_CREATED", "CONSUMER_STATUS_CHANGED");
    }
}
