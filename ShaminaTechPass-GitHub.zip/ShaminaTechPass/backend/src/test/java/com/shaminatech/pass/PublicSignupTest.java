package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.ResultActions;

import com.jayway.jsonpath.JsonPath;
import com.shaminatech.pass.establishment.EstablishmentStatus;
import com.shaminatech.pass.loyalty.ProgramType;

/**
 * Cadastro público pelo QR Code: fluxo válido, duplicidade, tentativa de obter o cartão de outra pessoa, limite de
 * clientes (inclusive simultâneo), link desativado/trocado, programa pausado, estabelecimento suspenso, repetição do
 * envio, proteções do formulário e isolamento entre estabelecimentos. Carteiras digitais desligadas (ver
 * {@code PublicSignupWalletTest} para a emissão com Google Wallet simulado).
 */
class PublicSignupTest extends LoyaltyTestSupport {

    private long program;
    private long linkId;
    private String token;

    @BeforeEach
    void setUpLink() throws Exception {
        program = stampsProgram(a, ownerA, 10, true);
        ResultActions created = postJson(ownerA, base(a) + "/programs/" + program + "/signup-link", "{}").andExpect(status().isCreated());
        linkId = id(created);
        String url = read(created, "$.url");
        assertThat(url).startsWith("http://localhost:4203/cadastro/");
        token = url.substring(url.lastIndexOf('/') + 1);
    }

    private String info(String t) throws Exception {
        return mvc.perform(get("/api/public/signup/" + t)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
    }

    /** Abre a página (token do formulário), espera o tempo mínimo de preenchimento e envia. */
    private ResultActions signup(String t, String name, String phone, String email, String requestId) throws Exception {
        String formToken = JsonPath.read(info(t), "$.formToken");
        clock.advance(Duration.ofSeconds(5));
        return send(t, name, phone, email, requestId, formToken, "");
    }

    private ResultActions send(String t, String name, String phone, String email, String requestId, String formToken,
                               String website) throws Exception {
        String body = "{\"fullName\":\"" + name + "\",\"phone\":\"" + phone + "\"," + (email == null ? "" : "\"email\":\"" + email + "\",")
                + "\"privacyAccepted\":true,\"marketingOptIn\":false,\"requestId\":\"" + requestId + "\","
                + (formToken == null ? "" : "\"formToken\":\"" + formToken + "\",") + "\"website\":\"" + website + "\"}";
        return mvc.perform(post("/api/public/signup/" + t).with(csrf()).contentType(MediaType.APPLICATION_JSON).content(body));
    }

    private static String rid() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    private int count(String sql, Object... args) {
        Integer n = jdbc.queryForObject(sql, Integer.class, args);
        return n == null ? 0 : n;
    }

    @Test
    void validSignupCreatesConsumerAndCardWithoutMovement() throws Exception {
        String page = info(token);
        assertThat((String) JsonPath.read(page, "$.status")).isEqualTo("OPEN");
        assertThat((String) JsonPath.read(page, "$.establishmentName")).isEqualTo("Estabelecimento loja-a");
        assertThat((String) JsonPath.read(page, "$.programName")).isEqualTo("Café");
        assertThat((List<String>) JsonPath.read(page, "$.rules")).contains("Ganhe 1 carimbo a cada visita registrada no balcão.",
                "Junte 10 carimbos e ganhe: Um café grátis.");
        assertThat(JsonPath.read(page, "$.validity").toString()).contains("30 dias sem compras");
        assertThat(page).doesNotContain("\"id\"").doesNotContain("establishmentId").doesNotContain("programId");

        Instant start = clock.instant();
        ResultActions result = signup(token, "Maria Souza Lima", "(11) 98888-1111", "maria@teste.local", rid())
                .andExpect(status().isCreated());
        assertThat((String) read(result, "$.status")).isEqualTo("REGISTERED");
        assertThat((String) read(result, "$.consumerFirstName")).isEqualTo("Maria");
        assertThat((String) read(result, "$.walletStatus")).isEqualTo("NOT_CONFIGURED");
        assertThat((Object) read(result, "$.walletPath")).isNull();
        String body = result.andReturn().getResponse().getContentAsString();
        assertThat(body).doesNotContain("98888").doesNotContain("maria@teste.local").doesNotContain("Lima");

        assertThat(jdbc.queryForObject("select source from consumer where phone = '11988881111'", String.class)).isEqualTo("PUBLIC_QR");
        assertThat(jdbc.queryForObject("select marketing_opt_in from consumer where phone = '11988881111'", Boolean.class)).isFalse();
        Long cardId = jdbc.queryForObject("select id from loyalty_card where program_id = ?", Long.class, program);
        assertThat(countTransactions(cardId, "CARD_ISSUED")).isEqualTo(1);
        assertThat(countTransactions(cardId, "EARN")).isZero();
        assertThat(jdbc.queryForObject("select channel from card_transaction where card_id = ?", String.class, cardId))
                .isEqualTo("PUBLIC_SIGNUP");
        // Validade conta da emissão; o cadastro não registra movimentação.
        assertThat(jdbc.queryForObject("select last_movement_at from loyalty_card where id = ?", Instant.class, cardId)).isNull();
        Instant expires = jdbc.queryForObject("select expires_at from loyalty_card where id = ?", Instant.class, cardId);
        assertThat(expires).isAfter(start.plus(Duration.ofDays(30))).isBefore(start.plus(Duration.ofDays(31)));
        assertThat(count("select count(*) from audit_event where action = 'CONSUMER_SELF_REGISTERED'")).isEqualTo(1);

        // O painel mostra o cadastro feito pelo QR Code.
        String links = getJson(ownerA, base(a) + "/signup-links");
        assertThat((Integer) JsonPath.read(links, "$.programs[0].link.signups")).isEqualTo(1);
    }

    @Test
    void duplicatePhoneOrEmailNeverReturnsTheExistingCard() throws Exception {
        signup(token, "Maria Souza", "11988881111", "maria@teste.local", rid()).andExpect(status().isCreated());
        long existingByPanel = consumer(ownerA, a, "Carlos Pereira", "11977772222");
        card(ownerA, a, existingByPanel, program);

        // Mesmo telefone de quem se cadastrou pelo QR Code
        ResultActions samePhone = signup(token, "Outra Pessoa", "11988881111", null, rid()).andExpect(status().isConflict());
        assertThat((String) read(samePhone, "$.code")).isEqualTo("SIGNUP_NOT_POSSIBLE");
        // Telefone de um cliente cadastrado no balcão: tentativa de obter o cartão de outra pessoa
        ResultActions other = signup(token, "Carlos Pereira", "11977772222", null, rid()).andExpect(status().isConflict());
        String body = other.andReturn().getResponse().getContentAsString();
        assertThat(body).doesNotContain("walletPath").doesNotContain("Pereira").doesNotContain("Carlos").doesNotContain("cartao/");
        assertThat((String) read(other, "$.code")).isEqualTo("SIGNUP_NOT_POSSIBLE");
        // E-mail já usado, telefone novo: mesma resposta genérica
        ResultActions email = signup(token, "Terceira Pessoa", "11966663333", "MARIA@teste.local", rid()).andExpect(status().isConflict());
        assertThat((String) read(email, "$.detail")).isEqualTo((String) read(samePhone, "$.detail"));

        assertThat(count("select count(*) from consumer")).isEqualTo(2);
        assertThat(count("select count(*) from loyalty_card")).isEqualTo(2);
        assertThat(count("select count(*) from wallet_link")).isZero();
    }

    @Test
    void repeatedSubmissionReturnsTheSameRegistration() throws Exception {
        String requestId = rid();
        String formToken = JsonPath.read(info(token), "$.formToken");
        clock.advance(Duration.ofSeconds(5));
        send(token, "Maria Souza", "11988881111", null, requestId, formToken, "").andExpect(status().isCreated());
        send(token, "Maria Souza", "11988881111", null, requestId, formToken, "").andExpect(status().isCreated());
        assertThat(count("select count(*) from consumer")).isEqualTo(1);
        assertThat(count("select count(*) from loyalty_card")).isEqualTo(1);
        // Fora da janela de repetição, o mesmo identificador não reabre o cadastro.
        clock.advance(Duration.ofMinutes(31));
        String fresh = JsonPath.read(info(token), "$.formToken");
        clock.advance(Duration.ofSeconds(5));
        send(token, "Maria Souza", "11988881111", null, requestId, fresh, "").andExpect(status().isConflict());
    }

    @Test
    void consumerLimitIsRespected() throws Exception {
        policy(a, 2, ProgramType.STAMPS, ProgramType.POINTS);
        signup(token, "Pessoa Um", "11900000001", null, rid()).andExpect(status().isCreated());
        signup(token, "Pessoa Dois", "11900000002", null, rid()).andExpect(status().isCreated());
        String page = info(token);
        assertThat((String) JsonPath.read(page, "$.status")).isEqualTo("FULL");
        assertThat((Object) JsonPath.read(page, "$.formToken")).isNull();
        assertThat(page).doesNotContain("\"2\"").doesNotContain("limite");
        // Formulário aberto antes de lotar: o envio é recusado no servidor.
        policy(a, 3, ProgramType.STAMPS, ProgramType.POINTS);
        String formToken = JsonPath.read(info(token), "$.formToken");
        policy(a, 2, ProgramType.STAMPS, ProgramType.POINTS);
        clock.advance(Duration.ofSeconds(5));
        ResultActions full = send(token, "Pessoa Três", "11900000003", null, rid(), formToken, "").andExpect(status().isConflict());
        assertThat((String) read(full, "$.code")).isEqualTo("SIGNUP_FULL");
        assertThat(count("select count(*) from consumer where status = 'ACTIVE'")).isEqualTo(2);
    }

    @Test
    void concurrentSignupsNeverExceedTheLimitNorDuplicate() throws Exception {
        policy(a, 3, ProgramType.STAMPS, ProgramType.POINTS);
        String formToken = JsonPath.read(info(token), "$.formToken");
        clock.advance(Duration.ofSeconds(5));
        List<Future<Integer>> different = runConcurrently(8, i -> send(token, "Pessoa Numero", "119100000" + (10 + i), null, rid(),
                formToken, "").andReturn().getResponse().getStatus());
        assertThat(different.stream().filter(f -> result(f) == 201).count()).isEqualTo(3);
        assertThat(count("select count(*) from consumer where establishment_id = ?", a.getId())).isEqualTo(3);

        policy(a, 100, ProgramType.STAMPS, ProgramType.POINTS);
        List<Future<Integer>> same = runConcurrently(6, i -> send(token, "Mesma Pessoa", "11955554444", null, rid(), formToken, "")
                .andReturn().getResponse().getStatus());
        assertThat(same.stream().filter(f -> result(f) == 201).count()).isEqualTo(1);
        assertThat(count("select count(*) from consumer where phone = '11955554444'")).isEqualTo(1);
        assertThat(count("select count(*) from loyalty_card")).isEqualTo(4);
    }

    @Test
    void disabledOrRegeneratedLinkIsUnavailable() throws Exception {
        String formToken = JsonPath.read(info(token), "$.formToken");
        postJson(ownerA, base(a) + "/signup-links/" + linkId + "/status", "{\"active\":false}").andExpect(status().isOk());
        String page = info(token);
        assertThat((String) JsonPath.read(page, "$.status")).isEqualTo("UNAVAILABLE");
        assertThat((Object) JsonPath.read(page, "$.establishmentName")).isNull();
        clock.advance(Duration.ofSeconds(5));
        ResultActions denied = send(token, "Maria Souza", "11988881111", null, rid(), formToken, "").andExpect(status().isConflict());
        assertThat((String) read(denied, "$.code")).isEqualTo("SIGNUP_UNAVAILABLE");

        postJson(ownerA, base(a) + "/signup-links/" + linkId + "/status", "{\"active\":true}").andExpect(status().isOk());
        assertThat((String) JsonPath.read(info(token), "$.status")).isEqualTo("OPEN");

        // Novo código: o QR Code antigo deixa de funcionar.
        ResultActions regenerated = postJson(ownerA, base(a) + "/signup-links/" + linkId + "/regenerate", "{}").andExpect(status().isOk());
        String newUrl = read(regenerated, "$.url");
        assertThat(newUrl).doesNotEndWith(token);
        mvc.perform(get("/api/public/signup/" + token)).andExpect(status().isNotFound());
        assertThat((String) JsonPath.read(info(newUrl.substring(newUrl.lastIndexOf('/') + 1)), "$.status")).isEqualTo("OPEN");
        // Tokens inválidos: mesma resposta, sem detalhes.
        mvc.perform(get("/api/public/signup/" + "f".repeat(32))).andExpect(status().isNotFound());
        mvc.perform(get("/api/public/signup/" + linkId)).andExpect(status().isNotFound());
        assertThat(count("select count(*) from consumer")).isZero();
    }

    @Test
    void pausedProgramAndSuspendedEstablishmentAreUnavailable() throws Exception {
        String formToken = JsonPath.read(info(token), "$.formToken");
        mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch(base(a) + "/programs/" + program + "/status")
                .session(ownerA).with(csrf()).contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"PAUSED\"}"))
                .andExpect(status().isOk());
        assertThat((String) JsonPath.read(info(token), "$.status")).isEqualTo("UNAVAILABLE");
        clock.advance(Duration.ofSeconds(5));
        send(token, "Maria Souza", "11988881111", null, rid(), formToken, "").andExpect(status().isConflict());

        mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch(base(a) + "/programs/" + program + "/status")
                .session(ownerA).with(csrf()).contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"ACTIVE\"}"))
                .andExpect(status().isOk());
        a.setStatus(EstablishmentStatus.SUSPENDED);
        establishments.save(a);
        String page = info(token);
        assertThat((String) JsonPath.read(page, "$.status")).isEqualTo("UNAVAILABLE");
        assertThat(page).doesNotContain("loja-a");
        assertThat(count("select count(*) from consumer")).isZero();
    }

    @Test
    void formProtectionsRejectBotsAndOldForms() throws Exception {
        String formToken = JsonPath.read(info(token), "$.formToken");
        // Enviado rápido demais
        ResultActions fast = send(token, "Maria Souza", "11988881111", null, rid(), formToken, "").andExpect(status().isBadRequest());
        assertThat((String) read(fast, "$.code")).isEqualTo("SIGNUP_TOO_FAST");
        clock.advance(Duration.ofSeconds(5));
        // Campo isca preenchido
        send(token, "Maria Souza", "11988881111", null, rid(), formToken, "https://spam.test").andExpect(status().isBadRequest());
        // Sem token, token adulterado e token de outro link
        send(token, "Maria Souza", "11988881111", null, rid(), null, "").andExpect(status().isBadRequest());
        send(token, "Maria Souza", "11988881111", null, rid(), formToken.substring(0, formToken.length() - 1) + (formToken.endsWith("0") ? "1" : "0"), "")
                .andExpect(status().isBadRequest());
        // Formulário aberto há mais de 2 horas
        clock.advance(Duration.ofHours(3));
        ResultActions old = send(token, "Maria Souza", "11988881111", null, rid(), formToken, "").andExpect(status().isBadRequest());
        assertThat((String) read(old, "$.code")).isEqualTo("SIGNUP_FORM_EXPIRED");
        // Ciência da privacidade é obrigatória e separada do consentimento de comunicações
        String fresh = JsonPath.read(info(token), "$.formToken");
        clock.advance(Duration.ofSeconds(5));
        mvc.perform(post("/api/public/signup/" + token).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content("{\"fullName\":\"Maria Souza\",\"phone\":\"11988881111\",\"privacyAccepted\":false,\"marketingOptIn\":true,"
                        + "\"requestId\":\"" + rid() + "\",\"formToken\":\"" + fresh + "\"}"))
                .andExpect(status().isBadRequest());
        // Sem CSRF
        mvc.perform(post("/api/public/signup/" + token).contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isForbidden());
        assertThat(count("select count(*) from consumer")).isZero();

        // Consentimento de comunicações é gravado só quando marcado
        mvc.perform(post("/api/public/signup/" + token).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content("{\"fullName\":\"Maria Souza\",\"phone\":\"11988881111\",\"privacyAccepted\":true,\"marketingOptIn\":true,"
                        + "\"requestId\":\"" + rid() + "\",\"formToken\":\"" + fresh + "\"}"))
                .andExpect(status().isCreated());
        assertThat(jdbc.queryForObject("select marketing_opt_in from consumer", Boolean.class)).isTrue();
    }

    @Test
    void vipProgramsCannotHavePublicSignup() throws Exception {
        long vip = program(ownerA, a, "{\"type\":\"VIP\",\"name\":\"VIP\"," + COMMON + "}");
        ResultActions denied = postJson(ownerA, base(a) + "/programs/" + vip + "/signup-link", "{}").andExpect(status().isConflict());
        assertThat((String) read(denied, "$.code")).isEqualTo("SIGNUP_LINK_NOT_ALLOWED");
        // Criar de novo o link do mesmo programa devolve o existente.
        long again = id(postJson(ownerA, base(a) + "/programs/" + program + "/signup-link", "{}").andExpect(status().isCreated()));
        assertThat(again).isEqualTo(linkId);
    }

    @Test
    void qrCodeIsGeneratedOnlyForTheOwnerEstablishment() throws Exception {
        String svg = mvc.perform(get(base(a) + "/signup-links/" + linkId + "/qr").session(ownerA)).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        assertThat(svg).startsWith("<svg").contains("<path");
        byte[] png = mvc.perform(get(base(a) + "/signup-links/" + linkId + "/qr?format=png&download=true").session(ownerA))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsByteArray();
        assertThat(png[1]).isEqualTo((byte) 'P');
        assertThat(png[2]).isEqualTo((byte) 'N');

        // Outro estabelecimento e anônimo não acessam o link de A.
        mvc.perform(get(base(b) + "/signup-links/" + linkId + "/qr").session(ownerB)).andExpect(status().isNotFound());
        postJson(ownerB, base(b) + "/signup-links/" + linkId + "/status", "{\"active\":false}").andExpect(status().isNotFound());
        postJson(ownerB, base(b) + "/signup-links/" + linkId + "/regenerate", "{}").andExpect(status().isNotFound());
        postJson(ownerB, base(b) + "/programs/" + program + "/signup-link", "{}").andExpect(status().isNotFound());
        mvc.perform(get(base(a) + "/signup-links/" + linkId + "/qr").session(ownerB)).andExpect(status().isForbidden());
        mvc.perform(get(base(a) + "/signup-links")).andExpect(status().isUnauthorized());
        assertThat((List<?>) JsonPath.read(getJson(ownerB, base(b) + "/signup-links"), "$.programs")).isEmpty();

        // O cadastro pelo link de A só cria cliente em A.
        signup(token, "Maria Souza", "11988881111", null, rid()).andExpect(status().isCreated());
        assertThat(count("select count(*) from consumer where establishment_id = ?", b.getId())).isZero();
        consumer(ownerB, b, "Maria Souza", "11988881111"); // o mesmo telefone em outra empresa é outro cadastro
    }

    // ---------------- apoio ----------------

    private interface IndexedTask<T> {
        T call(int index) throws Exception;
    }

    private <T> List<Future<T>> runConcurrently(int threads, IndexedTask<T> task) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch start = new CountDownLatch(1);
        List<Future<T>> futures = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            final int index = i;
            Callable<T> callable = () -> {
                start.await();
                return task.call(index);
            };
            futures.add(pool.submit(callable));
        }
        start.countDown();
        pool.shutdown();
        assertThat(pool.awaitTermination(60, TimeUnit.SECONDS)).isTrue();
        return futures;
    }

    private static <T> T result(Future<T> future) {
        try {
            return future.get();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
