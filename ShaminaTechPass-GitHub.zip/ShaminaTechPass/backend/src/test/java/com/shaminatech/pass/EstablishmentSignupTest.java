package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;

import com.jayway.jsonpath.JsonPath;
import com.shaminatech.pass.loyalty.policy.PolicyService;

/**
 * Autocadastro público de estabelecimentos com escolha de plano (fase de testes: sem cobrança), limites do plano no
 * backend, isolamento entre empresas e preservação do cadastro manual pelo administrador.
 */
class EstablishmentSignupTest extends IntegrationTestSupport {

    private static final String STRONG = "Senha-forte-2026";

    private static String body(String plan, String name, String email) {
        return "{\"plan\":\"" + plan + "\",\"establishmentName\":\"" + name + "\",\"contactPhone\":\"(45) 3000-0000\","
                + "\"ownerName\":\"Responsável Teste\",\"email\":\"" + email + "\",\"password\":\"" + STRONG + "\","
                + "\"passwordConfirmation\":\"" + STRONG + "\",\"termsAccepted\":true}";
    }

    private ResultActions signup(String json) throws Exception {
        return mvc.perform(post("/api/public/establishment-signup").with(csrf()).contentType(MediaType.APPLICATION_JSON).content(json));
    }

    /** Cadastra e devolve a sessão já autenticada pelo próprio cadastro. */
    private MockHttpSession signedUp(String plan, String email) throws Exception {
        MvcResult result = signup(body(plan, "Café " + plan, email)).andExpect(status().isCreated()).andReturn();
        return (MockHttpSession) result.getRequest().getSession(false);
    }

    private long establishmentOf(MockHttpSession session) throws Exception {
        String me = mvc.perform(get("/api/auth/me").session(session)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        return ((Number) JsonPath.read(me, "$.memberships[0].establishmentId")).longValue();
    }

    private String plan(MockHttpSession session, long establishmentId) throws Exception {
        return mvc.perform(get("/api/establishments/" + establishmentId + "/plan").session(session)).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
    }

    private ResultActions createProgram(MockHttpSession session, long establishmentId, String type, String name) throws Exception {
        String extra = switch (type) {
            case "POINTS" -> ",\"pointsPerUnit\":1,\"spendUnit\":1.00";
            case "CASHBACK" -> ",\"cashbackPercent\":5.00";
            case "STAMPS" -> ",\"stampsRequired\":10,\"stampCriterion\":\"VISIT\",\"stampReward\":\"Brinde\",\"restartAfterRedeem\":true";
            default -> "";
        };
        return mvc.perform(post("/api/establishments/" + establishmentId + "/programs").session(session).with(csrf())
                .contentType(MediaType.APPLICATION_JSON).content("{\"type\":\"" + type + "\",\"name\":\"" + name + "\","
                        + "\"inactivityDays\":30,\"validityMode\":\"END_OF_DAY\",\"expiredBalancePolicy\":\"KEEP\","
                        + "\"reversalPolicy\":\"REQUIRE_BALANCE\"" + extra + "}"));
    }

    private ResultActions createConsumer(MockHttpSession session, long establishmentId, int n) throws Exception {
        return mvc.perform(post("/api/establishments/" + establishmentId + "/consumers").session(session).with(csrf())
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"fullName\":\"Cliente " + n + "\",\"phone\":\"119" + String.format("%08d", n) + "\",\"privacyAcknowledged\":true}"));
    }

    private int count(String table) {
        return jdbc.queryForObject("select count(*) from " + table, Integer.class);
    }

    @Test
    void catalogShowsTheThreePlansAsFreeDuringTheTestPhase() throws Exception {
        String catalog = mvc.perform(get("/api/public/plans")).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat((Boolean) JsonPath.read(catalog, "$.trialFree")).isTrue();
        assertThat((String) JsonPath.read(catalog, "$.trialMessage")).contains("nenhuma cobrança");
        assertThat((List<String>) JsonPath.read(catalog, "$.plans[*].code")).containsExactly("FREE", "GROWTH", "PRO");
        assertThat((List<Integer>) JsonPath.read(catalog, "$.plans[*].listPriceCents")).containsExactly(0, 5900, 12900);
        assertThat((List<Object>) JsonPath.read(catalog, "$.plans[*].maxActiveConsumers")).containsExactly(10, 150, null);
        assertThat((List<Integer>) JsonPath.read(catalog, "$.plans[*].maxProgramTypes")).containsExactly(1, 2, 4);
        assertThat((List<Boolean>) JsonPath.read(catalog, "$.plans[*].selectable")).containsExactly(true, true, true);
    }

    @Test
    void eachPlanCreatesAWorkingOwnerAccountWithASessionAndNoBilling() throws Exception {
        for (String[] c : new String[][] {{"FREE", "10", "1"}, {"GROWTH", "150", "2"}, {"PRO", null, null}}) {
            String email = "dono." + c[0].toLowerCase() + "@teste.local";
            MvcResult result = signup(body(c[0], "Café " + c[0], email)).andExpect(status().isCreated())
                    .andExpect(jsonPath("$.plan").value(c[0])).andExpect(jsonPath("$.trialFree").value(true))
                    .andExpect(jsonPath("$.me.platformRole").doesNotExist())
                    .andExpect(jsonPath("$.me.memberships[0].role").value("OWNER")).andReturn();
            assertThat(result.getResponse().getContentAsString()).doesNotContain(STRONG).doesNotContain("passwordHash");
            MockHttpSession session = (MockHttpSession) result.getRequest().getSession(false);
            long id = establishmentOf(session);
            String plan = plan(session, id);
            assertThat((String) JsonPath.read(plan, "$.code")).isEqualTo(c[0]);
            assertThat((Boolean) JsonPath.read(plan, "$.trialFree")).isTrue();
            assertThat((String) JsonPath.read(plan, "$.trialMessage")).contains("nenhuma cobrança");
            assertThat((String) JsonPath.read(plan, "$.origin")).isEqualTo("SELF_SIGNUP");
            assertThat(JsonPath.<Object>read(plan, "$.limits.maxActiveConsumers")).isEqualTo(c[1] == null ? null : Integer.valueOf(c[1]));
            assertThat(JsonPath.<Object>read(plan, "$.limits.maxPrograms")).isEqualTo(c[2] == null ? null : Integer.valueOf(c[2]));
            int policyMax = jdbc.queryForObject("select max_active_consumers from establishment_policy where establishment_id = ?",
                    Integer.class, id);
            assertThat(policyMax).isEqualTo(c[1] == null ? PolicyService.MAX_CONSUMER_LIMIT : Integer.parseInt(c[1]));
            // A conta entra também pelo login normal (senha escolhida, sem troca obrigatória).
            mvc.perform(post("/api/auth/login").with(csrf()).contentType(MediaType.APPLICATION_JSON)
                    .content("{\"email\":\"" + email + "\",\"password\":\"" + STRONG + "\"}")).andExpect(status().isOk())
                    .andExpect(jsonPath("$.passwordChangeRequired").value(false));
        }
        assertThat(jdbc.queryForObject("select count(*) from establishment_plan where trial_free = true and access_status = 'ACTIVE'",
                Integer.class)).isEqualTo(3);
        assertThat((List<Integer>) jdbc.queryForList("select list_price_cents from establishment_plan order by list_price_cents", Integer.class))
                .containsExactly(0, 5900, 12900);
        assertThat(count("audit_event where action = 'ESTABLISHMENT_SELF_REGISTERED'")).isEqualTo(3);
    }

    @Test
    void invalidDataIsRejectedWithoutCreatingAnything() throws Exception {
        String ok = body("FREE", "Café Válido", "valido@teste.local");
        signup(ok.replace("\"termsAccepted\":true", "\"termsAccepted\":false")).andExpect(status().isBadRequest());
        signup(ok.replace(STRONG, "123")).andExpect(status().isBadRequest());
        signup(ok.replace("\"passwordConfirmation\":\"" + STRONG + "\"", "\"passwordConfirmation\":\"Outra-senha-2026\""))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.errors[0].field").value("passwordConfirmation"));
        signup(ok.replace("\"FREE\"", "\"ENTERPRISE\"")).andExpect(status().isBadRequest()).andExpect(jsonPath("$.errors[0].field").value("plan"));
        signup(ok.replace("valido@teste.local", "nao-e-email")).andExpect(status().isBadRequest());
        signup(ok.replace("Café Válido", "")).andExpect(status().isBadRequest());
        signup(ok.replace("}", ",\"website\":\"http://spam.example\"}")).andExpect(status().isBadRequest());
        mvc.perform(post("/api/public/establishment-signup").contentType(MediaType.APPLICATION_JSON).content(ok))
                .andExpect(status().isForbidden()); // sem CSRF
        assertThat(count("establishment")).isZero();
        assertThat(count("app_user")).isZero();
    }

    @Test
    void duplicateEmailNeverAttachesToAnExistingAccount() throws Exception {
        signedUp("FREE", "repetido@teste.local");
        signup(body("PRO", "Outro Café", "Repetido@Teste.Local")).andExpect(status().isConflict())
                .andExpect(jsonPath("$.errors[0].field").value("email"));
        platformAdmin("admin@teste.local");
        signup(body("FREE", "Café do Admin", "admin@teste.local")).andExpect(status().isConflict());
        assertThat(count("establishment")).isEqualTo(1);
        assertThat(count("membership")).isEqualTo(1);
        assertThat(jdbc.queryForObject("select platform_role from app_user where email = 'admin@teste.local'", String.class)).isNotNull();
    }

    @Test
    void concurrentSignupsWithTheSameEmailCreateExactlyOneEstablishment() throws Exception {
        int threads = 6;
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch start = new CountDownLatch(1);
        List<Future<Integer>> results = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            int k = i;
            Callable<Integer> task = () -> {
                start.await();
                return signup(body("GROWTH", "Café Simultâneo " + k, "simultaneo@teste.local")).andReturn().getResponse().getStatus();
            };
            results.add(pool.submit(task));
        }
        start.countDown();
        List<Integer> codes = new ArrayList<>();
        for (Future<Integer> f : results) {
            codes.add(f.get());
        }
        pool.shutdown();
        assertThat(codes).filteredOn(c -> c == 201).hasSize(1);
        assertThat(codes).filteredOn(c -> c != 201).allMatch(c -> c == 409);
        // Nenhum estabelecimento órfão, nenhum usuário sem vínculo.
        assertThat(count("establishment")).isEqualTo(1);
        assertThat(count("app_user")).isEqualTo(1);
        assertThat(count("membership")).isEqualTo(1);
        assertThat(count("establishment_plan")).isEqualTo(1);
        assertThat(count("establishment_policy")).isEqualTo(1);
    }

    @Test
    void theRequestCannotEscalatePrivilegesOrReachOtherEstablishments() throws Exception {
        // Campos de papel/permissão não existem no contrato: são ignorados e o papel é fixado no servidor.
        MockHttpSession other = signedUp("FREE", "vitima@teste.local");
        long victim = establishmentOf(other);
        signup(body("PRO", "Café Esperto", "esperto@teste.local").replace("}",
                ",\"platformRole\":\"PLATFORM_ADMIN\",\"role\":\"PLATFORM_ADMIN\",\"establishmentId\":" + victim + "}"))
                .andExpect(status().isCreated()).andExpect(jsonPath("$.me.platformRole").doesNotExist())
                .andExpect(jsonPath("$.me.memberships.length()").value(1));
        assertThat(jdbc.queryForObject("select platform_role from app_user where email = 'esperto@teste.local'", String.class)).isNull();
        assertThat(jdbc.queryForObject("select count(*) from membership m join app_user u on u.id = m.user_id "
                + "where u.email = 'esperto@teste.local' and m.establishment_id = ?", Integer.class, victim)).isZero();
        assertThat(jdbc.queryForObject("select count(*) from membership where establishment_id = ?", Integer.class, victim)).isEqualTo(1);

        MockHttpSession a = signedUp("PRO", "loja.a@teste.local");
        MockHttpSession b = signedUp("FREE", "loja.b@teste.local");
        long idA = establishmentOf(a);
        long idB = establishmentOf(b);
        assertThat(jdbc.queryForObject("select count(*) from app_user where platform_role is not null", Integer.class)).isZero();
        mvc.perform(get("/api/admin/establishments").session(a)).andExpect(status().isForbidden());
        mvc.perform(get("/api/establishments/" + idB + "/plan").session(a)).andExpect(status().isForbidden());
        mvc.perform(get("/api/establishments/" + idB + "/consumers").session(a)).andExpect(status().isForbidden());
        createProgram(a, idB, "POINTS", "Invasão").andExpect(status().isForbidden());
        assertThat(jdbc.queryForObject("select count(*) from loyalty_program where establishment_id = ?", Integer.class, idB)).isZero();
        assertThat(idA).isNotEqualTo(idB);
    }

    @Test
    void planLimitsAreEnforcedByTheBackend() throws Exception {
        // Free: 1 programa (logo, 1 tipo) e 10 clientes ativos.
        MockHttpSession free = signedUp("FREE", "limite.free@teste.local");
        long f = establishmentOf(free);
        createProgram(free, f, "POINTS", "Pontos").andExpect(status().isCreated());
        createProgram(free, f, "POINTS", "Pontos 2").andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("PLAN_PROGRAM_LIMIT"));
        createProgram(free, f, "STAMPS", "Carimbos").andExpect(status().isConflict());
        for (int i = 1; i <= 10; i++) {
            createConsumer(free, f, i).andExpect(status().isCreated());
        }
        createConsumer(free, f, 11).andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("CONSUMER_LIMIT_REACHED"));
        // Cliente inativo não conta: desativar um libera a vaga (e não apaga nada).
        long first = jdbc.queryForObject("select min(id) from consumer where establishment_id = ?", Long.class, f);
        mvc.perform(patch("/api/establishments/" + f + "/consumers/" + first + "/status").session(free).with(csrf())
                .contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"INACTIVE\"}")).andExpect(status().isOk());
        createConsumer(free, f, 11).andExpect(status().isCreated());
        String usage = plan(free, f);
        assertThat((Integer) JsonPath.read(usage, "$.usage.activeConsumers")).isEqualTo(10);
        assertThat((Integer) JsonPath.read(usage, "$.usage.programs")).isEqualTo(1);
        assertThat(count("consumer where establishment_id = " + f)).isEqualTo(11);

        // Growth: até 2 programas; encerrar um libera a vaga.
        MockHttpSession growth = signedUp("GROWTH", "limite.growth@teste.local");
        long g = establishmentOf(growth);
        createProgram(growth, g, "POINTS", "Pontos").andExpect(status().isCreated());
        long stamps = ((Number) JsonPath.read(createProgram(growth, g, "STAMPS", "Carimbos").andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString(), "$.id")).longValue();
        createProgram(growth, g, "CASHBACK", "Cashback").andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("PLAN_PROGRAM_LIMIT"));
        mvc.perform(patch("/api/establishments/" + g + "/programs/" + stamps + "/status").session(growth).with(csrf())
                .contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"ARCHIVED\"}")).andExpect(status().isOk());
        createProgram(growth, g, "CASHBACK", "Cashback").andExpect(status().isCreated());
        assertThat((List<String>) JsonPath.read(plan(growth, g), "$.usage.typesInUse")).containsExactly("POINTS", "CASHBACK");

        // Pro: os 4 tipos e programas sem limite comercial.
        MockHttpSession pro = signedUp("PRO", "limite.pro@teste.local");
        long p = establishmentOf(pro);
        for (String type : new String[] {"POINTS", "CASHBACK", "STAMPS", "VIP", "POINTS", "STAMPS"}) {
            createProgram(pro, p, type, "Programa " + type).andExpect(status().isCreated());
        }
        assertThat((Integer) JsonPath.read(plan(pro, p), "$.usage.programs")).isEqualTo(6);
    }

    @Test
    void manualCreationByTheAdminIsPreservedAndSelfSignupsAreIdentified() throws Exception {
        platformAdmin("admin@teste.local");
        MockHttpSession admin = login("admin@teste.local");
        mvc.perform(post("/api/admin/establishments").session(admin).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Manual\",\"slug\":\"manual\",\"owner\":{\"email\":\"manual@teste.local\",\"fullName\":\"Resp\","
                        + "\"temporaryPassword\":\"Senha-temp-123\"}}")).andExpect(status().isCreated())
                .andExpect(jsonPath("$.policy.maxActiveConsumers").value(100)).andExpect(jsonPath("$.plan").doesNotExist());
        signedUp("GROWTH", "auto@teste.local");
        String list = mvc.perform(get("/api/admin/establishments").session(admin)).andExpect(status().isOk()).andReturn()
                .getResponse().getContentAsString();
        assertThat((List<String>) JsonPath.read(list, "$.content[?(@.slug == 'manual')].plan")).containsExactly((String) null);
        assertThat((List<String>) JsonPath.read(list, "$.content[?(@.plan.selfSignup == true)].plan.code")).containsExactly("GROWTH");
        // Estabelecimento manual: sem registro de plano (limites da política, sem limite de programas) e senha temporária
        // ainda exigindo troca, como antes.
        assertThat(jdbc.queryForObject("select count(*) from establishment_plan p join establishment e on e.id = p.establishment_id "
                + "where e.slug = 'manual'", Integer.class)).isZero();
        assertThat(jdbc.queryForObject("select password_change_required from app_user where email = 'manual@teste.local'", Boolean.class)).isTrue();
        // A suspensão administrativa continua valendo para o autocadastrado.
        long auto = jdbc.queryForObject("select establishment_id from establishment_plan", Long.class);
        mvc.perform(patch("/api/admin/establishments/" + auto + "/status").session(admin).with(csrf())
                .contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"SUSPENDED\"}")).andExpect(status().isOk());
    }
}
