package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.Duration;

import org.junit.jupiter.api.Test;

import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.loyalty.signup.QrCodes;
import com.shaminatech.pass.loyalty.signup.SignupGuard;

/** Proteções do formulário público (sem Spring): assinatura, tempo mínimo, validade e limite por IP. */
class SignupGuardUnitTest {

    private final MutableClock clock = new MutableClock();

    @Test
    void attemptsPerIpAreLimitedPerHour() {
        SignupGuard guard = new SignupGuard(clock, "", 3, 120, 3);
        guard.countAttempt("10.0.0.1");
        guard.countAttempt("10.0.0.1");
        guard.countAttempt("10.0.0.1");
        assertThatThrownBy(() -> guard.countAttempt("10.0.0.1")).isInstanceOf(ApiException.class)
                .hasFieldOrPropertyWithValue("code", "RATE_LIMITED");
        guard.countAttempt("10.0.0.2"); // outro IP não é afetado
        clock.advance(Duration.ofHours(1));
        guard.countAttempt("10.0.0.1"); // nova janela
    }

    @Test
    void formTokenIsBoundToTheLinkAndToTheTime() {
        SignupGuard guard = new SignupGuard(clock, "", 3, 120, 100);
        String token = guard.issueFormToken("a".repeat(32));
        assertThatThrownBy(() -> guard.verifyFormToken("a".repeat(32), token)).hasFieldOrPropertyWithValue("code", "SIGNUP_TOO_FAST");
        clock.advance(Duration.ofSeconds(4));
        guard.verifyFormToken("a".repeat(32), token);
        assertThatThrownBy(() -> guard.verifyFormToken("b".repeat(32), token)).hasFieldOrPropertyWithValue("code", "SIGNUP_FORM_EXPIRED");
        // Outra instância (chave sorteada diferente) não aceita o token.
        SignupGuard restarted = new SignupGuard(clock, "", 3, 120, 100);
        assertThatThrownBy(() -> restarted.verifyFormToken("a".repeat(32), token)).hasFieldOrPropertyWithValue("code", "SIGNUP_FORM_EXPIRED");
        clock.advance(Duration.ofMinutes(121));
        assertThatThrownBy(() -> guard.verifyFormToken("a".repeat(32), token)).hasFieldOrPropertyWithValue("code", "SIGNUP_FORM_EXPIRED");
    }

    @Test
    void qrCodesAreRenderedAsSvgAndPng() {
        String svg = QrCodes.svg("https://pass.example.test/cadastro/" + "0".repeat(32));
        assertThat(svg).startsWith("<svg").contains("viewBox=\"0 0 ");
        byte[] png = QrCodes.png("https://pass.example.test/cadastro/" + "0".repeat(32), 512);
        assertThat(png.length).isGreaterThan(100);
        assertThat(new String(png, 1, 3, java.nio.charset.StandardCharsets.US_ASCII)).isEqualTo("PNG");
    }
}
