package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.TestPropertySource;

/** Proxy configurado, mas a conexão NÃO vem dele: o cabeçalho continua ignorado (proteção contra falsificação). */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = {"shaminatech.public.rate-limit-per-minute=3", "server.forward-headers-strategy=native",
        "server.tomcat.remoteip.internal-proxies=10\\.99\\.99\\.99"})
class ProxyUntrustedSourceTest extends IntegrationTestSupport {

    private static final String PUBLIC_URL = "/api/public/wallet-links/" + "d".repeat(32);

    static int status(int port, String forwardedFor) throws Exception {
        HttpRequest.Builder request = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + PUBLIC_URL)).GET();
        if (forwardedFor != null) {
            request.header("X-Forwarded-For", forwardedFor);
        }
        return HttpClient.newHttpClient().send(request.build(), HttpResponse.BodyHandlers.discarding()).statusCode();
    }

    @LocalServerPort
    int port;

    @Test
    void headerFromAnUntrustedAddressIsIgnored() throws Exception {
        int limited = 0;
        for (int i = 0; i < 5; i++) {
            if (status(port, "198.51.100." + i) == 429) limited++;
        }
        assertThat(limited).isEqualTo(2);
    }
}
