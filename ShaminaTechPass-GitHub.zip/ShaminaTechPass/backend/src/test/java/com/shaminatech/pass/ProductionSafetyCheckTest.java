package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

import com.shaminatech.pass.config.ProductionSafetyCheck;

/** O modo offline do Apple Wallet (homologação local) nunca sobe em produção. */
class ProductionSafetyCheckTest {

    @Test
    void appleOfflinePassesAreRefusedInProduction() {
        assertThatThrownBy(() -> new ProductionSafetyCheck(true, "validate", "none", "", true).verify())
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("offline-passes");
        assertThatCode(() -> new ProductionSafetyCheck(true, "validate", "none", "", false).verify()).doesNotThrowAnyException();
    }
}
