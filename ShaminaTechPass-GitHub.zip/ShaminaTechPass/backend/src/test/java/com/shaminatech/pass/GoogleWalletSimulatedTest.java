package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import com.jayway.jsonpath.JsonPath;
import com.shaminatech.pass.loyalty.wallet.WalletPass;
import com.shaminatech.pass.loyalty.wallet.WalletPassRepository;
import com.shaminatech.pass.loyalty.wallet.WalletSyncDispatcher;
import com.shaminatech.pass.loyalty.wallet.WalletSyncService;

/**
 * Integração Google Wallet com a API SIMULADA ({@link FakeGoogleWallet}, servidor local). Nenhuma chamada real ao Google:
 * estes testes validam o fluxo do Pass (emissão, atualização, falhas, recuperação, concorrência, links), não a aceitação
 * real dos dados pelo Google — que exige credenciais e um Android (teste real, pendente).
 */
class GoogleWalletSimulatedTest extends LoyaltyTestSupport {

    @DynamicPropertySource
    static void wallet(DynamicPropertyRegistry registry) {
        FakeGoogleWallet fake = FakeGoogleWallet.get();
        registry.add("shaminatech.wallet.google.enabled", () -> "true");
        registry.add("shaminatech.wallet.google.issuer-id", () -> FakeGoogleWallet.ISSUER_ID);
        registry.add("shaminatech.wallet.google.service-account-key-file", () -> fake.keyFile().toString());
        registry.add("shaminatech.wallet.google.origins", () -> "http://localhost:4203");
        registry.add("shaminatech.wallet.google.api-base-url", fake::baseUrl);
        registry.add("shaminatech.wallet.google.fallback-logo-uri", () -> "https://example.test/logo-padrao.png");
        registry.add("shaminatech.wallet.google.public-base-url", () -> "https://pass.example.test");
        registry.add("shaminatech.wallet.google.async-dispatch", () -> "false");
        registry.add("shaminatech.wallet.google.request-timeout", () -> "PT1S");
        registry.add("shaminatech.wallet.google.max-attempts", () -> "3");
    }

    @Autowired
    private WalletPassRepository passes;
    @Autowired
    private WalletSyncService syncService;
    @Autowired
    private WalletSyncDispatcher dispatcher;

    private final FakeGoogleWallet google = FakeGoogleWallet.get();
    private long program;
    private long consumer;
    private long card;

    @BeforeEach
    void setUpCard() throws Exception {
        google.reset();
        program = pointsProgram(a, ownerA, "");
        consumer = consumer(ownerA, a, "Joana Prado Lima", "11977771111");
        card = card(ownerA, a, consumer, program);
    }

    private String createLink(long cardId) throws Exception {
        String body = postJson(ownerA, base(a) + "/cards/" + cardId + "/wallet/google/links", "{}")
                .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString();
        return JsonPath.read(body, "$.url");
    }

    private WalletPass pass() {
        return passes.findByCardId(card).get(0);
    }

    private String objectId() {
        return pass().getExternalId();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> remote() {
        return google.objects.get(objectId());
    }

    @SuppressWarnings("unchecked")
    private Object remoteBalance() {
        Map<String, Object> points = (Map<String, Object>) remote().get("loyaltyPoints");
        return ((Map<String, Object>) points.get("balance")).values().iterator().next();
    }

    private String token(String url) {
        return url.substring(url.lastIndexOf('/') + 1);
    }

    // ---------------- Emissão ----------------

    @Test
    @SuppressWarnings("unchecked")
    void issuingCreatesClassAndObjectAndASignedSaveLink() throws Exception {
        String url = createLink(card);
        assertThat(url).startsWith("http://localhost:4203/carteira/");
        WalletPass pass = pass();
        assertThat(pass.getSyncStatus()).isEqualTo(WalletPass.SyncStatus.SYNCED);
        assertThat(pass.getExternalId()).startsWith(FakeGoogleWallet.ISSUER_ID + ".stp_card_" + card + "_");

        Map<String, Object> klass = google.classes.get(FakeGoogleWallet.ISSUER_ID + ".stp_prog_" + program);
        assertThat(klass).containsEntry("issuerName", "Estabelecimento loja-a").containsEntry("programName", "Pontos")
                .containsEntry("reviewStatus", "UNDER_REVIEW").containsEntry("hexBackgroundColor", "#f43f5e")
                .containsEntry("multipleDevicesAndHoldersAllowedStatus", "ONE_USER_ALL_DEVICES");
        assertThat(((Map<String, Object>) ((Map<String, Object>) klass.get("programLogo")).get("sourceUri")).get("uri"))
                .isEqualTo("https://example.test/logo-padrao.png");

        Map<String, Object> object = remote();
        String code = cardField(ownerA, a, card, "code");
        assertThat(object).containsEntry("state", "ACTIVE").containsEntry("accountName", "Joana");
        assertThat((Map<String, Object>) object.get("barcode")).containsEntry("type", "QR_CODE").containsEntry("value", code);
        assertThat(object.toString()).doesNotContain("11977771111"); // telefone nunca vai ao Google
        assertThat(remoteBalance()).isEqualTo(0);

        // Página pública: link válido → URL de salvamento com JWT assinado que referencia o objeto.
        String json = mvc.perform(get("/api/public/wallet-links/" + token(url))).andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("READY")).andExpect(jsonPath("$.consumerFirstName").value("Joana"))
                .andReturn().getResponse().getContentAsString();
        assertThat(json).doesNotContain("11977771111").doesNotContain("private").doesNotContain("Prado");
        String saveUrl = JsonPath.read(json, "$.saveUrl");
        assertThat(saveUrl).startsWith("https://pay.google.com/gp/v/save/");
        String jwt = saveUrl.substring("https://pay.google.com/gp/v/save/".length());
        assertThat(FakeGoogleWallet.verify(jwt, google.publicKey())).isTrue();
        Map<String, Object> claims = FakeGoogleWallet.claims(jwt);
        assertThat(claims).containsEntry("aud", "google").containsEntry("typ", "savetowallet")
                .containsEntry("iss", FakeGoogleWallet.CLIENT_EMAIL).containsEntry("origins", List.of("http://localhost:4203"));
        assertThat(claims.get("payload").toString()).contains(objectId());
    }

    @Test
    void repeatedIssuingReusesThePassAndNeverDuplicatesTheObject() throws Exception {
        createLink(card);
        createLink(card);
        assertThat(passes.findByCardId(card)).hasSize(1);
        assertThat(google.objects).hasSize(1);
        assertThat(google.calls.stream().filter(c -> c.startsWith("POST loyaltyObject"))).hasSize(1);
        assertThat(jdbc.queryForObject("select count(*) from wallet_link where card_id = ?", Integer.class, card)).isEqualTo(2);
    }

    // ---------------- Atualização ----------------

    @Test
    void confirmedMovementsUpdateTheRemoteBalanceAndValidity() throws Exception {
        createLink(card);
        clock.advance(Duration.ofDays(2));
        earn(ownerA, a, card, "{\"purchaseAmount\":42.90}", key()).andExpect(status().isCreated());
        assertThat(remoteBalance()).isEqualTo(42);
        assertThat(pass().getSyncStatus()).isEqualTo(WalletPass.SyncStatus.SYNCED);
        assertThat(remote().get("validTimeInterval").toString()).contains(cardField(ownerA, a, card, "expiresAt"));
        // Uma requisição repetida (mesma chave) não gera novo envio de saldo diferente.
        long writes = google.objectWrites();
        String k = key();
        earn(ownerA, a, card, "{\"purchaseAmount\":5.00}", k);
        earn(ownerA, a, card, "{\"purchaseAmount\":5.00}", k).andExpect(status().isOk());
        assertThat(remoteBalance()).isEqualTo(47);
        assertThat(google.objectWrites()).isEqualTo(writes + 1);
    }

    @Test
    void cardStatesMapToOfficialGoogleStates() throws Exception {
        createLink(card);
        // Desativado: continua na lista principal do Google Wallet, com a situação "Bloqueado".
        postJson(ownerA, base(a) + "/cards/" + card + "/suspend", "{}").andExpect(status().isOk());
        assertThat(remote()).containsEntry("state", "ACTIVE");
        assertThat(remote().get("secondaryLoyaltyPoints").toString()).contains("Bloqueado");
        postJson(ownerA, base(a) + "/cards/" + card + "/reactivate", "{}").andExpect(status().isOk());
        assertThat(remote()).containsEntry("state", "ACTIVE");
        assertThat(remote().get("secondaryLoyaltyPoints").toString()).contains("Ativo");
        assertThat(remote().get("textModulesData").toString()).doesNotContain("Cartão bloqueado");
        clock.advance(Duration.ofDays(40));
        expiration.run();
        assertThat(remote()).containsEntry("state", "EXPIRED");
        postJson(ownerA, base(a) + "/cards/" + card + "/cancel", "{\"reason\":\"Perdeu o celular\"}").andExpect(status().isOk());
        assertThat(remote()).containsEntry("state", "INACTIVE");
        assertThat(pass().getSyncStatus()).isEqualTo(WalletPass.SyncStatus.INVALIDATED);
    }

    // ---------------- Falhas e recuperação ----------------

    @Test
    void temporaryGoogleFailureNeverLosesOrDuplicatesTheMovement() throws Exception {
        createLink(card);
        google.failNext(503, 1);
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key()).andExpect(status().isCreated());
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo("10"); // movimentação gravada
        WalletPass failed = pass();
        assertThat(failed.getSyncStatus()).isEqualTo(WalletPass.SyncStatus.FAILED);
        assertThat(failed.getLastErrorStatus()).isEqualTo(503);
        assertThat(failed.getNextAttemptAt()).isNotNull();
        assertThat(remoteBalance()).isEqualTo(0); // o Google ainda mostra o valor antigo

        dispatcher.sweep(); // antes do prazo: não tenta
        assertThat(pass().getSyncStatus()).isEqualTo(WalletPass.SyncStatus.FAILED);
        clock.advance(Duration.ofMinutes(1));
        dispatcher.sweep();
        assertThat(pass().getSyncStatus()).isEqualTo(WalletPass.SyncStatus.SYNCED);
        assertThat(remoteBalance()).isEqualTo(10);
        assertThat(countTransactions(card, "EARN")).isEqualTo(1);
    }

    @Test
    void timeoutIsTreatedAsTemporaryFailure() throws Exception {
        createLink(card);
        google.delay(1500);
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key()).andExpect(status().isCreated());
        google.delay(0);
        assertThat(pass().getSyncStatus()).isEqualTo(WalletPass.SyncStatus.FAILED);
        assertThat(pass().getLastError()).contains("Tempo esgotado");
        assertThat(pass().getNextAttemptAt()).isNotNull();
    }

    @Test
    void permanentErrorWaitsForAuthorizedManualRetry() throws Exception {
        createLink(card);
        google.failNext(400, 1);
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key());
        WalletPass failed = pass();
        assertThat(failed.getSyncStatus()).isEqualTo(WalletPass.SyncStatus.FAILED);
        assertThat(failed.getNextAttemptAt()).isNull();
        clock.advance(Duration.ofHours(10));
        dispatcher.sweep();
        assertThat(pass().getSyncStatus()).isEqualTo(WalletPass.SyncStatus.FAILED);

        postJson(ownerB, base(a) + "/wallet/passes/" + failed.getId() + "/retry", "{}").andExpect(status().isForbidden());
        postJson(ownerB, base(b) + "/wallet/passes/" + failed.getId() + "/retry", "{}").andExpect(status().isNotFound());
        // A resposta sai antes do envio (feito após o commit); em seguida o passe está sincronizado.
        postJson(ownerA, base(a) + "/wallet/passes/" + failed.getId() + "/retry", "{}").andExpect(status().isOk());
        assertThat(pass().getSyncStatus()).isEqualTo(WalletPass.SyncStatus.SYNCED);
        assertThat(remoteBalance()).isEqualTo(10);
        List<String> actions = JsonPath.read(getJson(ownerA, base(a) + "/audit"), "$.content[*].action");
        assertThat(actions).contains("WALLET_SYNC_RETRIED", "WALLET_LINK_CREATED", "WALLET_PASS_CREATED");
    }

    @Test
    void retriesStopAfterTheConfiguredLimit() throws Exception {
        createLink(card);
        google.failNext(500, 10);
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key());
        for (int i = 0; i < 5; i++) {
            clock.advance(Duration.ofHours(7));
            dispatcher.sweep();
        }
        WalletPass pass = pass();
        assertThat(pass.getAttempts()).isEqualTo(3);
        assertThat(pass.getNextAttemptAt()).isNull();
        assertThat(getJson(ownerA, base(a) + "/wallet")).contains("\"FAILED\":1");
    }

    // ---------------- Concorrência ----------------

    @Test
    void concurrentSyncOfTheSamePassSendsOnce() throws Exception {
        createLink(card);
        WalletPass pass = pass();
        jdbc.update("update wallet_pass set sync_status = 'PENDING', desired_version = desired_version + 1, next_attempt_at = null"
                + " where id = ?", pass.getId());
        long before = google.objectWrites();
        google.delay(300);
        ExecutorService pool = Executors.newFixedThreadPool(4);
        CountDownLatch start = new CountDownLatch(1);
        for (int i = 0; i < 4; i++) {
            pool.submit(() -> {
                start.await();
                return syncService.process(pass.getId());
            });
        }
        start.countDown();
        pool.shutdown();
        assertThat(pool.awaitTermination(30, TimeUnit.SECONDS)).isTrue();
        google.delay(0);
        assertThat(google.objectWrites() - before).isEqualTo(1);
        assertThat(pass().getSyncStatus()).isEqualTo(WalletPass.SyncStatus.SYNCED);
    }

    // ---------------- Isolamento e links ----------------

    @Test
    void otherEstablishmentsCannotIssueOrSeeWalletPasses() throws Exception {
        postJson(ownerB, base(a) + "/cards/" + card + "/wallet/google/links", "{}").andExpect(status().isForbidden());
        postJson(ownerB, base(b) + "/cards/" + card + "/wallet/google/links", "{}").andExpect(status().isNotFound());
        mvc.perform(get(base(b) + "/cards/" + card + "/wallet").session(ownerB)).andExpect(status().isNotFound());
        assertThat(passes.findByCardId(card)).isEmpty();
    }

    @Test
    void distributionLinksAreSecretExpiringAndRevocable() throws Exception {
        String url = createLink(card);
        String token = token(url);
        assertThat(token).matches("[0-9a-f]{32}");
        assertThat(jdbc.queryForObject("select count(*) from wallet_link where token_hash = ?", Integer.class, token)).isZero();

        mvc.perform(get("/api/public/wallet-links/" + token)).andExpect(status().isOk());
        mvc.perform(get("/api/public/wallet-links/" + "0".repeat(32))).andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("WALLET_LINK_INVALID"));
        mvc.perform(get("/api/public/wallet-links/nao-e-token")).andExpect(status().isNotFound());

        long linkId = ((Number) JsonPath.read(getJson(ownerA, base(a) + "/cards/" + card + "/wallet"), "$.links[0].id")).longValue();
        postJson(ownerB, base(b) + "/wallet/links/" + linkId + "/revoke", "{}").andExpect(status().isNotFound());
        postJson(ownerA, base(a) + "/wallet/links/" + linkId + "/revoke", "{}").andExpect(status().isOk());
        mvc.perform(get("/api/public/wallet-links/" + token)).andExpect(status().isNotFound());

        String second = token(createLink(card));
        clock.advance(Duration.ofDays(3).plusMinutes(1));
        mvc.perform(get("/api/public/wallet-links/" + second)).andExpect(status().isNotFound());
    }

    @Test
    void cancelledCardsCannotBeDistributed() throws Exception {
        String token = token(createLink(card));
        postJson(ownerA, base(a) + "/cards/" + card + "/cancel", "{\"reason\":\"teste\"}");
        mvc.perform(get("/api/public/wallet-links/" + token)).andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("UNAVAILABLE")).andExpect(jsonPath("$.saveUrl").doesNotExist());
        postJson(ownerA, base(a) + "/cards/" + card + "/wallet/google/links", "{}").andExpect(status().isConflict());
    }

    @Test
    void programChangesResyncTheClassAndPublicImagesUseRandomTokens() throws Exception {
        createLink(card);
        long classWrites = google.calls.stream().filter(c -> c.contains("loyaltyClass")).count();
        mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put(base(a) + "/programs/" + program + "/design")
                .session(ownerA).with(org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf())
                .contentType(org.springframework.http.MediaType.APPLICATION_JSON)
                .content("{\"brandColor\":\"#0F766E\",\"textColor\":\"#FFFFFF\"}")).andExpect(status().isOk());
        assertThat(google.calls.stream().filter(c -> c.contains("loyaltyClass")).count()).isGreaterThan(classWrites);
        assertThat(google.classes.values().iterator().next()).containsEntry("hexBackgroundColor", "#0f766e");
        mvc.perform(get("/api/public/images/" + "a".repeat(32))).andExpect(status().isNotFound());
    }
}
