package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.shaminatech.pass.security.PasswordPolicy;

class PasswordPolicyTest {

    @Test
    void acceptsReasonablePasswords() {
        assertThat(PasswordPolicy.violation("Cafe-Central-2026")).isEmpty();
    }

    @Test
    void rejectsWeakOrOversizedPasswords() {
        assertThat(PasswordPolicy.violation(null)).isPresent();
        assertThat(PasswordPolicy.violation("curta1")).isPresent();
        assertThat(PasswordPolicy.violation("somenteletras")).isPresent();
        assertThat(PasswordPolicy.violation("1234567890123")).isPresent();
        // 40 caracteres acentuados = 80 bytes em UTF-8 (acima do limite do BCrypt).
        assertThat(PasswordPolicy.violation("é".repeat(40) + "1")).isPresent();
    }
}
