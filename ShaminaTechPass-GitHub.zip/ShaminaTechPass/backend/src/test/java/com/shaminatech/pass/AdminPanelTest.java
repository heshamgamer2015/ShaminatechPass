package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;

import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.user.AppUser;

class AdminPanelTest extends IntegrationTestSupport {

    private AppUser admin;
    private MockHttpSession adminSession;

    @BeforeEach
    void setUp() throws Exception {
        admin = platformAdmin("admin@teste.local");
        adminSession = login("admin@teste.local");
    }

    private static String createJson(String slug, String ownerEmail, String password) {
        String pwd = password == null ? "null" : "\"" + password + "\"";
        return """
                {"name":"Café Central","slug":"%s","contactEmail":"contato@cafe.local","contactPhone":"(11) 99999-0000",
                 "owner":{"email":"%s","fullName":"Maria Dona","temporaryPassword":%s}}
                """.formatted(slug, ownerEmail, pwd);
    }

    @Test
    void adminEndpointsRequirePlatformAdmin() throws Exception {
        mvc.perform(get("/api/admin/establishments")).andExpect(status().isUnauthorized());

        var establishment = establishment("loja");
        member(establishment, user("dono@teste.local"), MembershipRole.OWNER);
        MockHttpSession ownerSession = login("dono@teste.local");
        mvc.perform(get("/api/admin/establishments").session(ownerSession)).andExpect(status().isForbidden());
        mvc.perform(post("/api/admin/establishments").session(ownerSession).with(csrf())
                        .contentType(MediaType.APPLICATION_JSON).content(createJson("invasor", "x@teste.local", "Senha-temp-123")))
                .andExpect(status().isForbidden());
        mvc.perform(get("/api/admin/audit").session(ownerSession)).andExpect(status().isForbidden());
    }

    @Test
    void createsEstablishmentWithNewOwnerWhoMustChangePassword() throws Exception {
        mvc.perform(post("/api/admin/establishments").session(adminSession).with(csrf())
                        .contentType(MediaType.APPLICATION_JSON).content(createJson("cafe-central", "Maria@Cafe.local", "Senha-temp-123")))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.slug").value("cafe-central"))
                .andExpect(jsonPath("$.status").value("ACTIVE"))
                .andExpect(jsonPath("$.account.email").value("maria@cafe.local"))
                .andExpect(jsonPath("$.account.role").value("OWNER"))
                .andExpect(jsonPath("$.policy.maxActiveConsumers").value(100))
                .andExpect(jsonPath("$.usage.activeConsumers").value(0));

        AppUser owner = users.findByEmail("maria@cafe.local").orElseThrow();
        assertThat(owner.isPasswordChangeRequired()).isTrue();
        assertThat(owner.getPasswordHash()).doesNotContain("Senha-temp-123").startsWith("{bcrypt}");

        mvc.perform(get("/api/admin/audit").session(adminSession))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[*].action", hasItem("ESTABLISHMENT_CREATED")))
                .andExpect(jsonPath("$.content[*].action", hasItem("USER_CREATED")));
    }

    @Test
    void createRejectsDuplicateSlugInvalidDataAndMissingTemporaryPassword() throws Exception {
        establishment("ja-existe");
        mvc.perform(post("/api/admin/establishments").session(adminSession).with(csrf())
                        .contentType(MediaType.APPLICATION_JSON).content(createJson("ja-existe", "a@teste.local", "Senha-temp-123")))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.errors[0].field").value("slug"));

        mvc.perform(post("/api/admin/establishments").session(adminSession).with(csrf())
                        .contentType(MediaType.APPLICATION_JSON).content(createJson("Slug Inválido!", "nao-email", "123")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[*].field", hasItem("slug")))
                .andExpect(jsonPath("$.errors[*].field", hasItem("owner.email")))
                .andExpect(jsonPath("$.errors[*].field", hasItem("owner.temporaryPassword")));

        mvc.perform(post("/api/admin/establishments").session(adminSession).with(csrf())
                        .contentType(MediaType.APPLICATION_JSON).content(createJson("sem-senha", "novo@teste.local", null)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].field").value("temporaryPassword"));
        // A transação foi desfeita: o estabelecimento não ficou criado pela metade.
        assertThat(establishments.existsBySlug("sem-senha")).isFalse();
    }

    @Test
    void suspendingAnEstablishmentBlocksItsTeam() throws Exception {
        var establishment = establishment("suspensa");
        member(establishment, user("dono@teste.local"), MembershipRole.OWNER);
        MockHttpSession ownerSession = login("dono@teste.local");
        mvc.perform(get("/api/establishments/" + establishment.getId()).session(ownerSession)).andExpect(status().isOk());

        mvc.perform(patch("/api/admin/establishments/" + establishment.getId() + "/status").session(adminSession).with(csrf())
                        .contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"SUSPENDED\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("SUSPENDED"));

        mvc.perform(get("/api/establishments/" + establishment.getId()).session(ownerSession))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("ESTABLISHMENT_INACTIVE"));
    }

    @Test
    void adminCannotDisableOwnAccountButCanDisableAndUnlockOthers() throws Exception {
        mvc.perform(patch("/api/admin/users/" + admin.getId() + "/status").session(adminSession).with(csrf())
                        .contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"DISABLED\"}"))
                .andExpect(status().isBadRequest());

        AppUser other = user("outro@teste.local");
        mvc.perform(patch("/api/admin/users/" + other.getId() + "/status").session(adminSession).with(csrf())
                        .contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"DISABLED\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("DISABLED"));
        mvc.perform(post("/api/admin/users/" + other.getId() + "/unlock").session(adminSession).with(csrf()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.locked").value(false));
        mvc.perform(get("/api/admin/users?q=outro").session(adminSession))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(1));
    }

    @Test
    void listsAndFiltersEstablishments() throws Exception {
        establishment("alfa");
        establishment("beta");
        mvc.perform(get("/api/admin/establishments?q=alf").session(adminSession))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.content[0].slug").value("alfa"));
        mvc.perform(get("/api/admin/establishments?status=ACTIVE&size=500").session(adminSession))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size").value(100))
                .andExpect(jsonPath("$.totalElements").value(2));
        mvc.perform(get("/api/admin/establishments?status=INEXISTENTE").session(adminSession))
                .andExpect(status().isBadRequest());
        mvc.perform(get("/api/admin/establishments/999999").session(adminSession)).andExpect(status().isNotFound());
    }

    @Test
    void platformAdminHasNoImplicitAccessToEstablishmentPanel() throws Exception {
        var establishment = establishment("privado");
        mvc.perform(get("/api/establishments/" + establishment.getId()).session(adminSession)).andExpect(status().isForbidden());
    }
}
