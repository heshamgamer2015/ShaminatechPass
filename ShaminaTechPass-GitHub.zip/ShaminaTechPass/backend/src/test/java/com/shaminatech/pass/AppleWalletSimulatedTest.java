package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.ByteArrayInputStream;
import java.security.MessageDigest;
import java.time.Duration;
import java.time.Instant;
import java.util.Collection;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.imageio.ImageIO;

import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoVerifierBuilder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import com.jayway.jsonpath.JsonPath;
import com.shaminatech.pass.loyalty.wallet.WalletPass;
import com.shaminatech.pass.loyalty.wallet.WalletPass.Provider;
import com.shaminatech.pass.loyalty.wallet.WalletPassRepository;
import com.shaminatech.pass.loyalty.wallet.WalletSyncDispatcher;

import tools.jackson.databind.json.JsonMapper;

/**
 * Integração Apple Wallet com Apple SIMULADA ({@link FakeApple}: certificado de teste gerado na hora e APNs local).
 * Valida o .pkpass (estrutura, manifesto, assinatura), o web service oficial, as notificações e os estados — não a
 * aceitação real pelo iPhone, que exige conta Apple Developer, certificado verdadeiro e HTTPS público (teste real pendente).
 */
class AppleWalletSimulatedTest extends LoyaltyTestSupport {

    private static final String WS = "/api/public/apple-wallet/v1";
    private static final String DEVICE = "a1b2c3d4e5f6device01";
    private static final String PUSH_TOKEN = "ab".repeat(32);

    @DynamicPropertySource
    static void apple(DynamicPropertyRegistry registry) {
        FakeApple fake = FakeApple.get();
        registry.add("shaminatech.wallet.apple.enabled", () -> "true");
        registry.add("shaminatech.wallet.apple.pass-type-identifier", () -> FakeApple.PASS_TYPE_ID);
        registry.add("shaminatech.wallet.apple.team-identifier", () -> FakeApple.TEAM_ID);
        registry.add("shaminatech.wallet.apple.certificate-file", () -> fake.p12().toString());
        registry.add("shaminatech.wallet.apple.certificate-password", () -> FakeApple.P12_PASSWORD);
        registry.add("shaminatech.wallet.apple.wwdr-certificate-file", () -> fake.wwdrFile().toString());
        registry.add("shaminatech.wallet.apple.web-service-base-url", () -> "https://pass.example.test");
        registry.add("shaminatech.wallet.apple.auth-secret", () -> "segredo-de-teste-com-mais-de-32-caracteres!");
        registry.add("shaminatech.wallet.apple.apns-base-url", fake::apnsUrl);
        registry.add("shaminatech.wallet.apple.request-timeout", () -> "PT2S");
        registry.add("shaminatech.wallet.apple.support-name", () -> "ShaminaTech (teste)");
        registry.add("shaminatech.wallet.apple.support-email", () -> "suporte@example.test");
        registry.add("shaminatech.wallet.google.async-dispatch", () -> "false");
    }

    @Autowired
    private WalletPassRepository passes;
    @Autowired
    private WalletSyncDispatcher dispatcher;
    @Autowired
    private JsonMapper json;

    private final FakeApple apple = FakeApple.get();
    private long card;

    @BeforeEach
    void setUpCard() throws Exception {
        apple.reset();
        long program = pointsProgram(a, ownerA, "");
        long consumer = consumer(ownerA, a, "Joana Prado Lima", "11977771111");
        card = card(ownerA, a, consumer, program);
    }

    // ---------------- Apoio ----------------

    private String createLink(long cardId) throws Exception {
        String body = postJson(ownerA, base(a) + "/cards/" + cardId + "/wallet/links", "{}")
                .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString();
        String url = JsonPath.read(body, "$.url");
        return url.substring(url.lastIndexOf('/') + 1);
    }

    private WalletPass applePass(long cardId) {
        return passes.findByCardIdAndProvider(cardId, Provider.APPLE_WALLET).orElseThrow();
    }

    private String serial() {
        return applePass(card).getExternalId();
    }

    private Map<String, byte[]> unzip(byte[] data) throws Exception {
        Map<String, byte[]> files = new HashMap<>();
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(data))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                files.put(entry.getName(), zip.readAllBytes());
            }
        }
        return files;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> passJson(byte[] pkpass) throws Exception {
        return json.readValue(unzip(pkpass).get("pass.json"), Map.class);
    }

    private byte[] download(String token) throws Exception {
        return mvc.perform(get("/api/public/wallet-links/" + token + "/apple")).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsByteArray();
    }

    /** Token de autenticação do passe, lido do próprio pass.json (como o iPhone faz). */
    private String authToken(String linkToken) throws Exception {
        return (String) passJson(download(linkToken)).get("authenticationToken");
    }

    private MockHttpServletResponse latest(String serial, String auth, String ifModifiedSince) throws Exception {
        var request = get(WS + "/passes/" + FakeApple.PASS_TYPE_ID + "/" + serial);
        if (auth != null) {
            request.header("Authorization", "ApplePass " + auth);
        }
        if (ifModifiedSince != null) {
            request.header("If-Modified-Since", ifModifiedSince);
        }
        return mvc.perform(request).andReturn().getResponse();
    }

    private int register(String device, String serial, String auth) throws Exception {
        var request = post(WS + "/devices/" + device + "/registrations/" + FakeApple.PASS_TYPE_ID + "/" + serial)
                .contentType(MediaType.APPLICATION_JSON).content("{\"pushToken\":\"" + PUSH_TOKEN + "\"}");
        if (auth != null) {
            request.header("Authorization", "ApplePass " + auth);
        }
        return mvc.perform(request).andReturn().getResponse().getStatus();
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> field(Map<String, Object> pass, String group, String key) {
        Map<String, Object> storeCard = (Map<String, Object>) pass.get("storeCard");
        return ((List<Map<String, Object>>) storeCard.get(group)).stream().filter(f -> key.equals(f.get("key"))).findFirst()
                .orElse(null);
    }

    // ---------------- Emissão e estrutura do .pkpass ----------------

    @Test
    @SuppressWarnings("unchecked")
    void issuingProducesAValidSignedPkpass() throws Exception {
        String token = createLink(card);
        WalletPass pass = applePass(card);
        assertThat(pass.getSyncStatus()).isEqualTo(WalletPass.SyncStatus.SYNCED); // sem aparelhos: nada a notificar
        assertThat(pass.getExternalId()).matches("stp[0-9a-f]{32}"); // aleatório: não revela o id interno do cartão
        assertThat(passes.findByCardId(card)).hasSize(1); // Google desligado: só o passe Apple

        // Página pública oferece o Apple Wallet.
        mvc.perform(get("/api/public/wallet-links/" + token)).andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("READY"))
                .andExpect(jsonPath("$.apple.status").value("READY"))
                .andExpect(jsonPath("$.apple.url").value("/api/public/wallet-links/" + token + "/apple"))
                .andExpect(jsonPath("$.google").doesNotExist());

        MockHttpServletResponse response = mvc.perform(get("/api/public/wallet-links/" + token + "/apple"))
                .andExpect(status().isOk()).andReturn().getResponse();
        assertThat(response.getContentType()).isEqualTo("application/vnd.apple.pkpass");
        assertThat(response.getHeader("Cache-Control")).contains("no-store");
        Map<String, byte[]> files = unzip(response.getContentAsByteArray());
        assertThat(files.keySet()).contains("pass.json", "manifest.json", "signature", "icon.png", "icon@2x.png", "icon@3x.png",
                "logo.png", "logo@2x.png", "logo@3x.png");

        // Manifesto: SHA-1 de cada arquivo, exceto o próprio manifesto e a assinatura.
        Map<String, String> manifest = json.readValue(files.get("manifest.json"), Map.class);
        assertThat(manifest.keySet()).doesNotContain("manifest.json", "signature");
        assertThat(manifest.keySet()).containsExactlyInAnyOrderElementsOf(files.keySet().stream()
                .filter(n -> !n.equals("manifest.json") && !n.equals("signature")).toList());
        for (Map.Entry<String, String> e : manifest.entrySet()) {
            assertThat(e.getValue()).isEqualTo(HexFormat.of().formatHex(MessageDigest.getInstance("SHA-1").digest(files.get(e.getKey()))));
        }

        // Assinatura PKCS #7 destacada do manifesto, com o certificado do passe e o intermediário, e signing-time.
        CMSSignedData signed = new CMSSignedData(new CMSProcessableByteArray(files.get("manifest.json")), files.get("signature"));
        Collection<X509CertificateHolder> certs = signed.getCertificates().getMatches(null);
        assertThat(certs).extracting(h -> h.getSubject().toString())
                .anyMatch(s -> s.contains(FakeApple.PASS_TYPE_ID)).anyMatch(s -> s.contains("Fake Apple WWDR"));
        SignerInformation signer = signed.getSignerInfos().getSigners().iterator().next();
        assertThat(signer.verify(new JcaSimpleSignerInfoVerifierBuilder().build(apple.leaf()))).isTrue();
        assertThat(signer.getSignedAttributes().get(CMSAttributes.signingTime)).isNotNull();
        assertThat(signed.isDetachedSignature()).isTrue();

        // pass.json
        Map<String, Object> pass1 = json.readValue(files.get("pass.json"), Map.class);
        String code = cardField(ownerA, a, card, "code");
        assertThat(pass1).containsEntry("formatVersion", 1).containsEntry("passTypeIdentifier", FakeApple.PASS_TYPE_ID)
                .containsEntry("teamIdentifier", FakeApple.TEAM_ID).containsEntry("serialNumber", pass.getExternalId())
                .containsEntry("webServiceURL", "https://pass.example.test/api/public/apple-wallet")
                .containsEntry("organizationName", "Estabelecimento loja-a").containsEntry("sharingProhibited", true)
                .containsKey("storeCard").containsKey("expirationDate").doesNotContainKey("voided");
        assertThat((String) pass1.get("authenticationToken")).hasSize(64);
        assertThat((List<Map<String, Object>>) pass1.get("barcodes")).first()
                .satisfies(b -> assertThat(b).containsEntry("format", "PKBarcodeFormatQR").containsEntry("message", code));
        assertThat(field(pass1, "primaryFields", "saldo")).containsEntry("label", "PONTOS").containsEntry("value", 0);
        assertThat(field(pass1, "headerFields", "situacao")).containsEntry("value", "Ativo");
        assertThat(field(pass1, "secondaryFields", "cliente")).containsEntry("value", "Joana");
        assertThat(field(pass1, "backFields", "emissor").get("value").toString()).contains("ShaminaTech (teste)", "suporte@example.test");
        String raw = new String(files.get("pass.json"), java.nio.charset.StandardCharsets.UTF_8);
        assertThat(raw).doesNotContain("11977771111").doesNotContain("Prado"); // minimização de dados

        // Imagens nos tamanhos do Apple Wallet (ícone padrão da ShaminaTech, pois o programa não tem logotipo).
        var icon3x = ImageIO.read(new ByteArrayInputStream(files.get("icon@3x.png")));
        assertThat(icon3x.getWidth()).isEqualTo(87);
        assertThat(icon3x.getHeight()).isEqualTo(87);
        var logo2x = ImageIO.read(new ByteArrayInputStream(files.get("logo@2x.png")));
        assertThat(logo2x.getHeight()).isLessThanOrEqualTo(100);
        assertThat(logo2x.getWidth()).isLessThanOrEqualTo(320);
    }

    @Test
    void repeatedIssuingReusesTheSamePassAndSerial() throws Exception {
        createLink(card);
        String serial = serial();
        createLink(card);
        assertThat(passes.findByCardId(card)).hasSize(1);
        assertThat(serial()).isEqualTo(serial);
    }

    // ---------------- Web service: registro, consulta e atualização ----------------

    @Test
    @SuppressWarnings("unchecked")
    void deviceRegistrationPushAndUpdateFollowTheAppleProtocol() throws Exception {
        String link = createLink(card);
        String serial = serial();
        String auth = authToken(link);

        // Autenticação obrigatória: sem token, token errado ou Pass Type ID errado → 401.
        assertThat(register(DEVICE, serial, null)).isEqualTo(401);
        assertThat(register(DEVICE, serial, "0".repeat(64))).isEqualTo(401);
        assertThat(mvc.perform(post(WS + "/devices/" + DEVICE + "/registrations/pass.outro.tipo/" + serial)
                .header("Authorization", "ApplePass " + auth).contentType(MediaType.APPLICATION_JSON)
                .content("{\"pushToken\":\"" + PUSH_TOKEN + "\"}")).andReturn().getResponse().getStatus()).isEqualTo(401);
        // Registro: 201 na primeira vez, 200 se repetido (idempotente).
        assertThat(register(DEVICE, serial, auth)).isEqualTo(201);
        assertThat(register(DEVICE, serial, auth)).isEqualTo(200);
        assertThat(jdbc.queryForObject("select count(*) from apple_device_registration", Integer.class)).isEqualTo(1);

        // Lista de passes alterados: sem marca → todos; com a marca devolvida → 204 (nada novo).
        String list = mvc.perform(get(WS + "/devices/" + DEVICE + "/registrations/" + FakeApple.PASS_TYPE_ID))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat((List<String>) JsonPath.read(list, "$.serialNumbers")).containsExactly(serial);
        String tag = JsonPath.read(list, "$.lastUpdated");
        mvc.perform(get(WS + "/devices/" + DEVICE + "/registrations/" + FakeApple.PASS_TYPE_ID).param("passesUpdatedSince", tag))
                .andExpect(status().isNoContent());

        MockHttpServletResponse first = latest(serial, auth, null);
        assertThat(first.getStatus()).isEqualTo(200);
        String lastModified = first.getHeader("Last-Modified");
        assertThat(lastModified).isNotNull();
        assertThat(latest(serial, auth, lastModified).getStatus()).isEqualTo(304);
        assertThat(latest(serial, null, null).getStatus()).isEqualTo(401);

        // Compra confirmada → notificação APNs vazia ao aparelho → lista e passe novos.
        clock.advance(Duration.ofMinutes(5));
        earn(ownerA, a, card, "{\"purchaseAmount\":42.90}", key()).andExpect(status().isCreated());
        assertThat(apple.pushes).hasSize(1);
        assertThat(apple.pushes.get(0)).isEqualTo(new FakeApple.Push(PUSH_TOKEN, FakeApple.PASS_TYPE_ID, "{}"));
        assertThat(applePass(card).getSyncStatus()).isEqualTo(WalletPass.SyncStatus.SYNCED);
        String changed = mvc.perform(get(WS + "/devices/" + DEVICE + "/registrations/" + FakeApple.PASS_TYPE_ID)
                .param("passesUpdatedSince", tag)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat((List<String>) JsonPath.read(changed, "$.serialNumbers")).containsExactly(serial);
        MockHttpServletResponse updated = latest(serial, auth, lastModified);
        assertThat(updated.getStatus()).isEqualTo(200);
        Map<String, Object> pass = passJson(updated.getContentAsByteArray());
        assertThat(field(pass, "primaryFields", "saldo")).containsEntry("value", 42);
        assertThat(pass.get("authenticationToken")).isEqualTo(auth); // a Apple proíbe trocar o token
        assertThat(Instant.parse((String) pass.get("expirationDate"))).isAfter(clock.instant().plus(Duration.ofDays(20)));

        // Baixar ou consultar o passe não renova a validade nem cria movimentação.
        String expiresBefore = cardField(ownerA, a, card, "expiresAt");
        clock.advance(Duration.ofDays(2)); // dentro da validade do link (3 dias)
        latest(serial, auth, null);
        download(link);
        assertThat(cardField(ownerA, a, card, "expiresAt")).isEqualTo(expiresBefore);

        // Remoção do registro.
        mvc.perform(delete(WS + "/devices/" + DEVICE + "/registrations/" + FakeApple.PASS_TYPE_ID + "/" + serial)
                .header("Authorization", "ApplePass " + auth)).andExpect(status().isOk());
        assertThat(jdbc.queryForObject("select count(*) from apple_device_registration", Integer.class)).isZero();
        mvc.perform(post(WS + "/log").contentType(MediaType.APPLICATION_JSON).content("{\"logs\":[\"teste\"]}"))
                .andExpect(status().isOk());
    }

    // ---------------- Estados ----------------

    @Test
    void blockedCardStaysVisibleAndIsReactivated() throws Exception {
        String link = createLink(card);
        String serial = serial();
        String auth = authToken(link);
        register(DEVICE, serial, auth);

        postJson(ownerA, base(a) + "/cards/" + card + "/suspend", "{}").andExpect(status().isOk());
        assertThat(apple.pushes).hasSize(1);
        Map<String, Object> blocked = passJson(latest(serial, auth, null).getContentAsByteArray());
        assertThat(blocked).doesNotContainKey("voided").containsKey("expirationDate"); // continua na carteira
        assertThat(field(blocked, "headerFields", "situacao")).containsEntry("value", "Bloqueado");
        assertThat(field(blocked, "backFields", "aviso")).containsEntry("label", "Cartão bloqueado");
        assertThat(applePass(card).getRemoteState()).isEqualTo("BLOCKED");
        // O bloqueio vale no backend, não importa o que o celular mostra.
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key()).andExpect(status().is4xxClientError());

        postJson(ownerA, base(a) + "/cards/" + card + "/reactivate", "{}").andExpect(status().isOk());
        Map<String, Object> active = passJson(latest(serial, auth, null).getContentAsByteArray());
        assertThat(field(active, "headerFields", "situacao")).containsEntry("value", "Ativo");
        assertThat(field(active, "backFields", "aviso")).isNull();
        assertThat(applePass(card).getRemoteState()).isEqualTo("ACTIVE");
    }

    @Test
    void expirationAndCancellationAreShownByTheOfficialFields() throws Exception {
        String link = createLink(card);
        String serial = serial();
        String auth = authToken(link);
        register(DEVICE, serial, auth);

        clock.advance(Duration.ofDays(40));
        expiration.run();
        Map<String, Object> expired = passJson(latest(serial, auth, null).getContentAsByteArray());
        assertThat(Instant.parse((String) expired.get("expirationDate"))).isBefore(clock.instant());
        assertThat(field(expired, "headerFields", "situacao")).containsEntry("value", "Vencido");
        assertThat(applePass(card).getRemoteState()).isEqualTo("EXPIRED");

        link = createLink(card); // o primeiro link já venceu (3 dias); um novo continua valendo para o mesmo passe
        assertThat(serial()).isEqualTo(serial);
        postJson(ownerA, base(a) + "/cards/" + card + "/cancel", "{\"reason\":\"Perdeu o celular\"}").andExpect(status().isOk());
        Map<String, Object> cancelled = passJson(latest(serial, auth, null).getContentAsByteArray());
        assertThat(cancelled).containsEntry("voided", true).doesNotContainKey("expirationDate");
        assertThat(applePass(card).getSyncStatus()).isEqualTo(WalletPass.SyncStatus.INVALIDATED);
        // Link e download deixam de entregar o cartão cancelado.
        mvc.perform(get("/api/public/wallet-links/" + link)).andExpect(jsonPath("$.status").value("UNAVAILABLE"));
        mvc.perform(get("/api/public/wallet-links/" + link + "/apple")).andExpect(status().isNotFound());
    }

    // ---------------- Falhas de comunicação ----------------

    @Test
    void temporaryApnsFailureIsRetriedAndDeadDevicesAreRemoved() throws Exception {
        String link = createLink(card);
        String serial = serial();
        register(DEVICE, serial, authToken(link));

        apple.respondNext(503);
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key()).andExpect(status().isCreated()); // a compra nunca falha
        WalletPass failed = applePass(card);
        assertThat(failed.getSyncStatus()).isEqualTo(WalletPass.SyncStatus.FAILED);
        assertThat(failed.getNextAttemptAt()).isNotNull();
        assertThat(failed.getLastErrorStatus()).isEqualTo(503);

        clock.advance(Duration.ofMinutes(1));
        dispatcher.sweep();
        assertThat(applePass(card).getSyncStatus()).isEqualTo(WalletPass.SyncStatus.SYNCED);
        assertThat(apple.pushes).hasSize(2);

        // 410: o aparelho não existe mais → registro removido, passe sincronizado.
        apple.respondNext(410);
        earn(ownerA, a, card, "{\"purchaseAmount\":5.00}", key()).andExpect(status().isCreated());
        assertThat(applePass(card).getSyncStatus()).isEqualTo(WalletPass.SyncStatus.SYNCED);
        assertThat(jdbc.queryForObject("select count(*) from apple_device_registration", Integer.class)).isZero();
    }

    // ---------------- Isolamento ----------------

    @Test
    void passesAndTokensAreIsolatedBetweenCardsAndEstablishments() throws Exception {
        String linkA = createLink(card);
        String authA = authToken(linkA);
        String serialA = serial();

        long programB = pointsProgram(b, ownerB, "");
        long consumerB = consumer(ownerB, b, "Carlos Souza", "11955554444");
        long cardB = card(ownerB, b, consumerB, programB);
        postJson(ownerB, base(b) + "/cards/" + cardB + "/wallet/links", "{}").andExpect(status().isCreated());
        String serialB = applePass(cardB).getExternalId();

        // Outro estabelecimento não emite nem vê o cartão de A.
        postJson(ownerB, base(a) + "/cards/" + card + "/wallet/links", "{}").andExpect(status().isForbidden());
        postJson(ownerB, base(b) + "/cards/" + card + "/wallet/links", "{}").andExpect(status().isNotFound());
        // O token do passe A não abre nem registra o passe B.
        assertThat(latest(serialB, authA, null).getStatus()).isEqualTo(401);
        assertThat(register(DEVICE, serialB, authA)).isEqualTo(401);
        assertThat(latest(serialA, authA, null).getStatus()).isEqualTo(200);
        // Serial inexistente não é revelado (401, como token inválido).
        assertThat(latest("stp" + "0".repeat(32), authA, null).getStatus()).isEqualTo(401);
        // Link inválido não baixa nada.
        mvc.perform(get("/api/public/wallet-links/" + "0".repeat(32) + "/apple")).andExpect(status().isNotFound());
    }

    @Test
    void panelShowsApplePassAndRegisteredDevices() throws Exception {
        String link = createLink(card);
        register(DEVICE, serial(), authToken(link));
        mvc.perform(get(base(a) + "/cards/" + card + "/wallet").session(ownerA)).andExpect(status().isOk())
                .andExpect(jsonPath("$.apple.provider").value("APPLE_WALLET"))
                .andExpect(jsonPath("$.apple.status").value("SYNCED"))
                .andExpect(jsonPath("$.appleDevices").value(1))
                .andExpect(jsonPath("$.appleAvailable").value(true))
                .andExpect(jsonPath("$.pass").doesNotExist());
        mvc.perform(get(base(a) + "/wallet").session(ownerA)).andExpect(status().isOk())
                .andExpect(jsonPath("$.apple.configured").value(true))
                .andExpect(jsonPath("$.configured").value(false));
    }
}
