package com.shaminatech.pass;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;

/** Relógio controlável pelos testes de data e horário (validade e expiração). */
public class MutableClock extends Clock {

    public static final Instant DEFAULT = Instant.parse("2026-11-05T15:00:00Z"); // 05/11/2026 12:00 em São Paulo

    private volatile Instant now = DEFAULT;

    public void reset() {
        now = DEFAULT;
    }

    public void set(Instant instant) {
        now = instant;
    }

    public void advance(Duration duration) {
        now = now.plus(duration);
    }

    @Override
    public ZoneId getZone() {
        return ZoneOffset.UTC;
    }

    @Override
    public Clock withZone(ZoneId zone) {
        return this;
    }

    @Override
    public Instant instant() {
        return now;
    }
}
