package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Duration;
import java.time.Instant;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import com.jayway.jsonpath.JsonPath;

/**
 * Etapa 8 — regra obrigatória: a validade por inatividade só é renovada por movimentação legítima confirmada pela
 * empresa (compra ou resgate). Consultar, ler o código, sincronizar/abrir a carteira, editar o cadastro ou mudar a
 * situação do cartão NÃO renovam. (Lembretes: coberto em NotificationRemindersTest.)
 */
class ValidityRenewalTest extends LoyaltyTestSupport {

    @DynamicPropertySource
    static void wallet(DynamicPropertyRegistry registry) {
        FakeGoogleWallet fake = FakeGoogleWallet.get();
        registry.add("shaminatech.wallet.google.enabled", () -> "true");
        registry.add("shaminatech.wallet.google.issuer-id", () -> FakeGoogleWallet.ISSUER_ID);
        registry.add("shaminatech.wallet.google.service-account-key-file", () -> fake.keyFile().toString());
        registry.add("shaminatech.wallet.google.origins", () -> "http://localhost:4203");
        registry.add("shaminatech.wallet.google.api-base-url", fake::baseUrl);
        registry.add("shaminatech.wallet.google.fallback-logo-uri", () -> "https://example.test/logo-padrao.png");
        registry.add("shaminatech.wallet.google.public-base-url", () -> "https://pass.example.test");
        registry.add("shaminatech.wallet.google.async-dispatch", () -> "false");
        registry.add("shaminatech.wallet.google.request-timeout", () -> "PT1S");
        registry.add("shaminatech.wallet.google.max-attempts", () -> "3");
    }

    private long consumer;
    private long card;

    @BeforeEach
    void setUpCard() throws Exception {
        FakeGoogleWallet.get().reset();
        long program = pointsProgram(a, ownerA, "");
        consumer = consumer(ownerA, a, "Validade Teste", "11955554444");
        card = card(ownerA, a, consumer, program);
    }

    private Instant expiresAt() {
        return jdbc.queryForObject("select expires_at from loyalty_card where id = ?", Instant.class, card);
    }

    private Instant lastMovement() {
        return jdbc.queryForObject("select last_movement_at from loyalty_card where id = ?", Instant.class, card);
    }

    @Test
    void onlyAConfirmedPurchaseOrRedemptionRenewsTheInactivityPeriod() throws Exception {
        Instant initial = expiresAt();
        Instant initialMovement = lastMovement();
        clock.advance(Duration.ofDays(10));

        // Consultas e leitura do código no balcão.
        String detail = getJson(ownerA, base(a) + "/cards/" + card);
        String code = JsonPath.read(detail, "$.card.code");
        getJson(ownerA, base(a) + "/cards/lookup?code=" + code);
        getJson(ownerA, base(a) + "/cards/" + card + "/transactions");
        getJson(ownerA, base(a) + "/cards");
        getJson(ownerA, base(a) + "/consumers/" + consumer);

        // Carteira: gerar o link, sincronizar e o cliente abrir o link público.
        String url = JsonPath.read(postJson(ownerA, base(a) + "/cards/" + card + "/wallet/google/links", "{}")
                .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString(), "$.url");
        mvc.perform(get("/api/public/wallet-links/" + url.substring(url.lastIndexOf('/') + 1))).andExpect(status().isOk());
        getJson(ownerA, base(a) + "/cards/" + card + "/wallet");

        // Edição do cadastro e mudança de situação (bloquear e reativar).
        mvc.perform(put(base(a) + "/consumers/" + consumer).session(ownerA).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content("{\"fullName\":\"Validade Teste Editado\",\"phone\":\"11955554444\",\"email\":null,\"externalRef\":null,"
                        + "\"marketingOptIn\":true}")).andExpect(status().isOk());
        postJson(ownerA, base(a) + "/cards/" + card + "/suspend", "{\"reason\":\"teste\"}").andExpect(status().isOk());
        postJson(ownerA, base(a) + "/cards/" + card + "/reactivate", "{\"reason\":\"teste\"}").andExpect(status().isOk());

        assertThat(expiresAt()).isEqualTo(initial);
        assertThat(lastMovement()).isEqualTo(initialMovement);

        // Controle positivo: uma compra confirmada renova a partir de agora.
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key()).andExpect(status().isCreated());
        assertThat(expiresAt()).isAfter(initial);
        Instant afterPurchase = expiresAt();

        // Um estorno também não renova (não é uma nova compra).
        clock.advance(Duration.ofDays(3));
        String tx = getJson(ownerA, base(a) + "/cards/" + card + "/transactions");
        net.minidev.json.JSONArray ids = JsonPath.read(tx, "$.content[?(@.type == 'EARN')].id");
        long earnId = ((Number) ids.get(0)).longValue();
        postJson(ownerA, base(a) + "/transactions/" + earnId + "/reverse", "{\"reason\":\"teste\"}", key()).andExpect(status().isCreated());
        assertThat(expiresAt()).isEqualTo(afterPurchase);
    }
}
