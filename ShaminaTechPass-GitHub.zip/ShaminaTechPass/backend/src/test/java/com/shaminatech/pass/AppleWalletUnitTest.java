package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEnums.CardStatus;
import com.shaminatech.pass.loyalty.wallet.apple.ApplePassMapper;
import com.shaminatech.pass.loyalty.wallet.apple.ApplePassMapper.PassData;
import com.shaminatech.pass.loyalty.wallet.apple.AppleWalletProperties;

/** Mapeamento do pass.json (estilo storeCard) e validação da configuração Apple — sem rede. */
class AppleWalletUnitTest {

    private static PassData data(ProgramType type, String balance, Integer stamps, CardStatus status) {
        return new PassData("stp123", "pass.test.x", "TESTTEAM12", "https://pass.example.test/api/public/apple-wallet",
                "a".repeat(64), "Café Central", "Clube Café", "#112233", "#FFFFFF", status, type, new BigDecimal(balance), stamps,
                "Ana", "1234-5678-9012-3456", "1234567890123456", Instant.parse("2026-12-31T03:00:00Z"), "31/12/2026 00:00",
                null, "Volte sempre", null, null, "cafe@example.test", null, "ShaminaTech", "suporte@example.test", null, null);
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> primary(Map<String, Object> pass) {
        return ((List<Map<String, Object>>) ((Map<String, Object>) pass.get("storeCard")).get("primaryFields")).get(0);
    }

    @Test
    void loyaltyTypesMapToTheBalanceField() {
        assertThat(primary(ApplePassMapper.passJson(data(ProgramType.POINTS, "150", null, CardStatus.ACTIVE))))
                .containsEntry("label", "PONTOS").containsEntry("value", 150);
        Map<String, Object> cashback = primary(ApplePassMapper.passJson(data(ProgramType.CASHBACK, "12.5", null, CardStatus.ACTIVE)));
        assertThat(cashback).containsEntry("label", "CASHBACK").containsEntry("currencyCode", "BRL")
                .containsEntry("value", new BigDecimal("12.50"));
        assertThat(primary(ApplePassMapper.passJson(data(ProgramType.STAMPS, "3", 10, CardStatus.ACTIVE))))
                .containsEntry("label", "CARIMBOS").containsEntry("value", "3 de 10");
        assertThat(primary(ApplePassMapper.passJson(data(ProgramType.VIP, "0", null, CardStatus.ACTIVE))))
                .containsEntry("label", "NÍVEL");
    }

    @Test
    void statesUseTheOfficialFields() {
        Map<String, Object> active = ApplePassMapper.passJson(data(ProgramType.POINTS, "1", null, CardStatus.ACTIVE));
        assertThat(active).containsEntry("backgroundColor", "rgb(17, 34, 51)").containsEntry("foregroundColor", "rgb(255, 255, 255)")
                .containsKey("expirationDate").doesNotContainKey("voided");
        assertThat(ApplePassMapper.passJson(data(ProgramType.POINTS, "1", null, CardStatus.SUSPENDED)))
                .containsKey("expirationDate").doesNotContainKey("voided");
        assertThat(ApplePassMapper.passJson(data(ProgramType.POINTS, "1", null, CardStatus.CANCELLED)))
                .containsEntry("voided", true).doesNotContainKey("expirationDate");
        assertThat(ApplePassMapper.passJson(data(ProgramType.STAMPS, "10", 10, CardStatus.COMPLETED))).containsEntry("voided", true);
        assertThat(ApplePassMapper.remoteState(CardStatus.SUSPENDED)).isEqualTo("BLOCKED");
        assertThat(ApplePassMapper.situation(CardStatus.SUSPENDED)).isEqualTo("Bloqueado");
    }

    @Test
    void configurationRequiresHttpsAndAllCredentials() {
        AppleWalletProperties empty = new AppleWalletProperties(true, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null, null);
        assertThat(empty.missing()).hasSize(7);
        AppleWalletProperties http = new AppleWalletProperties(true, "pass.x.y", "TESTTEAM12", "a.p12", "", "w.cer",
                "http://192.168.0.10:8083", false, "s".repeat(40), null, "ShaminaTech", "s@x.test", null, null, Duration.ofSeconds(1),
                null, null);
        assertThat(http.missing()).singleElement().asString().contains("HTTPS");
        assertThat(http.webServiceUrl()).isEqualTo("http://192.168.0.10:8083/api/public/apple-wallet");
    }
}
