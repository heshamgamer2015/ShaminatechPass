package com.shaminatech.pass;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;

/** Com a integração desligada (padrão), nada é enviado ao Google e o painel informa o que falta. */
class WalletNotConfiguredTest extends LoyaltyTestSupport {

    @Test
    void issuingIsRefusedAndStatusExplainsWhatIsMissing() throws Exception {
        long card = card(ownerA, a, consumer(ownerA, a, "Lia", "11966665555"), pointsProgram(a, ownerA, ""));
        postJson(ownerA, base(a) + "/cards/" + card + "/wallet/google/links", "{}").andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("WALLET_NOT_CONFIGURED"));
        mvc.perform(get(base(a) + "/wallet").session(ownerA)).andExpect(status().isOk())
                .andExpect(jsonPath("$.enabled").value(false)).andExpect(jsonPath("$.configured").value(false))
                .andExpect(jsonPath("$.missing.length()").value(org.hamcrest.Matchers.greaterThan(0)))
                .andExpect(jsonPath("$.apple.enabled").value(false)).andExpect(jsonPath("$.apple.configured").value(false))
                .andExpect(jsonPath("$.apple.missing.length()").value(org.hamcrest.Matchers.greaterThan(0)));
        mvc.perform(get("/api/public/wallet-links/" + "b".repeat(32))).andExpect(status().isNotFound());
        mvc.perform(get("/api/public/wallet-links/" + "b".repeat(32) + "/apple")).andExpect(status().isNotFound());
        // Web service da Apple desligado: não aceita registro nem entrega passe.
        mvc.perform(get("/api/public/apple-wallet/v1/passes/pass.x.y/stp1").header("Authorization", "ApplePass x"))
                .andExpect(status().isUnauthorized());
        // Endpoints do painel exigem login; os públicos não dão acesso a nada além do link.
        mvc.perform(get(base(a) + "/wallet")).andExpect(status().isUnauthorized());
        mvc.perform(get("/api/public/outra-coisa")).andExpect(status().isUnauthorized());
    }
}
