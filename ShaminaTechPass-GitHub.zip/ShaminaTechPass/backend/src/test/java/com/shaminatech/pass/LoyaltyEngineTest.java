package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;

import org.junit.jupiter.api.Test;

/** Motor de fidelidade: cálculos, resgates, idempotência, validade, expiração, cancelamento e estornos. */
class LoyaltyEngineTest extends LoyaltyTestSupport {

    // ---------------- Carimbos ----------------

    @Test
    void stampsCompleteRedeemAndRestart() throws Exception {
        long program = stampsProgram(a, ownerA, 5, true);
        long card = card(ownerA, a, consumer(ownerA, a, "Ana", "11988887777"), program);

        earn(ownerA, a, card, "{\"quantity\":3}", key()).andExpect(status().isCreated());
        earn(ownerA, a, card, "{\"quantity\":3}", key()).andExpect(status().isUnprocessableContent())
                .andExpect(jsonPath("$.code").value("TOO_MANY_STAMPS"));
        earn(ownerA, a, card, "{\"quantity\":2}", key()).andExpect(status().isCreated())
                .andExpect(jsonPath("$.card.rewardAvailable").value(true));
        earn(ownerA, a, card, "{}", key()).andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("CARD_FULL"));

        redeem(ownerA, a, card, "{}", key()).andExpect(status().isCreated())
                .andExpect(jsonPath("$.transaction.description").value("Um café grátis"))
                .andExpect(jsonPath("$.card.balance").value(0))
                .andExpect(jsonPath("$.card.completedCycles").value(1))
                .andExpect(jsonPath("$.card.status").value("ACTIVE"));
        earn(ownerA, a, card, "{}", key()).andExpect(status().isCreated()); // novo ciclo
    }

    @Test
    void stampsWithoutRestartCloseTheCard() throws Exception {
        long program = stampsProgram(a, ownerA, 2, false);
        long card = card(ownerA, a, consumer(ownerA, a, "Bia", "11988887766"), program);
        earn(ownerA, a, card, "{\"quantity\":2}", key()).andExpect(status().isCreated());
        redeem(ownerA, a, card, "{}", key()).andExpect(status().isCreated()).andExpect(jsonPath("$.card.status").value("COMPLETED"));
        earn(ownerA, a, card, "{}", key()).andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("CARD_COMPLETED"));
    }

    @Test
    void redeemingAnIncompleteStampCardIsRejected() throws Exception {
        long card = card(ownerA, a, consumer(ownerA, a, "Caio", "11988887755"), stampsProgram(a, ownerA, 4, true));
        earn(ownerA, a, card, "{}", key()).andExpect(status().isCreated());
        redeem(ownerA, a, card, "{}", key()).andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("INSUFFICIENT_BALANCE"));
    }

    // ---------------- Pontos ----------------

    @Test
    void pointsUseConfiguredRoundingAndMinimum() throws Exception {
        long down = pointsProgram(a, ownerA, ",\"rounding\":\"DOWN\",\"minPurchaseAmount\":5.00");
        long consumer = consumer(ownerA, a, "Davi", "11988887744");
        long card = card(ownerA, a, consumer, down);
        earn(ownerA, a, card, "{\"purchaseAmount\":10.99}", key()).andExpect(status().isCreated())
                .andExpect(jsonPath("$.transaction.amount").value(10));
        earn(ownerA, a, card, "{\"purchaseAmount\":4.99}", key()).andExpect(status().isUnprocessableContent())
                .andExpect(jsonPath("$.code").value("BELOW_MINIMUM"));
        earn(ownerA, a, card, "{}", key()).andExpect(status().isBadRequest());
        earn(ownerA, a, card, "{\"purchaseAmount\":1.005}", key()).andExpect(status().isBadRequest());

        long halfUp = program(ownerA, a, "{\"type\":\"POINTS\",\"name\":\"Dobro\"," + COMMON
                + ",\"pointsPerUnit\":2,\"spendUnit\":5.00,\"rounding\":\"HALF_UP\"}");
        long card2 = card(ownerA, a, consumer, halfUp);
        // 13,75 / 5 = 2,75 unidades × 2 = 5,5 pontos → HALF_UP = 6
        earn(ownerA, a, card2, "{\"purchaseAmount\":13.75}", key()).andExpect(jsonPath("$.transaction.amount").value(6));
    }

    @Test
    void pointsRedeemRewardsFromTheSameProgramOnly() throws Exception {
        long program = pointsProgram(a, ownerA, "");
        long other = pointsProgram(a, ownerA, "");
        long reward = id(postJson(ownerA, base(a) + "/programs/" + program + "/rewards", "{\"name\":\"Sobremesa\",\"cost\":15}")
                .andExpect(status().isCreated()));
        long foreignReward = id(postJson(ownerA, base(a) + "/programs/" + other + "/rewards", "{\"name\":\"X\",\"cost\":1}"));
        long card = card(ownerA, a, consumer(ownerA, a, "Eva", "11988887733"), program);

        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key());
        redeem(ownerA, a, card, "{\"rewardId\":" + reward + "}", key()).andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("INSUFFICIENT_BALANCE"));
        redeem(ownerA, a, card, "{\"rewardId\":" + foreignReward + "}", key()).andExpect(status().isNotFound());
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key());
        redeem(ownerA, a, card, "{\"rewardId\":" + reward + "}", key()).andExpect(status().isCreated())
                .andExpect(jsonPath("$.transaction.amount").value(-15))
                .andExpect(jsonPath("$.card.balance").value(5));
    }

    // ---------------- Cashback ----------------

    @Test
    void cashbackIsExactWithBigDecimal() throws Exception {
        long program = program(ownerA, a, "{\"type\":\"CASHBACK\",\"name\":\"Volta\"," + COMMON
                + ",\"cashbackPercent\":3.5,\"rounding\":\"DOWN\",\"maxCreditPerPurchase\":5.00,\"maxRedeemPercent\":50}");
        long card = card(ownerA, a, consumer(ownerA, a, "Fábio", "11988887722"), program);
        // 19,99 × 3,5% = 0,69965 → DOWN = 0,69
        earn(ownerA, a, card, "{\"purchaseAmount\":19.99}", key()).andExpect(jsonPath("$.transaction.amount").value(0.69));
        // 1000 × 3,5% = 35,00 → limitado a 5,00
        earn(ownerA, a, card, "{\"purchaseAmount\":1000.00}", key()).andExpect(jsonPath("$.transaction.amount").value(5.0));
        for (int i = 0; i < 3; i++) {
            earn(ownerA, a, card, "{\"purchaseAmount\":2.86}", key()); // 0,1001 → 0,10
        }
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo("5.99");
        // usa no máximo 50% de uma compra de R$ 1,00
        redeem(ownerA, a, card, "{\"amount\":0.60,\"purchaseAmount\":1.00}", key()).andExpect(status().isUnprocessableContent())
                .andExpect(jsonPath("$.code").value("ABOVE_MAX_REDEEM"));
        redeem(ownerA, a, card, "{\"amount\":0.50,\"purchaseAmount\":1.00}", key()).andExpect(status().isCreated());
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo(new BigDecimal("5.49"));
    }

    // ---------------- Idempotência ----------------

    @Test
    void repeatedRequestIsNotCreditedTwiceNorRenewsValidity() throws Exception {
        long card = card(ownerA, a, consumer(ownerA, a, "Gil", "11988887711"), pointsProgram(a, ownerA, ""));
        String k = key();
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", k).andExpect(status().isCreated());
        String expiresAfterFirst = cardField(ownerA, a, card, "expiresAt");

        clock.advance(Duration.ofDays(3));
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", k).andExpect(status().isOk())
                .andExpect(jsonPath("$.replayed").value(true));
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo("10");
        assertThat(countTransactions(card, "EARN")).isEqualTo(1);
        assertThat(cardField(ownerA, a, card, "expiresAt")).isEqualTo(expiresAfterFirst);

        earn(ownerA, a, card, "{\"purchaseAmount\":99.00}", k).andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("IDEMPOTENCY_CONFLICT"));
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", null).andExpect(status().isBadRequest());
    }

    // ---------------- Validade por inatividade ----------------

    @Test
    void validityIsRenewedOnlyByLegitimateMovements() throws Exception {
        // 05/11/2026 12:00 (São Paulo), prazo de 30 dias, válido até o fim do dia.
        long program = pointsProgram(a, ownerA, ",\"minPurchaseAmount\":5.00");
        long card = card(ownerA, a, consumer(ownerA, a, "Hugo", "11988887700"), program);
        assertThat(cardField(ownerA, a, card, "validUntil")).isEqualTo("2026-12-05T23:59:59");

        clock.set(Instant.parse("2026-11-15T13:00:00Z"));
        earn(ownerA, a, card, "{\"purchaseAmount\":20.00}", key()).andExpect(status().isCreated());
        assertThat(cardField(ownerA, a, card, "validUntil")).isEqualTo("2026-12-15T23:59:59");

        clock.set(Instant.parse("2026-11-28T22:00:00Z"));
        earn(ownerA, a, card, "{\"purchaseAmount\":20.00}", key());
        assertThat(cardField(ownerA, a, card, "validUntil")).isEqualTo("2026-12-28T23:59:59");

        // Operação recusada, consulta e leitura do QR não renovam.
        clock.set(Instant.parse("2026-12-10T12:00:00Z"));
        earn(ownerA, a, card, "{\"purchaseAmount\":1.00}", key()).andExpect(status().isUnprocessableContent());
        String code = cardField(ownerA, a, card, "code");
        getJson(ownerA, base(a) + "/cards/lookup?code=" + code);
        getJson(ownerA, base(a) + "/cards/" + card + "/transactions");
        assertThat(cardField(ownerA, a, card, "validUntil")).isEqualTo("2026-12-28T23:59:59");
    }

    @Test
    void endOfDayUsesTheEstablishmentTimeZone() throws Exception {
        long card = card(ownerA, a, consumer(ownerA, a, "Íris", "11988886699"), pointsProgram(a, ownerA, ""));
        // 02:30 UTC de 16/11 ainda é 15/11 (23:30) em São Paulo → vale até 15/12 23:59:59 local.
        clock.set(Instant.parse("2026-11-16T02:30:00Z"));
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key());
        assertThat(cardField(ownerA, a, card, "validUntil")).isEqualTo("2026-12-15T23:59:59");
        assertThat(cardField(ownerA, a, card, "expiresAt")).isEqualTo("2026-12-16T03:00:00Z");
    }

    @Test
    void exactTimeModeExpiresAtTheSameHour() throws Exception {
        long program = program(ownerA, a, "{\"type\":\"STAMPS\",\"name\":\"Exato\",\"inactivityDays\":15,"
                + "\"validityMode\":\"EXACT_TIME\",\"expiredBalancePolicy\":\"KEEP\",\"reversalPolicy\":\"REQUIRE_BALANCE\","
                + "\"stampsRequired\":10,\"stampCriterion\":\"VISIT\",\"stampReward\":\"Brinde\"}");
        long card = card(ownerA, a, consumer(ownerA, a, "Jade", "11988886688"), program);
        assertThat(cardField(ownerA, a, card, "expiresAt")).isEqualTo("2026-11-20T15:00:00Z");
    }

    // ---------------- Expiração ----------------

    @Test
    void expiredCardIsRejectedProcessedOnceAndCanBeReactivatedKeepingBalance() throws Exception {
        long card = card(ownerA, a, consumer(ownerA, a, "Kátia", "11988886677"), pointsProgram(a, ownerA, ""));
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key());

        clock.set(Instant.parse("2026-12-06T03:00:00Z")); // 06/12 00:00 em São Paulo: venceu
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key()).andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("CARD_EXPIRED"));
        assertThat(cardField(ownerA, a, card, "status")).isEqualTo("EXPIRED");
        assertThat(cardField(ownerA, a, card, "storedStatus")).isEqualTo("ACTIVE");

        assertThat(expiration.run().cardsExpired()).isEqualTo(1);
        assertThat(expiration.run().cardsExpired()).isZero(); // idempotente
        assertThat(countTransactions(card, "CARD_EXPIRED")).isEqualTo(1);
        assertThat(cardField(ownerA, a, card, "storedStatus")).isEqualTo("EXPIRED");
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo("10"); // KEEP: saldo congelado

        postJson(ownerA, base(a) + "/cards/" + card + "/reactivate", "{\"reason\":\"Cliente voltou\"}")
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("ACTIVE"))
                .andExpect(jsonPath("$.validUntil").value("2027-01-05T23:59:59"))
                .andExpect(jsonPath("$.availableBalance").value(10));
    }

    @Test
    void forfeitPolicyZeroesTheBalanceWithACompensatingRecord() throws Exception {
        long program = program(ownerA, a, "{\"type\":\"POINTS\",\"name\":\"Perde\",\"inactivityDays\":30,"
                + "\"validityMode\":\"END_OF_DAY\",\"expiredBalancePolicy\":\"FORFEIT\",\"reversalPolicy\":\"REQUIRE_BALANCE\","
                + "\"pointsPerUnit\":1,\"spendUnit\":1.00}");
        long card = card(ownerA, a, consumer(ownerA, a, "Leo", "11988886666"), program);
        earn(ownerA, a, card, "{\"purchaseAmount\":25.00}", key());
        clock.advance(Duration.ofDays(31));
        expiration.run();
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo("0");
        assertThat(countTransactions(card, "BALANCE_FORFEITED")).isEqualTo(1);
        assertThat(jdbc.queryForObject("select amount from card_transaction where card_id = ? and type = 'BALANCE_FORFEITED'",
                BigDecimal.class, card)).isEqualByComparingTo("-25");
    }

    @Test
    void benefitValidityIsIndependentFromCardValidity() throws Exception {
        long program = pointsProgram(a, ownerA, ",\"benefitValidityDays\":10");
        long reward = id(postJson(ownerA, base(a) + "/programs/" + program + "/rewards", "{\"name\":\"Brinde\",\"cost\":5}"));
        long card = card(ownerA, a, consumer(ownerA, a, "Mia", "11988886655"), program);
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key());

        clock.advance(Duration.ofDays(11));
        assertThat(cardField(ownerA, a, card, "status")).isEqualTo("ACTIVE");
        assertThat(cardField(ownerA, a, card, "availableBalance")).isEqualTo("0");
        redeem(ownerA, a, card, "{\"rewardId\":" + reward + "}", key()).andExpect(status().isConflict());

        assertThat(expiration.run().cardsWithExpiredBenefits()).isEqualTo(1);
        assertThat(expiration.run().cardsWithExpiredBenefits()).isZero();
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo("0");
        assertThat(countTransactions(card, "BENEFIT_EXPIRED")).isEqualTo(1);
        assertThat(cardField(ownerA, a, card, "status")).isEqualTo("ACTIVE");
    }

    // ---------------- Cancelamento ----------------

    @Test
    void cancelledCardAcceptsNoFurtherMovements() throws Exception {
        long card = card(ownerA, a, consumer(ownerA, a, "Nina", "11988886644"), pointsProgram(a, ownerA, ""));
        long tx = ((Number) read(earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key()), "$.transaction.id")).longValue();
        postJson(ownerA, base(a) + "/cards/" + card + "/cancel", "{}").andExpect(status().isBadRequest()); // exige motivo
        postJson(ownerA, base(a) + "/cards/" + card + "/cancel", "{\"reason\":\"Cartão perdido\"}").andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("CANCELLED"));

        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key()).andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("CARD_CANCELLED"));
        redeem(ownerA, a, card, "{\"rewardId\":1}", key()).andExpect(status().isConflict());
        postJson(ownerA, base(a) + "/cards/" + card + "/reactivate", "{}").andExpect(status().isConflict());
        postJson(ownerA, base(a) + "/transactions/" + tx + "/reverse", "{\"reason\":\"x\"}", key()).andExpect(status().isConflict());
        assertThat(jdbc.queryForObject("select count(*) from loyalty_card where id = ?", Integer.class, card)).isEqualTo(1);
    }

    @Test
    void suspendedCardIsBlockedUntilReactivatedWithoutRenewal() throws Exception {
        long card = card(ownerA, a, consumer(ownerA, a, "Otto", "11988886633"), pointsProgram(a, ownerA, ""));
        String expires = cardField(ownerA, a, card, "expiresAt");
        postJson(ownerA, base(a) + "/cards/" + card + "/suspend", "{\"reason\":\"Conferência\"}").andExpect(status().isOk());
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00}", key()).andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("CARD_SUSPENDED"));
        clock.advance(Duration.ofDays(2));
        postJson(ownerA, base(a) + "/cards/" + card + "/reactivate", "{}").andExpect(status().isOk());
        assertThat(cardField(ownerA, a, card, "expiresAt")).isEqualTo(expires);
    }

    // ---------------- Estornos ----------------

    @Test
    void reversalRespectsTheProgramPolicy() throws Exception {
        long strict = pointsProgram(a, ownerA, "");
        long reward = id(postJson(ownerA, base(a) + "/programs/" + strict + "/rewards", "{\"name\":\"Brinde\",\"cost\":15}"));
        long consumer = consumer(ownerA, a, "Pia", "11988886622");
        long card = card(ownerA, a, consumer, strict);
        long earnTx = ((Number) read(earn(ownerA, a, card, "{\"purchaseAmount\":20.00}", key()), "$.transaction.id")).longValue();
        long redeemTx = ((Number) read(redeem(ownerA, a, card, "{\"rewardId\":" + reward + "}", key()), "$.transaction.id")).longValue();

        postJson(ownerA, base(a) + "/transactions/" + earnTx + "/reverse", "{\"reason\":\"Compra cancelada\"}", key())
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("INSUFFICIENT_BALANCE_FOR_REVERSAL"));
        assertThat(balance(ownerA, a, card)).isEqualByComparingTo("5");

        // Estornar o resgate devolve os pontos aos mesmos lotes.
        String expires = cardField(ownerA, a, card, "expiresAt");
        clock.advance(Duration.ofDays(1));
        postJson(ownerA, base(a) + "/transactions/" + redeemTx + "/reverse", "{\"reason\":\"Resgate indevido\"}", key())
                .andExpect(status().isCreated()).andExpect(jsonPath("$.card.balance").value(20));
        assertThat(cardField(ownerA, a, card, "expiresAt")).isEqualTo(expires); // estorno não renova
        postJson(ownerA, base(a) + "/transactions/" + redeemTx + "/reverse", "{\"reason\":\"de novo\"}", key())
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("ALREADY_REVERSED"));

        postJson(ownerA, base(a) + "/transactions/" + earnTx + "/reverse", "{\"reason\":\"Compra cancelada\"}", key())
                .andExpect(status().isCreated()).andExpect(jsonPath("$.card.balance").value(0));
        assertThat(countTransactions(card, "EARN")).isEqualTo(1); // original preservado (imutável)
        assertThat(countTransactions(card, "REVERSAL")).isEqualTo(2);
    }

    @Test
    void allowNegativeReversalIsCompensatedByLaterEarnings() throws Exception {
        long program = program(ownerA, a, "{\"type\":\"POINTS\",\"name\":\"Flex\",\"inactivityDays\":30,"
                + "\"validityMode\":\"END_OF_DAY\",\"expiredBalancePolicy\":\"KEEP\",\"reversalPolicy\":\"ALLOW_NEGATIVE\","
                + "\"pointsPerUnit\":1,\"spendUnit\":1.00}");
        long reward = id(postJson(ownerA, base(a) + "/programs/" + program + "/rewards", "{\"name\":\"Brinde\",\"cost\":15}"));
        long card = card(ownerA, a, consumer(ownerA, a, "Rui", "11988886611"), program);
        long earnTx = ((Number) read(earn(ownerA, a, card, "{\"purchaseAmount\":20.00}", key()), "$.transaction.id")).longValue();
        redeem(ownerA, a, card, "{\"rewardId\":" + reward + "}", key());
        postJson(ownerA, base(a) + "/transactions/" + earnTx + "/reverse", "{\"reason\":\"Compra cancelada\"}", key())
                .andExpect(status().isCreated()).andExpect(jsonPath("$.card.balance").value(-15));
        earn(ownerA, a, card, "{\"purchaseAmount\":20.00}", key()).andExpect(jsonPath("$.card.balance").value(5))
                .andExpect(jsonPath("$.card.availableBalance").value(5));
    }

    // ---------------- Canais e modo leitura ----------------

    @Test
    void qrLookupIdentifiesOnlyCardsOfTheSameEstablishment() throws Exception {
        long card = card(ownerA, a, consumer(ownerA, a, "Sol", "11988886600"), pointsProgram(a, ownerA, ""));
        String display = cardField(ownerA, a, card, "displayCode");
        getJson(ownerA, base(a) + "/cards/lookup?code=" + display.toLowerCase());
        mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get(base(b) + "/cards/lookup")
                .param("code", display).session(ownerB)).andExpect(status().isNotFound());
        mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get(base(a) + "/cards/lookup")
                .param("code", "invalido").session(ownerA)).andExpect(status().isBadRequest());

        earn(ownerA, a, card, "{\"purchaseAmount\":10.00,\"channel\":\"QR_CODE\"}", key()).andExpect(status().isCreated())
                .andExpect(jsonPath("$.transaction.channel").value("QR_CODE"));
        earn(ownerA, a, card, "{\"purchaseAmount\":10.00,\"channel\":\"NFC\"}", key()).andExpect(status().isBadRequest());
    }

    @Test
    void cardsOfAnotherEstablishmentAreInvisible() throws Exception {
        long cardA = card(ownerA, a, consumer(ownerA, a, "Téo", "11988885599"), pointsProgram(a, ownerA, ""));
        long txA = ((Number) read(earn(ownerA, a, cardA, "{\"purchaseAmount\":10.00}", key()), "$.transaction.id")).longValue();
        // Conta de B usando o próprio caminho com ids de A: não encontrado.
        mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get(base(b) + "/cards/" + cardA)
                .session(ownerB)).andExpect(status().isNotFound());
        earn(ownerB, b, cardA, "{\"purchaseAmount\":10.00}", key()).andExpect(status().isNotFound());
        postJson(ownerB, base(b) + "/transactions/" + txA + "/reverse", "{\"reason\":\"x\"}", key()).andExpect(status().isNotFound());
        // Caminho de A com a sessão de B: proibido.
        earn(ownerB, a, cardA, "{\"purchaseAmount\":10.00}", key()).andExpect(status().isForbidden());
        assertThat(balance(ownerA, a, cardA)).isEqualByComparingTo("10");
    }
}
