package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.ByteArrayInputStream;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoVerifierBuilder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import com.jayway.jsonpath.JsonPath;

import tools.jackson.databind.json.JsonMapper;

/**
 * Página de homologação Apple Wallet (perfil local): acesso só do administrador da plataforma, link público com token
 * temporário, cabeçalhos do .pkpass e nenhuma exposição de credenciais. Usa o certificado de teste {@link FakeApple}.
 */
@ActiveProfiles("local")
class AppleHomologationEndpointTest extends LoyaltyTestSupport {

    private static final String ADMIN = "/api/admin/apple-wallet/homologation";
    private static final String PUBLIC = "/api/public/apple-wallet-homologation/";

    @DynamicPropertySource
    static void apple(DynamicPropertyRegistry registry) {
        FakeApple fake = FakeApple.get();
        // Fluxo normal desligado e sem HTTPS público: só o modo offline de homologação fica disponível.
        registry.add("shaminatech.wallet.apple.pass-type-identifier", () -> FakeApple.PASS_TYPE_ID);
        registry.add("shaminatech.wallet.apple.team-identifier", () -> FakeApple.TEAM_ID);
        registry.add("shaminatech.wallet.apple.certificate-file", () -> fake.p12().toString());
        registry.add("shaminatech.wallet.apple.certificate-password", () -> FakeApple.P12_PASSWORD);
        registry.add("shaminatech.wallet.apple.wwdr-certificate-file", () -> fake.wwdrFile().toString());
        registry.add("shaminatech.wallet.apple.support-name", () -> "ShaminaTech");
        registry.add("shaminatech.wallet.apple.support-email", () -> "shaminatech@gmail.com");
        registry.add("shaminatech.wallet.apple.homologation.output-dir", () -> "");
    }

    private final JsonMapper json = JsonMapper.builder().build();
    private MockHttpSession admin;

    @BeforeEach
    void admin() throws Exception {
        platformAdmin("admin@teste.local");
        admin = login("admin@teste.local");
    }

    private String generate() throws Exception {
        String body = mvc.perform(post(ADMIN + "/passes").session(admin).with(csrf()))
                .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString();
        assertThat(body).doesNotContain(FakeApple.P12_PASSWORD);
        return JsonPath.read(body, "$.token");
    }

    @Test
    void onlyThePlatformAdminReachesTheHomologationPage() throws Exception {
        mvc.perform(get(ADMIN)).andExpect(status().isUnauthorized());
        mvc.perform(post(ADMIN + "/passes").with(csrf())).andExpect(status().isUnauthorized());
        mvc.perform(get(ADMIN).session(ownerA)).andExpect(status().isForbidden());
        mvc.perform(post(ADMIN + "/passes").session(ownerA).with(csrf())).andExpect(status().isForbidden());
        mvc.perform(post(ADMIN + "/passes").session(admin)).andExpect(status().isForbidden()); // sem CSRF

        String status = mvc.perform(get(ADMIN).session(admin)).andExpect(status().isOk())
                .andExpect(header().string("Cache-Control", "no-store")).andReturn().getResponse().getContentAsString();
        assertThat((Boolean) JsonPath.read(status, "$.ready")).isTrue();
        assertThat((String) JsonPath.read(status, "$.certificate.passTypeIdentifier")).isEqualTo(FakeApple.PASS_TYPE_ID);
        assertThat((String) JsonPath.read(status, "$.certificate.teamIdentifier")).isEqualTo(FakeApple.TEAM_ID);
        assertThat((Boolean) JsonPath.read(status, "$.updatablePassesConfigured")).isFalse();
        assertThat((Integer) JsonPath.read(status, "$.linkTtlMinutes")).isEqualTo(15);
        assertThat(status).doesNotContain(FakeApple.P12_PASSWORD).doesNotContain(".p12").doesNotContain("wwdr");
    }

    @Test
    @SuppressWarnings("unchecked")
    void theTokenDeliversTheSignedPassWithTheAppleHeadersAndIsNotConsumed() throws Exception {
        String token = generate();
        assertThat(token).matches("[A-Za-z0-9_-]{43}");
        for (int i = 0; i < 3; i++) { // o iPhone pode repetir a requisição
            byte[] pkpass = mvc.perform(get(PUBLIC + token)).andExpect(status().isOk())
                    .andExpect(header().string("Content-Type", "application/vnd.apple.pkpass"))
                    .andExpect(header().string("Content-Disposition", "attachment; filename=\"shaminatech-pass-demonstracao.pkpass\""))
                    .andExpect(header().string("Cache-Control", "no-store"))
                    .andExpect(header().string("X-Content-Type-Options", "nosniff"))
                    .andReturn().getResponse().getContentAsByteArray();
            Map<String, byte[]> files = unzip(pkpass);
            assertThat(files).containsKeys("pass.json", "manifest.json", "signature", "icon.png", "logo.png");
            Map<String, Object> pass = json.readValue(files.get("pass.json"), Map.class);
            assertThat(pass).containsEntry("passTypeIdentifier", FakeApple.PASS_TYPE_ID).containsEntry("teamIdentifier", FakeApple.TEAM_ID)
                    .containsEntry("organizationName", "ShaminaTech Pass").containsEntry("backgroundColor", "rgb(244, 63, 94)")
                    .doesNotContainKey("webServiceURL").doesNotContainKey("authenticationToken");
            CMSSignedData signed = new CMSSignedData(new CMSProcessableByteArray(files.get("manifest.json")), files.get("signature"));
            SignerInformation signer = signed.getSignerInfos().getSigners().iterator().next();
            assertThat(signer.verify(new JcaSimpleSignerInfoVerifierBuilder().build(FakeApple.get().leaf()))).isTrue();
            assertThat(new String(pkpass, java.nio.charset.StandardCharsets.ISO_8859_1)).doesNotContain(FakeApple.P12_PASSWORD)
                    .doesNotContain("PRIVATE KEY");
        }
    }

    @Test
    void invalidExpiredAndForeignTokensNeverDeliverAFile() throws Exception {
        String token = generate();
        mvc.perform(get(PUBLIC + "abc")).andExpect(status().isNotFound());
        mvc.perform(get(PUBLIC + "A".repeat(43))).andExpect(status().isNotFound());
        mvc.perform(get(PUBLIC + token.substring(1) + "x")).andExpect(status().isNotFound());
        for (String probe : new String[] {"..%2F..%2Fcredenciais%2Fshaminatech-pass.p12", "shaminatech-pass.p12", "p12-password.txt"}) {
            int code = mvc.perform(get(PUBLIC + probe)).andReturn().getResponse().getStatus();
            assertThat(code).as(probe).isBetween(400, 404);
        }
        mvc.perform(get("/api/public/apple-wallet-homologation")).andExpect(r -> assertThat(r.getResponse().getStatus()).isGreaterThanOrEqualTo(400));

        clock.advance(Duration.ofMinutes(15));
        String body = mvc.perform(get(PUBLIC + token)).andExpect(status().isGone())
                .andExpect(header().string("Content-Type", "text/plain;charset=UTF-8"))
                .andReturn().getResponse().getContentAsString(java.nio.charset.StandardCharsets.UTF_8);
        assertThat(body).contains("expirou");
    }

    @Test
    void theQrCodeOnlyEncodesTheLanAddressOfAnActiveLink() throws Exception {
        String token = generate();
        String lan = "http://192.168.0.4:4203" + PUBLIC + token;
        String svg = mvc.perform(get(ADMIN + "/qr").param("url", lan).session(admin)).andExpect(status().isOk())
                .andExpect(header().string("Content-Type", "image/svg+xml")).andReturn().getResponse().getContentAsString();
        assertThat(svg).startsWith("<svg");
        mvc.perform(get(ADMIN + "/qr").param("url", lan)).andExpect(status().isUnauthorized());
        for (String bad : new String[] {"http://localhost:4203" + PUBLIC + token, "http://127.0.0.1:4203" + PUBLIC + token,
                "http://192.168.0.4:4203" + PUBLIC + "A".repeat(43), "http://192.168.0.4:4203/api/admin/users",
                "javascript:alert(1)", "http://user:pw@192.168.0.4:4203" + PUBLIC + token, lan + "?x=1"}) {
            mvc.perform(get(ADMIN + "/qr").param("url", bad).session(admin)).andExpect(status().isBadRequest());
        }
        clock.advance(Duration.ofMinutes(16));
        mvc.perform(get(ADMIN + "/qr").param("url", lan).session(admin)).andExpect(status().isBadRequest());
    }

    @Test
    void theUpdatableAppleFlowStaysUnavailable() throws Exception {
        generate();
        // A homologação não cria passes no banco nem habilita o Apple Wallet para os consumidores.
        assertThat(jdbc.queryForObject("select count(*) from wallet_pass", Integer.class)).isZero();
        String wallet = mvc.perform(get("/api/admin/apple-wallet/homologation").session(admin)).andReturn().getResponse().getContentAsString();
        assertThat((Boolean) JsonPath.read(wallet, "$.updatablePassesConfigured")).isFalse();
    }

    private static Map<String, byte[]> unzip(byte[] data) throws Exception {
        Map<String, byte[]> files = new LinkedHashMap<>();
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(data))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                files.put(entry.getName(), zip.readAllBytes());
            }
        }
        return files;
    }
}
