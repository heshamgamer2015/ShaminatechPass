package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Etapa 8 — verificação de integridade dos dados EXISTENTES no PostgreSQL local, somente leitura.
 * A conexão JDBC é aberta em modo read-only (o próprio PostgreSQL recusa qualquer escrita); não há contexto Spring.
 * As mesmas consultas servem de verificação pós-restauração de backup (docs/seguranca-operacao.md).
 * <pre>mvn test -Dtest=PostgresIntegrityIT -Dpass.pg-it=true</pre>
 */
@EnabledIfSystemProperty(named = "pass.pg-it", matches = "true")
class PostgresIntegrityIT {

    /** Cada consulta conta linhas INCONSISTENTES; o esperado é zero em todas. */
    static final Map<String, String> CHECKS = new LinkedHashMap<>();
    static {
        CHECKS.put("saldo do cartão diferente da soma dos lotes restantes",
                "select count(*) from loyalty_card c where c.balance <> coalesce((select sum(l.remaining) from benefit_lot l where l.card_id = c.id), 0)");
        CHECKS.put("saldo do cartão diferente do saldo após a última movimentação",
                "select count(*) from loyalty_card c where exists (select 1 from card_transaction t where t.card_id = c.id) and c.balance <> "
                        + "(select t.balance_after from card_transaction t where t.card_id = c.id order by t.id desc limit 1)");
        CHECKS.put("saldo negativo", "select count(*) from loyalty_card where balance < 0");
        CHECKS.put("lote com restante negativo ou maior que o original",
                "select count(*) from benefit_lot where remaining < 0 or remaining > original_amount");
        CHECKS.put("cartão de outra empresa que a do cliente",
                "select count(*) from loyalty_card c join consumer k on k.id = c.consumer_id where c.establishment_id <> k.establishment_id");
        CHECKS.put("cartão de outra empresa que a do programa",
                "select count(*) from loyalty_card c join loyalty_program p on p.id = c.program_id where c.establishment_id <> p.establishment_id");
        CHECKS.put("movimentação de outra empresa que a do cartão",
                "select count(*) from card_transaction t join loyalty_card c on c.id = t.card_id where t.establishment_id <> c.establishment_id");
        CHECKS.put("lote de outra empresa que a do cartão",
                "select count(*) from benefit_lot l join loyalty_card c on c.id = l.card_id where l.establishment_id <> c.establishment_id");
        CHECKS.put("recompensa de programa inexistente",
                "select count(*) from loyalty_reward r where not exists (select 1 from loyalty_program p where p.id = r.program_id)");
        CHECKS.put("estorno duplicado da mesma movimentação",
                "select count(*) from (select reverses_id from card_transaction where reverses_id is not null group by reverses_id having count(*) > 1) d");
        CHECKS.put("passe de carteira de cartão inexistente",
                "select count(*) from wallet_pass w where not exists (select 1 from loyalty_card c where c.id = w.card_id)");
        CHECKS.put("clientes ativos acima do limite (informativo: redução de limite preserva clientes)", null);
    }

    @Test
    void existingDataIsConsistent() throws Exception {
        // Sem contexto Spring (nenhum inicializador roda): só uma conexão JDBC somente leitura ao banco local.
        java.util.Properties p = new java.util.Properties();
        var credentials = new org.springframework.core.io.ClassPathResource("application-credentials.yml");
        if (credentials.exists()) {
            var yaml = new org.springframework.beans.factory.config.YamlPropertiesFactoryBean();
            yaml.setResources(credentials);
            p = yaml.getObject();
        }
        String url = System.getenv().getOrDefault("DB_URL", p.getProperty("spring.datasource.url", "jdbc:postgresql://localhost:5432/shaminatech_pass"));
        String user = System.getenv().getOrDefault("DB_USERNAME", p.getProperty("spring.datasource.username", "postgres"));
        String password = System.getenv().getOrDefault("DB_PASSWORD", p.getProperty("spring.datasource.password", ""));
        java.sql.Connection connection = java.sql.DriverManager.getConnection(url, user, password);
        connection.setReadOnly(true);
        try (var st = connection.createStatement()) {
            // Em autocommit, o driver só aplica read-only dentro de transação; fixa no nível da sessão.
            st.execute("SET SESSION CHARACTERISTICS AS TRANSACTION READ ONLY");
        }
        JdbcTemplate jdbc = new JdbcTemplate(new org.springframework.jdbc.datasource.SingleConnectionDataSource(connection, true));
        try {
            check(jdbc);
        } finally {
            connection.close();
        }
    }

    private void check(JdbcTemplate jdbc) {
        assertThat(jdbc.queryForObject("show transaction_read_only", String.class)).isEqualTo("on");
        Map<String, Integer> problems = new LinkedHashMap<>();
        CHECKS.forEach((name, sql) -> {
            if (sql == null) return;
            Integer n = jdbc.queryForObject(sql, Integer.class);
            System.out.println("[INTEGRIDADE] " + name + ": " + n);
            if (n != null && n > 0) problems.put(name, n);
        });
        List<Map<String, Object>> overLimit = jdbc.queryForList("select e.id, count(k.id) as ativos, p.max_active_consumers as limite "
                + "from establishment e join establishment_policy p on p.establishment_id = e.id "
                + "left join consumer k on k.establishment_id = e.id and k.status = 'ACTIVE' "
                + "group by e.id, p.max_active_consumers having count(k.id) > p.max_active_consumers");
        System.out.println("[INTEGRIDADE] estabelecimentos acima do limite (permitido após redução; novos cadastros bloqueados): " + overLimit.size());
        System.out.println("[INTEGRIDADE] cartões verificados: " + jdbc.queryForObject("select count(*) from loyalty_card", Integer.class)
                + ", movimentações: " + jdbc.queryForObject("select count(*) from card_transaction", Integer.class));
        Integer leftovers = jdbc.queryForObject(
                "select count(*) from information_schema.schemata where schema_name like 'stpass_it_%'", Integer.class);
        System.out.println("[INTEGRIDADE] esquemas descartáveis de teste remanescentes: " + leftovers);
        assertThat(leftovers).as("esquemas de teste não removidos").isZero();
        assertThat(problems).as("inconsistências nos dados existentes").isEmpty();
    }
}
