package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import org.junit.jupiter.api.Test;
import org.springframework.test.context.TestPropertySource;

/** Limite de requisições por IP nos endpoints públicos (dificulta adivinhar tokens de link). */
@TestPropertySource(properties = "shaminatech.public.rate-limit-per-minute=5")
class PublicRateLimitTest extends IntegrationTestSupport {

    @Test
    void publicEndpointsAreRateLimitedPerClient() throws Exception {
        int limited = 0;
        for (int i = 0; i < 8; i++) {
            int code = mvc.perform(get("/api/public/wallet-links/" + "c".repeat(32))).andReturn().getResponse().getStatus();
            if (code == 429) {
                limited++;
            }
        }
        assertThat(limited).isEqualTo(3);
        // O limite não afeta o restante da API.
        assertThat(mvc.perform(get("/api/health")).andReturn().getResponse().getStatus()).isEqualTo(200);
    }
}
