package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.Clock;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.TestPropertySource;

import com.shaminatech.pass.common.error.ApiException;
import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.establishment.EstablishmentRepository;
import com.shaminatech.pass.loyalty.LoyaltyDtos.ConsumerRequest;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.CardEngine;
import com.shaminatech.pass.loyalty.card.CardEnums.Channel;
import com.shaminatech.pass.loyalty.card.LoyaltyCard;
import com.shaminatech.pass.loyalty.card.LoyaltyCardRepository;
import com.shaminatech.pass.loyalty.consumer.Consumer;
import com.shaminatech.pass.loyalty.consumer.ConsumerRepository;
import com.shaminatech.pass.loyalty.consumer.ConsumerService;
import com.shaminatech.pass.loyalty.policy.EstablishmentPolicyRepository;
import com.shaminatech.pass.loyalty.policy.PolicyService;
import com.shaminatech.pass.loyalty.program.LoyaltyProgram;
import com.shaminatech.pass.loyalty.program.LoyaltyProgramRepository;
import com.shaminatech.pass.membership.Membership;
import com.shaminatech.pass.membership.MembershipRepository;
import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.security.AuthenticatedUser;
import com.shaminatech.pass.user.AppUser;
import com.shaminatech.pass.user.AppUserRepository;

/**
 * Concorrência real no PostgreSQL local (bloqueios FOR UPDATE e restrições UNIQUE do banco). Opcional:
 * <pre>mvn test -Dtest=PostgresLoyaltyIT -Dpass.pg-it=true</pre>
 * Usa {@code ddl-auto=validate} (não altera o schema). Como threads concorrentes precisam de transações
 * confirmadas, o teste cria um estabelecimento temporário próprio (slug "it-pg-…") e, ao final, remove
 * <b>somente</b> as linhas que ele mesmo criou. Nenhum dado existente é lido, alterado ou apagado.
 */
@SpringBootTest
@EnabledIfSystemProperty(named = "pass.pg-it", matches = "true")
@TestPropertySource(properties = {
        "spring.jpa.hibernate.ddl-auto=validate",
        "shaminatech.bootstrap.admin.email=",
        "shaminatech.bootstrap.admin.password=",
        "shaminatech.loyalty.expiration.enabled=false",
        "shaminatech.wallet.google.enabled=false",
        "shaminatech.wallet.google.api-base-url=http://127.0.0.1:9"
})
class PostgresLoyaltyIT {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private EstablishmentRepository establishments;
    @Autowired private EstablishmentPolicyRepository policies;
    @Autowired private PolicyService policyService;
    @Autowired private AppUserRepository users;
    @Autowired private MembershipRepository memberships;
    @Autowired private ConsumerRepository consumers;
    @Autowired private LoyaltyProgramRepository programs;
    @Autowired private LoyaltyCardRepository cards;
    @Autowired private CardEngine engine;
    @Autowired private ConsumerService consumerService;
    @Autowired private Clock clock;

    private Long establishmentId;
    private Long userId;
    private Long cardId;

    @BeforeEach
    void setUp() {
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        Establishment e = establishments.save(new Establishment("IT PostgreSQL (temporário)", "it-pg-" + suffix));
        establishmentId = e.getId();
        var policy = policyService.createFor(e);
        policy.update(5, 30, "America/Sao_Paulo", EnumSet.of(ProgramType.POINTS));
        policies.save(policy);
        AppUser user = users.save(new AppUser("it-pg-" + suffix + "@teste.local", "IT", "{noop}nao-usada", false));
        userId = user.getId();
        memberships.save(new Membership(e, user, MembershipRole.OWNER));
        Consumer consumer = consumers.save(new Consumer(e, "Cliente IT", "1190000" + suffix.replaceAll("\\D", "0").substring(0, 4),
                clock.instant()));
        LoyaltyProgram program = new LoyaltyProgram(e, ProgramType.POINTS, "Pontos IT", 30);
        program.setPointsPerUnit(1);
        program.setSpendUnit(new BigDecimal("1.00"));
        programs.save(program);
        LoyaltyCard card = engine.issue(consumers.findById(consumer.getId()).orElseThrow(), program, null, userId);
        cardId = card.getId();
    }

    @AfterEach
    void removeOnlyWhatThisTestCreated() {
        Long id = establishmentId;
        jdbc.update("delete from benefit_lot_usage where lot_id in (select id from benefit_lot where establishment_id = ?)", id);
        jdbc.update("delete from benefit_lot where establishment_id = ?", id);
        jdbc.update("delete from card_transaction where establishment_id = ?", id);
        jdbc.update("delete from loyalty_card where establishment_id = ?", id);
        jdbc.update("delete from loyalty_program where establishment_id = ?", id);
        jdbc.update("delete from consumer where establishment_id = ?", id);
        jdbc.update("delete from audit_event where establishment_id = ?", id);
        jdbc.update("delete from establishment_policy where establishment_id = ?", id);
        jdbc.update("delete from membership where establishment_id = ?", id);
        jdbc.update("delete from app_user where id = ?", userId);
        jdbc.update("delete from establishment where id = ?", id);
        SecurityContextHolder.clearContext();
    }

    private <T> List<Future<T>> concurrently(int threads, Callable<T> task) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch start = new CountDownLatch(1);
        List<Future<T>> futures = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            futures.add(pool.submit(() -> {
                start.await();
                return task.call();
            }));
        }
        start.countDown();
        pool.shutdown();
        assertThat(pool.awaitTermination(60, TimeUnit.SECONDS)).isTrue();
        return futures;
    }

    private BigDecimal balance() {
        return jdbc.queryForObject("select balance from loyalty_card where id = ?", BigDecimal.class, cardId);
    }

    @Test
    void concurrentEarningsAndDuplicatesOnPostgres() throws Exception {
        for (var f : concurrently(12, () -> engine.earn(establishmentId, cardId,
                new CardEngine.EarnCommand(new BigDecimal("7.00"), null, Channel.MANUAL, null), UUID.randomUUID().toString(), userId))) {
            f.get();
        }
        assertThat(balance()).isEqualByComparingTo("84");

        String key = UUID.randomUUID().toString();
        int replays = 0;
        for (var f : concurrently(8, () -> engine.earn(establishmentId, cardId,
                new CardEngine.EarnCommand(new BigDecimal("10.00"), null, Channel.QR_CODE, null), key, userId).replayed())) {
            replays += f.get() ? 1 : 0;
        }
        assertThat(replays).isEqualTo(7);
        assertThat(balance()).isEqualByComparingTo("94");
        assertThat(jdbc.queryForObject("select count(*) from card_transaction where card_id = ? and type = 'EARN'",
                Integer.class, cardId)).isEqualTo(13);
        assertThat(jdbc.queryForObject("select coalesce(sum(remaining), 0) from benefit_lot where card_id = ?",
                BigDecimal.class, cardId)).isEqualByComparingTo("94");
    }

    @Test
    void consumerLimitHoldsUnderConcurrencyOnPostgres() throws Exception {
        AppUser user = users.findById(userId).orElseThrow();
        var auth = new UsernamePasswordAuthenticationToken(AuthenticatedUser.from(user, clock.instant()), null, List.of());
        int[] seq = {0};
        int created = 0;
        int rejected = 0;
        for (var f : concurrently(12, () -> {
            SecurityContextHolder.getContext().setAuthentication(auth);
            int n;
            synchronized (seq) {
                n = ++seq[0];
            }
            try {
                consumerService.create(establishmentId, new ConsumerRequest("Concorrente " + n,
                        "119555500" + String.format("%02d", n), null, null, false, true));
                return true;
            } catch (ApiException e) {
                return false;
            } finally {
                SecurityContextHolder.clearContext();
            }
        })) {
            if (f.get()) {
                created++;
            } else {
                rejected++;
            }
        }
        // Já existia 1 cliente ativo; limite 5 → só 4 novos.
        assertThat(created).isEqualTo(4);
        assertThat(rejected).isEqualTo(8);
        assertThat(jdbc.queryForObject("select count(*) from consumer where establishment_id = ? and status = 'ACTIVE'",
                Integer.class, establishmentId)).isEqualTo(5);
    }
}
