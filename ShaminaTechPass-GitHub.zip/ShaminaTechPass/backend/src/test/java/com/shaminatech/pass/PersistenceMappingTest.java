package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;

import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.membership.Permission;
import com.shaminatech.pass.membership.PermissionRepository;
import com.shaminatech.pass.membership.RolePermissionRepository;

/** Mapeamento JPA: tabelas, relacionamentos, restrições únicas e dados de catálogo. */
class PersistenceMappingTest extends IntegrationTestSupport {

    @Autowired
    private PermissionRepository permissions;
    @Autowired
    private RolePermissionRepository rolePermissions;

    @Test
    void schemaHasAllFoundationTables() {
        List<String> tables = jdbc.queryForList(
                "select lower(table_name) from information_schema.tables where lower(table_schema) = 'public'", String.class);
        assertThat(tables).contains("establishment", "app_user", "membership", "permission", "role_permission", "audit_event");
    }

    @Test
    void persistsEntitiesAndRelationships() {
        var establishment = establishment("relacao");
        var user = user("relacao@teste.local");
        var membership = member(establishment, user, MembershipRole.MANAGER);

        var loaded = memberships.findForUser(establishment.getId(), user.getId()).orElseThrow();
        assertThat(loaded.getId()).isEqualTo(membership.getId());
        assertThat(loaded.getEstablishment().getSlug()).isEqualTo("relacao");
        assertThat(loaded.getRole()).isEqualTo(MembershipRole.MANAGER);
        assertThat(loaded.getCreatedAt()).isNotNull();
        assertThat(establishment.getCreatedAt()).isNotNull();
        assertThat(jdbc.queryForObject("select role from membership where id = ?", String.class, membership.getId()))
                .isEqualTo("MANAGER");
    }

    @Test
    void uniqueConstraintsAreEnforced() {
        var establishment = establishment("unico");
        var user = user("unico@teste.local");
        member(establishment, user, MembershipRole.STAFF);

        assertThatThrownBy(() -> member(establishment, user, MembershipRole.MANAGER))
                .isInstanceOf(DataIntegrityViolationException.class);
        assertThatThrownBy(() -> user("unico@teste.local")).isInstanceOf(DataIntegrityViolationException.class);
        assertThatThrownBy(() -> establishment("unico")).isInstanceOf(DataIntegrityViolationException.class);
    }

    @Test
    void foreignKeysProtectRelationships() {
        var establishment = establishment("fk");
        member(establishment, user("fk@teste.local"), MembershipRole.STAFF);
        assertThatThrownBy(() -> jdbc.update("delete from establishment where id = ?", establishment.getId()))
                .isInstanceOf(DataIntegrityViolationException.class);
    }

    @Test
    void permissionCatalogIsSeededWithDefaultRoles() {
        assertThat(permissions.count()).isEqualTo(Permission.values().length);
        assertThat(rolePermissions.findPermissionCodesByRole(MembershipRole.OWNER))
                .containsExactlyInAnyOrder(java.util.Arrays.stream(Permission.values()).map(Enum::name).toArray(String[]::new));
        assertThat(rolePermissions.findPermissionCodesByRole(MembershipRole.MANAGER))
                .containsExactlyInAnyOrder("ESTABLISHMENT_VIEW");
        assertThat(rolePermissions.findPermissionCodesByRole(MembershipRole.STAFF))
                .containsExactly("ESTABLISHMENT_VIEW");
    }

    @Test
    void schemaCreatedByHibernateHasNoEnumCheckConstraints() {
        // Banco de teste criado do zero (create-drop): equivale a criar todas as tabelas como novas.
        Integer checks = jdbc.queryForObject("""
                select count(*) from information_schema.table_constraints
                where constraint_type = 'CHECK' and table_schema = 'public'
                """, Integer.class);
        assertThat(checks).isZero();
    }
}
