package com.shaminatech.pass;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Signature;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import tools.jackson.databind.json.JsonMapper;

/**
 * Servidor HTTP local que imita a API do Google Wallet nos testes SIMULADOS (nenhuma chamada sai da máquina):
 * endpoint OAuth (confere a assinatura RS256 da asserção), loyaltyClass/loyaltyObject (insert → 409 se existir,
 * get, patch) e injeção de falhas (status HTTP e atraso para simular tempo esgotado).
 */
public final class FakeGoogleWallet {

    public static final String ISSUER_ID = "3388000000000000001"; // fictício, só para testes
    public static final String CLIENT_EMAIL = "pass-test@projeto-ficticio.iam.gserviceaccount.com";

    private static final JsonMapper JSON = JsonMapper.builder().build();
    private static FakeGoogleWallet instance;

    public final Map<String, Map<String, Object>> classes = new ConcurrentHashMap<>();
    public final Map<String, Map<String, Object>> objects = new ConcurrentHashMap<>();
    public final List<String> calls = Collections.synchronizedList(new ArrayList<>());
    public final AtomicInteger tokenRequests = new AtomicInteger();
    public final Map<String, Integer> notifications = new ConcurrentHashMap<>();
    private volatile int failStatus;
    private volatile int failRemaining;
    private volatile long delayMillis;

    private final HttpServer server;
    private final KeyPair keys;
    private final Path keyFile;

    private FakeGoogleWallet() throws Exception {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048);
        keys = generator.generateKeyPair();
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/token", this::token);
        server.createContext("/walletobjects/v1/", this::api);
        server.setExecutor(java.util.concurrent.Executors.newFixedThreadPool(8));
        server.start();
        String pem = "-----BEGIN PRIVATE KEY-----\n" + Base64.getMimeEncoder().encodeToString(keys.getPrivate().getEncoded())
                + "\n-----END PRIVATE KEY-----\n";
        keyFile = Files.createTempFile("pass-test-sa", ".json");
        keyFile.toFile().deleteOnExit();
        Files.writeString(keyFile, JSON.writeValueAsString(Map.of("type", "service_account", "client_email", CLIENT_EMAIL,
                "private_key", pem, "token_uri", baseUrl() + "/token")));
    }

    public static synchronized FakeGoogleWallet get() {
        if (instance == null) {
            try {
                instance = new FakeGoogleWallet();
            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
        }
        return instance;
    }

    public String baseUrl() {
        return "http://127.0.0.1:" + server.getAddress().getPort();
    }

    public Path keyFile() {
        return keyFile;
    }

    public RSAPublicKey publicKey() {
        return (RSAPublicKey) keys.getPublic();
    }

    public void reset() {
        classes.clear();
        objects.clear();
        calls.clear();
        failStatus = 0;
        failRemaining = 0;
        delayMillis = 0;
        notifications.clear();
    }

    /** As próximas {@code times} chamadas à API (não ao token) respondem {@code status}. */
    public void failNext(int status, int times) {
        failStatus = status;
        failRemaining = times;
    }

    public void delay(long millis) {
        delayMillis = millis;
    }

    public long objectWrites() {
        return calls.stream().filter(c -> c.startsWith("POST loyaltyObject") || c.startsWith("PATCH loyaltyObject")).count();
    }

    // ---------------- Handlers ----------------

    private void token(HttpExchange ex) throws IOException {
        tokenRequests.incrementAndGet();
        String form = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        String assertion = null;
        for (String part : form.split("&")) {
            if (part.startsWith("assertion=")) {
                assertion = URLDecoder.decode(part.substring(10), StandardCharsets.UTF_8);
            }
        }
        if (assertion == null || !verify(assertion, publicKey())) {
            respond(ex, 401, Map.of("error", "invalid_grant"));
            return;
        }
        respond(ex, 200, Map.of("access_token", "token-de-teste", "expires_in", 3600, "token_type", "Bearer"));
    }

    @SuppressWarnings("unchecked")
    private void api(HttpExchange ex) throws IOException {
        // A falha programada é decidida na CHEGADA do pedido: um pedido atrasado de um teste anterior (cliente já
        // desistiu por tempo esgotado) não pode acordar depois e consumir a falha programada pelo teste seguinte.
        int simulatedFailure = 0;
        synchronized (this) {
            if (failRemaining > 0) {
                failRemaining--;
                simulatedFailure = failStatus;
            }
        }
        try {
            if (delayMillis > 0) {
                Thread.sleep(delayMillis);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        if (!"Bearer token-de-teste".equals(ex.getRequestHeaders().getFirst("Authorization"))) {
            respond(ex, 401, error(401, "Unauthenticated"));
            return;
        }
        String[] path = ex.getRequestURI().getPath().substring("/walletobjects/v1/".length()).split("/", 2);
        String resource = path[0];
        String id = path.length > 1 ? URLDecoder.decode(path[1], StandardCharsets.UTF_8) : null;
        String method = ex.getRequestMethod();
        calls.add(method + " " + resource + (id == null ? "" : " " + id));
        if (simulatedFailure > 0) {
            respond(ex, simulatedFailure, error(simulatedFailure, "Falha simulada"));
            return;
        }
        Map<String, Map<String, Object>> store = resource.equals("loyaltyClass") ? classes : objects;
        byte[] raw = readAll(ex.getRequestBody());
        Map<String, Object> body = raw.length == 0 ? Map.of() : JSON.readValue(raw, Map.class);
        if ("POST".equals(method) && id != null && id.endsWith("/addMessage")) {
            addMessage(ex, store, id.substring(0, id.length() - "/addMessage".length()), (Map<String, Object>) body.get("message"));
            return;
        }
        switch (method) {
            case "POST" -> {
                String newId = (String) body.get("id");
                if (store.containsKey(newId)) {
                    respond(ex, 409, error(409, "Wallet Object already exists."));
                    return;
                }
                if (resource.equals("loyaltyObject") && !classes.containsKey((String) body.get("classId"))) {
                    respond(ex, 404, error(404, "Wallet Object Class not found."));
                    return;
                }
                store.put(newId, new ConcurrentHashMap<>(body));
                respond(ex, 200, body);
            }
            case "PATCH" -> {
                Map<String, Object> current = store.get(id);
                if (current == null) {
                    respond(ex, 404, error(404, "Wallet Object not found."));
                    return;
                }
                current.putAll(body);
                respond(ex, 200, current);
            }
            case "GET" -> {
                Map<String, Object> current = store.get(id);
                if (current == null) {
                    respond(ex, 404, error(404, "not found"));
                } else {
                    respond(ex, 200, current);
                }
            }
            default -> respond(ex, 405, error(405, "method"));
        }
    }

    /** Simula addMessage: id repetido = 409; mais de 3 avisos (TEXT_AND_NOTIFY) no objeto = 429 QuotaExceeded. */
    @SuppressWarnings("unchecked")
    private void addMessage(HttpExchange ex, Map<String, Map<String, Object>> store, String objectId, Map<String, Object> message)
            throws IOException {
        Map<String, Object> current = store.get(objectId);
        if (current == null) {
            respond(ex, 404, error(404, "Wallet Object not found."));
            return;
        }
        synchronized (current) {
            List<Map<String, Object>> list = new ArrayList<>((List<Map<String, Object>>) current.getOrDefault("messages", List.of()));
            if (list.stream().anyMatch(m -> message.get("id").equals(m.get("id")))) {
                respond(ex, 409, error(409, "Message with this id already exists."));
                return;
            }
            if ("TEXT_AND_NOTIFY".equals(message.get("messageType"))) {
                int sent = notifications.merge(objectId, 1, Integer::sum);
                if (sent > 3) {
                    respond(ex, 429, error(429, "QuotaExceededException: notification limit reached for this pass."));
                    return;
                }
            }
            list.add(message);
            current.put("messages", list);
        }
        respond(ex, 200, Map.of("resource", current));
    }

    /** Mensagens gravadas no objeto (como o Google guardaria). */
    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> messages(String objectId) {
        Map<String, Object> current = objects.get(objectId);
        return current == null ? List.of() : (List<Map<String, Object>>) current.getOrDefault("messages", List.of());
    }

    private static Map<String, Object> error(int code, String message) {
        return Map.of("error", Map.of("code", code, "message", message));
    }

    private static void respond(HttpExchange ex, int status, Object body) throws IOException {
        byte[] bytes = JSON.writeValueAsBytes(body);
        ex.getResponseHeaders().add("Content-Type", "application/json");
        try {
            ex.sendResponseHeaders(status, bytes.length);
            try (OutputStream out = ex.getResponseBody()) {
                out.write(bytes);
            }
        } catch (IOException ignored) {
            // cliente desistiu (tempo esgotado)
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        return in.readAllBytes();
    }

    /** Confere a assinatura RS256 de um JWT compacto. */
    public static boolean verify(String jwt, RSAPublicKey key) {
        try {
            String[] parts = jwt.split("\\.");
            Signature signature = Signature.getInstance("SHA256withRSA");
            signature.initVerify(key);
            signature.update((parts[0] + "." + parts[1]).getBytes(StandardCharsets.US_ASCII));
            return signature.verify(Base64.getUrlDecoder().decode(parts[2]));
        } catch (Exception e) {
            return false;
        }
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> claims(String jwt) {
        return JSON.readValue(Base64.getUrlDecoder().decode(jwt.split("\\.")[1]), Map.class);
    }
}
