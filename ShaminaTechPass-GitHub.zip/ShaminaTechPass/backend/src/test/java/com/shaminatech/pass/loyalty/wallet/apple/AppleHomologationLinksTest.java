package com.shaminatech.pass.loyalty.wallet.apple;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

/** Tokens temporários da homologação: aleatórios, 15 minutos, não consumidos, limitados e limpos da memória. */
class AppleHomologationLinksTest {

    private static final class TestClock extends Clock {
        Instant now = Instant.parse("2026-11-25T12:00:00Z");

        @Override
        public ZoneId getZone() {
            return ZoneOffset.UTC;
        }

        @Override
        public Clock withZone(ZoneId zone) {
            return this;
        }

        @Override
        public Instant instant() {
            return now;
        }
    }

    private static AppleOfflineHomologation.Generated pass(String serial) {
        return new AppleOfflineHomologation.Generated(serial, new byte[] {1, 2, 3}, "00");
    }

    @Test
    void tokensAreRandomExpireAfter15MinutesAndAreNotConsumedOnFirstUse() {
        TestClock clock = new TestClock();
        AppleHomologationLinks links = new AppleHomologationLinks(clock);
        Set<String> tokens = new HashSet<>();
        for (int i = 0; i < 50; i++) {
            tokens.add(links.create(pass("s" + i)).token());
        }
        assertThat(tokens).hasSize(50).allMatch(t -> t.matches("[A-Za-z0-9_-]{43}"));

        AppleHomologationLinks.Link link = links.create(pass("demo"));
        assertThat(link.expiresAt()).isEqualTo(clock.now.plus(Duration.ofMinutes(15)));
        assertThat(links.find(link.token())).isInstanceOf(AppleHomologationLinks.Lookup.Found.class);
        assertThat(links.find(link.token())).isInstanceOf(AppleHomologationLinks.Lookup.Found.class);
        clock.now = clock.now.plus(Duration.ofMinutes(14).plusSeconds(59));
        assertThat(links.find(link.token())).isInstanceOf(AppleHomologationLinks.Lookup.Found.class);
        clock.now = clock.now.plusSeconds(1);
        assertThat(links.find(link.token())).isInstanceOf(AppleHomologationLinks.Lookup.Expired.class);
        assertThat(links.active(link.token())).isEmpty();
        assertThat(links.find("../../etc/passwd")).isInstanceOf(AppleHomologationLinks.Lookup.NotFound.class);
        assertThat(links.find(null)).isInstanceOf(AppleHomologationLinks.Lookup.NotFound.class);
    }

    @Test
    void activeLinksDownloadsAndMemoryAreBounded() {
        TestClock clock = new TestClock();
        AppleHomologationLinks links = new AppleHomologationLinks(clock);
        AppleHomologationLinks.Link first = links.create(pass("first"));
        for (int i = 0; i < AppleHomologationLinks.MAX_ACTIVE; i++) {
            clock.now = clock.now.plusSeconds(1);
            links.create(pass("n" + i));
        }
        assertThat(links.stored()).isEqualTo(AppleHomologationLinks.MAX_ACTIVE);
        assertThat(links.find(first.token())).isInstanceOf(AppleHomologationLinks.Lookup.Expired.class); // o mais antigo saiu

        AppleHomologationLinks.Link limited = links.create(pass("limited"));
        for (int i = 0; i < AppleHomologationLinks.MAX_DOWNLOADS; i++) {
            assertThat(links.find(limited.token())).isInstanceOf(AppleHomologationLinks.Lookup.Found.class);
        }
        assertThat(links.find(limited.token())).isInstanceOf(AppleHomologationLinks.Lookup.Expired.class);

        clock.now = clock.now.plus(Duration.ofMinutes(16));
        links.cleanup();
        assertThat(links.stored()).isZero(); // arquivos vencidos saem da memória
        clock.now = clock.now.plus(Duration.ofHours(2));
        links.cleanup();
        assertThat(links.find(limited.token())).isInstanceOf(AppleHomologationLinks.Lookup.NotFound.class);
    }
}
