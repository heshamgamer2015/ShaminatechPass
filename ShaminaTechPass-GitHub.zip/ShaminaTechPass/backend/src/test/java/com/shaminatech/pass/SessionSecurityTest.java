package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;

import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.security.AuthenticatedUser;

/**
 * Etapa 8 — sessões: troca de senha encerra as outras sessões do usuário, a sessão não guarda o hash da senha,
 * fixação de sessão e separação entre administrador e estabelecimento.
 */
class SessionSecurityTest extends IntegrationTestSupport {

    private static final String NEW_PASSWORD = "NovaSenha-2026x";

    private void changePassword(MockHttpSession session, String current, String next) throws Exception {
        mvc.perform(post("/api/auth/change-password").session(session).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"currentPassword\":\"" + current + "\",\"newPassword\":\"" + next + "\"}"))
                .andExpect(status().isNoContent());
    }

    @Test
    void changingThePasswordRevokesOtherSessionsButKeepsTheCurrentOne() throws Exception {
        Establishment e = establishment("sessoes");
        member(e, user("dono@sessoes.local"), MembershipRole.OWNER);
        MockHttpSession laptop = login("dono@sessoes.local");
        MockHttpSession stolen = login("dono@sessoes.local"); // ex.: sessão esquecida em outro computador

        changePassword(laptop, PASSWORD, NEW_PASSWORD);

        mvc.perform(get("/api/establishments/" + e.getId()).session(stolen))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("SESSION_REVOKED"));
        mvc.perform(get("/api/establishments/" + e.getId()).session(laptop)).andExpect(status().isOk());
        // A senha antiga não entra mais; a nova entra.
        mvc.perform(post("/api/auth/login").with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content(loginJson("dono@sessoes.local", PASSWORD))).andExpect(status().isUnauthorized());
        login("dono@sessoes.local", NEW_PASSWORD);
    }

    @Test
    void adminPasswordResetRevokesTheEstablishmentSessions() throws Exception {
        Establishment e = establishment("reset-sessao");
        member(e, user("dono@reset.local"), MembershipRole.OWNER);
        platformAdmin("admin@reset.local");
        MockHttpSession owner = login("dono@reset.local");
        MockHttpSession admin = login("admin@reset.local");

        mvc.perform(post("/api/admin/establishments/" + e.getId() + "/account/reset-password").session(admin).with(csrf())
                        .contentType(MediaType.APPLICATION_JSON).content("{\"temporaryPassword\":\"Temporaria-2026\"}"))
                .andExpect(status().isOk());

        mvc.perform(get("/api/auth/me").session(owner))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("SESSION_REVOKED"));
    }

    @Test
    void theSessionKeepsOnlyACredentialStampNeverThePasswordHash() throws Exception {
        user("hash@sessao.local");
        MockHttpSession session = login("hash@sessao.local");
        var context = (org.springframework.security.core.context.SecurityContext) session.getAttribute("SPRING_SECURITY_CONTEXT");
        AuthenticatedUser principal = (AuthenticatedUser) context.getAuthentication().getPrincipal();
        assertThat(principal.getPassword()).isNull();
        assertThat(principal.getCredentialStamp()).isNotBlank()
                .isNotEqualTo(users.findByEmail("hash@sessao.local").orElseThrow().getPasswordHash());
    }

    @Test
    void loginIssuesANewSessionIdentifier() throws Exception {
        user("fixacao@sessao.local");
        MockHttpSession before = new MockHttpSession();
        String fixedId = before.getId();
        var result = mvc.perform(post("/api/auth/login").session(before).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content(loginJson("fixacao@sessao.local", PASSWORD))).andExpect(status().isOk()).andReturn();
        assertThat(result.getRequest().getSession(false).getId()).isNotEqualTo(fixedId);
    }

    @Test
    void businessAccountCannotReachAdminEndpointsAndAdminHasNoTenantAccess() throws Exception {
        Establishment e = establishment("separacao");
        member(e, user("dono@separacao.local"), MembershipRole.OWNER);
        platformAdmin("admin@separacao.local");
        MockHttpSession owner = login("dono@separacao.local");
        MockHttpSession admin = login("admin@separacao.local");

        mvc.perform(get("/api/admin/establishments").session(owner)).andExpect(status().isForbidden());
        mvc.perform(post("/api/admin/establishments/" + e.getId() + "/account/reset-password").session(owner).with(csrf())
                .contentType(MediaType.APPLICATION_JSON).content("{\"temporaryPassword\":\"Temporaria-2026\"}"))
                .andExpect(status().isForbidden());
        // O administrador não registra compras nem consulta clientes do estabelecimento.
        mvc.perform(get("/api/establishments/" + e.getId() + "/consumers").session(admin)).andExpect(status().isForbidden());
        mvc.perform(post("/api/establishments/" + e.getId() + "/cards/1/earn").session(admin).with(csrf())
                .header("Idempotency-Key", "k-admin-1").contentType(MediaType.APPLICATION_JSON).content("{\"quantity\":1}"))
                .andExpect(status().isForbidden());
    }

    @Test
    void stateChangingRequestsWithoutCsrfAreRejectedEvenWhenAuthenticated() throws Exception {
        user("csrf@sessao.local");
        MockHttpSession session = login("csrf@sessao.local");
        mvc.perform(post("/api/auth/change-password").session(session).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"currentPassword\":\"" + PASSWORD + "\",\"newPassword\":\"" + NEW_PASSWORD + "\"}"))
                .andExpect(status().isForbidden());
    }

    /** Sem canal de entrega configurado (padrão desta versão), o pedido de recuperação não emite nenhum token. */
    @Test
    void passwordResetWithoutADeliveryChannelIssuesNoToken() throws Exception {
        user("sem-envio@sessao.local");
        mvc.perform(post("/api/auth/password-reset/request").with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"sem-envio@sessao.local\"}")).andExpect(status().isAccepted());
        assertThat(jdbc.queryForObject("select count(*) from password_reset_token", Integer.class)).isZero();
        assertThat(jdbc.queryForObject("select details from audit_event where action = 'PASSWORD_RESET_REQUESTED'", String.class))
                .contains("não configurado");
    }
}
