package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;

import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.membership.Membership;
import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.membership.MembershipStatus;

/** Isolamento entre estabelecimentos e regra de uma única conta empresarial por estabelecimento. */
class TenantIsolationTest extends IntegrationTestSupport {

    private Establishment a;
    private Establishment b;

    @BeforeEach
    void setUp() {
        a = establishment("loja-a");
        b = establishment("loja-b");
        member(a, user("dono.a@teste.local"), MembershipRole.OWNER);
        member(b, user("dono.b@teste.local"), MembershipRole.OWNER);
    }

    private String base(Establishment establishment) {
        return "/api/establishments/" + establishment.getId();
    }

    @Test
    void businessAccountSeesOnlyOwnEstablishment() throws Exception {
        MockHttpSession owner = login("dono.a@teste.local");

        mvc.perform(get(base(a)).session(owner))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.myRole").value("OWNER"))
                .andExpect(jsonPath("$.policy.maxActiveConsumers").value(100));
        mvc.perform(get("/api/auth/me").session(owner))
                .andExpect(jsonPath("$.memberships.length()").value(1))
                .andExpect(jsonPath("$.memberships[0].establishmentId").value(a.getId()));

        for (String path : new String[] {"", "/audit", "/consumers", "/programs", "/cards", "/transactions", "/overview",
                "/indicators", "/rewards"}) {
            int code = mvc.perform(get(base(b) + path).session(owner)).andReturn().getResponse().getStatus();
            assertThat(code).as("GET " + path).isEqualTo(403);
        }
        mvc.perform(put(base(b)).session(owner).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"Invadido\"}"))
                .andExpect(status().isForbidden());
        mvc.perform(post(base(b) + "/consumers").session(owner).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"fullName\":\"X\",\"phone\":\"11999990000\",\"privacyAcknowledged\":true}"))
                .andExpect(status().isForbidden());
    }

    @Test
    void teamManagementEndpointsNoLongerExist() throws Exception {
        MockHttpSession owner = login("dono.a@teste.local");
        mvc.perform(get(base(a) + "/members").session(owner)).andExpect(status().isNotFound());
        mvc.perform(post(base(a) + "/members").session(owner).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"x@teste.local\",\"fullName\":\"X\",\"role\":\"STAFF\",\"temporaryPassword\":\"Senha-temp-123\"}"))
                .andExpect(status().isNotFound());
    }

    @Test
    void legacyStaffAndManagerMembershipsAreKeptButGrantNoAccess() throws Exception {
        member(a, user("gerente.a@teste.local"), MembershipRole.MANAGER);
        member(a, user("func.a@teste.local"), MembershipRole.STAFF);

        MockHttpSession staff = login("func.a@teste.local");
        mvc.perform(get(base(a)).session(staff)).andExpect(status().isForbidden());
        mvc.perform(get(base(a) + "/consumers").session(staff)).andExpect(status().isForbidden());
        mvc.perform(get("/api/auth/me").session(staff)).andExpect(jsonPath("$.memberships.length()").value(0));

        MockHttpSession manager = login("gerente.a@teste.local");
        mvc.perform(get(base(a)).session(manager)).andExpect(status().isForbidden());
        assertThat(memberships.count()).isEqualTo(4); // nada foi apagado
    }

    @Test
    void databaseRejectsASecondActiveBusinessAccount() {
        assertThatThrownBy(() -> member(a, user("segundo.dono@teste.local"), MembershipRole.OWNER))
                .isInstanceOf(DataIntegrityViolationException.class);
    }

    @Test
    void disabledBusinessAccountFreesTheSlot() {
        Membership current = memberships.findBusinessAccount(a.getId()).orElseThrow();
        current.setStatus(MembershipStatus.DISABLED);
        memberships.saveAndFlush(current);
        assertThat(memberships.findBusinessAccount(a.getId())).isEmpty();
        member(a, user("novo.dono@teste.local"), MembershipRole.OWNER);
        assertThat(memberships.findBusinessAccount(a.getId())).get()
                .extracting(m -> m.getUser().getEmail()).isEqualTo("novo.dono@teste.local");
    }

    @Test
    void platformAdminHasNoImplicitAccessToLoyaltyData() throws Exception {
        platformAdmin("admin@teste.local");
        MockHttpSession admin = login("admin@teste.local");
        mvc.perform(get(base(a)).session(admin)).andExpect(status().isForbidden());
        mvc.perform(get(base(a) + "/consumers").session(admin)).andExpect(status().isForbidden());
        mvc.perform(get(base(a) + "/cards").session(admin)).andExpect(status().isForbidden());
    }

    @Test
    void suspendedEstablishmentIsBlocked() throws Exception {
        a.setStatus(com.shaminatech.pass.establishment.EstablishmentStatus.SUSPENDED);
        establishments.save(a);
        MockHttpSession owner = login("dono.a@teste.local");
        mvc.perform(get(base(a)).session(owner))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("ESTABLISHMENT_INACTIVE"));
    }
}
