package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.TestPropertySource;

/** Conexão vinda do proxy confiável: cada cliente real tem o seu limite; o mesmo cliente continua limitado. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = {"shaminatech.public.rate-limit-per-minute=3", "server.forward-headers-strategy=native",
        "server.tomcat.remoteip.internal-proxies=127\\.0\\.0\\.1"})
class ProxyTrustedTest extends IntegrationTestSupport {

    private static final String PUBLIC_URL = "/api/public/wallet-links/" + "d".repeat(32);

    static int status(int port, String forwardedFor) throws Exception {
        HttpRequest.Builder request = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + PUBLIC_URL)).GET();
        if (forwardedFor != null) {
            request.header("X-Forwarded-For", forwardedFor);
        }
        return HttpClient.newHttpClient().send(request.build(), HttpResponse.BodyHandlers.discarding()).statusCode();
    }

    @LocalServerPort
    int port;

    @Test
    void eachRealClientBehindTheProxyHasItsOwnLimit() throws Exception {
        for (int i = 0; i < 5; i++) {
            assertThat(status(port, "192.0.2." + (10 + i))).isNotEqualTo(429); // clientes diferentes
        }
        int limited = 0;
        for (int i = 0; i < 5; i++) {
            if (status(port, "192.0.2.200") == 429) limited++; // o mesmo cliente
        }
        assertThat(limited).isEqualTo(2);
    }

    @Test
    void aClientCannotPrependAFakeAddressToTheChain() throws Exception {
        // O cliente envia "1.2.3.4" e o proxy acrescenta o IP real; vale o último IP não confiável (o real).
        int limited = 0;
        for (int i = 0; i < 5; i++) {
            if (status(port, "1.2.3." + i + ", 192.0.2.250") == 429) limited++;
        }
        assertThat(limited).isEqualTo(2);
    }
}
