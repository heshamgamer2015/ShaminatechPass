package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Duration;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.ResultActions;

import com.jayway.jsonpath.JsonPath;
import com.shaminatech.pass.loyalty.wallet.WalletPass;
import com.shaminatech.pass.loyalty.wallet.WalletPassRepository;
import com.shaminatech.pass.loyalty.wallet.WalletSyncDispatcher;

/**
 * Cadastro público com o Google Wallet SIMULADO ({@link FakeGoogleWallet}): o consumidor recebe o link da carteira,
 * a emissão não duplica e falhas do Google não desfazem o cadastro nem mostram o cartão como adicionado.
 */
class PublicSignupWalletTest extends LoyaltyTestSupport {

    @DynamicPropertySource
    static void wallet(DynamicPropertyRegistry registry) {
        FakeGoogleWallet fake = FakeGoogleWallet.get();
        registry.add("shaminatech.wallet.google.enabled", () -> "true");
        registry.add("shaminatech.wallet.google.issuer-id", () -> FakeGoogleWallet.ISSUER_ID);
        registry.add("shaminatech.wallet.google.service-account-key-file", () -> fake.keyFile().toString());
        registry.add("shaminatech.wallet.google.origins", () -> "http://localhost:4203");
        registry.add("shaminatech.wallet.google.api-base-url", fake::baseUrl);
        registry.add("shaminatech.wallet.google.fallback-logo-uri", () -> "https://example.test/logo-padrao.png");
        registry.add("shaminatech.wallet.google.public-base-url", () -> "https://pass.example.test");
        registry.add("shaminatech.wallet.google.async-dispatch", () -> "false");
        registry.add("shaminatech.wallet.google.request-timeout", () -> "PT1S");
        registry.add("shaminatech.wallet.google.max-attempts", () -> "3");
    }

    @Autowired
    private WalletPassRepository passes;
    @Autowired
    private WalletSyncDispatcher dispatcher;

    private final FakeGoogleWallet google = FakeGoogleWallet.get();
    private String token;

    @BeforeEach
    void setUpLink() throws Exception {
        google.reset();
        long program = pointsProgram(a, ownerA, "");
        String url = read(postJson(ownerA, base(a) + "/programs/" + program + "/signup-link", "{}").andExpect(status().isCreated()),
                "$.url");
        token = url.substring(url.lastIndexOf('/') + 1);
    }

    private ResultActions signup(String requestId, String phone) throws Exception {
        String info = mvc.perform(get("/api/public/signup/" + token)).andExpect(status().isOk()).andReturn().getResponse()
                .getContentAsString();
        assertThat((Boolean) JsonPath.read(info, "$.walletAvailable")).isTrue();
        String formToken = JsonPath.read(info, "$.formToken");
        clock.advance(Duration.ofSeconds(5));
        return mvc.perform(post("/api/public/signup/" + token).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .content("{\"fullName\":\"Ana Clara Dias\",\"phone\":\"" + phone + "\",\"privacyAccepted\":true,"
                        + "\"requestId\":\"" + requestId + "\",\"formToken\":\"" + formToken + "\"}"));
    }

    private String walletPage(String path) throws Exception {
        return mvc.perform(get("/api/public/wallet-links/" + path.substring("/carteira/".length()))).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
    }

    @Test
    void signupDeliversTheGoogleWalletLinkWithoutDuplicatingTheObject() throws Exception {
        String requestId = UUID.randomUUID().toString();
        ResultActions result = signup(requestId, "11944443333").andExpect(status().isCreated());
        assertThat((String) read(result, "$.walletStatus")).isEqualTo("LINK_READY");
        String path = read(result, "$.walletPath");
        assertThat(path).matches("^/carteira/[0-9a-f]{32}$");
        String page = walletPage(path);
        assertThat((String) JsonPath.read(page, "$.status")).isEqualTo("READY");
        assertThat((String) JsonPath.read(page, "$.consumerFirstName")).isEqualTo("Ana");
        assertThat((String) JsonPath.read(page, "$.google.url")).startsWith("https://pay.google.com/gp/v/save/");

        // Repetir o envio devolve o mesmo cartão (novo link de distribuição, mesmo passe e mesmo objeto no Google).
        long writes = google.objectWrites();
        signup(requestId, "11944443333").andExpect(status().isCreated());
        assertThat(passes.count()).isEqualTo(1);
        assertThat(google.objectWrites()).isEqualTo(writes);
        assertThat(jdbc.queryForObject("select count(*) from loyalty_card", Integer.class)).isEqualTo(1);
    }

    @Test
    void googleFailureKeepsTheRegistrationAndShowsPreparing() throws Exception {
        google.failNext(503, 5);
        ResultActions result = signup(UUID.randomUUID().toString(), "11944442222").andExpect(status().isCreated());
        assertThat((String) read(result, "$.status")).isEqualTo("REGISTERED");
        String path = read(result, "$.walletPath");
        WalletPass pass = passes.findAll().get(0);
        assertThat(pass.getSyncStatus()).isEqualTo(WalletPass.SyncStatus.FAILED);
        String page = walletPage(path);
        assertThat((String) JsonPath.read(page, "$.status")).isEqualTo("PREPARING");
        assertThat(page).doesNotContain("pay.google.com");
        assertThat(jdbc.queryForObject("select count(*) from consumer", Integer.class)).isEqualTo(1);

        // O Google volta: a varredura conclui a emissão e o mesmo link passa a oferecer o botão.
        google.failNext(503, 0);
        clock.advance(Duration.ofMinutes(5));
        dispatcher.sweep();
        assertThat(passes.findAll().get(0).getSyncStatus()).isEqualTo(WalletPass.SyncStatus.SYNCED);
        assertThat((String) JsonPath.read(walletPage(path), "$.status")).isEqualTo("READY");
    }
}
