package com.shaminatech.pass;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.establishment.EstablishmentRepository;
import com.shaminatech.pass.membership.Membership;
import com.shaminatech.pass.membership.MembershipRepository;
import com.shaminatech.pass.membership.MembershipRole;
import com.shaminatech.pass.user.AppUser;
import com.shaminatech.pass.user.AppUserRepository;

/**
 * Verificação opcional contra o PostgreSQL local real (banco shaminatech_pass), depois que o
 * backend já criou as tabelas no perfil "local". Executar com:
 * <pre>mvn test -Dtest=PostgresSchemaIT -Dpass.pg-it=true</pre>
 * Usa ddl-auto=validate (não altera o schema) e grava dentro de uma transação desfeita ao
 * final do teste: nenhum dado permanece no banco.
 */
@SpringBootTest
@EnabledIfSystemProperty(named = "pass.pg-it", matches = "true")
@TestPropertySource(properties = {
        "spring.jpa.hibernate.ddl-auto=validate",
        "shaminatech.bootstrap.admin.email=",
        "shaminatech.bootstrap.admin.password=",
        "shaminatech.wallet.google.enabled=false",
        "shaminatech.wallet.google.api-base-url=http://127.0.0.1:9"
})
class PostgresSchemaIT {

    @Autowired
    private JdbcTemplate jdbc;
    @Autowired
    private EstablishmentRepository establishments;
    @Autowired
    private AppUserRepository users;
    @Autowired
    private MembershipRepository memberships;

    @Test
    void entitiesMatchThePostgresSchema() {
        assertThat(jdbc.queryForObject("select version()", String.class)).startsWith("PostgreSQL");
        List<String> tables = jdbc.queryForList(
                "select table_name from information_schema.tables where table_schema = 'public'", String.class);
        assertThat(tables).contains("establishment", "app_user", "membership", "permission", "role_permission", "audit_event",
                "platform_loyalty_defaults", "establishment_policy", "consumer", "loyalty_program", "loyalty_reward", "vip_tier",
                "loyalty_card", "card_transaction", "benefit_lot", "benefit_lot_usage", "stored_image", "wallet_pass", "wallet_class",
                "wallet_link", "apple_device_registration", "public_signup_link", "public_signup", "wallet_reminder", "notification_settings", "establishment_location", "password_reset_token");
        List<String> constraints = jdbc.queryForList(
                "select constraint_name from information_schema.table_constraints where table_schema = 'public'", String.class);
        assertThat(constraints).contains("uk_membership_account_slot", "uk_card_tx_idempotency", "uk_card_tx_reverses",
                "uk_loyalty_card_code", "uk_consumer_establishment_phone");
    }

    @Test
    @Transactional
    void persistsAndReadsBackInPostgres() {
        Establishment establishment = establishments.save(new Establishment("IT Postgres", "it-postgres-rollback"));
        AppUser user = users.save(new AppUser("it-postgres@teste.local", "IT", "{noop}nao-usada", false));
        Membership membership = memberships.save(new Membership(establishment, user, MembershipRole.OWNER));
        memberships.flush();

        assertThat(memberships.findForUser(establishment.getId(), user.getId())).get()
                .extracting(Membership::getId).isEqualTo(membership.getId());
        assertThat(jdbc.queryForObject("select count(*) from membership where id = ?", Integer.class, membership.getId()))
                .isEqualTo(1);
    }

    @Test
    void noEnumChecksRemain() {
        // Depois de sql/001_etapa2_remove_enum_checks.sql não resta nenhuma CHECK de lista de enum.
        assertThat(jdbc.queryForList("""
                select c.conname from pg_constraint c join pg_namespace n on n.oid = c.connamespace
                where c.contype = 'c' and n.nspname = 'public'
                """, String.class)).isEmpty();
    }
}
