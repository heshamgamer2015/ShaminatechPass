package com.shaminatech.pass;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.ResultActions;

import com.jayway.jsonpath.JsonPath;
import com.shaminatech.pass.establishment.Establishment;
import com.shaminatech.pass.loyalty.ProgramType;
import com.shaminatech.pass.loyalty.card.ExpirationProcessor;
import com.shaminatech.pass.membership.MembershipRole;

/** Apoio aos testes de fidelidade: dois estabelecimentos, cada um com sua conta empresarial. */
abstract class LoyaltyTestSupport extends IntegrationTestSupport {

    @Autowired
    protected ExpirationProcessor expiration;

    protected Establishment a;
    protected Establishment b;
    protected MockHttpSession ownerA;
    protected MockHttpSession ownerB;

    @BeforeEach
    void setUpTenants() throws Exception {
        a = establishment("loja-a");
        b = establishment("loja-b");
        policy(a, 100, ProgramType.STAMPS, ProgramType.POINTS, ProgramType.CASHBACK, ProgramType.VIP);
        policy(b, 100, ProgramType.STAMPS, ProgramType.POINTS, ProgramType.CASHBACK);
        member(a, user("dono.a@teste.local"), MembershipRole.OWNER);
        member(b, user("dono.b@teste.local"), MembershipRole.OWNER);
        ownerA = login("dono.a@teste.local");
        ownerB = login("dono.b@teste.local");
    }

    protected static String base(Establishment e) {
        return "/api/establishments/" + e.getId();
    }

    protected ResultActions postJson(MockHttpSession session, String url, String json) throws Exception {
        return mvc.perform(post(url).session(session).with(csrf()).contentType(MediaType.APPLICATION_JSON).content(json));
    }

    protected ResultActions postJson(MockHttpSession session, String url, String json, String idempotencyKey) throws Exception {
        return mvc.perform(post(url).session(session).with(csrf()).contentType(MediaType.APPLICATION_JSON)
                .header("Idempotency-Key", idempotencyKey).content(json));
    }

    protected String getJson(MockHttpSession session, String url) throws Exception {
        return mvc.perform(get(url).session(session)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
    }

    protected static long id(ResultActions result) throws Exception {
        return ((Number) JsonPath.read(result.andReturn().getResponse().getContentAsString(), "$.id")).longValue();
    }

    protected static <T> T read(ResultActions result, String path) throws Exception {
        return JsonPath.read(result.andReturn().getResponse().getContentAsString(), path);
    }

    protected static String key() {
        return UUID.randomUUID().toString();
    }

    protected long consumer(MockHttpSession session, Establishment e, String name, String phone) throws Exception {
        return id(postJson(session, base(e) + "/consumers",
                "{\"fullName\":\"" + name + "\",\"phone\":\"" + phone + "\",\"privacyAcknowledged\":true}")
                .andExpect(status().isCreated()));
    }

    protected static final String COMMON = "\"inactivityDays\":30,\"validityMode\":\"END_OF_DAY\","
            + "\"expiredBalancePolicy\":\"KEEP\",\"reversalPolicy\":\"REQUIRE_BALANCE\"";

    protected long program(MockHttpSession session, Establishment e, String json) throws Exception {
        return id(postJson(session, base(e) + "/programs", json).andExpect(status().isCreated()));
    }

    protected long stampsProgram(Establishment e, MockHttpSession session, int required, boolean restart) throws Exception {
        return program(session, e, "{\"type\":\"STAMPS\",\"name\":\"Café\"," + COMMON + ",\"stampsRequired\":" + required
                + ",\"stampCriterion\":\"VISIT\",\"stampReward\":\"Um café grátis\",\"restartAfterRedeem\":" + restart + "}");
    }

    protected long pointsProgram(Establishment e, MockHttpSession session, String extra) throws Exception {
        return program(session, e, "{\"type\":\"POINTS\",\"name\":\"Pontos\"," + COMMON
                + ",\"pointsPerUnit\":1,\"spendUnit\":1.00" + extra + "}");
    }

    protected long card(MockHttpSession session, Establishment e, long consumerId, long programId) throws Exception {
        return id(postJson(session, base(e) + "/cards", "{\"consumerId\":" + consumerId + ",\"programId\":" + programId + "}")
                .andExpect(status().isCreated()));
    }

    protected ResultActions earn(MockHttpSession session, Establishment e, long cardId, String json, String key) throws Exception {
        return postJson(session, base(e) + "/cards/" + cardId + "/earn", json, key);
    }

    protected ResultActions redeem(MockHttpSession session, Establishment e, long cardId, String json, String key) throws Exception {
        return postJson(session, base(e) + "/cards/" + cardId + "/redeem", json, key);
    }

    protected BigDecimal balance(MockHttpSession session, Establishment e, long cardId) throws Exception {
        Object value = JsonPath.read(getJson(session, base(e) + "/cards/" + cardId), "$.card.balance");
        return new BigDecimal(value.toString());
    }

    protected String cardField(MockHttpSession session, Establishment e, long cardId, String field) throws Exception {
        Object value = JsonPath.read(getJson(session, base(e) + "/cards/" + cardId), "$.card." + field);
        return value == null ? null : value.toString();
    }

    protected int countTransactions(long cardId, String type) {
        Integer n = jdbc.queryForObject("select count(*) from card_transaction where card_id = ? and type = ?", Integer.class,
                cardId, type);
        return n == null ? 0 : n;
    }
}
