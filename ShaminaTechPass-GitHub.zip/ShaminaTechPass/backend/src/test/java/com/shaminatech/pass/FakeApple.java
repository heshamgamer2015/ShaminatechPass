package com.shaminatech.pass;

import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.X500NameBuilder;
import org.bouncycastle.asn1.x500.style.BCStyle;
import org.bouncycastle.asn1.x509.BasicConstraints;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import com.sun.net.httpserver.HttpServer;

/**
 * Apple SIMULADA para os testes: gera na hora uma autoridade "WWDR" falsa e um certificado Pass Type ID de teste
 * (nada disso é credencial real) e sobe um APNs local que registra as notificações recebidas.
 */
final class FakeApple {

    static final String PASS_TYPE_ID = "pass.test.shaminatech.fidelidade";
    static final String TEAM_ID = "TESTTEAM12";
    static final String P12_PASSWORD = "senha-de-teste";

    record Push(String token, String topic, String body) {
    }

    private static FakeApple instance;

    final List<Push> pushes = new CopyOnWriteArrayList<>();
    private final Deque<Integer> nextStatuses = new ArrayDeque<>();
    private final HttpServer server;
    private final Path p12;
    private final Path wwdrFile;
    private final X509Certificate leaf;
    private final X509Certificate wwdr;

    static synchronized FakeApple get() {
        if (instance == null) {
            try {
                instance = new FakeApple();
            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
        }
        return instance;
    }

    private FakeApple() throws Exception {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048);
        KeyPair caKeys = generator.generateKeyPair();
        KeyPair passKeys = generator.generateKeyPair();
        Instant now = Instant.now();
        X500Name caName = new X500Name("CN=Fake Apple WWDR CA G4 (somente testes), O=Teste");
        wwdr = new JcaX509CertificateConverter().getCertificate(new JcaX509v3CertificateBuilder(caName, BigInteger.ONE,
                Date.from(now.minus(1, ChronoUnit.DAYS)), Date.from(now.plus(365, ChronoUnit.DAYS)), caName, caKeys.getPublic())
                .addExtension(Extension.basicConstraints, true, new BasicConstraints(true))
                .build(new JcaContentSignerBuilder("SHA256withRSA").build(caKeys.getPrivate())));
        X500Name subject = new X500NameBuilder(BCStyle.INSTANCE)
                .addRDN(BCStyle.UID, PASS_TYPE_ID)
                .addRDN(BCStyle.CN, "Pass Type ID: " + PASS_TYPE_ID)
                .addRDN(BCStyle.OU, TEAM_ID)
                .addRDN(BCStyle.O, "Teste")
                .build();
        leaf = new JcaX509CertificateConverter().getCertificate(new JcaX509v3CertificateBuilder(caName, BigInteger.TWO,
                Date.from(now.minus(1, ChronoUnit.DAYS)), Date.from(now.plus(365, ChronoUnit.DAYS)), subject, passKeys.getPublic())
                .build(new JcaContentSignerBuilder("SHA256withRSA").build(caKeys.getPrivate())));
        Path dir = Files.createTempDirectory("fake-apple");
        p12 = dir.resolve("pass-type-id-teste.p12");
        KeyStore store = KeyStore.getInstance("PKCS12");
        store.load(null, null);
        store.setKeyEntry("pass", passKeys.getPrivate(), P12_PASSWORD.toCharArray(), new X509Certificate[] {leaf, wwdr});
        try (OutputStream out = Files.newOutputStream(p12)) {
            store.store(out, P12_PASSWORD.toCharArray());
        }
        wwdrFile = dir.resolve("fake-wwdr.cer");
        Files.write(wwdrFile, wwdr.getEncoded());
        p12.toFile().deleteOnExit();
        wwdrFile.toFile().deleteOnExit();

        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/3/device/", exchange -> {
            String token = exchange.getRequestURI().getPath().substring("/3/device/".length());
            String body;
            try (InputStream in = exchange.getRequestBody()) {
                body = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
            pushes.add(new Push(token, exchange.getRequestHeaders().getFirst("apns-topic"), body));
            Integer status;
            synchronized (nextStatuses) {
                status = nextStatuses.poll();
            }
            int code = status == null ? 200 : status;
            byte[] response = code == 200 ? new byte[0]
                    : ("{\"reason\":\"" + (code == 410 ? "Unregistered" : "ServiceUnavailable") + "\"}").getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(code, response.length == 0 ? -1 : response.length);
            if (response.length > 0) {
                exchange.getResponseBody().write(response);
            }
            exchange.close();
        });
        server.start();
    }

    void reset() {
        pushes.clear();
        synchronized (nextStatuses) {
            nextStatuses.clear();
        }
    }

    /** Próximas respostas do APNs (uma por notificação). */
    void respondNext(Integer... statuses) {
        synchronized (nextStatuses) {
            nextStatuses.addAll(List.of(statuses));
        }
    }

    String apnsUrl() {
        return "http://127.0.0.1:" + server.getAddress().getPort();
    }

    Path p12() {
        return p12;
    }

    Path wwdrFile() {
        return wwdrFile;
    }

    X509Certificate leaf() {
        return leaf;
    }

    X509Certificate wwdr() {
        return wwdr;
    }
}
