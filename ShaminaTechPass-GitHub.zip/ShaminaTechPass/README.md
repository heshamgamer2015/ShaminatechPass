# ShaminaTech Pass

Plataforma Micro SaaS multiempresa de fidelidade digital para estabelecimentos comerciais.

> **Status:** Etapa 1 — fundação do sistema (multiempresa, autenticação, painéis ShaminaTech e do estabelecimento).
> Fidelidade, carteiras digitais e planos ainda **não** foram implementados.

## Estrutura

```
ShaminatechPass/
├── backend/    Spring Boot 4.1.2 · Java 17 · Maven · Spring Security · Spring Data JPA  (porta 8083)
├── frontend/   Angular 22 · TypeScript · npm                                            (porta 4203, proxy /api → 8083)
└── sql/        Scripts SQL de execução manual (criação do banco)
```

| Ferramenta | Versão |
|---|---|
| Java (Temurin) | 17.0.18 |
| Maven | 3.9.12 |
| Node.js / npm | 24.21.0 / 11.5.2 |
| Angular CLI | 22.2 (local ao projeto, via `npx ng`) |
| PostgreSQL | 17.9 (serviço Windows `postgresql-x64-17`, porta 5432) |

## Banco de dados e perfis

| Perfil | `ddl-auto` | Uso |
|---|---|---|
| *(padrão)* | `validate` | Seguro: apenas confere o schema. |
| `local` | `update` | Desenvolvimento: o Hibernate **cria** tabelas/colunas novas a partir das entidades. Nunca remove tabelas ou colunas; DDL com falha interrompe a inicialização (`halt_on_error`). |
| `prod` | `validate` | Produção. **Nunca** usar `update`. |

- Sem Flyway/Liquibase; sem `create`/`create-drop` no banco de desenvolvimento.
- Testes automatizados usam H2 em memória (modo PostgreSQL) e **nunca** tocam o banco `shaminatech_pass`.
- O banco e o usuário são criados uma única vez pelo responsável: `sql/000_create_database.sql`.

### Credenciais locais (nunca versionadas)

Copie `backend/src/main/resources/application-credentials.yml.example` para `application-credentials.yml`
(mesma pasta, ignorado pelo Git) e preencha: conexão do banco e, opcionalmente, o primeiro administrador
da plataforma (`shaminatech.bootstrap.admin.*`). Alternativa: variáveis `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`,
`BOOTSTRAP_ADMIN_EMAIL`, `BOOTSTRAP_ADMIN_PASSWORD`.

O administrador inicial só é criado se ainda não existir nenhum, e precisa trocar a senha no primeiro acesso.

## Como executar

**Backend — IntelliJ IDEA:** *File → Open* → pasta `backend/`. Use a configuração de execução
**ShaminaTechPassApplication (local)** (já versionada em `backend/.run/`, com o perfil `local` ativo).

Linha de comando (alternativa):
```bash
mvn -f backend/pom.xml spring-boot:run -Dspring-boot.run.profiles=local
```

**Frontend:**
```bash
cd frontend
npm install
npx ng serve
```
Abra http://localhost:4203.

## Testes

```bash
mvn -f backend/pom.xml test
```
```bash
mvn -f backend/pom.xml test -Dtest=PostgresSchemaIT -Dpass.pg-it=true
```
(o segundo valida as entidades contra o PostgreSQL local real, com `validate` e transação desfeita ao final)
```bash
cd frontend && npx ng test --watch=false
```

## Arquitetura

### Multiempresa (multi-tenant)
Banco e schema compartilhados, com isolamento por **coluna de tenant** (`establishment_id`).

- `TenantAccessService.require(establishmentId, permissão)` é o ponto único de isolamento: confere vínculo
  **ativo** do usuário logado, estabelecimento **ativo** e permissão do papel. Todo serviço do painel do
  estabelecimento começa por essa chamada.
- Repositórios de dados do tenant só buscam **por estabelecimento + id** (ex.: `findInEstablishment`), então
  trocar um id na URL por um de outro estabelecimento resulta em 404.
- Administradores da plataforma **não** têm acesso implícito aos painéis dos estabelecimentos; usam `/api/admin`.

### Autenticação e autorização
- Sessão no servidor com cookie `STPASS_SESSION` (HttpOnly, SameSite=Lax; `Secure` em produção). Nenhum token no `localStorage`.
- CSRF obrigatório em requisições que alteram dados (cookie `XSRF-TOKEN` + cabeçalho `X-XSRF-TOKEN`, suportado nativamente pelo Angular).
- Senhas com BCrypt (`DelegatingPasswordEncoder`), política mínima (10+ caracteres, letras e números, ≤ 72 bytes).
- Bloqueio temporário após falhas consecutivas (padrão: 5 falhas → 15 min); mensagem de erro genérica (não revela se o e-mail existe).
- Senha temporária com troca obrigatória no primeiro acesso, aplicada no **backend**.
- A cada requisição autenticada o usuário é revalidado no banco: desativação ou mudança de papel encerram a sessão na hora.
- `/api/admin/**` → apenas `PLATFORM_ADMIN`. Tudo que não está mapeado é negado.

### Papéis e permissões
| Permissão | Proprietário | Gerente | Funcionário |
|---|:-:|:-:|:-:|
| `ESTABLISHMENT_VIEW` | ✔ | ✔ | ✔ |
| `ESTABLISHMENT_EDIT` | ✔ | | |
| `MEMBERS_VIEW` | ✔ | ✔ | |
| `MEMBERS_MANAGE` | ✔ | | |
| `AUDIT_VIEW` | ✔ | | |

Gravadas nas tabelas `permission` / `role_permission` na inicialização (só inserções; ajustes manuais são preservados).

### Tabelas (geradas pelo Hibernate no perfil `local`)
`establishment` · `app_user` · `membership` (usuário ↔ estabelecimento + papel) · `permission` · `role_permission` · `audit_event`.
Enums são gravados como texto legível (`EnumNameConverter`). Atenção: o conversor sozinho **não** impede o Hibernate 7 de gerar `CHECK (coluna IN (...))`; quem impede é `EnumWithoutCheckJavaType`, registrado automaticamente para todos os enums da aplicação (`EnumCheckFreeTypeContributor`). Assim, novos valores não exigem alteração manual do banco. As CHECKs criadas antes desta correção são removidas por `sql/001_etapa2_remove_enum_checks.sql`.

### Frontend
```
src/app/
├── core/       api (serviços HTTP, interceptor de erros), auth (sessão, guards), models, notificações
├── shared/     componentes reutilizáveis (cabeçalho, alerta, selo, tabela de auditoria, paginação, toasts…)
├── layout/     shell responsivo (menu lateral / gaveta no celular)
└── features/   auth · admin (painel ShaminaTech) · establishment (painel do estabelecimento) · errors
```
Guards e menus servem à experiência de uso; a autorização real é sempre do backend.

## Endpoints

| Método | Caminho | Acesso |
|---|---|---|
| GET | `/api/health` | público |
| GET | `/api/auth/csrf` | público |
| POST | `/api/auth/login` | público |
| POST | `/api/auth/logout` | autenticado |
| GET | `/api/auth/me` | autenticado |
| POST | `/api/auth/change-password` | autenticado |
| GET/POST | `/api/admin/establishments` | admin |
| GET | `/api/admin/establishments/{id}` | admin |
| PATCH | `/api/admin/establishments/{id}/status` | admin |
| GET | `/api/admin/users` | admin |
| PATCH | `/api/admin/users/{id}/status` | admin |
| POST | `/api/admin/users/{id}/unlock` | admin |
| GET | `/api/admin/audit` | admin |
| GET/PUT | `/api/establishments/{id}` | vínculo + `ESTABLISHMENT_VIEW` / `_EDIT` |
| GET/POST | `/api/establishments/{id}/members` | vínculo + `MEMBERS_VIEW` / `_MANAGE` |
| PATCH | `/api/establishments/{id}/members/{membershipId}` | vínculo + `MEMBERS_MANAGE` |
| GET | `/api/establishments/{id}/audit` | vínculo + `AUDIT_VIEW` |

Erros seguem RFC 9457 (`application/problem+json`) com `code`, `detail` e `errors[]` por campo.

## Google Wallet (Etapa 3)

Integração real com a API REST oficial (`walletobjects/v1`), sem SDK adicional (HTTP do JDK + RS256):

- **Emissor único (ShaminaTech)**, uma `LoyaltyClass` por programa (`{issuer}.stp_prog_{id}`) com o nome, cor, logotipo e
  destaque do estabelecimento, e um `LoyaltyObject` por cartão (`{issuer}.stp_card_{id}_{aleatório}`).
- **Saldo**: pontos (`int`), cashback (`money`, BRL, micros) e carimbos (`"3 de 10"`). VIP continua não operacional.
- **Estados**: ativo → `ACTIVE`; desativado → `INACTIVE`; expirado por inatividade → `EXPIRED` (+ `validTimeInterval`);
  carimbos concluídos → `COMPLETED`; cancelado → `INACTIVE` e o passe deixa de ser sincronizado.
- **Sincronização confiável**: a movimentação marca o passe como pendente na mesma transação; o envio ao Google ocorre depois
  do commit, fora de transação, com reserva (FOR UPDATE + prazo), tentativas com espera crescente, varredura a cada minuto e
  reenvio manual. Falhas do Google nunca desfazem nem duplicam movimentações.
- **Distribuição**: link `/carteira/{token}` (128 bits, guardado só como SHA-256, expira em 3 dias, revogável, limite de
  requisições por IP). A página pública mostra só estabelecimento, programa e primeiro nome, e o botão abre
  `https://pay.google.com/gp/v/save/{JWT}` assinado no servidor.
- **Imagens**: o Google baixa logotipo/destaque pela internet: `GET /api/public/images/{token aleatório}` exige
  `shaminatech.wallet.google.public-base-url` (HTTPS público) ou `fallback-logo-uri`.

Configuração: ver `application-credentials.yml.example`. Testes: `GoogleWalletSimulatedTest` usa um servidor local que imita a
API (não chama o Google). O teste real exige credenciais, conta de teste e um Android.
