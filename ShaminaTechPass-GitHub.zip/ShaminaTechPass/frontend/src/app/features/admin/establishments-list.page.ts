import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { ApiError, toApiError } from '../../core/api/api-error';
import { AdminApi } from '../../core/api/admin-api.service';
import { EstablishmentStatus, EstablishmentSummary, Page } from '../../core/models';
import { AlertComponent } from '../../shared/ui/alert.component';
import { EmptyStateComponent } from '../../shared/ui/empty-state.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { PagerComponent } from '../../shared/ui/pager.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';

@Component({
  selector: 'app-establishments-list-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe, FormsModule, RouterLink, AlertComponent, EmptyStateComponent, IconComponent, PageHeaderComponent,
    PagerComponent, SpinnerComponent, StatusBadgeComponent],
  template: `
    <app-page-header title="Estabelecimentos" subtitle="Contas de clientes da plataforma, uso do limite e situação.">
      <a class="btn btn-primary" routerLink="novo"><app-icon name="plus" /> Novo estabelecimento</a>
    </app-page-header>

    @if (totals(); as t) {
      <section class="stats totals" aria-label="Totais por situação">
        <button type="button" class="stat" [class.sel]="status === ''" (click)="filterStatus('')">
          <span class="stat-label">Todos</span><span class="stat-value">{{ t.all }}</span></button>
        <button type="button" class="stat" [class.sel]="status === 'ACTIVE'" (click)="filterStatus('ACTIVE')">
          <span class="stat-label">Ativos</span><span class="stat-value">{{ t.active }}</span></button>
        <button type="button" class="stat" [class.sel]="status === 'SUSPENDED'" (click)="filterStatus('SUSPENDED')">
          <span class="stat-label">Suspensos</span><span class="stat-value">{{ t.suspended }}</span></button>
        <button type="button" class="stat" [class.sel]="status === 'CANCELLED'" (click)="filterStatus('CANCELLED')">
          <span class="stat-label">Cancelados</span><span class="stat-value">{{ t.cancelled }}</span></button>
      </section>
    }

    <form class="toolbar" (ngSubmit)="search(0)" role="search">
      <input class="input" type="search" name="q" [(ngModel)]="query" placeholder="Buscar por nome ou identificador" aria-label="Buscar" />
      <select class="select" name="status" [(ngModel)]="status" (ngModelChange)="search(0)" aria-label="Situação">
        <option value="">Todas as situações</option>
        <option value="ACTIVE">Ativos</option>
        <option value="SUSPENDED">Suspensos</option>
        <option value="CANCELLED">Cancelados</option>
      </select>
      <button class="btn" type="submit"><app-icon name="search" /> Buscar</button>
    </form>

    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (!result()) {
      <app-spinner />
    } @else if (result()!.content.length === 0) {
      <app-empty-state icon="building" title="Nenhum estabelecimento encontrado"
        [description]="query || status ? 'Nenhum resultado para a busca. Ajuste os filtros.' : 'Cadastre o primeiro cliente da plataforma.'" />
    } @else {
      <div class="table-wrap">
        <table class="table responsive">
          <thead>
            <tr><th>Estabelecimento</th><th>Situação</th><th>Plano</th><th>Uso do limite de clientes</th><th class="num">Cartões ativos</th><th>Criado em</th><th><span class="sr-only">Ações</span></th></tr>
          </thead>
          <tbody>
            @for (e of result()!.content; track e.id) {
              <tr>
                <td data-label="Estabelecimento">
                  <span class="name"><a [routerLink]="[e.id]"><strong>{{ e.name }}</strong></a>
                    <span class="muted small mono">{{ e.slug }}</span></span>
                </td>
                <td data-label="Situação"><app-badge [value]="e.status" /></td>
                <td data-label="Plano">
                  @if (e.plan; as p) {
                    <strong>{{ p.name }}</strong>
                    @if (p.selfSignup) { <span class="badge tone-info">Autocadastro</span> }
                    @if (p.trialFree) { <span class="muted small">grátis (testes)</span> }
                  } @else {
                    <span class="muted small">Definido pela ShaminaTech</span>
                  }
                </td>
                <td data-label="Uso do limite">
                  <span class="usage">
                    <span class="num">{{ e.usage.activeConsumers }} / {{ e.plan?.code === 'PRO' ? 'ilimitado' : e.usage.maxActiveConsumers }}</span>
                    <span class="meter" aria-hidden="true"><span [style.width.%]="usage(e)" [class.warn]="usage(e) >= 80 && usage(e) < 100"
                          [class.full]="usage(e) >= 100"></span></span>
                    @if (usage(e) >= 100) {
                      <span class="badge tone-danger">Limite atingido</span>
                    } @else if (usage(e) >= 80) {
                      <span class="badge tone-warning">Perto do limite</span>
                    }
                  </span>
                </td>
                <td data-label="Cartões ativos" class="num">{{ e.usage.activeCards }}</td>
                <td data-label="Criado em">{{ e.createdAt | date: 'dd/MM/yyyy' }}</td>
                <td class="cell-actions"><a class="btn btn-sm" [routerLink]="[e.id]">Abrir <app-icon name="chevron-right" [size]="16" /></a></td>
              </tr>
            }
          </tbody>
        </table>
      </div>
      <app-pager [page]="result()!.page" [totalPages]="result()!.totalPages" (pageChange)="search($event)" />
    }
  `,
  styles: `
    .name {
      display: grid;
    }
    .name a {
      color: var(--text);
      text-decoration: none;
    }
    .name a:hover {
      color: var(--primary-ink);
    }
    .totals {
      margin-bottom: 1rem;
    }
    .totals .stat {
      border: 0;
      background: none;
      font: inherit;
      text-align: left;
      cursor: pointer;
    }
    .totals .stat:hover {
      background: var(--surface-muted);
    }
    .totals .stat.sel {
      background: var(--primary-soft);
    }
    .totals .stat.sel .stat-label {
      color: var(--primary-ink);
    }
    .usage {
      display: inline-grid;
      grid-template-columns: auto 90px auto;
      align-items: center;
      gap: 0.6rem;
    }
    @media (max-width: 720px) {
      .usage {
        grid-template-columns: auto 60px;
      }
    }
  `,
})
export class EstablishmentsListPage {
  private readonly api = inject(AdminApi);

  protected query = '';
  protected status: EstablishmentStatus | '' = '';
  protected readonly result = signal<Page<EstablishmentSummary> | null>(null);
  protected readonly error = signal<ApiError | null>(null);

  constructor() {
    this.search(0);
    this.loadTotals();
  }

  /** Totais por situação, a partir do total de registros de cada consulta (não da página atual). */
  protected readonly totals = signal<{ all: number; active: number; suspended: number; cancelled: number } | null>(null);

  protected filterStatus(status: EstablishmentStatus | ''): void {
    this.status = status;
    this.search(0);
  }

  private loadTotals(): void {
    forkJoin({
      all: this.api.establishments('', '', 0),
      active: this.api.establishments('', 'ACTIVE', 0),
      suspended: this.api.establishments('', 'SUSPENDED', 0),
      cancelled: this.api.establishments('', 'CANCELLED', 0),
    }).subscribe({
      next: (r) => this.totals.set({ all: r.all.totalElements, active: r.active.totalElements, suspended: r.suspended.totalElements,
        cancelled: r.cancelled.totalElements }),
      error: () => this.totals.set(null),
    });
  }

  /** Percentual do limite de clientes ativos em uso (limite 0 = sem vagas). */
  protected usage(e: EstablishmentSummary): number {
    const max = e.usage.maxActiveConsumers;
    if (max <= 0) return 100;
    return Math.min(100, Math.round((e.usage.activeConsumers / max) * 100));
  }

  protected search(page: number): void {
    this.error.set(null);
    this.api.establishments(this.query, this.status, page).subscribe({
      next: (r) => this.result.set(r),
      error: (e) => this.error.set(toApiError(e)),
    });
  }
}
