import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { AdminApi, AppleHomologationPass, AppleHomologationStatus } from '../../core/api/admin-api.service';
import { toApiError } from '../../core/api/api-error';
import { NotificationService } from '../../core/notifications/notification.service';
import { AlertComponent } from '../../shared/ui/alert.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';

const LOOPBACK = /^(localhost|127\.\d+\.\d+\.\d+|\[?::1\]?|0\.0\.0\.0)$/i;

/**
 * Apple Wallet — Homologação (painel ShaminaTech, ambiente local). Gera um cartão de demonstração estático, assinado
 * com o certificado oficial, e mostra o QR Code com o endereço da rede local para instalar no iPhone.
 */
@Component({
  selector: 'app-apple-homologation-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe, AlertComponent, IconComponent, PageHeaderComponent, SpinnerComponent],
  template: `
    <app-page-header title="Apple Wallet — Homologação"
                     subtitle="Cartão de demonstração da ShaminaTech para testar a instalação na Carteira do iPhone" />

    @if (unavailable()) {
      <app-alert kind="info">A homologação Apple Wallet só está disponível no ambiente local de desenvolvimento.</app-alert>
    } @else if (loadError(); as e) {
      <app-alert kind="error">{{ e }}</app-alert>
    } @else if (status(); as s) {
      <section class="card">
        <div class="head">
          <h2>Certificado oficial</h2>
          <span class="pill" [class.ok]="s.ready" [class.bad]="!s.ready">
            <app-icon [name]="s.ready ? 'check-circle' : 'alert'" [size]="14" />{{ s.ready ? 'Carregado' : 'Indisponível' }}
          </span>
        </div>
        <dl class="details">
          <dt>Pass Type ID</dt><dd class="mono">{{ s.certificate.passTypeIdentifier ?? '—' }}</dd>
          <dt>Team ID</dt><dd class="mono">{{ s.certificate.teamIdentifier ?? '—' }}</dd>
          @if (s.certificate.loaded) {
            <dt>Emitido por</dt><dd>{{ s.certificate.issuer }}</dd>
            <dt>Válido até</dt><dd>{{ s.certificate.expiresAt | date: 'dd/MM/yyyy' }}</dd>
          }
        </dl>
        @if (s.certificate.error; as err) {
          <app-alert kind="error">{{ err }}</app-alert>
        }
        @for (m of s.missing; track m) {
          <app-alert kind="warning">{{ m }}</app-alert>
        }
      </section>

      <section class="card">
        <div class="head">
          <h2>Cartão de demonstração</h2>
          <button class="btn btn-primary" type="button" [disabled]="!s.ready || generating()" (click)="generate()">
            <app-icon name="refresh" [size]="16" />
            {{ generating() ? 'Gerando…' : pass() ? 'Gerar novo cartão de demonstração' : 'Gerar cartão de demonstração' }}
          </button>
        </div>
        <p class="note info"><app-icon name="info" [size]="16" />
          <span>Demonstração <strong>estática</strong> com dados fictícios da ShaminaTech: o cartão não recebe atualizações
            automáticas (sem servidor público HTTPS). Não é apresentado aos estabelecimentos.</span></p>

        @if (generateError(); as e) {
          <app-alert kind="error">{{ e }}</app-alert>
        }

        @if (pass(); as p) {
          @if (expired()) {
            <app-alert kind="warning">O link de instalação expirou. Gere um novo cartão de demonstração.</app-alert>
          } @else {
            <div class="body">
              <figure class="qr">
                @if (host()) {
                  <img [src]="qrSrc()" alt="QR Code para instalar o cartão de demonstração no iPhone" width="240" height="240" />
                } @else {
                  <span class="muted small">Nenhum endereço de rede local encontrado.</span>
                }
              </figure>
              <div class="info">
                <ol class="steps">
                  <li>Conecte o iPhone à <strong>mesma rede Wi-Fi</strong> deste computador.</li>
                  <li>Abra a <strong>Câmera</strong> e aponte para o QR Code.</li>
                  <li>Toque no aviso para abrir no Safari e depois em <strong>Adicionar</strong>.</li>
                </ol>
                @if (s.lanAddresses.length > 1 && isLoopbackPage) {
                  <label class="muted small" for="lan">Endereço da rede local</label>
                  <select id="lan" class="input" [value]="host()" (change)="pickHost($event)">
                    @for (ip of s.lanAddresses; track ip) {
                      <option [value]="ip">{{ ip }}</option>
                    }
                  </select>
                }
                <label class="muted small" for="install-url">Endereço de instalação</label>
                <div class="url">
                  <input #urlInput class="input mono" id="install-url" [value]="installUrl()" readonly (focus)="urlInput.select()" />
                  <button class="btn btn-sm" type="button" (click)="copy(urlInput)"><app-icon name="copy" [size]="14" />Copiar link</button>
                </div>
                <dl class="details">
                  <dt>Link válido por</dt><dd><strong>{{ remaining() }}</strong> (até {{ p.expiresAt | date: 'HH:mm:ss' }})</dd>
                  <dt>Número de série</dt><dd class="mono">{{ p.serialNumber }}</dd>
                  <dt>Tamanho</dt><dd>{{ (p.sizeBytes / 1024).toFixed(1) }} KB</dd>
                </dl>
                <p class="muted small">O prazo vale só para o link de download. Depois de adicionado, o cartão continua na Carteira.</p>
                <div class="actions">
                  <a class="btn" [href]="p.installPath" download="shaminatech-pass-demonstracao.pkpass">
                    <app-icon name="download" [size]="16" />Baixar cartão</a>
                </div>
              </div>
            </div>
          }
        }
      </section>
    } @else {
      <app-spinner />
    }
  `,
  styles: `
    .card {
      display: grid;
      gap: 0.75rem;
      margin-bottom: 1rem;
    }
    .head {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      gap: 0.75rem;
    }
    .head h2 {
      margin: 0;
    }
    .pill {
      display: inline-flex;
      align-items: center;
      gap: 0.3rem;
      padding: 0.2rem 0.6rem;
      border-radius: 999px;
      font-size: 0.8rem;
      font-weight: 600;
    }
    .pill.ok {
      background: color-mix(in srgb, var(--success) 14%, transparent);
      color: var(--success);
    }
    .pill.bad {
      background: color-mix(in srgb, var(--danger, #dc2626) 14%, transparent);
      color: var(--danger, #dc2626);
    }
    .details {
      display: grid;
      grid-template-columns: max-content minmax(0, 1fr);
      gap: 0.35rem 1rem;
      margin: 0;
    }
    .details dt {
      color: var(--text-muted);
    }
    .details dd {
      margin: 0;
      overflow-wrap: anywhere;
    }
    .body {
      display: grid;
      grid-template-columns: auto minmax(0, 1fr);
      gap: 1.25rem;
      align-items: start;
    }
    @media (max-width: 700px) {
      .body {
        grid-template-columns: 1fr;
        justify-items: center;
      }
    }
    .qr {
      display: grid;
      place-items: center;
      width: 256px;
      height: 256px;
      margin: 0;
      border: 1px solid var(--border);
      border-radius: var(--radius);
      background: #fff;
    }
    .qr img {
      display: block;
      width: 240px;
      height: 240px;
    }
    .info {
      display: grid;
      gap: 0.6rem;
      width: 100%;
    }
    .steps {
      margin: 0;
      padding-left: 1.2rem;
      display: grid;
      gap: 0.25rem;
    }
    .url {
      display: flex;
      gap: 0.5rem;
    }
    .url .input {
      flex: 1;
      min-width: 0;
      font-size: 0.8rem;
    }
    .actions {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
    }
  `,
})
export class AppleHomologationPage {
  private readonly api = inject(AdminApi);
  private readonly notifications = inject(NotificationService);

  protected readonly status = signal<AppleHomologationStatus | null>(null);
  protected readonly loadError = signal<string | null>(null);
  protected readonly unavailable = signal(false);
  protected readonly pass = signal<AppleHomologationPass | null>(null);
  protected readonly generating = signal(false);
  protected readonly generateError = signal<string | null>(null);
  private readonly now = signal(Date.now());
  private readonly chosenHost = signal<string | null>(null);

  /** Página aberta por localhost: o iPhone precisa do IP da rede, então usamos o endereço informado pelo backend. */
  protected readonly isLoopbackPage = LOOPBACK.test(window.location.hostname);

  protected readonly host = computed(() => {
    if (!this.isLoopbackPage) return window.location.hostname;
    return this.chosenHost() ?? this.status()?.lanAddresses[0] ?? null;
  });

  protected readonly installUrl = computed(() => {
    const p = this.pass();
    const host = this.host();
    if (!p || !host) return '';
    const port = window.location.port ? `:${window.location.port}` : '';
    return `${window.location.protocol}//${host}${port}${p.installPath}`;
  });

  protected readonly qrSrc = computed(() => this.api.appleHomologationQrUrl(this.installUrl()));

  private readonly msLeft = computed(() => {
    const p = this.pass();
    return p ? new Date(p.expiresAt).getTime() - this.now() : 0;
  });
  protected readonly expired = computed(() => this.pass() !== null && this.msLeft() <= 0);
  protected readonly remaining = computed(() => {
    const s = Math.max(0, Math.floor(this.msLeft() / 1000));
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')} min`;
  });

  constructor() {
    const timer = setInterval(() => this.now.set(Date.now()), 1000);
    inject(DestroyRef).onDestroy(() => clearInterval(timer));
    this.api.appleHomologation().subscribe({
      next: (s) => this.status.set(s),
      error: (e) => {
        const err = toApiError(e);
        if (err.status === 404) this.unavailable.set(true);
        else this.loadError.set(err.message);
      },
    });
  }

  protected generate(): void {
    this.generating.set(true);
    this.generateError.set(null);
    this.api.generateAppleHomologationPass().subscribe({
      next: (p) => {
        this.generating.set(false);
        this.now.set(Date.now());
        this.pass.set(p);
        this.notifications.success('Cartão de demonstração gerado. Escaneie o QR Code com o iPhone.');
      },
      error: (e) => {
        this.generating.set(false);
        this.generateError.set(toApiError(e).message);
      },
    });
  }

  protected pickHost(event: Event): void {
    this.chosenHost.set((event.target as HTMLSelectElement).value);
  }

  /** Copia o link; em http pela rede (sem Clipboard API) usa a seleção do campo. */
  protected copy(input: HTMLInputElement): void {
    const done = () => this.notifications.success('Link copiado.');
    const fallback = () => {
      input.select();
      // eslint-disable-next-line @typescript-eslint/no-deprecated
      if (document.execCommand('copy')) done();
      else this.notifications.error('Não foi possível copiar; selecione o endereço e copie manualmente.');
    };
    if (navigator.clipboard?.writeText) navigator.clipboard.writeText(input.value).then(done, fallback);
    else fallback();
  }
}
