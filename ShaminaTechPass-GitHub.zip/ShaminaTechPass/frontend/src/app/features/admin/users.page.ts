import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { IconComponent } from '../../shared/ui/icon.component';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { FormsModule } from '@angular/forms';
import { ApiError, toApiError } from '../../core/api/api-error';
import { AdminApi } from '../../core/api/admin-api.service';
import { AuthService } from '../../core/auth/auth.service';
import { Page, UserSummary } from '../../core/models';
import { NotificationService } from '../../core/notifications/notification.service';
import { AlertComponent } from '../../shared/ui/alert.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { PagerComponent } from '../../shared/ui/pager.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';

@Component({
  selector: 'app-users-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe, FormsModule, AlertComponent, IconComponent, PageHeaderComponent, PagerComponent, SpinnerComponent, StatusBadgeComponent],
  template: `
    <app-page-header title="Usuários" subtitle="Todas as contas de acesso da plataforma." />

    <form class="toolbar" (ngSubmit)="load(0)" role="search">
      <input class="input" type="search" name="q" [(ngModel)]="query" placeholder="Buscar por nome ou e-mail" aria-label="Buscar" />
      <button class="btn" type="submit"><app-icon name="search" /> Buscar</button>
    </form>

    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (result(); as r) {
      <div class="table-wrap">
        <table class="table responsive">
          <thead>
            <tr><th>Usuário</th><th>Perfil</th><th>Situação</th><th>Último acesso</th><th><span class="sr-only">Ações</span></th></tr>
          </thead>
          <tbody>
            @for (u of r.content; track u.id) {
              <tr>
                <td data-label="Usuário">
                  <span class="person">
                    <span class="initial" aria-hidden="true">{{ u.fullName.charAt(0) }}</span>
                    <span class="person-text"><strong>{{ u.fullName }}</strong><span class="person-sub">{{ u.email }}</span></span>
                  </span>
                </td>
                <td data-label="Perfil">
                  @if (u.platformRole) {
                    <app-badge [value]="u.platformRole" labelText="Admin ShaminaTech" />
                  } @else {
                    <span class="muted">Estabelecimento</span>
                  }
                </td>
                <td data-label="Situação">
                  <app-badge [value]="u.status" />
                  @if (u.locked) {
                    <app-badge value="LOCKED" labelText="Bloqueado" />
                  }
                </td>
                <td data-label="Último acesso">{{ u.lastLoginAt ? (u.lastLoginAt | date: 'dd/MM/yyyy HH:mm') : '—' }}</td>
                <td class="cell-actions">
                  @if (u.id !== auth.user()?.id) {
                    <div class="actions row-actions">
                      @if (u.locked) {
                        <button class="btn btn-sm" type="button" (click)="unlock(u)">Desbloquear</button>
                      }
                      @if (u.status === 'ACTIVE') {
                        <button class="btn btn-sm btn-danger" type="button" (click)="toggle(u)">Desativar</button>
                      } @else {
                        <button class="btn btn-sm" type="button" (click)="toggle(u)">Reativar</button>
                      }
                    </div>
                  } @else {
                    <span class="muted">Você</span>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>
      <app-pager [page]="r.page" [totalPages]="r.totalPages" (pageChange)="load($event)" />
    } @else {
      <app-spinner />
    }
  `,
})
export class UsersPage {
  private readonly api = inject(AdminApi);
  private readonly notifications = inject(NotificationService);
  private readonly dialogs = inject(ConfirmService);
  protected readonly auth = inject(AuthService);

  protected query = '';
  protected readonly result = signal<Page<UserSummary> | null>(null);
  protected readonly error = signal<ApiError | null>(null);

  constructor() {
    this.load(0);
  }

  protected load(page: number): void {
    this.error.set(null);
    this.api.users(this.query, page).subscribe({
      next: (r) => this.result.set(r),
      error: (e) => this.error.set(toApiError(e)),
    });
  }

  protected async toggle(user: UserSummary): Promise<void> {
    const next = user.status === 'ACTIVE' ? 'DISABLED' : 'ACTIVE';
    if (
      next === 'DISABLED' &&
      !(await this.dialogs.confirm({
        title: `Desativar ${user.fullName}?`,
        message: 'O acesso será encerrado imediatamente.',
        confirmLabel: 'Desativar',
        tone: 'danger',
      }))
    ) {
      return;
    }
    this.api.changeUserStatus(user.id, next).subscribe({
      next: (updated) => this.replace(updated, next === 'ACTIVE' ? 'Usuário reativado.' : 'Usuário desativado.'),
      error: (e) => this.notifications.error(toApiError(e).message),
    });
  }

  protected unlock(user: UserSummary): void {
    this.api.unlockUser(user.id).subscribe({
      next: (updated) => this.replace(updated, 'Usuário desbloqueado.'),
      error: (e) => this.notifications.error(toApiError(e).message),
    });
  }

  private replace(updated: UserSummary, message: string): void {
    this.result.update((r) => (r ? { ...r, content: r.content.map((u) => (u.id === updated.id ? updated : u)) } : r));
    this.notifications.success(message);
  }
}
