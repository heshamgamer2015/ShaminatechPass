import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { AlertComponent } from '../../shared/ui/alert.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { toApiError } from '../../core/api/api-error';
import { AdminApi } from '../../core/api/admin-api.service';
import { PolicyView } from '../../core/loyalty-models';
import { NotificationService } from '../../core/notifications/notification.service';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { PolicyFormComponent } from './policy-form.component';

@Component({
  selector: 'app-defaults-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [AlertComponent, IconComponent, PageHeaderComponent, SpinnerComponent, PolicyFormComponent],
  styles: `
    .gap {
      margin-bottom: 1rem;
    }
  `,
  template: `
    <app-page-header title="Regras padrão" subtitle="Aplicadas aos estabelecimentos criados a partir de agora (os existentes não mudam)" />
    <p class="note info gap"><app-icon name="info" [size]="16" />
      <span>Estas regras são copiadas para cada estabelecimento <strong>no momento da criação</strong>. Alterar aqui não muda
        os estabelecimentos existentes — ajuste-os individualmente.</span></p>
    @if (loadError(); as e) {
      <app-alert kind="error">{{ e }}</app-alert>
    } @else if (policy(); as p) {
      <section class="card">
        <app-policy-form [policy]="p" [busy]="saving()" submitLabel="Salvar regras padrão" (save)="save($event)" />
      </section>
    } @else {
      <app-spinner />
    }
  `,
})
export class DefaultsPage {
  private readonly api = inject(AdminApi);
  private readonly notifications = inject(NotificationService);
  protected readonly policy = signal<PolicyView | null>(null);
  protected readonly saving = signal(false);
  protected readonly loadError = signal<string | null>(null);

  constructor() {
    this.api.defaults().subscribe({ next: (p) => this.policy.set(p), error: (e) => this.loadError.set(toApiError(e).message) });
  }

  protected save(p: PolicyView): void {
    this.saving.set(true);
    this.api.updateDefaults(p).subscribe({
      next: (updated) => {
        this.saving.set(false);
        this.policy.set(updated);
        this.notifications.success('Regras padrão salvas.');
      },
      error: (e) => {
        this.saving.set(false);
        this.notifications.error(toApiError(e).message);
      },
    });
  }
}
