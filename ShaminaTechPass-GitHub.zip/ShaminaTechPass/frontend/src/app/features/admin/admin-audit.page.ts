import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { EmptyStateComponent } from '../../shared/ui/empty-state.component';
import { ApiError, toApiError } from '../../core/api/api-error';
import { AdminApi } from '../../core/api/admin-api.service';
import { AuditEvent, Page } from '../../core/models';
import { AlertComponent } from '../../shared/ui/alert.component';
import { AuditTableComponent } from '../../shared/ui/audit-table.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { PagerComponent } from '../../shared/ui/pager.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';

@Component({
  selector: 'app-admin-audit-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [AlertComponent, AuditTableComponent, EmptyStateComponent, PageHeaderComponent, PagerComponent, SpinnerComponent],
  template: `
    <app-page-header title="Auditoria" subtitle="Eventos de segurança e administração de toda a plataforma. Registro permanente, somente leitura." />
    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (result(); as r) {
      @if (r.content.length === 0) {
        <app-empty-state icon="shield" title="Nenhum evento registrado ainda" />
      } @else {
        <app-audit-table [events]="r.content" [showEstablishment]="true" />
      }
      <app-pager [page]="r.page" [totalPages]="r.totalPages" (pageChange)="load($event)" />
    } @else {
      <app-spinner />
    }
  `,
})
export class AdminAuditPage {
  private readonly api = inject(AdminApi);
  protected readonly result = signal<Page<AuditEvent> | null>(null);
  protected readonly error = signal<ApiError | null>(null);

  constructor() {
    this.load(0);
  }

  protected load(page: number): void {
    this.api.audit(page).subscribe({
      next: (r) => this.result.set(r),
      error: (e) => this.error.set(toApiError(e)),
    });
  }
}
