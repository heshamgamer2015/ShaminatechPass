import { ChangeDetectionStrategy, Component, isDevMode } from '@angular/core';
import { NavItem, ShellComponent } from '../../layout/shell.component';

@Component({
  selector: 'app-admin-layout',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ShellComponent],
  template: `<app-shell area="Painel ShaminaTech" [nav]="nav" />`,
})
export class AdminLayoutComponent {
  protected readonly nav: NavItem[] = [
    { section: 'Plataforma', label: 'Estabelecimentos', link: '/admin/estabelecimentos', icon: 'building' },
    { section: 'Plataforma', label: 'Usuários', link: '/admin/usuarios', icon: 'users' },
    { section: 'Plataforma', label: 'Regras padrão', link: '/admin/regras-padrao', icon: 'sliders' },
    { section: 'Controle', label: 'Auditoria', link: '/admin/auditoria', icon: 'shield' },
    { section: 'Controle', label: 'Planos e assinaturas', link: '/admin/planos', soon: true, icon: 'card' },
    // Homologação técnica: só no ambiente de desenvolvimento (o backend também só a expõe no perfil local).
    ...(isDevMode() ? [{ section: 'Homologação', label: 'Apple Wallet', link: '/admin/homologacao-apple-wallet', icon: 'wallet' }] : []),
  ];
}
