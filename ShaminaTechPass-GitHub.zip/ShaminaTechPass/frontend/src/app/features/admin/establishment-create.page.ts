import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { IconComponent } from '../../shared/ui/icon.component';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { AdminApi } from '../../core/api/admin-api.service';
import { NotificationService } from '../../core/notifications/notification.service';
import { generateTemporaryPassword, slugify } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { FieldErrorComponent } from '../../shared/ui/field-error.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';

@Component({
  selector: 'app-establishment-create-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, RouterLink, AlertComponent, FieldErrorComponent, IconComponent, PageHeaderComponent],
  template: `
    <app-page-header title="Novo estabelecimento" subtitle="Cria o estabelecimento e sua conta empresarial única (e-mail e senha)."
                     backLink="/admin/estabelecimentos" backLabel="Estabelecimentos" />

    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    }

    <form class="card form" [formGroup]="form" (ngSubmit)="submit()" novalidate>
      <fieldset class="form">
        <legend>1. Estabelecimento</legend>
        <div class="form-row">
          <div class="field">
            <label for="name">Nome</label>
            <input id="name" class="input" formControlName="name" maxlength="150" (input)="suggestSlug()" />
            <app-field-error [server]="fe('name')" [local]="invalid('name') ? 'Informe o nome.' : null" />
          </div>
          <div class="field">
            <label for="slug">Identificador</label>
            <input id="slug" class="input mono" formControlName="slug" maxlength="80" (input)="slugEdited = true" />
            <span class="hint">Letras minúsculas, números e hífens. Não pode ser alterado depois.</span>
            <app-field-error [server]="fe('slug')" [local]="invalid('slug') ? 'Identificador inválido.' : null" />
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label for="contactEmail">E-mail de contato <span class="muted">(opcional)</span></label>
            <input id="contactEmail" class="input" type="email" formControlName="contactEmail" />
            <app-field-error [server]="fe('contactEmail')" [local]="invalid('contactEmail') ? 'E-mail inválido.' : null" />
          </div>
          <div class="field">
            <label for="contactPhone">Telefone <span class="muted">(opcional)</span></label>
            <input id="contactPhone" class="input" type="tel" formControlName="contactPhone" maxlength="30" />
            <app-field-error [server]="fe('contactPhone')" />
          </div>
        </div>
      </fieldset>

      <fieldset class="form" formGroupName="owner">
        <legend>2. Conta empresarial</legend>
        <div class="form-row">
          <div class="field">
            <label for="ownerName">Nome completo</label>
            <input id="ownerName" class="input" formControlName="fullName" maxlength="150" />
            <app-field-error [server]="fe('owner.fullName')" [local]="ownerInvalid('fullName') ? 'Informe o nome.' : null" />
          </div>
          <div class="field">
            <label for="ownerEmail">E-mail de acesso</label>
            <input id="ownerEmail" class="input" type="email" formControlName="email" />
            <app-field-error [server]="fe('owner.email')" [local]="ownerInvalid('email') ? 'Informe um e-mail válido.' : null" />
          </div>
        </div>
        <div class="field">
          <label for="temporaryPassword">Senha temporária</label>
          <div class="input-group">
            <input id="temporaryPassword" class="input mono" formControlName="temporaryPassword" autocomplete="off" />
            <button class="btn" type="button" (click)="generatePassword()"><app-icon name="refresh" [size]="16" /> Gerar</button>
            <button class="btn btn-icon" type="button" (click)="copyPassword()" [disabled]="!form.controls.owner.controls.temporaryPassword.value"
                    aria-label="Copiar senha temporária"><app-icon name="copy" [size]="16" /></button>
          </div>
          <span class="hint">
            Entregue ao responsável por um canal seguro. Ele deverá trocá-la no primeiro acesso.
            Se o e-mail já tiver conta, a senha atual dele é mantida.
          </span>
          <app-field-error [server]="fe('owner.temporaryPassword') || fe('temporaryPassword')" />
        </div>
      </fieldset>

      <p class="note"><app-icon name="info" [size]="16" />
        <span>Os limites iniciais vêm das <a routerLink="/admin/regras-padrao">regras padrão</a> e podem ser ajustados depois,
          na página do estabelecimento.</span></p>
      <div class="form-footer">
        <button class="btn btn-primary" type="submit" [disabled]="saving()">{{ saving() ? 'Salvando…' : 'Cadastrar estabelecimento' }}</button>
        <a class="btn btn-ghost" routerLink="/admin/estabelecimentos">Cancelar</a>
      </div>
    </form>
  `,
})
export class EstablishmentCreatePage {
  private readonly api = inject(AdminApi);
  private readonly router = inject(Router);
  private readonly notifications = inject(NotificationService);

  protected slugEdited = false;

  /** Copia a senha temporária para entregar ao responsável por canal seguro. */
  protected async copyPassword(): Promise<void> {
    const value = this.form.controls.owner.controls.temporaryPassword.value;
    if (!value) return;
    try {
      await navigator.clipboard.writeText(value);
      this.notifications.success('Senha copiada.');
    } catch {
      this.notifications.error('Não foi possível copiar. Selecione e copie manualmente.');
    }
  }
  protected readonly saving = signal(false);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly form = inject(NonNullableFormBuilder).group({
    name: ['', [Validators.required, Validators.maxLength(150)]],
    slug: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^[a-z0-9]+(-[a-z0-9]+)*$/)]],
    contactEmail: ['', Validators.email],
    contactPhone: [''],
    owner: inject(NonNullableFormBuilder).group({
      fullName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      temporaryPassword: [generateTemporaryPassword()],
    }),
  });

  protected fe(field: string): string | undefined {
    return this.error()?.fieldErrors[field];
  }

  protected invalid(name: 'name' | 'slug' | 'contactEmail'): boolean {
    const c = this.form.controls[name];
    return c.touched && c.invalid;
  }

  protected ownerInvalid(name: 'fullName' | 'email'): boolean {
    const c = this.form.controls.owner.controls[name];
    return c.touched && c.invalid;
  }

  protected suggestSlug(): void {
    if (!this.slugEdited) {
      this.form.controls.slug.setValue(slugify(this.form.controls.name.value));
    }
  }

  protected generatePassword(): void {
    this.form.controls.owner.controls.temporaryPassword.setValue(generateTemporaryPassword());
  }

  protected submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    this.saving.set(true);
    this.error.set(null);
    this.api
      .createEstablishment({
        name: v.name,
        slug: v.slug,
        contactEmail: v.contactEmail || null,
        contactPhone: v.contactPhone || null,
        owner: { ...v.owner, temporaryPassword: v.owner.temporaryPassword || null },
      })
      .subscribe({
        next: (created) => {
          this.notifications.success(`Estabelecimento "${created.name}" cadastrado.`);
          void this.router.navigate(['/admin/estabelecimentos', created.id]);
        },
        error: (e) => {
          this.error.set(toApiError(e));
          this.saving.set(false);
        },
      });
  }
}
