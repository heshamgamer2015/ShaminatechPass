import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { AppleHomologationPage } from './apple-homologation.page';

const STATUS = {
  ready: true,
  certificate: {
    loaded: true, passTypeIdentifier: 'pass.com.shaminatech.pass', teamIdentifier: 'GH47G54T8K',
    subject: 'Pass Type ID: pass.com.shaminatech.pass',
    issuer: 'Apple Worldwide Developer Relations Certification Authority (G4)', expiresAt: '2027-12-25T17:52:20Z', error: null,
  },
  missing: [], updatablePassesConfigured: false, lanAddresses: ['192.168.0.4', '10.0.0.8'], linkTtlMinutes: 15,
};

describe('AppleHomologationPage', () => {
  async function setup(status: object | null = STATUS, httpStatus = 200) {
    await TestBed.configureTestingModule({
      imports: [AppleHomologationPage],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
    const fixture = TestBed.createComponent(AppleHomologationPage);
    const http = TestBed.inject(HttpTestingController);
    const req = http.expectOne('/api/admin/apple-wallet/homologation');
    if (httpStatus === 200) req.flush(status);
    else req.flush({ status: httpStatus }, { status: httpStatus, statusText: 'x' });
    await fixture.whenStable();
    return { fixture, http, el: fixture.nativeElement as HTMLElement };
  }

  it('mostra o certificado e gera o QR Code com o IP da rede local (nunca localhost)', async () => {
    const { fixture, http, el } = await setup();
    expect(el.textContent).toContain('GH47G54T8K');
    expect(el.textContent).toContain('pass.com.shaminatech.pass');
    expect(el.textContent).toContain('não recebe atualizações');
    expect(el.querySelector('.qr img')).toBeNull();

    (el.querySelector('.card .btn-primary') as HTMLButtonElement).click();
    const gen = http.expectOne('/api/admin/apple-wallet/homologation/passes');
    expect(gen.request.method).toBe('POST');
    const token = 'A'.repeat(43);
    gen.flush({
      serialNumber: 'stp-homolog-1', sha256: '00', sizeBytes: 9240, token,
      installPath: '/api/public/apple-wallet-homologation/' + token,
      createdAt: new Date().toISOString(), expiresAt: new Date(Date.now() + 15 * 60_000).toISOString(),
    });
    await fixture.whenStable();

    const url = (el.querySelector('#install-url') as HTMLInputElement).value;
    expect(url).toContain('://192.168.0.4');
    expect(url).toContain('/api/public/apple-wallet-homologation/' + token);
    expect(url).not.toMatch(/localhost|127\.0\.0\.1/);
    const qr = decodeURIComponent((el.querySelector('.qr img') as HTMLImageElement).getAttribute('src')!);
    expect(qr).toBe('/api/admin/apple-wallet/homologation/qr?url=' + url);
    expect(el.querySelector('a[download]')!.getAttribute('href')).toBe('/api/public/apple-wallet-homologation/' + token);
    expect(el.textContent).toMatch(/1[45]:\d\d min/);
    expect(el.textContent).toContain('Copiar link');
    http.verify();
  });

  it('informa quando a homologação não existe fora do ambiente local', async () => {
    const { el } = await setup(null, 404);
    expect(el.textContent).toContain('só está disponível no ambiente local');
  });

  it('não permite gerar com o certificado indisponível e mostra o motivo', async () => {
    const { el } = await setup({
      ...STATUS, ready: false,
      certificate: { ...STATUS.certificate, loaded: false, error: 'Não foi possível ler o certificado .p12 (arquivo ausente ou senha incorreta).' },
    });
    expect((el.querySelector('.card .btn-primary') as HTMLButtonElement | null)?.disabled ?? true).toBe(true);
    expect(el.textContent).toContain('senha incorreta');
  });
});
