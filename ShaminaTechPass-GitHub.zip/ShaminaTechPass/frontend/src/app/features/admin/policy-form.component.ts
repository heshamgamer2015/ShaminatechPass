import { ChangeDetectionStrategy, Component, effect, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { PolicyView, ProgramType } from '../../core/loyalty-models';
import { PROGRAM_TYPE_LABELS, label } from '../../shared/labels';

const TYPES: ProgramType[] = ['STAMPS', 'POINTS', 'CASHBACK', 'VIP'];
const ZONES = ['America/Sao_Paulo', 'America/Manaus', 'America/Cuiaba', 'America/Belem', 'America/Fortaleza', 'America/Recife',
  'America/Bahia', 'America/Porto_Velho', 'America/Rio_Branco', 'America/Noronha'];

/** Formulário de limites (usado no estabelecimento e nas regras padrão). */
@Component({
  selector: 'app-policy-form',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  template: `
    <form class="form" (ngSubmit)="submit()">
      <div class="form-row">
        <div class="field">
          <label [for]="prefix() + 'max'">Limite de clientes ativos</label>
          <input [id]="prefix() + 'max'" class="input" type="number" min="0" max="1000000" name="max" [(ngModel)]="max" />
          <span class="hint">Conta clientes com cadastro ativo, não cartões. Com 0, nenhum novo cliente pode ser ativado.</span>
        </div>
        <div class="field">
          <label [for]="prefix() + 'days'">Inatividade padrão (dias)</label>
          <input [id]="prefix() + 'days'" class="input" type="number" min="1" max="3650" name="days" [(ngModel)]="days" />
          <span class="hint">Sugestão inicial ao criar programas.</span>
        </div>
        <div class="field">
          <label [for]="prefix() + 'zone'">Fuso horário</label>
          <select [id]="prefix() + 'zone'" class="select" name="zone" [(ngModel)]="zone">
            @for (z of zones; track z) { <option [value]="z">{{ z }}</option> }
          </select>
        </div>
      </div>
      <fieldset>
        <legend>Tipos de cartão permitidos</legend>
        <div class="types">
          @for (t of types; track t) {
            <label class="type-chip" [class.on]="selected().includes(t)">
              <input type="checkbox" [name]="'t' + t" [ngModel]="selected().includes(t)" (ngModelChange)="toggle(t, $event)" />
              <span>{{ typeLabel(t) }}@if (t === 'VIP') { <small class="muted"> · em preparação</small> }</span>
            </label>
          }
        </div>
        <p class="hint">Desabilitar um tipo preserva programas e cartões existentes, mas bloqueia novas movimentações dele.</p>
      </fieldset>
      <div class="form-footer">
        <button class="btn btn-primary" type="submit" [disabled]="busy()">{{ busy() ? 'Salvando…' : submitLabel() }}</button>
      </div>
    </form>
  `,
  styles: `
    .types {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
    }
    .type-chip {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      min-height: 40px;
      padding: 0 0.85rem;
      border: 1.5px solid var(--border);
      border-radius: var(--radius-sm);
      cursor: pointer;
    }
    .type-chip.on {
      border-color: var(--primary);
      background: var(--primary-soft);
    }
    .type-chip:has(input:focus-visible) {
      box-shadow: var(--focus-ring);
    }
  `,
})
export class PolicyFormComponent {
  readonly policy = input.required<PolicyView>();
  readonly busy = input(false);
  readonly submitLabel = input('Salvar limites');
  readonly prefix = input('p-');
  readonly save = output<PolicyView>();

  protected readonly types = TYPES;
  protected zones = ZONES;
  protected max = 0;
  protected days = 90;
  protected zone = 'America/Sao_Paulo';
  protected readonly selected = signal<ProgramType[]>([]);

  constructor() {
    effect(() => {
      const p = this.policy();
      this.max = p.maxActiveConsumers;
      this.days = p.defaultInactivityDays;
      this.zone = p.timeZone;
      if (!ZONES.includes(p.timeZone)) this.zones = [p.timeZone, ...ZONES];
      this.selected.set([...p.allowedProgramTypes]);
    });
  }

  protected toggle(t: ProgramType, on: boolean): void {
    this.selected.update((list) => (on ? [...new Set([...list, t])] : list.filter((x) => x !== t)));
  }

  protected submit(): void {
    this.save.emit({ maxActiveConsumers: Number(this.max), defaultInactivityDays: Number(this.days), timeZone: this.zone,
      allowedProgramTypes: this.selected() });
  }

  protected typeLabel(t: string): string {
    return label(PROGRAM_TYPE_LABELS, t);
  }
}
