import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, effect, inject, input, signal } from '@angular/core';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { RouterLink } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { AdminApi } from '../../core/api/admin-api.service';
import { EstablishmentDetail, EstablishmentStatus } from '../../core/models';
import { NotificationService } from '../../core/notifications/notification.service';
import { PolicyView } from '../../core/loyalty-models';
import { PROGRAM_TYPE_LABELS, STATUS_LABELS, generateTemporaryPassword, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';
import { PolicyFormComponent } from './policy-form.component';

@Component({
  selector: 'app-establishment-detail-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe, RouterLink, AlertComponent, PageHeaderComponent, SpinnerComponent, StatusBadgeComponent, PolicyFormComponent],
  template: `
    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
      <p><a routerLink="/admin/estabelecimentos">Voltar para a lista</a></p>
    } @else if (detail(); as d) {
      <app-page-header [title]="d.name" [subtitle]="'Identificador: ' + d.slug" backLink="/admin/estabelecimentos"
                       backLabel="Estabelecimentos" />

      <div class="grid">
        <section class="card">
          <h2>Dados</h2>
          <dl class="details">
            <dt>Situação</dt><dd><app-badge [value]="d.status" /></dd>
            <dt>E-mail</dt><dd>{{ d.contactEmail ?? '—' }}</dd>
            <dt>Telefone</dt><dd>{{ d.contactPhone ?? '—' }}</dd>
            <dt>Criado em</dt><dd>{{ d.createdAt | date: 'dd/MM/yyyy HH:mm' }}</dd>
            <dt>Atualizado</dt><dd>{{ d.updatedAt | date: 'dd/MM/yyyy HH:mm' }}</dd>
          </dl>
        </section>
        <section class="card">
          <h2>Situação da conta</h2>
          <p class="muted">Contas suspensas ou canceladas não acessam o painel do estabelecimento.</p>
          <div class="actions">
            @for (s of statuses; track s) {
              @if (s !== d.status) {
                <button class="btn btn-sm" [class.btn-danger]="s !== 'ACTIVE'" type="button" [disabled]="saving()"
                        (click)="changeStatus(s)">
                  {{ actionLabel(s) }}
                </button>
              }
            }
          </div>
        </section>
      </div>

      <div class="grid">
        <section class="card">
          <h2>Utilização</h2>
          <dl class="details">
            <dt>Clientes ativos</dt>
            <dd>
              {{ d.usage.activeConsumers }} de {{ d.usage.maxActiveConsumers }}
              <span class="meter usage" role="meter" aria-valuemin="0" aria-valuemax="100" [attr.aria-valuenow]="usage(d)"
                    [attr.aria-label]="'Limite utilizado: ' + usage(d) + '%'">
                <span [style.width.%]="usage(d)" [class.warn]="usage(d) >= 80 && usage(d) < 100" [class.full]="usage(d) >= 100"></span>
              </span>
            </dd>
            <dt>Clientes cadastrados</dt><dd>{{ d.usage.totalConsumers }}</dd>
            <dt>Cartões ativos</dt><dd>{{ d.usage.activeCards }}</dd>
            <dt>Cartões emitidos</dt><dd>{{ d.usage.totalCards }}</dd>
            <dt>Programas</dt><dd>{{ programsText(d) }}</dd>
          </dl>
          <p class="muted">A ShaminaTech vê apenas contagens; os dados dos clientes pertencem ao estabelecimento.</p>
        </section>
        <section class="card">
          <h2>Conta empresarial</h2>
          @if (d.account; as a) {
            <dl class="details">
              <dt>Responsável</dt><dd>{{ a.fullName }}</dd>
              <dt>E-mail de acesso</dt><dd>{{ a.email }}</dd>
              <dt>Situação</dt><dd><app-badge [value]="a.userStatus" /></dd>
            </dl>
            <button class="btn btn-sm" type="button" [disabled]="saving()" (click)="resetPassword()">Gerar nova senha temporária</button>
            @if (newPassword(); as pw) {
              <app-alert kind="success">Nova senha temporária: <strong class="mono">{{ pw }}</strong> — entregue por um canal seguro; a troca é obrigatória no próximo acesso.</app-alert>
            }
          } @else {
            <p class="muted">Sem conta empresarial ativa.</p>
          }
        </section>
      </div>

      <section class="card">
        <h2>Limites e tipos de cartão</h2>
        <p class="muted">Reduzir o limite não apaga nem desativa clientes: apenas bloqueia novas ativações. Desabilitar um tipo preserva
          programas e cartões, mas bloqueia novas movimentações dele.</p>
        <app-policy-form [policy]="d.policy" [busy]="saving()" (save)="savePolicy($event)" />
      </section>
    } @else {
      <app-spinner />
    }
  `,
  styles: `
    .usage {
      display: block;
      max-width: 220px;
      margin-top: 0.35rem;
    }
  `,
})
export class EstablishmentDetailPage {
  private readonly api = inject(AdminApi);
  private readonly notifications = inject(NotificationService);
  private readonly dialogs = inject(ConfirmService);

  /** Parâmetro de rota :id. */
  readonly id = input.required<string>();

  protected readonly statuses: EstablishmentStatus[] = ['ACTIVE', 'SUSPENDED', 'CANCELLED'];
  protected readonly detail = signal<EstablishmentDetail | null>(null);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly saving = signal(false);
  protected readonly newPassword = signal<string | null>(null);

  constructor() {
    effect(() => {
      const id = Number(this.id());
      this.detail.set(null);
      this.error.set(null);
      this.api.establishment(id).subscribe({
        next: (d) => this.detail.set(d),
        error: (e) => this.error.set(toApiError(e)),
      });
    });
  }

  protected actionLabel(status: EstablishmentStatus): string {
    return status === 'ACTIVE' ? 'Reativar' : status === 'SUSPENDED' ? 'Suspender' : 'Cancelar conta';
  }

  /** Percentual do limite de clientes ativos em uso (limite 0 = sem vagas). */
  protected usage(d: EstablishmentDetail): number {
    const max = d.usage.maxActiveConsumers;
    return max <= 0 ? 100 : Math.min(100, Math.round((d.usage.activeConsumers / max) * 100));
  }

  protected async changeStatus(status: EstablishmentStatus): Promise<void> {
    const d = this.detail();
    if (!d) return;
    const ok = await this.dialogs.confirm({
      title: `Alterar a situação de "${d.name}"?`,
      message: `Nova situação: ${STATUS_LABELS[status]}. A alteração fica registrada na auditoria.`,
      confirmLabel: 'Alterar situação',
      tone: status === 'ACTIVE' ? 'primary' : 'danger',
    });
    if (!ok) return;
    this.saving.set(true);
    this.api.changeEstablishmentStatus(d.id, status).subscribe({
      next: (updated) => {
        this.detail.set(updated);
        this.saving.set(false);
        this.notifications.success('Situação atualizada.');
      },
      error: (e) => {
        this.saving.set(false);
        this.notifications.error(toApiError(e).message);
      },
    });
  }

  protected programsText(d: EstablishmentDetail): string {
    const parts = Object.entries(d.programsByType).map(([t, n]) => `${n} ${label(PROGRAM_TYPE_LABELS, t).toLowerCase()}`);
    return parts.length ? parts.join(', ') : 'nenhum';
  }

  protected async savePolicy(policy: PolicyView): Promise<void> {
    const d = this.detail();
    if (!d) return;
    const effects: string[] = [];
    if (policy.maxActiveConsumers < d.usage.activeConsumers) {
      effects.push(`O novo limite (${policy.maxActiveConsumers}) fica abaixo dos ${d.usage.activeConsumers} clientes ativos: ninguém é desativado, mas novas ativações ficam bloqueadas.`);
    }
    const removed = d.policy.allowedProgramTypes.filter((t) => !policy.allowedProgramTypes.includes(t));
    if (removed.length > 0) {
      effects.push(`Tipos desabilitados (${removed.map((t) => PROGRAM_TYPE_LABELS[t] ?? t).join(', ')}): programas e cartões são preservados, mas não aceitam novas movimentações.`);
    }
    const ok = await this.dialogs.confirm({
      title: `Salvar os limites de "${d.name}"?`,
      message: (effects.length > 0 ? effects.join('\n\n') + '\n\n' : '') + 'A alteração fica registrada na auditoria.',
      confirmLabel: 'Salvar limites',
      tone: effects.length > 0 ? 'danger' : 'primary',
    });
    if (!ok) return;
    this.saving.set(true);
    this.api.updatePolicy(d.id, policy).subscribe({
      next: (updated) => {
        this.detail.set(updated);
        this.saving.set(false);
        this.notifications.success('Limites atualizados.');
      },
      error: (e) => {
        this.saving.set(false);
        this.notifications.error(toApiError(e).message);
      },
    });
  }

  protected async resetPassword(): Promise<void> {
    const d = this.detail();
    if (!d) return;
    const ok = await this.dialogs.confirm({
      title: 'Gerar nova senha temporária?',
      message: 'A senha atual da conta empresarial deixará de funcionar. A troca será obrigatória no próximo acesso.',
      confirmLabel: 'Gerar senha',
      tone: 'danger',
    });
    if (!ok) return;
    const password = generateTemporaryPassword();
    this.saving.set(true);
    this.api.resetAccountPassword(d.id, password).subscribe({
      next: (updated) => {
        this.detail.set(updated);
        this.saving.set(false);
        this.newPassword.set(password);
      },
      error: (e) => {
        this.saving.set(false);
        this.notifications.error(toApiError(e).message);
      },
    });
  }
}
