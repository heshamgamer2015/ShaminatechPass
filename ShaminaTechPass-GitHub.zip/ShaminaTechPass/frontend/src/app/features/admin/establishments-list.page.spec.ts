import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { EstablishmentSummary } from '../../core/models';
import { EstablishmentsListPage } from './establishments-list.page';

function est(id: number, active: number, max: number): EstablishmentSummary {
  return {
    id, name: 'Loja ' + id, slug: 'loja-' + id, status: 'ACTIVE', contactEmail: null, createdAt: '2026-11-01T12:00:00Z',
    usage: { activeConsumers: active, totalConsumers: active, maxActiveConsumers: max, activeCards: active, totalCards: active },
  };
}

function page(content: EstablishmentSummary[], total = content.length) {
  return { content, page: 0, size: 20, totalElements: total, totalPages: 1 };
}

describe('EstablishmentsListPage', () => {
  async function setup() {
    await TestBed.configureTestingModule({
      imports: [EstablishmentsListPage],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
    const fixture = TestBed.createComponent(EstablishmentsListPage);
    await fixture.whenStable();
    const http = TestBed.inject(HttpTestingController);
    // 1ª requisição: a lista; as quatro seguintes: os totais por situação (total de registros de cada consulta).
    const requests = http.match((r) => r.url === '/api/admin/establishments');
    expect(requests.length).toBe(5);
    requests[0].flush(page([est(1, 10, 100), est(2, 85, 100), est(3, 100, 100), est(4, 0, 0)]));
    const totals = [42, 30, 7, 5];
    requests.slice(1).forEach((r, i) => r.flush(page([], totals[i])));
    await fixture.whenStable();
    return { fixture, el: fixture.nativeElement as HTMLElement, requests };
  }

  it('destaca estabelecimentos perto do limite e com limite atingido', async () => {
    const { el } = await setup();
    const rows = [...el.querySelectorAll('tbody tr')].map((r) => r.textContent ?? '');
    expect(rows[0]).not.toMatch(/Perto do limite|Limite atingido/);
    expect(rows[1]).toContain('Perto do limite');
    expect(rows[2]).toContain('Limite atingido');
    // Limite zero: nenhuma vaga — tratado como atingido, sem divisão por zero.
    expect(rows[3]).toContain('Limite atingido');
  });

  it('mostra os totais por situação a partir do total de registros, não da página atual', async () => {
    const { el, requests } = await setup();
    expect(requests.slice(1).map((r) => r.request.params.get('status') ?? '')).toEqual(['', 'ACTIVE', 'SUSPENDED', 'CANCELLED']);
    const values = [...el.querySelectorAll('.totals .stat-value')].map((v) => v.textContent?.trim());
    expect(values).toEqual(['42', '30', '7', '5']);
  });
});
