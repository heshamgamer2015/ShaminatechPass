import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';
import { ROLE_LABELS, label } from '../../shared/labels';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';

/** Usuário vinculado a mais de um estabelecimento escolhe em qual entrar. */
@Component({
  selector: 'app-select-establishment-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, StatusBadgeComponent],
  styleUrl: '../auth/auth-page.scss',
  template: `
    <section class="card auth-card">
      <div class="brand"><span class="mark" aria-hidden="true">P</span><span>ShaminaTech <strong>Pass</strong></span></div>
      <h1>Escolha o estabelecimento</h1>
      <ul class="list">
        @for (m of auth.user()?.memberships ?? []; track m.establishmentId) {
          <li>
            <a [routerLink]="['/e', m.establishmentId]" class="item">
              <span>
                <strong>{{ m.establishmentName }}</strong>
                <span class="muted"> · {{ roleLabel(m.role) }}</span>
              </span>
              @if (m.establishmentStatus !== 'ACTIVE') {
                <app-badge [value]="m.establishmentStatus" />
              }
            </a>
          </li>
        }
      </ul>
      <p class="links"><button class="btn btn-ghost btn-sm" type="button" (click)="logout()">Sair</button></p>
    </section>
  `,
  styles: `
    .list {
      list-style: none;
      padding: 0;
      margin: 0;
      display: grid;
      gap: 0.5rem;
    }
    .item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 1rem;
      padding: 0.85rem 1rem;
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
      color: var(--text);
      text-decoration: none;
    }
    .item:hover {
      border-color: var(--primary);
      background: var(--primary-soft);
    }
  `,
})
export class SelectEstablishmentPage {
  protected readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  protected roleLabel(role: string): string {
    return label(ROLE_LABELS, role);
  }

  protected async logout(): Promise<void> {
    await this.auth.logout();
    await this.router.navigate(['/login']);
  }
}
