import { Directive, ElementRef, OnDestroy, afterNextRender, effect, inject, input } from '@angular/core';

/** Visitante pediu menos movimento no sistema operacional? */
export function prefersReducedMotion(): boolean {
  return typeof window !== 'undefined' && typeof window.matchMedia === 'function'
    && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

/**
 * Revela o elemento ao entrar na tela (fade + leve deslocamento, só CSS). Sem IntersectionObserver ou com movimento
 * reduzido, o conteúdo aparece direto — nada fica escondido.
 */
@Directive({ selector: '[appReveal]', host: { class: 'reveal' } })
export class RevealDirective implements OnDestroy {
  private readonly el = inject(ElementRef<HTMLElement>);
  /** Atraso em ms (para escalonar itens de uma lista). */
  readonly appReveal = input<number | ''>('');
  private observer?: IntersectionObserver;

  constructor() {
    afterNextRender(() => {
      const node = this.el.nativeElement as HTMLElement;
      const delay = Number(this.appReveal() || 0);
      if (delay) node.style.setProperty('--reveal-delay', `${delay}ms`);
      if (prefersReducedMotion() || typeof IntersectionObserver === 'undefined') {
        node.classList.add('is-visible');
        return;
      }
      this.observer = new IntersectionObserver(
        (entries) => {
          for (const e of entries) {
            if (e.isIntersecting) {
              node.classList.add('is-visible');
              this.observer?.disconnect();
            }
          }
        },
        { threshold: 0.12, rootMargin: '0px 0px -40px 0px' },
      );
      this.observer.observe(node);
    });
  }

  ngOnDestroy(): void {
    this.observer?.disconnect();
  }
}

/** Anima a troca de um número (ex.: resultados do simulador). Respeita movimento reduzido. */
@Directive({ selector: '[appCountUp]' })
export class CountUpDirective implements OnDestroy {
  private readonly el = inject(ElementRef<HTMLElement>);
  readonly appCountUp = input.required<number>();
  readonly format = input<'money' | 'int' | 'percent'>('int');
  private current = 0;
  private frame = 0;

  constructor() {
    effect(() => {
      const target = this.appCountUp();
      const fmt = this.format();
      cancelAnimationFrame(this.frame);
      if (prefersReducedMotion() || typeof requestAnimationFrame === 'undefined') {
        this.render(target, fmt);
        this.current = target;
        return;
      }
      const from = this.current;
      const start = performance.now();
      const duration = 450;
      const step = (now: number) => {
        const t = Math.min(1, (now - start) / duration);
        const eased = 1 - Math.pow(1 - t, 3);
        const value = from + (target - from) * eased;
        this.render(value, fmt);
        if (t < 1) this.frame = requestAnimationFrame(step);
        else this.current = target;
      };
      this.frame = requestAnimationFrame(step);
    });
  }

  private render(value: number, fmt: 'money' | 'int' | 'percent'): void {
    (this.el.nativeElement as HTMLElement).textContent = formatNumber(value, fmt);
  }

  ngOnDestroy(): void {
    cancelAnimationFrame(this.frame);
  }
}

export function formatNumber(value: number, fmt: 'money' | 'int' | 'percent'): string {
  if (fmt === 'money') return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 });
  if (fmt === 'percent') return `${value.toLocaleString('pt-BR', { maximumFractionDigits: 1 })}%`;
  return Math.round(value).toLocaleString('pt-BR');
}
