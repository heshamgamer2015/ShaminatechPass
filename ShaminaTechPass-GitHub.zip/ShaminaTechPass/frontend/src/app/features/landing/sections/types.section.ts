import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { IconComponent } from '../../../shared/ui/icon.component';
import { RevealDirective } from '../landing-motion';

interface LoyaltyType {
  key: string;
  icon: string;
  name: string;
  short: string;
  example: string;
  bestFor: string;
  note?: string;
}

/** Os 4 modelos de fidelidade do produto, com exemplo prático ao passar o mouse/tocar. */
@Component({
  selector: 'app-lp-types',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent, RevealDirective],
  template: `
    <section id="modelos" class="lp-section alt" aria-labelledby="types-title">
      <div class="lp-container">
        <header class="lp-head" appReveal>
          <span class="lp-eyebrow">Modelos de fidelidade</span>
          <h2 id="types-title" class="lp-title">Escolha como seu cliente é recompensado</h2>
          <p class="lp-lead">Quatro formatos prontos. Comece por um e combine conforme o seu plano.</p>
        </header>
        <div class="types">
          @for (t of types; track t.key; let i = $index) {
            <button type="button" class="type" [class.active]="active() === t.key" [appReveal]="i * 80"
                    (click)="active.set(t.key)" (mouseenter)="active.set(t.key)" [attr.aria-pressed]="active() === t.key">
              <span class="icon"><app-icon [name]="t.icon" [size]="26" /></span>
              <strong>{{ t.name }}</strong>
              <span class="short">{{ t.short }}</span>
              <span class="example"><span class="label">Exemplo</span>{{ t.example }}</span>
              <span class="best">Ideal para: {{ t.bestFor }}</span>
              @if (t.note) { <span class="note">{{ t.note }}</span> }
            </button>
          }
        </div>
      </div>
    </section>
  `,
  styles: `
    .types {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(min(100%, 250px), 1fr));
      gap: 1rem;
    }
    .type {
      display: grid;
      align-content: start;
      gap: 0.55rem;
      padding: 1.6rem 1.4rem;
      border: 1.5px solid var(--border);
      border-radius: 20px;
      background: #fff;
      font: inherit;
      text-align: left;
      color: inherit;
      cursor: pointer;
      transition: border-color 0.25s, box-shadow 0.25s, transform 0.25s var(--ease);
    }
    .type:hover,
    .type.active {
      border-color: var(--primary);
      box-shadow: 0 18px 40px rgb(244 63 94 / 12%);
      transform: translateY(-4px);
    }
    .type:focus-visible {
      outline: none;
      box-shadow: var(--focus-ring);
    }
    .icon {
      display: grid;
      place-items: center;
      width: 54px;
      height: 54px;
      border-radius: 16px;
      background: var(--primary-soft);
      color: var(--primary);
      transition: background 0.25s, color 0.25s;
    }
    .type.active .icon {
      background: var(--primary);
      color: #fff;
    }
    strong {
      font-size: 1.2rem;
    }
    .short {
      color: var(--text-muted);
      line-height: 1.5;
    }
    .example {
      display: grid;
      gap: 0.15rem;
      padding: 0.75rem 0.85rem;
      border-radius: 12px;
      background: var(--surface-muted);
      font-size: var(--text-sm);
      line-height: 1.45;
    }
    .label {
      font-size: var(--text-xs);
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--primary-ink);
    }
    .best,
    .note {
      font-size: var(--text-sm);
      color: var(--text-muted);
    }
    .note {
      font-style: italic;
    }
  `,
})
export class TypesSection {
  protected readonly active = signal('STAMPS');
  protected readonly types: LoyaltyType[] = [
    { key: 'STAMPS', icon: 'check-circle', name: 'Carimbos', short: 'A cada compra o cliente avança um carimbo até ganhar a recompensa.',
      example: 'Junte 10 carimbos e ganhe um café.', bestFor: 'cafeterias, sorveterias, barbearias' },
    { key: 'POINTS', icon: 'star', name: 'Pontos', short: 'O cliente acumula pontos pelo valor gasto e troca por recompensas que você escolhe.',
      example: '1 ponto a cada R$ 1. Com 500 pontos, uma sobremesa.', bestFor: 'restaurantes, lanchonetes, lojas' },
    { key: 'CASHBACK', icon: 'wallet', name: 'Cashback', short: 'Parte do valor da compra volta como saldo para usar na próxima visita.',
      example: '5% de volta em crédito no próprio estabelecimento.', bestFor: 'lojas, mercados, ticket mais alto' },
    { key: 'VIP', icon: 'shield', name: 'Níveis VIP', short: 'O cliente sobe de nível (Bronze, Prata, Ouro) e libera benefícios maiores.',
      example: 'Clientes Ouro têm prioridade e um mimo por mês.', bestFor: 'relacionamento de longo prazo',
      note: 'Cadastro de níveis disponível; evolução automática em desenvolvimento.' },
  ];
}
