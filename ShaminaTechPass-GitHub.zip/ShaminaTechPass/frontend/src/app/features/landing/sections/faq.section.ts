import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RevealDirective } from '../landing-motion';

/** Perguntas frequentes (respostas fiéis ao que o produto faz hoje). Usa <details> nativo: acessível sem JS. */
@Component({
  selector: 'app-lp-faq',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RevealDirective],
  template: `
    <section id="faq" class="lp-section alt" aria-labelledby="faq-title">
      <div class="lp-container narrow">
        <header class="lp-head" appReveal>
          <span class="lp-eyebrow">Perguntas frequentes</span>
          <h2 id="faq-title" class="lp-title">Tudo o que você precisa saber</h2>
        </header>
        <div class="faq">
          @for (q of questions; track q.q; let i = $index) {
            <details [appReveal]="i * 40" [open]="i === 0">
              <summary>{{ q.q }}</summary>
              <p>{{ q.a }}</p>
            </details>
          }
        </div>
      </div>
    </section>
  `,
  styles: `
    .narrow {
      max-width: 820px;
    }
    .faq {
      display: grid;
      gap: 0.75rem;
    }
    details {
      border: 1px solid var(--border);
      border-radius: 16px;
      background: #fff;
      transition: box-shadow 0.25s, border-color 0.25s;
    }
    details[open] {
      border-color: #fecdd3;
      box-shadow: 0 12px 30px rgb(244 63 94 / 8%);
    }
    summary {
      position: relative;
      padding: 1.15rem 3.25rem 1.15rem 1.35rem;
      font-weight: 650;
      list-style: none;
      cursor: pointer;
    }
    summary::-webkit-details-marker {
      display: none;
    }
    summary::after {
      content: '';
      position: absolute;
      right: 1.35rem;
      top: 50%;
      width: 10px;
      height: 10px;
      border-right: 2px solid var(--primary);
      border-bottom: 2px solid var(--primary);
      transform: translateY(-70%) rotate(45deg);
      transition: transform 0.25s var(--ease);
    }
    details[open] summary::after {
      transform: translateY(-30%) rotate(225deg);
    }
    summary:focus-visible {
      outline: none;
      box-shadow: var(--focus-ring);
      border-radius: 16px;
    }
    p {
      margin: 0;
      padding: 0 1.35rem 1.25rem;
      color: var(--text-muted);
      line-height: 1.65;
    }
  `,
})
export class FaqSection {
  protected readonly questions = [
    { q: 'O cliente precisa baixar algum aplicativo?',
      a: 'Não. O cliente escaneia o QR Code com a câmera do celular, faz um cadastro rápido e adiciona o cartão à carteira digital. Nenhum aplicativo extra é necessário.' },
    { q: 'Funciona no Google Wallet e no Apple Wallet?',
      a: 'O cartão funciona hoje no Google Wallet (Android e navegador). A integração com o Apple Wallet já está desenvolvida e em fase de homologação com a Apple; ela será liberada assim que concluída.' },
    { q: 'Como funciona o QR Code de cadastro?',
      a: 'Você gera um QR Code por programa no painel, imprime e coloca no balcão. Ele é reutilizável por todos os clientes. Se precisar, você pode desativá-lo ou gerar um novo a qualquer momento.' },
    { q: 'O cliente precisa criar conta ou senha?',
      a: 'Não. Basta nome e celular (e-mail é opcional). Não pedimos CPF, endereço nem data de nascimento.' },
    { q: 'Como funciona a validade do cartão?',
      a: 'Você define quantos dias o cartão vale sem movimentação. Só compras ou resgates registrados no balcão renovam o prazo — abrir o cartão ou receber um lembrete não renova. Antes de vencer, um lembrete pode avisar o cliente.' },
    { q: 'Quais tipos de fidelidade existem?',
      a: 'Carimbos, pontos, cashback (crédito para usar no próprio estabelecimento) e níveis VIP. Cada plano libera uma quantidade de tipos e de programas.' },
    { q: 'Posso acompanhar os resultados?',
      a: 'Sim. O painel mostra clientes ativos, cadastros pelo QR Code, quem voltou, frequência de visitas, recompensas resgatadas e as compras registradas — sempre com dados reais do seu negócio.' },
    { q: 'Serve para restaurante, cafeteria e loja?',
      a: 'Sim. Cafeterias e sorveterias costumam usar carimbos; restaurantes e lanchonetes, pontos; lojas, cashback. Barbearias, salões e pequenos comércios também se adaptam bem.' },
    { q: 'Como funciona o plano gratuito?',
      a: 'O plano Free é gratuito para sempre, com até 10 clientes ativos, 1 programa e 1 tipo de fidelidade. É ideal para testar com seus clientes mais fiéis antes de crescer.' },
    { q: 'Como contrato?',
      a: 'A contratação é feita com a equipe ShaminaTech, que configura o seu estabelecimento e explica o painel. Fale com a gente pelo formulário abaixo.' },
  ];
}
