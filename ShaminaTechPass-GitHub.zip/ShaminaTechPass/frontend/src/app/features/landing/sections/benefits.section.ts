import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { IconComponent } from '../../../shared/ui/icon.component';
import { RevealDirective } from '../landing-motion';

/** Benefícios para o estabelecimento e para o consumidor (alternância por abas). */
@Component({
  selector: 'app-lp-benefits',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent, RevealDirective],
  template: `
    <section id="beneficios" class="lp-section" aria-labelledby="benefits-title">
      <div class="lp-container">
        <header class="lp-head" appReveal>
          <span class="lp-eyebrow">Benefícios</span>
          <h2 id="benefits-title" class="lp-title">Bom para o seu caixa. Simples para o seu cliente.</h2>
          <p class="lp-lead">Fidelidade que funciona no dia a dia do balcão — e que o cliente realmente usa.</p>
        </header>

        <div class="switch" role="tablist" aria-label="Para quem">
          <button type="button" role="tab" id="tab-business" aria-controls="panel-benefits" [attr.aria-selected]="audience() === 'business'"
                  (click)="audience.set('business')"><app-icon name="building" [size]="18" /> Para o estabelecimento</button>
          <button type="button" role="tab" id="tab-client" aria-controls="panel-benefits" [attr.aria-selected]="audience() === 'client'"
                  (click)="audience.set('client')"><app-icon name="user" [size]="18" /> Para o cliente</button>
        </div>

        <div id="panel-benefits" class="cards" role="tabpanel" [attr.aria-labelledby]="audience() === 'business' ? 'tab-business' : 'tab-client'">
          @for (b of audience() === 'business' ? business : client; track b.title; let i = $index) {
            <article class="card-b" [appReveal]="i * 60">
              <span class="icon"><app-icon [name]="b.icon" [size]="20" /></span>
              <h3>{{ b.title }}</h3>
              <p>{{ b.text }}</p>
            </article>
          }
        </div>
      </div>
    </section>
  `,
  styles: `
    .switch {
      display: flex;
      width: fit-content;
      max-width: 100%;
      margin: 0 auto 2rem;
      padding: 4px;
      border-radius: 14px;
      background: var(--surface-sunken);
    }
    .switch button {
      display: inline-flex;
      align-items: center;
      gap: 0.4rem;
      min-height: 44px;
      padding: 0 1.1rem;
      border: 0;
      border-radius: 10px;
      background: none;
      font: inherit;
      font-weight: 650;
      color: var(--text-muted);
      cursor: pointer;
    }
    .switch button[aria-selected='true'] {
      background: #fff;
      color: var(--primary-ink);
      box-shadow: var(--shadow-sm);
    }
    .switch button:focus-visible {
      outline: none;
      box-shadow: var(--focus-ring);
    }
    .cards {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(min(100%, 260px), 1fr));
      gap: 1rem;
    }
    .card-b {
      display: grid;
      align-content: start;
      gap: 0.45rem;
      padding: 1.4rem;
      border-radius: 18px;
      background: var(--surface-muted);
      transition: background 0.25s, transform 0.25s var(--ease);
    }
    .card-b:hover {
      background: #fff1f2;
      transform: translateY(-3px);
    }
    .icon {
      display: grid;
      place-items: center;
      width: 42px;
      height: 42px;
      border-radius: 12px;
      background: #fff;
      color: var(--primary);
      box-shadow: var(--shadow-xs);
    }
    h3 {
      margin: 0.35rem 0 0;
      font-size: 1.02rem;
    }
    p {
      margin: 0;
      color: var(--text-muted);
      line-height: 1.55;
    }
    @media (max-width: 480px) {
      .switch {
        width: 100%;
      }
      .switch button {
        flex: 1;
        justify-content: center;
        padding: 0 0.5rem;
        font-size: var(--text-sm);
      }
    }
  `,
})
export class BenefitsSection {
  protected readonly audience = signal<'business' | 'client'>('business');
  protected readonly business = [
    { icon: 'refresh', title: 'Mais clientes voltando', text: 'Uma recompensa clara dá ao cliente um motivo concreto para escolher você de novo.' },
    { icon: 'phone', title: 'Sem aplicativo próprio', text: 'Nada de desenvolver, publicar ou convencer o cliente a baixar um app.' },
    { icon: 'qr', title: 'Cadastro por QR Code', text: 'Um QR no balcão faz o cadastro sozinho, sem ocupar sua equipe.' },
    { icon: 'wallet', title: 'Na carteira do celular', text: 'O cartão fica no Google Wallet, ao lado dos cartões de banco do cliente.' },
    { icon: 'bell', title: 'Lembretes automáticos', text: 'Avise quando falta pouco para a recompensa ou quando o cartão vai vencer.' },
    { icon: 'chart', title: 'Relatórios de retorno', text: 'Veja quem voltou, frequência, recompensas resgatadas e compras registradas.' },
    { icon: 'scan', title: 'Balcão rápido', text: 'Leia o código ou busque o cliente pelo nome e registre em segundos.' },
    { icon: 'sliders', title: '4 modelos de fidelidade', text: 'Pontos, cashback, carimbos ou níveis VIP — do jeito do seu negócio.' },
    { icon: 'shield', title: 'Controle e segurança', text: 'Proteção contra registros duplicados, estornos rastreáveis e auditoria de cada ação.' },
  ];
  protected readonly client = [
    { icon: 'phone', title: 'Sem baixar app', text: 'Só a câmera do celular e um cadastro rápido. Nada de senha.' },
    { icon: 'wallet', title: 'Cartão sempre à mão', text: 'Fica na carteira do celular. Não se perde, não esquece em casa.' },
    { icon: 'star', title: 'Progresso visível', text: 'O cliente vê quantos carimbos ou pontos tem e quanto falta.' },
    { icon: 'bell', title: 'Lembrete na hora certa', text: 'Aviso quando a recompensa está perto ou quando o cartão vai vencer.' },
    { icon: 'gift', title: 'Recompensa sem complicação', text: 'É só mostrar o cartão no balcão para resgatar.' },
    { icon: 'lock', title: 'Dados protegidos', text: 'Pedimos só nome e celular. Sem CPF, endereço ou data de nascimento.' },
  ];
}
