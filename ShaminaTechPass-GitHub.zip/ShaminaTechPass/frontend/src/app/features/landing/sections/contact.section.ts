import { ChangeDetectionStrategy, Component, computed, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { IconComponent } from '../../../shared/ui/icon.component';
import { RevealDirective } from '../landing-motion';
import { LANDING_CONFIG } from '../landing.config';

/**
 * CTA final + formulário de interesse. Nada é enviado a servidores: o formulário só monta a mensagem e abre o canal
 * oficial configurado (WhatsApp ou e-mail). Sem canal configurado, o envio fica desativado e isso é informado.
 */
@Component({
  selector: 'app-lp-contact',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, RouterLink, IconComponent, RevealDirective],
  templateUrl: './contact.section.html',
  styleUrl: './contact.section.scss',
})
export class ContactSection {
  readonly plan = input('');
  readonly cta = output<string>();
  protected readonly config = LANDING_CONFIG;
  protected readonly hasChannel = !!(LANDING_CONFIG.whatsapp || LANDING_CONFIG.contactEmail);
  protected readonly sent = signal(false);
  protected name = '';
  protected business = '';
  protected city = '';
  protected phone = '';
  protected segment = 'Cafeteria';
  protected readonly segments = ['Cafeteria', 'Restaurante', 'Lanchonete', 'Sorveteria', 'Barbearia / salão', 'Loja', 'Outro'];
  protected readonly chosenPlan = computed(() => this.plan() || 'Ainda não sei');

  protected message(): string {
    return [
      'Olá! Quero conhecer o ShaminaTech Pass.',
      `Nome: ${this.name.trim()}`,
      `Negócio: ${this.business.trim()} (${this.segment})`,
      this.city.trim() ? `Cidade: ${this.city.trim()}` : '',
      this.phone.trim() ? `Telefone: ${this.phone.trim()}` : '',
      `Plano de interesse: ${this.chosenPlan()}`,
    ].filter(Boolean).join('\n');
  }

  protected ready(): boolean {
    return !!this.name.trim() && !!this.business.trim();
  }

  /** Abre o WhatsApp (padrão) ou o e-mail com a mensagem pronta; quem envia é o próprio visitante. */
  protected submit(channel: 'whatsapp' | 'email' = LANDING_CONFIG.whatsapp ? 'whatsapp' : 'email'): void {
    if (!this.hasChannel || !this.ready()) return;
    const url = channel === 'whatsapp' && LANDING_CONFIG.whatsapp ? this.whatsappUrl() : this.emailUrl();
    if (!url) return;
    this.cta.emit('contato_' + channel);
    window.open(url, '_blank', 'noopener');
    this.sent.set(true);
  }

  protected whatsappUrl(): string {
    return `https://wa.me/${LANDING_CONFIG.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(this.message())}`;
  }

  protected emailUrl(): string {
    if (!LANDING_CONFIG.contactEmail) return '';
    return `mailto:${LANDING_CONFIG.contactEmail}?subject=${encodeURIComponent('Quero conhecer o ShaminaTech Pass')}`
      + `&body=${encodeURIComponent(this.message())}`;
  }

  /** Telefone exibido no formato brasileiro: (45) 99105-4598. */
  protected readonly phoneLabel = (() => {
    const d = LANDING_CONFIG.whatsapp.replace(/\D/g, '').replace(/^55/, '');
    return d.length === 11 ? `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}` : d;
  })();
}
