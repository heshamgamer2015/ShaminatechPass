import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { IconComponent } from '../../../shared/ui/icon.component';
import { RouterLink } from '@angular/router';
import { RevealDirective } from '../landing-motion';
import { LANDING_CONFIG, PLANS, Plan } from '../landing.config';

/** Planos da plataforma. Sem checkout: o botão abre o cadastro com o plano escolhido (grátis na fase de testes). */
@Component({
  selector: 'app-lp-plans',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent, RevealDirective, RouterLink],
  template: `
    <section id="planos" class="lp-section" aria-labelledby="plans-title">
      <div class="lp-container">
        <header class="lp-head" appReveal>
          <span class="lp-eyebrow">Planos</span>
          <h2 id="plans-title" class="lp-title">Comece grátis. Cresça quando fizer sentido.</h2>
          <p class="lp-lead">Comece no plano gratuito e evolua conforme o seu negócio cresce.</p>
          @if (trialFree) {
            <p class="trial" role="note"><app-icon name="check-circle" [size]="18" />
              <span><strong>Fase de testes:</strong> todos os planos estão gratuitos — sem cartão de crédito e sem cobrança.</span></p>
          }
        </header>
        <div class="plans">
          @for (p of plans; track p.key; let i = $index) {
            <article class="plan" [class.featured]="p.highlight" [appReveal]="i * 100" [attr.aria-label]="'Plano ' + p.name">
              @if (p.highlight) { <span class="ribbon">Recomendado</span> }
              <h3>{{ p.name }}</h3>
              <p class="tag">{{ p.tagline }}</p>
              <p class="price"><strong>{{ p.price }}</strong><span>{{ p.period }}</span></p>
              @if (trialFree && p.key !== 'free') { <p class="free-now">Grátis durante a fase de testes</p> }
              <a class="lp-btn" [class.primary]="p.highlight" routerLink="/criar-conta" [queryParams]="{ plano: p.key }"
                 (click)="signupClick(p)">{{ p.cta }}</a>
              <a class="talk" href="#contato" (click)="choose.emit(p)">Tirar dúvidas com a ShaminaTech</a>
              <ul>
                @for (f of p.features; track f) { <li><app-icon name="check" [size]="16" /> {{ f }}</li> }
              </ul>
            </article>
          }
        </div>
        <p class="notes">
          Valores comerciais previstos. Durante a fase de testes o uso é gratuito em qualquer plano; se a cobrança for implantada,
          ela só começará com o seu aceite.
          Apple Wallet em fase de homologação. ¹ Depende de suporte do Google Wallet e de permissão de localização no celular do cliente.
        </p>
      </div>
    </section>
  `,
  styles: `
    .trial {
      display: inline-flex;
      align-items: flex-start;
      max-width: 100%;
      text-align: left;
      gap: 0.4rem;
      margin: 1rem auto 0;
      padding: 0.55rem 1rem;
      border-radius: 999px;
      background: var(--success-soft);
      color: var(--success);
      font-size: var(--text-sm);
    }
    .free-now {
      margin: -0.25rem 0 0;
      color: var(--success);
      font-size: var(--text-sm);
      font-weight: 700;
    }
    .talk {
      align-self: center;
      font-size: var(--text-sm);
      color: var(--text-muted);
    }
    .plans {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 1.25rem;
      align-items: stretch;
    }
    .plan {
      position: relative;
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      padding: 2rem 1.75rem;
      border: 1px solid var(--border);
      border-radius: 24px;
      background: #fff;
      transition: transform 0.25s var(--ease), box-shadow 0.25s;
    }
    .plan:hover {
      transform: translateY(-4px);
      box-shadow: 0 20px 44px rgb(15 23 42 / 8%);
    }
    .plan.featured {
      border: 2px solid var(--primary);
      box-shadow: 0 30px 60px rgb(244 63 94 / 16%);
    }
    .ribbon {
      position: absolute;
      top: -14px;
      left: 50%;
      transform: translateX(-50%);
      padding: 0.3rem 0.9rem;
      border-radius: 999px;
      background: var(--primary);
      color: #fff;
      font-size: var(--text-xs);
      font-weight: 700;
      white-space: nowrap;
    }
    h3 {
      margin: 0;
      font-size: 1.3rem;
    }
    .tag {
      margin: 0;
      color: var(--text-muted);
      min-height: 2.8em;
    }
    .price {
      display: flex;
      align-items: baseline;
      gap: 0.35rem;
      margin: 0.25rem 0 0.5rem;
    }
    .price strong {
      font-size: 2.6rem;
      letter-spacing: -0.03em;
    }
    .price span {
      color: var(--text-muted);
    }
    ul {
      display: grid;
      gap: 0.6rem;
      margin: 0.75rem 0 0;
      padding: 1rem 0 0;
      border-top: 1px solid var(--border);
      list-style: none;
    }
    li {
      display: flex;
      gap: 0.5rem;
      align-items: flex-start;
    }
    li app-icon {
      margin-top: 0.15rem;
      color: var(--primary);
    }
    .notes {
      max-width: 760px;
      margin: 2rem auto 0;
      text-align: center;
      font-size: var(--text-sm);
      color: var(--text-muted);
    }
    @media (max-width: 960px) {
      .plans {
        grid-template-columns: 1fr;
        max-width: 460px;
        margin-inline: auto;
      }
      .tag {
        min-height: 0;
      }
    }
  `,
})
export class PlansSection {
  readonly choose = output<Plan>();
  protected readonly plans = PLANS;
  protected readonly trialFree = LANDING_CONFIG.trialFree;

  protected signupClick(p: Plan): void {
    LANDING_CONFIG.track('cadastro_' + p.key);
  }
}
