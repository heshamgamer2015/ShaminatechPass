import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { IconComponent } from '../../../shared/ui/icon.component';
import { BrandMarkComponent } from '../../../shared/ui/brand-mark.component';

/** Primeira dobra: proposta de valor, CTAs e o cartão na carteira do celular. */
@Component({
  selector: 'app-lp-hero',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent, BrandMarkComponent],
  template: `
    <section class="hero" aria-labelledby="hero-title">
      <div class="lp-container grid">
        <div class="copy">
          <span class="lp-eyebrow"><app-icon name="wallet" [size]="15" /> Fidelidade digital para o seu negócio</span>
          <h1 id="hero-title">Seus clientes voltam mais.<br /><span>Sem aplicativo próprio.</span></h1>
          <p class="lp-lead">
            O ShaminaTech Pass cria o cartão fidelidade do seu negócio direto na carteira do celular do cliente — com
            pontos, cashback, carimbos ou níveis VIP. Cadastro por QR Code, registro de compras em segundos e o cartão se
            atualiza sozinho.
          </p>
          <div class="ctas">
            <a class="lp-btn primary" href="#contato" (click)="cta.emit('hero_conhecer')">Quero conhecer <app-icon name="chevron-right" [size]="18" /></a>
            <a class="lp-btn" href="#demonstracao" (click)="cta.emit('hero_demo')">Testar demonstração</a>
            <a class="lp-btn ghost" href="#planos" (click)="cta.emit('hero_planos')">Ver planos</a>
          </div>
          <ul class="proof">
            <li><app-icon name="check" [size]="16" /> Plano gratuito para começar</li>
            <li><app-icon name="check" [size]="16" /> Cliente não baixa nada</li>
            <li><app-icon name="check" [size]="16" /> Pronto em minutos</li>
          </ul>
        </div>

        <div class="visual" aria-label="Exemplo de cartão fidelidade na carteira do celular" role="img">
          <div class="phone">
            <div class="notch"></div>
            <div class="wallet-top"><span>Carteira</span><span class="plus">+</span></div>
            <div class="pass">
              <div class="pass-head">
                <span class="logo"><app-brand-mark [size]="22" color="#ffffff" /></span>
                <span class="pass-names"><small>Café Aroma</small><strong>Cartão Fidelidade</strong></span>
              </div>
              <div class="stamps" aria-hidden="true">
                @for (s of stamps; track $index) {
                  <span class="stamp" [class.on]="s" [style.animation-delay.ms]="$index * 120"></span>
                }
              </div>
              <div class="pass-foot">
                <span><small>Faltam</small><strong>3 carimbos</strong></span>
                <span><small>Recompensa</small><strong>Café grátis</strong></span>
              </div>
              <div class="qr" aria-hidden="true"></div>
            </div>
            <div class="card-ghost one"></div>
            <div class="card-ghost two"></div>
          </div>
          <div class="toast t1"><app-icon name="check-circle" [size]="18" /><span><strong>+1 carimbo</strong><small>Compra registrada agora</small></span></div>
          <div class="toast t2"><app-icon name="bell" [size]="18" /><span><strong>Falta pouco!</strong><small>Mais 3 visitas e o café é seu</small></span></div>
        </div>
      </div>
    </section>
  `,
  styleUrl: './hero.section.scss',
})
export class HeroSection {
  readonly cta = output<string>();
  protected readonly stamps = [true, true, true, true, true, true, true, false, false, false];
}
