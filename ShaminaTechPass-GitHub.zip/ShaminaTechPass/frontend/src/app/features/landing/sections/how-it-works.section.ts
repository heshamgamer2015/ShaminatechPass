import { ChangeDetectionStrategy, Component } from '@angular/core';
import { IconComponent } from '../../../shared/ui/icon.component';
import { RevealDirective } from '../landing-motion';

/** Jornada do estabelecimento em 7 passos conectados (aparecem em sequência ao rolar). */
@Component({
  selector: 'app-lp-how',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent, RevealDirective],
  template: `
    <section id="como-funciona" class="lp-section alt" aria-labelledby="how-title">
      <div class="lp-container">
        <header class="lp-head" appReveal>
          <span class="lp-eyebrow">Como funciona</span>
          <h2 id="how-title" class="lp-title">Do QR Code no balcão ao cliente voltando</h2>
          <p class="lp-lead">Você configura uma vez. Depois, cada compra registrada atualiza o cartão no celular do cliente.</p>
        </header>
        <ol class="steps">
          @for (s of steps; track s.title; let i = $index) {
            <li class="step" [appReveal]="i * 90">
              <span class="num">{{ i + 1 }}</span>
              <span class="icon"><app-icon [name]="s.icon" [size]="22" /></span>
              <h3>{{ s.title }}</h3>
              <p>{{ s.text }}</p>
              <span class="who" [class.client]="s.who === 'Cliente'">{{ s.who }}</span>
            </li>
          }
        </ol>
      </div>
    </section>
  `,
  styles: `
    .steps {
      list-style: none;
      margin: 0;
      padding: 0;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(min(100%, 240px), 1fr));
      gap: 1rem;
      counter-reset: s;
    }
    .step {
      position: relative;
      display: grid;
      align-content: start;
      gap: 0.5rem;
      padding: 1.5rem 1.25rem 1.25rem;
      border: 1px solid var(--border);
      border-radius: 18px;
      background: #fff;
      transition: transform 0.25s var(--ease), box-shadow 0.25s var(--ease), border-color 0.25s;
    }
    .step:hover {
      transform: translateY(-4px);
      border-color: #fecdd3;
      box-shadow: 0 16px 36px rgb(244 63 94 / 10%);
    }
    .num {
      position: absolute;
      top: 1rem;
      right: 1.1rem;
      font-size: 2.2rem;
      font-weight: 800;
      line-height: 1;
      color: #ffe4e6;
    }
    .icon {
      display: grid;
      place-items: center;
      width: 46px;
      height: 46px;
      border-radius: 14px;
      background: var(--primary);
      color: #fff;
      box-shadow: 0 8px 18px rgb(244 63 94 / 28%);
    }
    h3 {
      margin: 0.4rem 0 0;
      font-size: 1.05rem;
    }
    p {
      margin: 0;
      color: var(--text-muted);
      line-height: 1.55;
    }
    .who {
      justify-self: start;
      margin-top: 0.35rem;
      padding: 0.15rem 0.6rem;
      border-radius: 999px;
      background: var(--surface-muted);
      font-size: var(--text-xs);
      font-weight: 650;
      color: var(--text-muted);
    }
    .who.client {
      background: #eff6ff;
      color: #1d4ed8;
    }
  `,
})
export class HowItWorksSection {
  protected readonly steps = [
    { icon: 'star', title: 'Crie o programa', text: 'Escolha pontos, cashback, carimbos ou VIP e defina a recompensa em poucos cliques.', who: 'Seu negócio' },
    { icon: 'qr', title: 'Gere o QR Code', text: 'Imprima e coloque no balcão, na mesa ou na vitrine. Um único QR serve para todos.', who: 'Seu negócio' },
    { icon: 'phone', title: 'O cliente escaneia', text: 'Pela câmera do celular, ele abre a página de cadastro do seu programa.', who: 'Cliente' },
    { icon: 'user', title: 'Cadastro em 1 minuto', text: 'Nome e celular. Sem criar conta, sem senha, sem baixar aplicativo.', who: 'Cliente' },
    { icon: 'wallet', title: 'Cartão na carteira', text: 'Com um toque, o cartão vai para a carteira digital do celular.', who: 'Cliente' },
    { icon: 'scan', title: 'Registre as compras', text: 'No balcão, leia o código do cartão ou busque pelo nome e confirme.', who: 'Seu negócio' },
    { icon: 'refresh', title: 'Tudo se atualiza', text: 'Saldo, progresso e recompensas aparecem no cartão do cliente automaticamente.', who: 'Automático' },
  ];
}
