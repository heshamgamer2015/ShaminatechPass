import { ChangeDetectionStrategy, Component, DestroyRef, afterNextRender, inject, signal } from '@angular/core';
import { IconComponent } from '../../../shared/ui/icon.component';
import { RevealDirective, prefersReducedMotion } from '../landing-motion';

const STEPS = [
  { icon: 'building', title: 'Chega ao seu negócio', text: 'Vê o QR Code no balcão: “Ganhe um café a cada 10 visitas”.', screen: 'Bem-vindo!', detail: 'Escaneie para participar' },
  { icon: 'camera', title: 'Escaneia o QR Code', text: 'Usa a câmera do próprio celular. Nada para instalar.', screen: 'Café Aroma', detail: 'Programa de fidelidade' },
  { icon: 'user', title: 'Faz o cadastro', text: 'Nome e celular, em menos de um minuto.', screen: 'Cadastro concluído', detail: 'Olá, Mariana!' },
  { icon: 'wallet', title: 'Adiciona o cartão', text: 'Um toque e o cartão vai para a carteira do celular.', screen: 'Cartão adicionado', detail: '0 de 10 carimbos' },
  { icon: 'scan', title: 'Compra', text: 'Mostra o cartão no balcão e o atendente registra.', screen: 'Compra registrada', detail: '+1 carimbo' },
  { icon: 'star', title: 'Acompanha o progresso', text: 'O cartão se atualiza sozinho a cada visita.', screen: '9 de 10 carimbos', detail: 'Falta só 1!' },
  { icon: 'refresh', title: 'Volta outras vezes', text: 'Um lembrete avisa quando a recompensa está perto.', screen: 'Lembrete', detail: 'Seu café grátis está a 1 visita' },
  { icon: 'gift', title: 'Ganha a recompensa', text: 'Resgata no balcão — e o ciclo recomeça.', screen: 'Recompensa liberada', detail: 'Um café grátis ☕' },
];

/** Jornada do consumidor: passos com destaque que avança sozinho e um celular que mostra cada momento. */
@Component({
  selector: 'app-lp-journey',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent, RevealDirective],
  template: `
    <section id="jornada" class="lp-section alt" aria-labelledby="journey-title">
      <div class="lp-container">
        <header class="lp-head" appReveal>
          <span class="lp-eyebrow"><app-icon name="user" [size]="15" /> Jornada do cliente</span>
          <h2 id="journey-title" class="lp-title">Do primeiro café à recompensa — em poucos toques</h2>
          <p class="lp-lead">Veja a experiência do seu cliente, do QR Code no balcão até voltar para resgatar.</p>
        </header>
        <div class="journey" appReveal>
          <ol class="list">
            @for (s of steps; track s.title; let i = $index) {
              <li [class.done]="i < current()" [class.current]="i === current()">
                <button type="button" (click)="go(i)" [attr.aria-current]="i === current() ? 'step' : null">
                  <span class="dot"><app-icon [name]="s.icon" [size]="16" /></span>
                  <span class="tx"><b>{{ s.title }}</b><small>{{ s.text }}</small></span>
                </button>
              </li>
            }
          </ol>
          <div class="device" aria-live="polite">
            <div class="screen">
              @for (s of [steps[current()]]; track s.title) {
                <div class="moment">
                  <span class="m-icon"><app-icon [name]="s.icon" [size]="34" /></span>
                  <b>{{ s.screen }}</b>
                  <small>{{ s.detail }}</small>
                  <span class="stamps" aria-hidden="true">
                    @for (k of ten; track k) { <i [class.on]="k < stampsAt(current())"></i> }
                  </span>
                </div>
              }
            </div>
            <div class="dots" aria-hidden="true">
              @for (s of steps; track s.title; let i = $index) { <i [class.on]="i === current()"></i> }
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
  styleUrl: './journey.section.scss',
})
export class JourneySection {
  protected readonly steps = STEPS;
  protected readonly ten = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  protected readonly current = signal(0);
  private timer: ReturnType<typeof setInterval> | null = null;

  constructor() {
    afterNextRender(() => {
      if (prefersReducedMotion()) return;
      this.timer = setInterval(() => this.current.update((i) => (i + 1) % STEPS.length), 3200);
    });
    inject(DestroyRef).onDestroy(() => this.stop());
  }

  protected go(i: number): void {
    this.stop();
    this.current.set(i);
  }

  /** Carimbos no cartão ilustrativo em cada momento da jornada. */
  protected stampsAt(step: number): number {
    return [0, 0, 0, 0, 1, 9, 9, 10][step];
  }

  private stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }
}
