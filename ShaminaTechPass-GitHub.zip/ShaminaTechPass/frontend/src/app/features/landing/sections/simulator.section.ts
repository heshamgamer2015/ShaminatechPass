import { NgTemplateOutlet } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, output, signal } from '@angular/core';
import { IconComponent } from '../../../shared/ui/icon.component';
import { CountUpDirective, RevealDirective, formatNumber } from '../landing-motion';
import { SIMULATION_DEFAULTS, SIMULATION_PRESETS, SimulationInput, normalize, simulate } from '../roi-simulator';

interface Field {
  key: keyof SimulationInput;
  label: string;
  min: number;
  max: number;
  step: number;
  unit: 'int' | 'money' | 'percent' | 'decimal';
  hint: string;
}

/** Simulação comercial interativa. Estimativas demonstrativas, ajustáveis — nunca garantia de resultado. */
@Component({
  selector: 'app-lp-simulator',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [NgTemplateOutlet, IconComponent, CountUpDirective, RevealDirective],
  templateUrl: './simulator.section.html',
  styleUrl: './simulator.section.scss',
})
export class SimulatorSection {
  readonly cta = output<string>();
  protected readonly presets = SIMULATION_PRESETS;
  protected readonly preset = signal('cafe');
  protected readonly input = signal<SimulationInput>({ ...SIMULATION_DEFAULTS, ...SIMULATION_PRESETS[0].values });
  protected readonly result = computed(() => simulate(this.input()));
  protected readonly bars = computed(() => {
    const r = this.result();
    const max = Math.max(r.revenueWithProgram, 1);
    return { without: (r.baselineRevenue / max) * 100, with: (r.revenueWithProgram / max) * 100 };
  });

  protected readonly business: Field[] = [
    { key: 'activeCustomers', label: 'Clientes atendidos por mês', min: 20, max: 3000, step: 10, unit: 'int', hint: 'Clientes diferentes no mês.' },
    { key: 'averageTicket', label: 'Ticket médio', min: 5, max: 500, step: 1, unit: 'money', hint: 'Valor médio de cada compra.' },
    { key: 'visitsPerCustomer', label: 'Visitas por cliente no mês', min: 0.5, max: 12, step: 0.1, unit: 'decimal', hint: 'Sem programa de fidelidade.' },
    { key: 'grossMarginPercent', label: 'Sua margem bruta', min: 10, max: 90, step: 1, unit: 'percent', hint: 'Quanto sobra da venda após o custo do produto.' },
  ];
  protected readonly program: Field[] = [
    { key: 'participationPercent', label: 'Clientes que entram no programa', min: 5, max: 90, step: 1, unit: 'percent', hint: 'Adesão estimada.' },
    { key: 'frequencyIncreasePercent', label: 'Aumento de frequência', min: 0, max: 60, step: 1, unit: 'percent', hint: 'Visitas a mais de quem participa.' },
    { key: 'extraReturnPercent', label: 'Clientes recuperados', min: 0, max: 40, step: 1, unit: 'percent', hint: 'Participantes que deixariam de voltar e voltam.' },
    { key: 'purchasesPerReward', label: 'Compras para ganhar 1 recompensa', min: 2, max: 30, step: 1, unit: 'int', hint: 'Ex.: 10 carimbos.' },
    { key: 'rewardCost', label: 'Custo de cada recompensa para você', min: 0, max: 200, step: 1, unit: 'money', hint: 'Custo do brinde, não o preço de venda.' },
    { key: 'planCost', label: 'Mensalidade do plano', min: 0, max: 129, step: 1, unit: 'money', hint: 'Free R$ 0 · Growth R$ 59 · Pro R$ 129.' },
  ];

  protected value(f: Field): number {
    return this.input()[f.key];
  }

  protected display(f: Field): string {
    const v = this.value(f);
    if (f.unit === 'decimal') return v.toLocaleString('pt-BR', { maximumFractionDigits: 1 });
    return formatNumber(v, f.unit === 'money' ? 'money' : f.unit === 'percent' ? 'percent' : 'int');
  }

  /** Preenchimento visual do slider (percentual do intervalo). */
  protected fill(f: Field): number {
    return ((this.value(f) - f.min) / (f.max - f.min)) * 100;
  }

  protected set(f: Field, raw: string): void {
    const n = Number(String(raw).replace(',', '.'));
    if (!Number.isFinite(n)) return;
    this.input.update((i) => normalize({ ...i, [f.key]: n }));
    this.preset.set('');
  }

  protected applyPreset(key: string): void {
    const p = SIMULATION_PRESETS.find((x) => x.key === key);
    if (!p) return;
    this.preset.set(key);
    this.input.update((i) => ({ ...SIMULATION_DEFAULTS, planCost: i.planCost, ...p.values }));
  }
}
