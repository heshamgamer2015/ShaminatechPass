import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { IconComponent } from '../../../shared/ui/icon.component';
import { BrandMarkComponent } from '../../../shared/ui/brand-mark.component';

/** Telas do painel reproduzidas em HTML/CSS (leves, nítidas em qualquer tela). Dados ilustrativos. */
@Component({
  selector: 'app-lp-demo-screen',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent, BrandMarkComponent],
  template: `
    <div class="window">
      <div class="chrome"><i></i><i></i><i></i><span>pass.shaminatech · {{ title() }}</span></div>
      <div class="body">
        @switch (screen()) {
          @case ('overview') {
            <div class="row4">
              <div class="kpi"><small>Clientes ativos</small><b>128</b><span class="meter"><span></span></span></div>
              <div class="kpi"><small>Cartões ativos</small><b>121</b></div>
              <div class="kpi"><small>Resgates (30 dias)</small><b>37</b></div>
              <div class="kpi"><small>Cadastros pelo QR</small><b>54</b></div>
            </div>
            <div class="row2">
              <div class="panel"><h4>Perto da recompensa</h4>
                @for (n of near; track n.name) {
                  <div class="line"><span>{{ n.name }}</span><span class="pill" [class.ok]="n.ready">{{ n.ready ? 'Pode resgatar' : n.left }}</span></div>
                }
              </div>
              <div class="panel"><h4>Visitas por semana</h4>
                <div class="chart">@for (h of chart; track $index) { <span [style.height.%]="h"></span> }</div>
              </div>
            </div>
          }
          @case ('operation') {
            <div class="op">
              <div class="panel">
                <div class="who"><span class="av">M</span><span><b>Mariana Costa</b><small>Cartão Café · 7 de 10 carimbos</small></span></div>
                <div class="balance"><small>Saldo disponível</small><b>7 carimbos</b></div>
                <div class="field">Carimbos a conceder <span>1</span></div>
                <div class="btn">Confirmar concessão</div>
              </div>
              <div class="panel success"><app-icon name="check-circle" [size]="28" /><b>Operação registrada</b><small>Novo saldo: 8 carimbos · cartão atualizado</small></div>
            </div>
          }
          @case ('qr') {
            <div class="qr-screen">
              <div class="qr-code"><app-brand-mark [size]="34" /></div>
              <div class="panel">
                <h4>QR Code de cadastro</h4>
                <small class="mono muted">pass.shaminatech/cadastro/7deb…</small>
                <div class="line"><span>Cadastros por este QR</span><b>54</b></div>
                <div class="line"><span>Situação</span><span class="pill ok">Ativo</span></div>
                <div class="btns"><span class="btn">Imprimir</span><span class="btn ghost">Baixar PNG</span></div>
              </div>
            </div>
          }
          @case ('customers') {
            <div class="panel table">
              @for (c of customers; track c.name) {
                <div class="tr"><span class="av">{{ c.name[0] }}</span><span class="grow"><b>{{ c.name }}</b><small>{{ c.phone }}</small></span>
                  <span>{{ c.balance }}</span><span class="pill ok">Ativo</span></div>
              }
            </div>
          }
          @case ('notifications') {
            <div class="panel">
              @for (n of reminders; track n.title) {
                <div class="toggle-row"><span class="tg" [class.on]="n.on"></span><span class="grow"><b>{{ n.title }}</b><small>{{ n.text }}</small></span></div>
              }
            </div>
          }
          @case ('design') {
            <div class="design">
              <div class="panel">
                <h4>Cores do cartão</h4>
                <div class="swatches">@for (c of colors; track c) { <span [style.background]="c" [class.sel]="c === '#f43f5e'"></span> }</div>
                <div class="line"><span>Contraste</span><span class="pill ok">Boa leitura</span></div>
                <div class="line"><span>Logotipo</span><span>logo.png ✓</span></div>
              </div>
              <div class="mini-pass"><span class="lg"><app-brand-mark [size]="18" color="#fff" /></span><b>Café Aroma</b><small>7 de 10 carimbos</small></div>
            </div>
          }
        }
      </div>
    </div>
  `,
  styleUrl: './demo-screens.component.scss',
})
export class DemoScreenComponent {
  readonly screen = input.required<string>();
  readonly title = input('');
  protected readonly near = [
    { name: 'Mariana Costa', ready: true, left: '' },
    { name: 'João Pereira', ready: false, left: 'faltam 2' },
    { name: 'Ana Ribeiro', ready: false, left: 'faltam 3' },
  ];
  protected readonly chart = [35, 52, 48, 66, 58, 80, 92];
  protected readonly customers = [
    { name: 'Mariana Costa', phone: '(11) 9•••• -4321', balance: '7 carimbos' },
    { name: 'Rafael Lima', phone: '(11) 9•••• -1180', balance: '320 pontos' },
    { name: 'Beatriz Souza', phone: '(21) 9•••• -7702', balance: 'R$ 12,40' },
    { name: 'Carlos Mendes', phone: '(31) 9•••• -5530', balance: '4 carimbos' },
  ];
  protected readonly reminders = [
    { title: 'Recompensa próxima', text: '“Falta 1 carimbo para o seu café grátis!”', on: true },
    { title: 'Cartão perto de vencer', text: 'Aviso 3 dias antes do vencimento.', on: true },
    { title: 'Saudade do cliente', text: 'Só para quem aceitou receber novidades.', on: false },
    { title: 'Proximidade da loja', text: 'O celular lembra do cartão perto da loja.', on: false },
  ];
  protected readonly colors = ['#f43f5e', '#0f172a', '#16a34a', '#2563eb', '#f59e0b'];
}
