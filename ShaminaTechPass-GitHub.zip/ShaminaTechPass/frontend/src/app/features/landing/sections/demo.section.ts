import { ChangeDetectionStrategy, Component, DestroyRef, afterNextRender, inject, signal } from '@angular/core';
import { IconComponent } from '../../../shared/ui/icon.component';
import { RevealDirective, prefersReducedMotion } from '../landing-motion';
import { DemoScreenComponent } from './demo-screens.component';

const TABS = [
  { key: 'overview', icon: 'home', label: 'Visão geral', title: 'Visão geral', text: 'Os números que importam: clientes ativos, cartões, resgates e quem está perto da recompensa.' },
  { key: 'operation', icon: 'scan', label: 'Operação rápida', title: 'Registrar compra', text: 'Leia o código do cartão ou busque pelo nome. Confirme e pronto — com proteção contra registro duplicado.' },
  { key: 'qr', icon: 'qr', label: 'QR Code', title: 'QR Code de cadastro', text: 'Um QR reutilizável para imprimir. Desative ou gere um novo quando quiser.' },
  { key: 'customers', icon: 'users', label: 'Clientes', title: 'Clientes', text: 'Busque por nome, telefone ou código. Veja cartões, saldos e todo o histórico.' },
  { key: 'notifications', icon: 'bell', label: 'Notificações', title: 'Notificações', text: 'Lembretes de recompensa e de validade, com horário e frequência sob controle.' },
  { key: 'design', icon: 'palette', label: 'Personalização', title: 'Personalização', text: 'Cores, logotipo e textos do cartão com prévia e verificação de contraste.' },
];

/** Por dentro do sistema: abas com telas ilustrativas; avançam sozinhas até o visitante interagir. */
@Component({
  selector: 'app-lp-demo',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent, RevealDirective, DemoScreenComponent],
  template: `
    <section id="demonstracao" class="lp-section" aria-labelledby="demo-title">
      <div class="lp-container">
        <header class="lp-head" appReveal>
          <span class="lp-eyebrow"><app-icon name="sliders" [size]="15" /> Por dentro do sistema</span>
          <h2 id="demo-title" class="lp-title">Um painel feito para o dia a dia do balcão</h2>
          <p class="lp-lead">Clique nas abas para conhecer as principais telas. Os dados abaixo são ilustrativos.</p>
        </header>
        <div class="demo" appReveal>
          <div class="tabs-v" role="tablist" aria-label="Telas do sistema" (keydown)="keys($event)">
            @for (t of tabs; track t.key; let i = $index) {
              <button type="button" role="tab" [id]="'demo-tab-' + t.key" [attr.aria-selected]="active() === i"
                      [attr.aria-controls]="'demo-panel'" [tabindex]="active() === i ? 0 : -1" (click)="select(i)">
                <span class="ic"><app-icon [name]="t.icon" [size]="18" /></span>
                <span class="tx"><b>{{ t.label }}</b><small>{{ t.text }}</small></span>
                @if (active() === i && autoplay()) { <span class="progress" aria-hidden="true"></span> }
              </button>
            }
          </div>
          <div id="demo-panel" role="tabpanel" [attr.aria-labelledby]="'demo-tab-' + tabs[active()].key" class="stage">
            @for (t of [tabs[active()]]; track t.key) {
              <app-lp-demo-screen [screen]="t.key" [title]="t.title" />
            }
          </div>
        </div>
      </div>
    </section>
  `,
  styles: `
    .demo {
      display: grid;
      grid-template-columns: minmax(0, 0.8fr) minmax(0, 1.2fr);
      gap: 1.5rem;
      align-items: start;
    }
    .tabs-v {
      display: grid;
      gap: 0.5rem;
    }
    .tabs-v button {
      position: relative;
      display: flex;
      gap: 0.85rem;
      padding: 0.9rem 1rem;
      overflow: hidden;
      border: 1px solid transparent;
      border-radius: 16px;
      background: none;
      font: inherit;
      text-align: left;
      color: inherit;
      cursor: pointer;
      transition: background 0.2s, border-color 0.2s;
    }
    .tabs-v button:hover {
      background: var(--surface-muted);
    }
    .tabs-v button[aria-selected='true'] {
      border-color: #fecdd3;
      background: #fff1f2;
    }
    .tabs-v button:focus-visible {
      outline: none;
      box-shadow: var(--focus-ring);
    }
    .ic {
      display: grid;
      place-items: center;
      width: 38px;
      height: 38px;
      flex: none;
      border-radius: 11px;
      background: var(--surface-muted);
      color: var(--text-muted);
    }
    [aria-selected='true'] .ic {
      background: var(--primary);
      color: #fff;
    }
    .tx {
      display: grid;
      gap: 0.15rem;
    }
    .tx small {
      color: var(--text-muted);
      line-height: 1.45;
    }
    .progress {
      position: absolute;
      left: 0;
      bottom: 0;
      height: 3px;
      width: 100%;
      background: var(--primary);
      transform-origin: left;
      animation: progress 6s linear both;
    }
    @keyframes progress {
      from {
        transform: scaleX(0);
      }
    }
    @media (max-width: 960px) {
      .demo {
        grid-template-columns: 1fr;
      }
      .tabs-v {
        display: flex;
        overflow-x: auto;
        scroll-snap-type: x mandatory;
        padding-bottom: 0.25rem;
      }
      .tabs-v button {
        flex: 0 0 auto;
        scroll-snap-align: start;
        padding: 0.6rem 0.85rem;
      }
      .tx small {
        display: none;
      }
    }
  `,
})
export class DemoSection {
  protected readonly tabs = TABS;
  protected readonly active = signal(0);
  protected readonly autoplay = signal(!prefersReducedMotion());
  private timer: ReturnType<typeof setInterval> | null = null;

  constructor() {
    afterNextRender(() => {
      if (!this.autoplay()) return;
      this.timer = setInterval(() => this.active.update((i) => (i + 1) % TABS.length), 6000);
    });
    inject(DestroyRef).onDestroy(() => this.stop());
  }

  protected select(i: number): void {
    this.stop();
    this.active.set(i);
  }

  /** Setas e Home/End navegam entre as abas (padrão WAI-ARIA). */
  protected keys(e: KeyboardEvent): void {
    const n = TABS.length;
    const map: Record<string, number> = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 };
    let next: number | null = null;
    if (e.key in map) next = (this.active() + map[e.key] + n) % n;
    if (e.key === 'Home') next = 0;
    if (e.key === 'End') next = n - 1;
    if (next === null) return;
    e.preventDefault();
    this.select(next);
    (document.getElementById('demo-tab-' + TABS[next].key) as HTMLElement | null)?.focus();
  }

  private stop(): void {
    this.autoplay.set(false);
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }
}
