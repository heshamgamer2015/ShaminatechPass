/**
 * Configuração comercial da landing page. Preencha os canais oficiais quando existirem — enquanto estiverem vazios,
 * os botões de contato levam ao formulário de interesse (que monta a mensagem para o canal configurado) ou, sem
 * canal, ao acesso à plataforma. Nenhum serviço externo (analytics, CRM, chat) é carregado sem configuração aqui.
 */
export const LANDING_CONFIG = {
  /** E-mail comercial da ShaminaTech (ex.: contato@...). Vazio = não exibir. */
  contactEmail: 'shaminatech@gmail.com' as string,
  /** WhatsApp comercial no formato internacional só com dígitos (ex.: 5511999990000). Vazio = não exibir. */
  whatsapp: '5545991054598' as string,
  /** Fase de testes: todos os planos gratuitos (o backend confirma em /api/public/plans e aplica no cadastro). */
  trialFree: true as boolean,
  /** Ponto de extensão para analytics futuro: chamado em cliques de CTA. Sem implementação = nada é enviado. */
  track: (_event: string, _data?: Record<string, string>): void => undefined,
};

export interface Plan {
  key: 'free' | 'growth' | 'pro';
  name: string;
  price: string;
  period: string;
  tagline: string;
  features: string[];
  highlight: boolean;
  cta: string;
}

/** Planos comerciais (preços previstos). Sem checkout: na fase de testes o cadastro é gratuito em qualquer plano. */
export const PLANS: Plan[] = [
  {
    key: 'free',
    name: 'Free',
    price: 'R$ 0',
    period: 'para sempre',
    tagline: 'Para conhecer e começar sem risco.',
    features: ['Até 10 clientes ativos', '1 programa de fidelidade', '1 tipo de fidelidade', 'QR Code de cadastro', 'Cartão no Google Wallet'],
    highlight: false,
    cta: 'Começar grátis',
  },
  {
    key: 'growth',
    name: 'Growth',
    price: 'R$ 59',
    period: '/mês',
    tagline: 'Para o negócio que quer ver os clientes voltando.',
    features: ['Até 150 clientes ativos', '2 programas de fidelidade', '2 tipos de fidelidade', 'Lembretes de recompensa e validade',
      'Relatórios de retorno', 'Personalização completa do cartão'],
    highlight: true,
    cta: 'Escolher Growth',
  },
  {
    key: 'pro',
    name: 'Pro',
    price: 'R$ 129',
    period: '/mês',
    tagline: 'Para quem quer todos os recursos, sem limites.',
    features: ['Clientes ativos ilimitados', 'Programas ilimitados', 'Os 4 tipos de fidelidade', 'Todos os recursos da plataforma',
      'Proximidade da loja nas carteiras¹'],
    highlight: false,
    cta: 'Escolher Pro',
  },
];
