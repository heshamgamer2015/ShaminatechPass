/**
 * Simulador comercial de retorno (landing page). TODOS os números são estimativas demonstrativas ajustáveis pelo
 * visitante — não são resultados medidos, garantia nem promessa. Faturamento não é lucro.
 *
 * Lógica (por mês):
 *   participantes            = clientes ativos × adesão
 *   visitas sem programa     = clientes ativos × visitas por cliente
 *   visitas extras (freq.)   = participantes × visitas por cliente × aumento de frequência
 *   clientes que voltam      = participantes × retorno adicional          (quem deixaria de voltar e volta)
 *   visitas extras (retorno) = clientes que voltam × visitas por cliente
 *   visitas adicionais       = visitas extras (freq.) + visitas extras (retorno)
 *   faturamento adicional    = visitas adicionais × ticket médio          (= retorno bruto; NÃO é lucro)
 *   recompensas no mês       = visitas dos participantes com programa ÷ compras para ganhar uma recompensa
 *   custo das recompensas    = recompensas no mês × custo médio de cada recompensa
 *   retorno líquido          = faturamento adicional × margem bruta − custo das recompensas − mensalidade do plano
 */
export interface SimulationInput {
  activeCustomers: number;
  averageTicket: number;
  visitsPerCustomer: number;
  participationPercent: number;
  frequencyIncreasePercent: number;
  extraReturnPercent: number;
  purchasesPerReward: number;
  rewardCost: number;
  grossMarginPercent: number;
  planCost: number;
}

export interface SimulationResult {
  participants: number;
  returningCustomers: number;
  baselineVisits: number;
  additionalVisits: number;
  baselineRevenue: number;
  additionalRevenue: number;
  rewardsPerMonth: number;
  rewardsCost: number;
  netReturn: number;
  revenueWithProgram: number;
  revenueGrowthPercent: number;
  annualNetReturn: number;
}

export const SIMULATION_DEFAULTS: SimulationInput = {
  activeCustomers: 400,
  averageTicket: 35,
  visitsPerCustomer: 1.5,
  participationPercent: 40,
  frequencyIncreasePercent: 20,
  extraReturnPercent: 10,
  purchasesPerReward: 10,
  rewardCost: 8,
  grossMarginPercent: 60,
  planCost: 59,
};

/** Perfis de partida (fictícios) para facilitar a primeira simulação. */
export const SIMULATION_PRESETS: { key: string; label: string; values: Partial<SimulationInput> }[] = [
  { key: 'cafe', label: 'Cafeteria', values: { activeCustomers: 400, averageTicket: 28, visitsPerCustomer: 3, purchasesPerReward: 10, rewardCost: 6 } },
  { key: 'restaurante', label: 'Restaurante', values: { activeCustomers: 600, averageTicket: 65, visitsPerCustomer: 1.5, purchasesPerReward: 8, rewardCost: 18 } },
  { key: 'barbearia', label: 'Barbearia', values: { activeCustomers: 250, averageTicket: 50, visitsPerCustomer: 1, purchasesPerReward: 6, rewardCost: 25 } },
  { key: 'loja', label: 'Loja', values: { activeCustomers: 300, averageTicket: 120, visitsPerCustomer: 0.8, purchasesPerReward: 5, rewardCost: 30 } },
];

const clamp = (v: number, min: number, max: number) => (Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : min);

/** Normaliza entradas fora do intervalo (campos digitados) antes do cálculo. */
export function normalize(input: SimulationInput): SimulationInput {
  return {
    activeCustomers: Math.round(clamp(input.activeCustomers, 0, 100_000)),
    averageTicket: clamp(input.averageTicket, 0, 10_000),
    visitsPerCustomer: clamp(input.visitsPerCustomer, 0, 60),
    participationPercent: clamp(input.participationPercent, 0, 100),
    frequencyIncreasePercent: clamp(input.frequencyIncreasePercent, 0, 200),
    extraReturnPercent: clamp(input.extraReturnPercent, 0, 100),
    purchasesPerReward: clamp(input.purchasesPerReward, 1, 100),
    rewardCost: clamp(input.rewardCost, 0, 10_000),
    grossMarginPercent: clamp(input.grossMarginPercent, 0, 100),
    planCost: clamp(input.planCost, 0, 100_000),
  };
}

export function simulate(raw: SimulationInput): SimulationResult {
  const i = normalize(raw);
  const participants = i.activeCustomers * (i.participationPercent / 100);
  const baselineVisits = i.activeCustomers * i.visitsPerCustomer;
  const frequencyVisits = participants * i.visitsPerCustomer * (i.frequencyIncreasePercent / 100);
  const returningCustomers = participants * (i.extraReturnPercent / 100);
  const returnVisits = returningCustomers * i.visitsPerCustomer;
  const additionalVisits = frequencyVisits + returnVisits;
  const baselineRevenue = baselineVisits * i.averageTicket;
  const additionalRevenue = additionalVisits * i.averageTicket;
  const participantVisits = participants * i.visitsPerCustomer + additionalVisits;
  const rewardsPerMonth = participantVisits / i.purchasesPerReward;
  const rewardsCost = rewardsPerMonth * i.rewardCost;
  const netReturn = additionalRevenue * (i.grossMarginPercent / 100) - rewardsCost - i.planCost;
  return {
    participants,
    returningCustomers,
    baselineVisits,
    additionalVisits,
    baselineRevenue,
    additionalRevenue,
    rewardsPerMonth,
    rewardsCost,
    netReturn,
    revenueWithProgram: baselineRevenue + additionalRevenue,
    revenueGrowthPercent: baselineRevenue > 0 ? (additionalRevenue / baselineRevenue) * 100 : 0,
    annualNetReturn: netReturn * 12,
  };
}
