import { ChangeDetectionStrategy, Component, DestroyRef, inject, signal } from '@angular/core';
import { Meta, MetaDefinition } from '@angular/platform-browser';
import { RouterLink } from '@angular/router';
import { BrandMarkComponent } from '../../shared/ui/brand-mark.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { LANDING_CONFIG, Plan } from './landing.config';
import { BenefitsSection } from './sections/benefits.section';
import { ContactSection } from './sections/contact.section';
import { DemoSection } from './sections/demo.section';
import { FaqSection } from './sections/faq.section';
import { HeroSection } from './sections/hero.section';
import { HowItWorksSection } from './sections/how-it-works.section';
import { JourneySection } from './sections/journey.section';
import { PlansSection } from './sections/plans.section';
import { SimulatorSection } from './sections/simulator.section';
import { TypesSection } from './sections/types.section';

const DESCRIPTION =
  'Fidelidade digital sem aplicativo: cartões de pontos, cashback, carimbos e níveis VIP na carteira do celular, cadastro por QR Code e relatórios de retorno. Comece grátis.';

/** Landing page comercial pública do ShaminaTech Pass (rota raiz para visitantes). */
@Component({
  selector: 'app-landing-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, BrandMarkComponent, IconComponent, HeroSection, HowItWorksSection, BenefitsSection, TypesSection,
    SimulatorSection, DemoSection, JourneySection, PlansSection, FaqSection, ContactSection],
  host: { class: 'lp', '(window:scroll)': 'onScroll()' },
  template: `
    <a class="skip-link" href="#conteudo-lp">Pular para o conteúdo</a>
    <header class="top" [class.scrolled]="scrolled()">
      <div class="lp-container bar">
        <a class="brand" href="#inicio" aria-label="ShaminaTech Pass — início">
          <app-brand-mark [size]="34" />
          <span class="names"><small>ShaminaTech</small><strong>Pass</strong></span>
        </a>
        <nav id="lp-nav" class="nav" [class.open]="menu()" aria-label="Seções">
          @for (l of links; track l.href) {
            <a [href]="l.href" (click)="menu.set(false)">{{ l.label }}</a>
          }
          <a class="enter" routerLink="/login">Entrar</a>
          <a class="lp-btn primary small" routerLink="/criar-conta" (click)="track('nav_criar_conta'); menu.set(false)">Criar conta grátis</a>
        </nav>
        <button type="button" class="burger" [attr.aria-expanded]="menu()" aria-controls="lp-nav"
                [attr.aria-label]="menu() ? 'Fechar menu' : 'Abrir menu'" (click)="menu.set(!menu())">
          <app-icon [name]="menu() ? 'x' : 'menu'" [size]="24" />
        </button>
      </div>
    </header>

    <main id="conteudo-lp" tabindex="-1">
      <div id="inicio"></div>
      <app-lp-hero (cta)="track($event)" />
      <app-lp-how />
      <app-lp-benefits />
      <app-lp-types />
      <app-lp-simulator (cta)="track($event)" />
      <app-lp-demo />
      <app-lp-journey />
      <app-lp-plans (choose)="choosePlan($event)" />
      <app-lp-faq />
      <app-lp-contact [plan]="plan()" (cta)="track($event)" />
    </main>

    <footer class="foot">
      <div class="lp-container foot-grid">
        <div class="foot-brand">
          <app-brand-mark [size]="28" />
          <span><strong>ShaminaTech Pass</strong><small>Um produto do ecossistema ShaminaTech.</small></span>
        </div>
        <nav aria-label="Rodapé">
          <a href="#como-funciona">Como funciona</a>
          <a href="#simulador">Simulador</a>
          <a href="#planos">Planos</a>
          <a href="#faq">Perguntas frequentes</a>
          <a routerLink="/login">Entrar</a>
        </nav>
        <small class="copy">© {{ year }} ShaminaTech. Google Wallet é marca da Google LLC; Apple Wallet é marca da Apple Inc.</small>
      </div>
    </footer>
  `,
  styleUrl: './landing.page.scss',
})
export class LandingPage {
  private readonly meta = inject(Meta);
  protected readonly year = new Date().getFullYear();
  protected readonly menu = signal(false);
  protected readonly scrolled = signal(false);
  protected readonly plan = signal('');
  protected readonly links = [
    { href: '#como-funciona', label: 'Como funciona' },
    { href: '#beneficios', label: 'Benefícios' },
    { href: '#simulador', label: 'Simulador' },
    { href: '#demonstracao', label: 'Demonstração' },
    { href: '#planos', label: 'Planos' },
    { href: '#faq', label: 'FAQ' },
  ];

  constructor() {
    const tags: MetaDefinition[] = [
      { name: 'description', content: DESCRIPTION },
      { property: 'og:title', content: 'ShaminaTech Pass — fidelidade digital sem aplicativo' },
      { property: 'og:description', content: DESCRIPTION },
      { property: 'og:type', content: 'website' },
      { name: 'theme-color', content: '#F43F5E' },
    ];
    tags.forEach((t) => this.meta.updateTag(t));
    inject(DestroyRef).onDestroy(() => {
      this.meta.removeTag("property='og:title'");
      this.meta.removeTag("property='og:description'");
      this.meta.removeTag("property='og:type'");
    });
  }

  protected onScroll(): void {
    this.scrolled.set(window.scrollY > 8);
  }

  protected choosePlan(p: Plan): void {
    this.plan.set(p.name);
    this.track('plano_' + p.key);
  }

  protected track(event: string): void {
    LANDING_CONFIG.track(event);
  }
}
