import { SIMULATION_DEFAULTS, SIMULATION_PRESETS, normalize, simulate } from './roi-simulator';

describe('simulador de retorno', () => {
  it('calcula cada etapa pela fórmula documentada (perfil Cafeteria)', () => {
    const r = simulate({ ...SIMULATION_DEFAULTS, ...SIMULATION_PRESETS[0].values });
    // 400 clientes × 40% = 160 participantes
    expect(r.participants).toBe(160);
    // 160 × 3 visitas × 20% = 96 visitas; 160 × 10% = 16 recuperados × 3 = 48 visitas
    expect(r.returningCustomers).toBe(16);
    expect(r.additionalVisits).toBe(144);
    // 144 × R$ 28
    expect(r.additionalRevenue).toBe(4032);
    // (160 × 3 + 144) ÷ 10 compras = 62,4 recompensas × R$ 6
    expect(r.rewardsPerMonth).toBeCloseTo(62.4, 5);
    expect(r.rewardsCost).toBeCloseTo(374.4, 5);
    // 4.032 × 60% − 374,40 − 59
    expect(r.netReturn).toBeCloseTo(1985.8, 5);
    expect(r.annualNetReturn).toBeCloseTo(1985.8 * 12, 5);
    expect(r.baselineRevenue).toBe(400 * 3 * 28);
    expect(r.revenueWithProgram).toBe(r.baselineRevenue + r.additionalRevenue);
  });

  it('nunca chama faturamento de lucro: o retorno líquido desconta margem, recompensas e plano', () => {
    const r = simulate({ ...SIMULATION_DEFAULTS, grossMarginPercent: 10, rewardCost: 50 });
    expect(r.additionalRevenue).toBeGreaterThan(0);
    expect(r.netReturn).toBeLessThan(0); // pode ser negativo: a simulação não esconde isso
  });

  it('sem participação não há ganho e o custo é só o plano', () => {
    const r = simulate({ ...SIMULATION_DEFAULTS, participationPercent: 0 });
    expect(r.additionalRevenue).toBe(0);
    expect(r.rewardsCost).toBe(0);
    expect(r.netReturn).toBe(-SIMULATION_DEFAULTS.planCost);
  });

  it('normaliza entradas inválidas sem quebrar o cálculo', () => {
    const n = normalize({ ...SIMULATION_DEFAULTS, activeCustomers: -5, participationPercent: 300, purchasesPerReward: 0, averageTicket: Number.NaN });
    expect(n.activeCustomers).toBe(0);
    expect(n.participationPercent).toBe(100);
    expect(n.purchasesPerReward).toBe(1);
    expect(n.averageTicket).toBe(0);
    const r = simulate({ ...SIMULATION_DEFAULTS, activeCustomers: 0 });
    expect(r.revenueGrowthPercent).toBe(0);
    expect(Number.isFinite(r.netReturn)).toBe(true);
  });
});
