import { TestBed } from '@angular/core/testing';
import { vi } from 'vitest';
import { Meta } from '@angular/platform-browser';
import { provideRouter } from '@angular/router';
import { LandingPage } from './landing.page';

describe('LandingPage', () => {
  async function setup() {
    await TestBed.configureTestingModule({ imports: [LandingPage], providers: [provideRouter([])] }).compileComponents();
    const fixture = TestBed.createComponent(LandingPage);
    await fixture.whenStable();
    return { fixture, el: fixture.nativeElement as HTMLElement };
  }

  it('tem todas as seções, um único h1 e navegação para cada âncora', async () => {
    const { el } = await setup();
    for (const id of ['como-funciona', 'beneficios', 'modelos', 'simulador', 'demonstracao', 'jornada', 'planos', 'faq', 'contato']) {
      expect(el.querySelector('#' + id), id).not.toBeNull();
    }
    expect(el.querySelectorAll('h1').length).toBe(1);
    expect(el.querySelectorAll('section h2').length).toBeGreaterThanOrEqual(9);
    expect(el.textContent).toContain('Testar demonstração');
    expect(el.textContent).toContain('Ver planos');
  });

  it('mostra os três planos com os valores provisórios e sem checkout', async () => {
    const { el } = await setup();
    const plans = [...el.querySelectorAll('.plan')].map((p) => p.textContent ?? '');
    expect(plans.length).toBe(3);
    expect(plans[0]).toContain('R$ 0');
    expect(plans[0]).toContain('Até 10 clientes ativos');
    expect(plans[1]).toContain('R$ 59');
    expect(plans[1]).toContain('Até 150 clientes ativos');
    expect(plans[2]).toContain('R$ 129');
    expect(plans[2]).toContain('Clientes ativos ilimitados');
    expect(el.querySelector('form[action], input[type=password], [name*=card]')).toBeNull();
  });

  it('o plano escolhido vai para a mensagem e o envio abre o WhatsApp ou o e-mail comercial', async () => {
    const { fixture, el } = await setup();
    const open = vi.spyOn(window, 'open').mockReturnValue(null);
    el.querySelectorAll<HTMLAnchorElement>('.plan .talk')[1].click();
    await fixture.whenStable();
    expect(el.querySelector('.plan-line')!.textContent).toContain('Growth');
    const [whatsapp, email] = [...el.querySelectorAll<HTMLButtonElement>('.form-card button')];
    expect(whatsapp.disabled).toBe(true); // nome e negócio são obrigatórios

    const type = (id: string, v: string) => {
      const i = el.querySelector<HTMLInputElement>('#' + id)!;
      i.value = v;
      i.dispatchEvent(new Event('input'));
    };
    type('lead-name', 'Ana');
    type('lead-business', 'Café Aroma');
    await fixture.whenStable();
    expect(whatsapp.disabled).toBe(false);

    whatsapp.click();
    const wa = String(open.mock.calls[0][0]);
    expect(wa.startsWith('https://wa.me/5545991054598?text=')).toBe(true);
    const text = decodeURIComponent(wa.split('text=')[1]);
    expect(text).toContain('Nome: Ana');
    expect(text).toContain('Negócio: Café Aroma (Cafeteria)');
    expect(text).toContain('Plano de interesse: Growth');

    email.click();
    expect(String(open.mock.calls[1][0]).startsWith('mailto:shaminatech@gmail.com?subject=')).toBe(true);
    expect(el.textContent).toContain('(45) 99105-4598');
    open.mockRestore();
  });

  it('cada plano abre o cadastro com o plano escolhido e a fase de testes aparece como gratuita', async () => {
    const { el } = await setup();
    const ctas = [...el.querySelectorAll<HTMLAnchorElement>('.plan .lp-btn')].map((a) => a.getAttribute('href'));
    expect(ctas).toEqual(['/criar-conta?plano=free', '/criar-conta?plano=growth', '/criar-conta?plano=pro']);
    expect(el.querySelector('#planos .trial')!.textContent).toContain('todos os planos estão');
    expect(el.querySelector('#planos .trial')!.textContent).toContain('sem cobrança');
    expect(el.querySelectorAll('.plan .free-now').length).toBe(2); // Growth e Pro: grátis nos testes
    expect(el.querySelector('header a[href="/criar-conta"]')).not.toBeNull();
  });

  it('deixa claro que o simulador é estimativa e que faturamento não é lucro', async () => {
    const { el } = await setup();
    const sim = el.querySelector('#simulador')!.textContent ?? '';
    expect(sim).toContain('estimativa demonstrativa');
    expect(sim).toContain('Faturamento não é lucro');
    expect(sim).not.toMatch(/lucro garantido|garantimos/i);
  });

  it('não promete o Apple Wallet como disponível e define a descrição da página', async () => {
    const { el } = await setup();
    expect(el.textContent).toContain('em fase de homologação');
    expect(TestBed.inject(Meta).getTag('name="description"')?.content).toContain('Fidelidade digital sem aplicativo');
  });

  it('o menu do celular abre e fecha ao escolher uma seção', async () => {
    const { fixture, el } = await setup();
    const burger = el.querySelector<HTMLButtonElement>('.burger')!;
    burger.click();
    await fixture.whenStable();
    expect(burger.getAttribute('aria-expanded')).toBe('true');
    el.querySelector<HTMLAnchorElement>('#lp-nav a[href="#planos"]')!.click();
    await fixture.whenStable();
    expect(burger.getAttribute('aria-expanded')).toBe('false');
  });
});
