import { ChangeDetectionStrategy, Component, inject, input } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';

/**
 * Página de mensagem genérica (acesso negado, página inexistente, sem vínculo).
 * O conteúdo vem do `data` da rota, ligado como input.
 */
@Component({
  selector: 'app-message-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink],
  styleUrl: '../auth/auth-page.scss',
  template: `
    <section class="card auth-card">
      <div class="brand"><span class="mark" aria-hidden="true">P</span><span>ShaminaTech <strong>Pass</strong></span></div>
      <h1>{{ heading() }}</h1>
      <p class="muted">{{ message() }}</p>
      <div class="actions">
        <a class="btn btn-primary" routerLink="/">Ir para o início</a>
        @if (auth.user()) {
          <button class="btn" type="button" (click)="logout()">Sair</button>
        }
      </div>
    </section>
  `,
})
export class MessagePage {
  protected readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  readonly heading = input('Página não encontrada');
  readonly message = input('O endereço acessado não existe.');

  protected async logout(): Promise<void> {
    await this.auth.logout();
    await this.router.navigate(['/login']);
  }
}
