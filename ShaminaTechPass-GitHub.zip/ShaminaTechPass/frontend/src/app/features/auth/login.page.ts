import { ChangeDetectionStrategy, Component, inject, input, signal } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { AuthService } from '../../core/auth/auth.service';
import { AlertComponent } from '../../shared/ui/alert.component';
import { FieldErrorComponent } from '../../shared/ui/field-error.component';
import { IconComponent } from '../../shared/ui/icon.component';

@Component({
  selector: 'app-login-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, AlertComponent, FieldErrorComponent, IconComponent],
  styleUrl: './auth-page.scss',
  template: `
    <div class="auth-shell">
      <aside class="auth-side" aria-hidden="true">
        <div class="brand light"><span class="mark">P</span><span>ShaminaTech <strong>Pass</strong></span></div>
        <div class="pitch">
          <h2>Fidelidade digital no balcão, no celular do cliente.</h2>
          <ul>
            <li><app-icon name="check" [size]="16" /> Cartões de carimbos, pontos e cashback</li>
            <li><app-icon name="check" [size]="16" /> Cadastro pelo QR Code, sem aplicativo</li>
            <li><app-icon name="check" [size]="16" /> Cartão no Google Wallet</li>
          </ul>
        </div>
        <span class="side-foot">ShaminaTech</span>
      </aside>

      <section class="auth-card">
        <div class="brand"><span class="mark" aria-hidden="true">P</span><span>ShaminaTech <strong>Pass</strong></span></div>
        <h1>Entrar</h1>
        <p class="muted subtitle">Acesse o painel do seu estabelecimento.</p>

        @if (sessao() === 'expirada') {
          <app-alert kind="warning">Sua sessão terminou. Entre novamente.</app-alert>
        }
        @if (error(); as e) {
          <app-alert kind="error">{{ e.message }}</app-alert>
        }

        <form class="form" [formGroup]="form" (ngSubmit)="submit()" novalidate>
          <div class="field">
            <label for="email">E-mail</label>
            <input id="email" class="input input-lg" type="email" formControlName="email" autocomplete="username" autofocus
                   inputmode="email" [attr.aria-invalid]="form.controls.email.touched && form.controls.email.invalid"
                   [class.invalid]="form.controls.email.touched && form.controls.email.invalid" />
            <app-field-error [local]="form.controls.email.touched && form.controls.email.invalid ? 'Informe um e-mail válido.' : null" />
          </div>
          <div class="field">
            <label for="password">Senha</label>
            <div class="pw">
              <input id="password" class="input input-lg" [type]="showPassword() ? 'text' : 'password'" formControlName="password"
                     autocomplete="current-password" (keyup)="capsCheck($event)" (keydown)="capsCheck($event)"
                     [attr.aria-invalid]="form.controls.password.touched && form.controls.password.invalid"
                     [class.invalid]="form.controls.password.touched && form.controls.password.invalid" aria-describedby="caps" />
              <button type="button" class="pw-toggle" (click)="showPassword.set(!showPassword())" [attr.aria-pressed]="showPassword()"
                      aria-controls="password">{{ showPassword() ? 'Ocultar' : 'Mostrar' }}</button>
            </div>
            <span id="caps" class="caps" [class.on]="capsLock()" aria-live="polite">{{ capsLock() ? 'Caps Lock ativado.' : '' }}</span>
            <app-field-error [local]="form.controls.password.touched && form.controls.password.invalid ? 'Informe a senha.' : null" />
          </div>
          <button class="btn btn-primary btn-lg btn-block" type="submit" [disabled]="loading()">
            {{ loading() ? 'Entrando…' : 'Entrar' }}
          </button>
        </form>
        <p class="links muted">Esqueceu a senha? Fale com o responsável pelo seu estabelecimento.</p>
      </section>
    </div>
  `,
})
export class LoginPage {
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  /** Query params ligados por withComponentInputBinding. */
  readonly voltar = input<string>();
  readonly sessao = input<string>();

  protected readonly loading = signal(false);
  protected readonly showPassword = signal(false);
  protected readonly capsLock = signal(false);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly form = inject(NonNullableFormBuilder).group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', Validators.required],
  });

  protected async submit(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      // Leva o cursor ao primeiro campo com erro (teclado e leitores de tela).
      const first = this.form.controls.email.invalid ? 'email' : 'password';
      setTimeout(() => document.getElementById(first)?.focus());
      return;
    }
    this.loading.set(true);
    this.error.set(null);
    try {
      const { email, password } = this.form.getRawValue();
      const me = await this.auth.login(email, password);
      const target = me.passwordChangeRequired ? '/alterar-senha' : this.safeReturnUrl() ?? this.auth.homeUrl();
      await this.router.navigateByUrl(target);
    } catch (e) {
      this.error.set(toApiError(e));
      this.form.controls.password.reset();
      this.showPassword.set(false);
    } finally {
      this.loading.set(false);
    }
  }

  /** Avisa quando o Caps Lock está ligado (erro comum de senha). */
  protected capsCheck(event: Event): void {
    const e = event as KeyboardEvent;
    if (typeof e.getModifierState === 'function') this.capsLock.set(e.getModifierState('CapsLock'));
  }

  /** Aceita apenas caminhos internos (evita redirecionamento para sites externos). */
  private safeReturnUrl(): string | null {
    const url = this.voltar();
    return url && url.startsWith('/') && !url.startsWith('//') && url !== '/login' ? url : null;
  }
}
