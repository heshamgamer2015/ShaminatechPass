import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { AbstractControl, NonNullableFormBuilder, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { toSignal } from '@angular/core/rxjs-interop';
import { Router, RouterLink } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { AuthService } from '../../core/auth/auth.service';
import { NotificationService } from '../../core/notifications/notification.service';
import { AlertComponent } from '../../shared/ui/alert.component';
import { FieldErrorComponent } from '../../shared/ui/field-error.component';

/** Mesmas regras do backend (PasswordPolicy): o servidor continua sendo a validação definitiva. */
function passwordPolicy(control: AbstractControl): ValidationErrors | null {
  const value = String(control.value ?? '');
  if (value.length < 10) return { policy: 'Use pelo menos 10 caracteres.' };
  if (!/[A-Za-zÀ-ÿ]/.test(value) || !/\d/.test(value)) return { policy: 'Use letras e números.' };
  return null;
}

@Component({
  selector: 'app-change-password-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, RouterLink, AlertComponent, FieldErrorComponent],
  styleUrl: './auth-page.scss',
  template: `
    <section class="auth-card single">
      <div class="brand"><span class="mark" aria-hidden="true">P</span><span>ShaminaTech <strong>Pass</strong></span></div>
      <h1>Alterar senha</h1>
      <p class="muted subtitle">Escolha uma senha que você não usa em outros sites.</p>
      @if (required()) {
        <app-alert kind="info">Por segurança, defina uma nova senha para continuar.</app-alert>
      }
      @if (error(); as e) {
        @if (!hasFieldErrors()) {
          <app-alert kind="error">{{ e.message }}</app-alert>
        }
      }

      <form class="form" [formGroup]="form" (ngSubmit)="submit()" novalidate>
        <div class="field">
          <label for="current">Senha atual</label>
          <input id="current" class="input input-lg" [type]="show() ? 'text' : 'password'" formControlName="currentPassword" autocomplete="current-password" />
          <app-field-error [server]="error()?.fieldErrors?.['currentPassword']"
                           [local]="touchedInvalid('currentPassword') ? 'Informe a senha atual.' : null" />
        </div>
        <div class="field">
          <label for="new">Nova senha</label>
          <input id="new" class="input input-lg" [type]="show() ? 'text' : 'password'" formControlName="newPassword" autocomplete="new-password"
                 aria-describedby="pw-rules" />
          <ul id="pw-rules" class="rules" aria-label="Requisitos da nova senha">
            <li [class.ok]="newValue().length >= 10">Pelo menos 10 caracteres</li>
            <li [class.ok]="hasLetter()">Letras</li>
            <li [class.ok]="hasDigit()">Números</li>
          </ul>
          <app-field-error [server]="error()?.fieldErrors?.['newPassword']"
                           [local]="touchedInvalid('newPassword') ? form.controls.newPassword.errors?.['policy'] ?? 'Informe a nova senha.' : null" />
        </div>
        <div class="field">
          <label for="confirm">Confirme a nova senha</label>
          <input id="confirm" class="input input-lg" [type]="show() ? 'text' : 'password'" formControlName="confirmPassword" autocomplete="new-password" />
          <app-field-error [local]="form.controls.confirmPassword.touched && mismatch() ? 'As senhas não conferem.' : null" />
        </div>
        <label class="check"><input type="checkbox" [checked]="show()" (change)="show.set(!show())" /> Mostrar as senhas</label>
        <button class="btn btn-primary btn-lg btn-block" type="submit" [disabled]="loading()">
          {{ loading() ? 'Salvando…' : 'Salvar nova senha' }}
        </button>
      </form>
      <p class="links">
        @if (required()) {
          <button class="btn btn-ghost btn-sm" type="button" (click)="logout()">Sair</button>
        } @else {
          <a routerLink="/">Voltar</a>
        }
      </p>
    </section>
  `,
})
export class ChangePasswordPage {
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly notifications = inject(NotificationService);

  protected readonly required = computed(() => this.auth.user()?.passwordChangeRequired ?? false);
  protected readonly loading = signal(false);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly hasFieldErrors = computed(() => Object.keys(this.error()?.fieldErrors ?? {}).length > 0);
  protected readonly form = inject(NonNullableFormBuilder).group({
    currentPassword: ['', Validators.required],
    newPassword: ['', [Validators.required, passwordPolicy]],
    confirmPassword: ['', Validators.required],
  });
  protected readonly show = signal(false);
  /** Valor da nova senha para a lista de requisitos (só orientação; a regra vale no servidor). */
  protected readonly newValue = toSignal(this.form.controls.newPassword.valueChanges, { initialValue: '' });
  protected readonly hasLetter = computed(() => /[A-Za-zÀ-ÿ]/.test(this.newValue()));
  protected readonly hasDigit = computed(() => /\d/.test(this.newValue()));

  protected touchedInvalid(name: 'currentPassword' | 'newPassword'): boolean {
    const control = this.form.controls[name];
    return control.touched && control.invalid;
  }

  protected mismatch(): boolean {
    const { newPassword, confirmPassword } = this.form.getRawValue();
    return newPassword !== confirmPassword;
  }

  protected async submit(): Promise<void> {
    if (this.form.invalid || this.mismatch()) {
      this.form.markAllAsTouched();
      return;
    }
    this.loading.set(true);
    this.error.set(null);
    try {
      const { currentPassword, newPassword } = this.form.getRawValue();
      await this.auth.changePassword(currentPassword, newPassword);
      this.notifications.success('Senha alterada com sucesso.');
      await this.router.navigateByUrl(this.auth.homeUrl());
    } catch (e) {
      this.error.set(toApiError(e));
    } finally {
      this.loading.set(false);
    }
  }

  protected async logout(): Promise<void> {
    await this.auth.logout();
    await this.router.navigate(['/login']);
  }
}
