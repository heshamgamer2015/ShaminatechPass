import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { vi } from 'vitest';
import { LoginPage } from './login.page';

describe('LoginPage', () => {
  async function setup() {
    await TestBed.configureTestingModule({
      imports: [LoginPage],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
    const fixture = TestBed.createComponent(LoginPage);
    const navigate = vi.spyOn(TestBed.inject(Router), 'navigateByUrl').mockResolvedValue(true);
    await fixture.whenStable();
    return { fixture, el: fixture.nativeElement as HTMLElement, http: TestBed.inject(HttpTestingController), navigate };
  }

  /** Deixa a cadeia de promises do login (csrf → login → navegação) terminar. */
  async function settle(fixture: { whenStable(): Promise<unknown> }) {
    await new Promise((resolve) => setTimeout(resolve));
    await fixture.whenStable();
  }

  function fill(el: HTMLElement, email: string, password: string) {
    const emailInput = el.querySelector<HTMLInputElement>('#email')!;
    const passwordInput = el.querySelector<HTMLInputElement>('#password')!;
    emailInput.value = email;
    emailInput.dispatchEvent(new Event('input'));
    passwordInput.value = password;
    passwordInput.dispatchEvent(new Event('input'));
  }

  it('não envia formulário inválido e mostra os erros dos campos', async () => {
    const { fixture, el, http } = await setup();
    el.querySelector('form')!.dispatchEvent(new Event('submit'));
    await fixture.whenStable();
    expect(el.textContent).toContain('Informe um e-mail válido.');
    expect(el.textContent).toContain('Informe a senha.');
    http.expectNone('/api/auth/login');
  });

  it('exibe a mensagem genérica do backend quando o login falha', async () => {
    const { fixture, el, http } = await setup();
    fill(el, 'dono@teste.local', 'senha-errada');
    el.querySelector('form')!.dispatchEvent(new Event('submit'));

    http.expectOne('/api/auth/csrf').flush(null, { status: 204, statusText: 'No Content' });
    await fixture.whenStable();
    http.expectOne('/api/auth/login').flush(
      { code: 'INVALID_CREDENTIALS', detail: 'E-mail ou senha inválidos.' },
      { status: 401, statusText: 'Unauthorized' },
    );
    await settle(fixture);
    expect(el.querySelector('app-alert')?.textContent).toContain('E-mail ou senha inválidos.');
  });

  it('após login com senha temporária, leva para a troca de senha', async () => {
    const { fixture, el, http, navigate } = await setup();
    fill(el, 'novo@teste.local', 'Senha-temp-123');
    el.querySelector('form')!.dispatchEvent(new Event('submit'));

    http.expectOne('/api/auth/csrf').flush(null, { status: 204, statusText: 'No Content' });
    await fixture.whenStable();
    http.expectOne('/api/auth/login').flush({
      id: 2, email: 'novo@teste.local', fullName: 'Novo', platformRole: null, passwordChangeRequired: true, memberships: [],
    });
    await settle(fixture);
    expect(navigate).toHaveBeenCalledWith('/alterar-senha');
  });
});
