import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { vi } from 'vitest';
import { PublicSignupInfo } from '../../core/loyalty-models';
import { DEVICE, DeviceInfo, detectDevice } from '../../shared/device';
import { SignupPage } from './signup.page';

const TOKEN = 'b'.repeat(32);

function info(over: Partial<PublicSignupInfo> = {}): PublicSignupInfo {
  return {
    status: 'OPEN', message: null, establishmentName: 'Café Aroma', programName: 'Cartão Café', programDescription: 'Para quem ama café',
    programType: 'STAMPS', rules: ['Ganhe 1 carimbo a cada visita registrada no balcão.'], rewards: [],
    validity: ['O cartão vence após 90 dias sem compras registradas.'], stampsRequired: 10, stampReward: 'Um café',
    design: { brandColor: '#F43F5E', textColor: '#FFFFFF', logoUrl: null, heroUrl: null, cardMessage: null, rewardInfo: null },
    formToken: '1700000000000.' + 'f'.repeat(64), walletAvailable: true, ...over,
  };
}

describe('SignupPage', () => {
  async function setup(data: PublicSignupInfo, device: DeviceInfo = detectDevice({ userAgent: '' })) {
    await TestBed.configureTestingModule({
      imports: [SignupPage],
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([]), { provide: DEVICE, useValue: device }],
    }).compileComponents();
    const fixture = TestBed.createComponent(SignupPage);
    fixture.componentRef.setInput('token', TOKEN);
    await fixture.whenStable();
    const http = TestBed.inject(HttpTestingController);
    http.expectOne(`/api/public/signup/${TOKEN}`).flush(data);
    await fixture.whenStable();
    return { fixture, el: fixture.nativeElement as HTMLElement, http };
  }

  function fill(el: HTMLElement, id: string, value: string) {
    const input = el.querySelector<HTMLInputElement>('#' + id)!;
    input.value = value;
    input.dispatchEvent(new Event('input'));
  }

  function check(el: HTMLElement, index: number) {
    const box = el.querySelectorAll<HTMLInputElement>('input[type=checkbox]')[index];
    box.click();
  }

  it('mostra o programa, as regras e as informações de privacidade', async () => {
    const { el } = await setup(info());
    expect(el.textContent).toContain('Café Aroma');
    expect(el.textContent).toContain('Ganhe 1 carimbo a cada visita');
    expect(el.textContent).toContain('Informações de privacidade');
    // comunicações promocionais: consentimento separado e desmarcado
    const boxes = el.querySelectorAll<HTMLInputElement>('input[type=checkbox]');
    expect(boxes.length).toBe(2);
    expect(boxes[1].checked).toBe(false);
  });

  it('não envia sem nome, celular e ciência da privacidade', async () => {
    const { fixture, el, http } = await setup(info());
    el.querySelector<HTMLButtonElement>('button[type=submit]')!.click();
    await fixture.whenStable();
    http.expectNone(`/api/public/signup/${TOKEN}`);
    expect(el.textContent).toContain('Informe seu nome.');
    expect(el.textContent).toContain('Confirme que leu as informações de privacidade.');
  });

  it('envia uma vez, com CSRF, e leva à página da carteira', async () => {
    const { fixture, el, http } = await setup(info());
    const navigate = vi.spyOn(TestBed.inject(Router), 'navigateByUrl').mockResolvedValue(true);
    fill(el, 'fullName', 'Maria Souza');
    fill(el, 'phone', '(11) 98888-1111');
    check(el, 0);
    await fixture.whenStable();
    const button = el.querySelector<HTMLButtonElement>('button[type=submit]')!;
    button.click();
    button.click(); // clique duplo: uma única requisição
    await fixture.whenStable();
    http.expectOne('/api/auth/csrf').flush(null);
    const post = http.expectOne((r) => r.method === 'POST' && r.url === `/api/public/signup/${TOKEN}`);
    expect(post.request.body.privacyAccepted).toBe(true);
    expect(post.request.body.marketingOptIn).toBe(false);
    expect(post.request.body.requestId).toMatch(/^[0-9a-f]{32}$/);
    expect(post.request.body.formToken).toContain('.');
    post.flush({
      status: 'REGISTERED', establishmentName: 'Café Aroma', programName: 'Cartão Café', programType: 'STAMPS',
      consumerFirstName: 'Maria', walletPath: '/carteira/' + 'c'.repeat(32), walletStatus: 'LINK_READY', message: 'ok',
    });
    await fixture.whenStable();
    expect(navigate).toHaveBeenCalledWith('/carteira/' + 'c'.repeat(32) + '?cadastro=1', { replaceUrl: true });
  });

  it('sem carteira configurada não afirma que o cartão foi adicionado', async () => {
    const { fixture, el, http } = await setup(info({ walletAvailable: false }));
    fill(el, 'fullName', 'Maria Souza');
    fill(el, 'phone', '11988881111');
    check(el, 0);
    el.querySelector<HTMLButtonElement>('button[type=submit]')!.click();
    await fixture.whenStable();
    http.expectOne('/api/auth/csrf').flush(null);
    http.expectOne((r) => r.method === 'POST').flush({
      status: 'REGISTERED', establishmentName: 'Café Aroma', programName: 'Cartão Café', programType: 'STAMPS',
      consumerFirstName: 'Maria', walletPath: null, walletStatus: 'NOT_CONFIGURED', message: 'Seu cartão está pronto.',
    });
    await fixture.whenStable();
    expect(el.textContent).toContain('Cadastro concluído');
    expect(el.textContent).toContain('Cartão preparado');
    expect(el.textContent).toContain('Carteira digital indisponível no momento');
    expect(el.textContent).not.toContain('adicionado ao Google Wallet');
  });

  it('cadastro já existente recebe mensagem genérica, sem dados do cartão', async () => {
    const { fixture, el, http } = await setup(info());
    fill(el, 'fullName', 'Outra Pessoa');
    fill(el, 'phone', '11988881111');
    check(el, 0);
    el.querySelector<HTMLButtonElement>('button[type=submit]')!.click();
    await fixture.whenStable();
    http.expectOne('/api/auth/csrf').flush(null);
    http.expectOne((r) => r.method === 'POST').flush(
      { code: 'SIGNUP_NOT_POSSIBLE', detail: 'Não foi possível concluir o cadastro online com estes dados. Se você já participa, peça no balcão para receber seu cartão novamente.' },
      { status: 409, statusText: 'Conflict' },
    );
    await fixture.whenStable();
    expect(el.textContent).toContain('peça no balcão');
    expect(el.querySelector('a[href^="/carteira"]')).toBeNull();
  });

  it('inscrições esgotadas e cadastro indisponível não mostram o formulário', async () => {
    const full = await setup(info({ status: 'FULL', message: 'As inscrições estão temporariamente esgotadas.', formToken: null }));
    expect(full.el.textContent).toContain('temporariamente esgotadas');
    expect(full.el.querySelector('form')).toBeNull();
    TestBed.resetTestingModule();
    const off = await setup(info({ status: 'UNAVAILABLE', message: 'O cadastro neste programa não está disponível no momento.',
      establishmentName: null, programName: null }));
    expect(off.el.textContent).toContain('Cadastro indisponível');
    expect(off.el.querySelector('form')).toBeNull();
  });

  it('o mesmo QR Code mostra as duas carteiras e destaca a do aparelho', async () => {
    const iphone = detectDevice({
      userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',
      maxTouchPoints: 5,
    });
    const { el } = await setup(info({ wallets: ['GOOGLE_WALLET', 'APPLE_WALLET'] }), iphone);
    const items = [...el.querySelectorAll('.pub-wallets li')].map((li) => li.textContent?.replace(/\s+/g, ' ').trim());
    expect(items[0]).toContain('Carteira da Apple (iPhone)');
    expect(items[0]).toContain('recomendado para o seu iPhone');
    expect(items[1]).toContain('Google Wallet (Android)');
    expect(el.querySelector('form')).not.toBeNull(); // o cadastro continua o mesmo nos dois aparelhos
  });
});
