import { ChangeDetectionStrategy, Component, computed, effect, inject, input, signal } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { SignupApi } from '../../core/api/signup-api.service';
import { PublicSignupInfo, PublicSignupResult } from '../../core/loyalty-models';
import { readableTextColor } from '../../shared/color';
import { DEVICE, PLATFORM_LABELS } from '../../shared/device';
import { PROGRAM_TYPE_LABELS, label } from '../../shared/labels';

/** Identificador aleatório do envio: repetir o mesmo envio (clique duplo, rede) não cria um segundo cadastro. */
function newRequestId(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Página pública de cadastro aberta pelo QR Code do balcão (sem login, otimizada para celular).
 * Pede só o necessário: nome e telefone (identificação no balcão e recuperação presencial do cartão) e e-mail opcional.
 * A ciência da privacidade é obrigatória; receber comunicações é um consentimento separado e desmarcado.
 * Se o telefone ou e-mail já estiver cadastrado, a página NÃO mostra o cartão existente: orienta a pedir no balcão.
 */
@Component({
  selector: 'app-signup-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule],
  template: `
    <main class="page">
      @if (loadError(); as e) {
        <section class="panel center">
          <span class="brand" aria-hidden="true">P</span>
          <h1>QR Code indisponível</h1>
          <p>{{ e }}</p>
        </section>
      } @else if (info(); as i) {
        @if (i.status === 'UNAVAILABLE') {
          <section class="panel center">
            <span class="brand" aria-hidden="true">P</span>
            <h1>Cadastro indisponível</h1>
            <p>{{ i.message }}</p>
          </section>
        } @else if (result(); as r) {
          <section class="panel center" aria-live="polite">
            <header class="band" [style.background]="brand()" [style.color]="ink()">
              @if (i.design?.logoUrl) { <img class="logo" [src]="i.design!.logoUrl" alt="" /> }
              <strong>{{ r.establishmentName }}</strong>
            </header>
            <ol class="steps" aria-label="Situação do cadastro">
              <li class="done">Cadastro concluído</li>
              <li class="done">Cartão preparado</li>
              <li [class.pending]="true">Carteira digital indisponível no momento</li>
            </ol>
            <h1>Tudo certo, {{ r.consumerFirstName }}!</h1>
            <p>Você já participa do programa <strong>{{ r.programName }}</strong>.</p>
            <p class="info">{{ r.message }}</p>
            <p class="hint">O cartão ainda não foi adicionado a nenhuma carteira digital. Quando a carteira estiver disponível,
              peça o link no balcão.</p>
          </section>
        } @else {
          <section class="panel">
            <header class="band" [style.background]="brand()" [style.color]="ink()">
              @if (i.design?.logoUrl) {
                <img class="logo" [src]="i.design!.logoUrl" alt="" />
              } @else {
                <span class="initial" aria-hidden="true">{{ initial() }}</span>
              }
              <div>
                <span class="small">{{ i.establishmentName }}</span>
                <h1>{{ i.programName }}</h1>
                <span class="small">{{ typeLabel(i.programType) }}</span>
              </div>
            </header>
            @if (i.design?.heroUrl) {
              <img class="hero" [src]="i.design!.heroUrl" alt="" />
            }
            <div class="content">
              @if (i.programDescription) { <p>{{ i.programDescription }}</p> }
              @if (i.design?.cardMessage) { <p class="muted">{{ i.design!.cardMessage }}</p> }

              @if (wallets(i).length > 0) {
                <div class="pub-wallets" aria-label="Carteiras digitais disponíveis">
                  <span class="small muted">Seu cartão fica no celular, sem baixar aplicativo:</span>
                  <ul>
                    @for (w of wallets(i); track w.kind) {
                      <li [class.rec]="w.recommended">{{ w.label }}
                        @if (w.recommended) { <small>· recomendado para o seu {{ platformLabel }}</small> }</li>
                    }
                  </ul>
                </div>
              }

              <h2>Como funciona</h2>
              <ul class="benefits">@for (r of i.rules; track r) { <li>{{ r }}</li> }</ul>

              @if (i.rewards.length > 0) {
                <h2>Recompensas</h2>
                <ul class="rewards">
                  @for (r of i.rewards; track r.name) {
                    <li><strong>{{ r.name }}</strong> <span class="cost">{{ r.cost }} pontos</span>
                      @if (r.description) { <br /><span class="muted">{{ r.description }}</span> }</li>
                  }
                </ul>
              }
              @if (i.design?.rewardInfo) { <p class="muted">{{ i.design!.rewardInfo }}</p> }

              <details class="more">
                <summary>Validade do cartão</summary>
                <ul class="list">@for (v of i.validity; track v) { <li>{{ v }}</li> }</ul>
              </details>

              @if (i.status === 'FULL') {
                <p class="warn" role="status">{{ i.message }}</p>
              } @else {
                <h2 class="form-title">Seu cadastro <small class="muted">· leva menos de 1 minuto</small></h2>
                <form [formGroup]="form" (ngSubmit)="submit()" novalidate>
                  @if (submitError(); as e) {
                    <p class="error" role="alert">{{ e.message }}</p>
                    @if (e.code === 'SIGNUP_FORM_EXPIRED') {
                      <button class="secondary" type="button" (click)="reload()">Recarregar o formulário</button>
                    }
                  }
                  <label for="fullName">Nome</label>
                  <input id="fullName" formControlName="fullName" autocomplete="name" maxlength="150"
                         [attr.aria-invalid]="invalid('fullName')" aria-describedby="fullName-error" />
                  @if (invalid('fullName') || fe('fullName')) {
                    <span class="field-error" id="fullName-error">{{ fe('fullName') ?? 'Informe seu nome.' }}</span>
                  }

                  <label for="phone">Celular com DDD</label>
                  <input id="phone" formControlName="phone" type="tel" inputmode="tel" autocomplete="tel" maxlength="25"
                         placeholder="(11) 91234-5678" [attr.aria-invalid]="invalid('phone')" aria-describedby="phone-hint phone-error" />
                  <span class="hint" id="phone-hint">Usado para identificar você no balcão e recuperar seu cartão.</span>
                  @if (invalid('phone') || fe('phone')) {
                    <span class="field-error" id="phone-error">{{ fe('phone') ?? 'Informe o celular com DDD (10 a 13 dígitos).' }}</span>
                  }

                  <label for="email">E-mail <span class="muted">(opcional)</span></label>
                  <input id="email" formControlName="email" type="email" inputmode="email" autocomplete="email" maxlength="254"
                         [attr.aria-invalid]="invalid('email')" aria-describedby="email-error" />
                  @if (invalid('email') || fe('email')) {
                    <span class="field-error" id="email-error">{{ fe('email') ?? 'E-mail inválido.' }}</span>
                  }

                  <!-- Campo isca: invisível para pessoas; robôs costumam preencher. -->
                  <div class="trap" aria-hidden="true">
                    <label for="website">Não preencha</label>
                    <input id="website" formControlName="website" tabindex="-1" autocomplete="off" />
                  </div>

                  <details class="privacy">
                    <summary>Informações de privacidade</summary>
                    <p><strong>{{ i.establishmentName }}</strong> é responsável pelo programa e usa seu nome, celular e, se informado,
                      e-mail apenas para identificar seu cartão de fidelidade, registrar compras, benefícios e resgates e
                      recuperar o cartão no balcão.</p>
                    <p>O ShaminaTech Pass é a plataforma que guarda esses dados em nome do estabelecimento. Não pedimos CPF,
                      endereço nem data de nascimento.</p>
                    @if (i.walletAvailable) {
                      <p>Se você adicionar o cartão ao Google Wallet ou ao Apple Wallet, a carteira recebe o nome do programa, seu
                        primeiro nome e o saldo — nunca seu celular ou e-mail.</p>
                    }
                    <p>Para corrigir ou excluir seus dados, fale com o estabelecimento.</p>
                  </details>

                  <label class="check">
                    <input type="checkbox" formControlName="privacyAccepted" />
                    <span>Li as informações de privacidade e quero participar do programa.</span>
                  </label>
                  @if (invalid('privacyAccepted') || fe('privacyAccepted')) {
                    <span class="field-error">{{ fe('privacyAccepted') ?? 'Confirme que leu as informações de privacidade.' }}</span>
                  }
                  <label class="check">
                    <input type="checkbox" formControlName="marketingOptIn" />
                    <span>Quero receber novidades e promoções de {{ i.establishmentName }} (opcional).</span>
                  </label>

                  <button class="primary" type="submit" [disabled]="sending()" [style.background]="brand()" [style.color]="ink()">
                    {{ sending() ? 'Enviando…' : 'Confirmar cadastro' }}
                  </button>
                  <p class="hint center-text">Gratuito e sem baixar aplicativo.</p>
                </form>
              }
            </div>
          </section>
        }
      } @else {
        <section class="panel center"><p>Carregando…</p></section>
      }
      <footer>ShaminaTech Pass</footer>
    </main>
  `,
  styles: `
    .page {
      min-height: 100vh;
      display: grid;
      justify-items: center;
      align-content: start;
      gap: 1rem;
      padding: 1rem;
      background: linear-gradient(160deg, var(--primary-soft), var(--bg) 50%);
    }
    .panel {
      width: 100%;
      max-width: 460px;
      border-radius: 18px;
      background: var(--surface);
      box-shadow: var(--shadow);
      overflow: hidden;
    }
    .panel.center {
      display: grid;
      gap: 0.75rem;
      text-align: center;
      padding: 0 0 1.5rem;
    }
    .panel.center > :not(.band) {
      margin-left: 1.25rem;
      margin-right: 1.25rem;
    }
    .panel.center > .brand {
      margin-top: 1.75rem;
    }
    .brand {
      justify-self: center;
      display: grid;
      place-items: center;
      width: 48px;
      height: 48px;
      border-radius: 12px;
      background: var(--primary);
      color: #fff;
      font-weight: 800;
      font-size: 1.4rem;
    }
    .band {
      display: flex;
      align-items: center;
      gap: 0.85rem;
      padding: 1.1rem 1.25rem;
      text-align: left;
    }
    .band h1 {
      margin: 0;
      font-size: 1.35rem;
      color: inherit;
    }
    .logo,
    .initial {
      width: 56px;
      height: 56px;
      flex: none;
      border-radius: 12px;
      object-fit: contain;
      background: rgb(255 255 255 / 85%);
    }
    .initial {
      display: grid;
      place-items: center;
      font-weight: 800;
      font-size: 1.5rem;
      color: #0f172a;
    }
    .small {
      display: block;
      font-size: 0.85rem;
      opacity: 0.9;
    }
    .hero {
      display: block;
      width: 100%;
      aspect-ratio: 1032 / 336;
      object-fit: cover;
    }
    .content {
      display: grid;
      gap: 0.6rem;
      padding: 1.1rem 1.25rem 1.5rem;
    }
    h2 {
      font-size: 1.02rem;
      margin: 0.6rem 0 0;
    }
    p {
      margin: 0;
    }
    .benefits {
      list-style: none;
      margin: 0;
      padding: 0;
      display: grid;
      gap: 0.5rem;
    }
    .benefits li {
      position: relative;
      padding: 0.6rem 0.75rem 0.6rem 2.4rem;
      border-radius: var(--radius-sm);
      background: var(--surface-muted);
      line-height: 1.4;
    }
    .benefits li::before {
      content: '';
      position: absolute;
      left: 0.75rem;
      top: 0.75rem;
      width: 18px;
      height: 18px;
      border-radius: 50%;
      background: var(--success) var(--icon-check) center / 12px no-repeat;
    }
    .more {
      padding: 0.7rem 0.85rem;
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
      font-size: 0.92rem;
    }
    .more summary {
      cursor: pointer;
      font-weight: 600;
      min-height: 28px;
    }
    .more .list {
      margin-top: 0.5rem;
    }
    .form-title {
      margin-top: 1.1rem;
      padding-top: 1.1rem;
      border-top: 1px solid var(--border);
    }
    .list,
    .rewards {
      margin: 0;
      padding-left: 1.15rem;
      display: grid;
      gap: 0.3rem;
    }
    .cost {
      color: var(--primary-ink);
      font-weight: 600;
    }
    form {
      display: grid;
      gap: 0.4rem;
    }
    label {
      font-weight: 600;
      font-size: 0.92rem;
      margin-top: 0.4rem;
    }
    input:not([type='checkbox']) {
      width: 100%;
      min-height: 48px;
      padding: 0 0.85rem;
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
      font: inherit;
      font-size: 1rem;
      background: var(--surface);
      color: var(--text);
    }
    input:not([type='checkbox']):focus {
      outline: none;
      border-color: var(--primary);
      box-shadow: var(--focus-ring);
    }
    input[aria-invalid='true'] {
      border-color: var(--danger);
    }
    .check {
      display: grid;
      grid-template-columns: auto 1fr;
      gap: 0.6rem;
      align-items: start;
      font-weight: 400;
    }
    .check input {
      width: 22px;
      height: 22px;
      margin: 0.1rem 0 0;
    }
    .privacy {
      margin-top: 0.6rem;
      padding: 0.7rem 0.85rem;
      border-radius: var(--radius-sm);
      background: var(--surface-muted);
      font-size: 0.88rem;
    }
    .privacy summary {
      cursor: pointer;
      font-weight: 600;
    }
    .privacy p {
      margin-top: 0.5rem;
    }
    .trap {
      position: absolute;
      left: -10000px;
      width: 1px;
      height: 1px;
      overflow: hidden;
    }
    .primary,
    .secondary {
      min-height: 52px;
      margin-top: 0.75rem;
      border: 0;
      border-radius: 999px;
      font: inherit;
      font-weight: 700;
      font-size: 1.05rem;
      cursor: pointer;
    }
    .secondary {
      min-height: 44px;
      border: 1px solid var(--border);
      background: var(--surface);
      font-size: 0.95rem;
    }
    .primary:disabled {
      opacity: 0.65;
      cursor: progress;
    }
    .hint,
    footer {
      font-size: 0.82rem;
      color: var(--text-muted);
    }
    .center-text {
      text-align: center;
    }
    .field-error,
    .error {
      color: var(--danger);
      font-size: 0.88rem;
    }
    .error {
      padding: 0.7rem;
      border-radius: var(--radius-sm);
      background: var(--danger-soft);
    }
    .warn,
    .info {
      padding: 0.75rem;
      border-radius: var(--radius-sm);
    }
    .warn {
      background: var(--warning-soft);
      color: var(--warning);
    }
    .info {
      background: var(--info-soft);
      color: var(--info);
    }
    .steps {
      list-style: none;
      padding: 0;
      display: grid;
      gap: 0.35rem;
      text-align: left;
      margin-top: 1rem;
    }
    .steps li {
      position: relative;
      padding-left: 1.75rem;
    }
    .steps li::before {
      content: '';
      position: absolute;
      left: 0;
      top: 0.2rem;
      width: 16px;
      height: 16px;
      border-radius: 50%;
      border: 2px solid var(--border-strong);
    }
    .steps li.done::before {
      border-color: var(--success);
      background: var(--success) var(--icon-check) center / 10px no-repeat;
    }
    .steps li.pending {
      color: var(--text-muted);
    }
  `,
})
export class SignupPage {
  private readonly api = inject(SignupApi);
  private readonly router = inject(Router);
  /** Aparelho identificado: só destaca a carteira recomendada (as duas continuam disponíveis depois do cadastro). */
  private readonly device = inject(DEVICE);
  protected readonly platformLabel = PLATFORM_LABELS[this.device.platform];

  /** Carteiras disponíveis, com a do aparelho destacada e em primeiro lugar. */
  protected wallets(i: PublicSignupInfo): { kind: string; label: string; recommended: boolean }[] {
    const labels: Record<string, string> = { GOOGLE_WALLET: 'Google Wallet (Android)', APPLE_WALLET: 'Carteira da Apple (iPhone)' };
    return (i.wallets ?? [])
      .filter((k) => labels[k])
      .map((k) => ({ kind: k, label: labels[k], recommended: k === this.device.recommended }))
      .sort((a, b) => Number(b.recommended) - Number(a.recommended));
  }

  /** :token da rota /cadastro/:token. */
  readonly token = input.required<string>();

  protected readonly info = signal<PublicSignupInfo | null>(null);
  protected readonly loadError = signal<string | null>(null);
  protected readonly result = signal<PublicSignupResult | null>(null);
  protected readonly submitError = signal<ApiError | null>(null);
  protected readonly sending = signal(false);
  private requestId = newRequestId();

  protected readonly form = inject(NonNullableFormBuilder).group({
    fullName: ['', [Validators.required, Validators.maxLength(150), Validators.pattern(/\p{L}.*\p{L}/u)]],
    phone: ['', [Validators.required, Validators.pattern(/^(?:\D*\d){10,13}\D*$/)]],
    email: ['', [Validators.email, Validators.maxLength(254)]],
    privacyAccepted: [false, Validators.requiredTrue],
    marketingOptIn: [false],
    website: [''],
  });

  protected readonly brand = computed(() => this.info()?.design?.brandColor ?? '#F43F5E');
  protected readonly ink = computed(() => readableTextColor(this.brand(), this.info()?.design?.textColor));
  protected readonly initial = computed(() => (this.info()?.establishmentName ?? 'P').charAt(0).toUpperCase());

  constructor() {
    effect(() => {
      this.token();
      this.reload();
    });
  }

  protected reload(): void {
    this.submitError.set(null);
    this.api.info(this.token()).subscribe({
      next: (i) => {
        this.info.set(i);
        this.requestId = newRequestId();
      },
      error: (e) => this.loadError.set(toApiError(e).message),
    });
  }

  protected invalid(name: keyof typeof this.form.controls): boolean {
    const c = this.form.controls[name];
    return c.touched && c.invalid;
  }

  protected fe(field: string): string | undefined {
    return this.submitError()?.fieldErrors?.[field];
  }

  protected submit(): void {
    const i = this.info();
    if (!i || this.sending()) return;
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    this.sending.set(true);
    this.submitError.set(null);
    this.api
      .register(this.token(), {
        fullName: v.fullName.trim(),
        phone: v.phone,
        email: v.email.trim() || null,
        privacyAccepted: v.privacyAccepted,
        marketingOptIn: v.marketingOptIn,
        requestId: this.requestId,
        formToken: i.formToken,
        website: v.website,
      })
      .subscribe({
        next: (r) => {
          this.sending.set(false);
          if (r.walletPath) {
            // A página da carteira mostra "Cadastro concluído" e o botão oficial assim que o cartão estiver pronto.
            void this.router.navigateByUrl(`${r.walletPath}?cadastro=1`, { replaceUrl: true });
          } else {
            this.result.set(r);
          }
        },
        error: (e) => {
          this.sending.set(false);
          const err = toApiError(e);
          this.submitError.set(err);
          // Recusa definitiva (duplicidade, lotação, indisponível): um novo envio deve ser tratado como novo cadastro.
          if (err.status !== 0) this.requestId = newRequestId();
        },
      });
  }

  protected typeLabel(t: string | null): string {
    return t ? label(PROGRAM_TYPE_LABELS, t) : '';
  }
}
