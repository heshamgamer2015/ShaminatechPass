import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject, input, signal } from '@angular/core';
import { AbstractControl, NonNullableFormBuilder, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { PlanApi, PlanCatalog, PlanCode, PlanOffer, formatPlanPrice, limitLabel } from '../../core/api/plan-api.service';
import { AuthService } from '../../core/auth/auth.service';
import { AlertComponent } from '../../shared/ui/alert.component';
import { BrandMarkComponent } from '../../shared/ui/brand-mark.component';
import { FieldErrorComponent } from '../../shared/ui/field-error.component';
import { IconComponent } from '../../shared/ui/icon.component';

const DRAFT_KEY = 'stp.cadastro-empresa';
const CODES: PlanCode[] = ['FREE', 'GROWTH', 'PRO'];

/** Mesmas regras do backend (PasswordPolicy): o servidor continua sendo a validação definitiva. */
function passwordPolicy(control: AbstractControl): ValidationErrors | null {
  const value = String(control.value ?? '');
  if (value.length < 10) return { policy: 'Use pelo menos 10 caracteres.' };
  if (!/[A-Za-zÀ-ÿ]/.test(value) || !/\d/.test(value)) return { policy: 'Use letras e números.' };
  return null;
}

/**
 * Autocadastro do estabelecimento: escolha do plano (todos gratuitos durante a fase de testes), dados do negócio e
 * da conta de acesso. Sem cartão de crédito e sem cobrança. Ao concluir, a sessão já vem aberta pelo servidor
 * (mesmo mecanismo do login) e o painel do estabelecimento abre na página do plano.
 * O rascunho (sem as senhas) fica só nesta aba do navegador para não perder o que foi digitado.
 */
@Component({
  selector: 'app-business-signup-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, RouterLink, AlertComponent, BrandMarkComponent, FieldErrorComponent, IconComponent],
  styleUrl: '../auth/auth-page.scss',
  styles: `
    .auth-shell {
      max-width: 1040px;
    }
    .side-plan {
      display: grid;
      gap: 0.6rem;
      padding: 1rem;
      border-radius: var(--radius);
      background: rgb(255 255 255 / 14%);
    }
    .side-plan strong {
      font-size: 1.4rem;
    }
    .plans {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 0.5rem;
      margin: 0;
      padding: 0;
      border: 0;
    }
    .plans legend {
      margin-bottom: 0.4rem;
      font-weight: 600;
    }
    .plan-opt {
      display: grid;
      gap: 0.15rem;
      padding: 0.7rem 0.75rem;
      border: 1px solid var(--border-strong);
      border-radius: var(--radius-sm);
      cursor: pointer;
    }
    .plan-opt:has(input:checked) {
      border: 2px solid var(--primary);
      background: var(--primary-soft);
    }
    .plan-opt:has(input:disabled) {
      opacity: 0.55;
      cursor: not-allowed;
    }
    .plan-opt input {
      position: absolute;
      opacity: 0;
    }
    .plan-opt small {
      color: var(--text-muted);
    }
    .row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.75rem;
    }
    @media (max-width: 640px) {
      .plans,
      .row {
        grid-template-columns: 1fr;
      }
    }
    .terms {
      font-size: var(--text-sm);
    }
    .check {
      display: flex;
      gap: 0.5rem;
      align-items: flex-start;
    }
    .trap {
      position: absolute;
      left: -10000px;
    }
  `,
  template: `
    <div class="auth-shell">
      <aside class="auth-side" aria-hidden="true">
        <div class="brand light"><app-brand-mark [size]="28" /><span>ShaminaTech <strong>Pass</strong></span></div>
        <div class="pitch">
          <h2>Crie a conta do seu estabelecimento em poucos minutos.</h2>
          @if (selected(); as p) {
            <div class="side-plan">
              <span>Plano escolhido</span>
              <strong>{{ p.name }}</strong>
              <span>{{ price(p) }}{{ p.listPriceCents ? '/mês previsto' : ' para sempre' }}</span>
              @if (catalog()?.trialFree && p.listPriceCents) { <span><strong>Grátis</strong> durante a fase de testes</span> }
            </div>
          }
          <ul>
            <li><app-icon name="check" [size]="16" /> Sem cartão de crédito e sem cobrança</li>
            <li><app-icon name="check" [size]="16" /> Acesso imediato ao painel</li>
            <li><app-icon name="check" [size]="16" /> QR Code para os clientes em Android e iPhone</li>
          </ul>
        </div>
        <span class="side-foot">ShaminaTech</span>
      </aside>

      <section class="auth-card">
        <div class="brand"><app-brand-mark [size]="28" /><span>ShaminaTech <strong>Pass</strong></span></div>
        <h1>Criar conta do estabelecimento</h1>
        <p class="muted subtitle">Já tem conta? <a routerLink="/login">Entrar</a></p>

        @if (catalogError()) {
          <app-alert kind="error">{{ catalogError() }}</app-alert>
        } @else if (catalog(); as c) {
          @if (!c.selfSignupEnabled) {
            <app-alert kind="info">O cadastro de novos estabelecimentos está fechado no momento. Fale com a ShaminaTech.</app-alert>
          } @else {
            @if (c.trialMessage) {
              <app-alert kind="success">{{ c.trialMessage }}</app-alert>
            }
            @if (error(); as e) {
              <app-alert kind="error">{{ e.message }}</app-alert>
            }
            <form class="form" [formGroup]="form" (ngSubmit)="submit()" novalidate>
              <fieldset class="plans">
                <legend>Plano</legend>
                @for (p of c.plans; track p.code) {
                  <label class="plan-opt">
                    <input type="radio" formControlName="plan" [value]="p.code" [attr.disabled]="p.selectable ? null : true" />
                    <strong>{{ p.name }}</strong>
                    <small>{{ price(p) }}{{ p.listPriceCents ? '/mês' : '' }}{{ c.trialFree && p.listPriceCents ? ' · grátis nos testes' : '' }}</small>
                    <small>{{ consumers(p) }} · {{ programsLabel(p) }}</small>
                  </label>
                }
              </fieldset>
              <app-field-error [server]="fe('plan')" />

              <div class="field">
                <label for="establishmentName">Nome do estabelecimento</label>
                <input id="establishmentName" class="input" formControlName="establishmentName" autocomplete="organization" maxlength="150"
                       [class.invalid]="bad('establishmentName')" />
                <app-field-error [local]="bad('establishmentName') ? 'Informe o nome do estabelecimento.' : null" [server]="fe('establishmentName')" />
              </div>
              <div class="row">
                <div class="field">
                  <label for="contactPhone">Telefone <span class="muted">(opcional)</span></label>
                  <input id="contactPhone" class="input" type="tel" inputmode="tel" formControlName="contactPhone" autocomplete="tel"
                         maxlength="30" placeholder="(45) 3000-0000" />
                  <app-field-error [server]="fe('contactPhone')" />
                </div>
                <div class="field">
                  <label for="contactEmail">E-mail de contato <span class="muted">(opcional)</span></label>
                  <input id="contactEmail" class="input" type="email" inputmode="email" formControlName="contactEmail" maxlength="254"
                         placeholder="Se vazio, usamos o e-mail de acesso" />
                  <app-field-error [server]="fe('contactEmail')" />
                </div>
              </div>
              <div class="field">
                <label for="ownerName">Seu nome (responsável)</label>
                <input id="ownerName" class="input" formControlName="ownerName" autocomplete="name" maxlength="150"
                       [class.invalid]="bad('ownerName')" />
                <app-field-error [local]="bad('ownerName') ? 'Informe o nome do responsável.' : null" [server]="fe('ownerName')" />
              </div>
              <div class="field">
                <label for="email">E-mail de acesso</label>
                <input id="email" class="input" type="email" inputmode="email" formControlName="email" autocomplete="username" maxlength="254"
                       [class.invalid]="bad('email')" />
                <app-field-error [local]="bad('email') ? 'Informe um e-mail válido.' : null" [server]="fe('email')" />
              </div>
              <div class="row">
                <div class="field">
                  <label for="password">Senha</label>
                  <input id="password" class="input" [type]="show() ? 'text' : 'password'" formControlName="password"
                         autocomplete="new-password" [class.invalid]="bad('password')" aria-describedby="pw-hint" />
                  <span id="pw-hint" class="hint">Pelo menos 10 caracteres, com letras e números.</span>
                  <app-field-error [local]="bad('password') ? (form.controls.password.errors?.['policy'] ?? 'Crie uma senha.') : null"
                                   [server]="fe('password')" />
                </div>
                <div class="field">
                  <label for="passwordConfirmation">Confirme a senha</label>
                  <input id="passwordConfirmation" class="input" [type]="show() ? 'text' : 'password'" formControlName="passwordConfirmation"
                         autocomplete="new-password" [class.invalid]="mismatch()" />
                  <app-field-error [local]="mismatch() ? 'As senhas não conferem.' : null" [server]="fe('passwordConfirmation')" />
                </div>
              </div>
              <label class="check small"><input type="checkbox" [checked]="show()" (change)="show.set(!show())" /> Mostrar senhas</label>

              <div class="trap" aria-hidden="true">
                <label for="website">Não preencha</label>
                <input id="website" formControlName="website" tabindex="-1" autocomplete="off" />
              </div>

              <details class="terms">
                <summary>Termos de uso e política de privacidade (fase de testes)</summary>
                <p>Durante a fase de testes, o ShaminaTech Pass pode ser usado gratuitamente em qualquer plano. Nenhuma cobrança é
                  feita e nenhum cartão de crédito é solicitado. Os valores mostrados são preços comerciais previstos; se a cobrança
                  for implantada, ela só começará depois do seu aceite explícito das condições comerciais, sem cobrança retroativa.</p>
                <p>Usamos o nome do estabelecimento, o seu nome, o e-mail e o telefone informados para criar e operar a sua conta e
                  para falar com você sobre o serviço. Os dados dos seus clientes pertencem ao seu estabelecimento e não são
                  compartilhados com outras empresas.</p>
              </details>
              <label class="check">
                <input type="checkbox" formControlName="termsAccepted" />
                <span>Li e aceito os termos de uso e a política de privacidade.</span>
              </label>
              <app-field-error [local]="bad('termsAccepted') ? 'Aceite os termos para continuar.' : null" [server]="fe('termsAccepted')" />

              <button class="btn btn-primary btn-lg btn-block" type="submit" [disabled]="sending()">
                {{ sending() ? 'Criando sua conta…' : 'Criar conta grátis' }}
              </button>
              <p class="muted small">Sem cartão de crédito. Você pode começar a configurar o programa de fidelidade logo em seguida.</p>
            </form>
          }
        } @else {
          <p class="muted">Carregando os planos…</p>
        }
      </section>
    </div>
  `,
})
export class BusinessSignupPage {
  private readonly api = inject(PlanApi);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  /** ?plano=free|growth|pro (vindo da landing page). */
  readonly plano = input<string>();

  protected readonly catalog = signal<PlanCatalog | null>(null);
  protected readonly catalogError = signal<string | null>(null);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly sending = signal(false);
  protected readonly show = signal(false);
  private readonly submitted = signal(false);

  protected readonly form = inject(NonNullableFormBuilder).group({
    plan: ['FREE' as PlanCode, Validators.required],
    establishmentName: ['', [Validators.required, Validators.maxLength(150)]],
    contactPhone: ['', [Validators.maxLength(30), Validators.pattern(/^[0-9+()\-\s]*$/)]],
    contactEmail: ['', [Validators.email, Validators.maxLength(254)]],
    ownerName: ['', [Validators.required, Validators.maxLength(150)]],
    email: ['', [Validators.required, Validators.email, Validators.maxLength(254)]],
    password: ['', [Validators.required, passwordPolicy]],
    passwordConfirmation: ['', Validators.required],
    termsAccepted: [false, Validators.requiredTrue],
    website: [''],
  });

  private readonly planValue = signal<PlanCode>('FREE');
  protected readonly selected = computed<PlanOffer | null>(
    () => this.catalog()?.plans.find((p) => p.code === this.planValue()) ?? null,
  );

  constructor() {
    this.restoreDraft();
    const sub = this.form.valueChanges.subscribe((v) => {
      this.planValue.set(this.form.controls.plan.value);
      this.saveDraft(v);
    });
    inject(DestroyRef).onDestroy(() => sub.unsubscribe());
    this.api.catalog().subscribe({
      next: (c) => {
        this.catalog.set(c);
        const wanted = (this.plano() ?? '').toUpperCase() as PlanCode;
        const choice = CODES.includes(wanted) ? wanted : this.form.controls.plan.value;
        const offer = c.plans.find((p) => p.code === choice && p.selectable) ?? c.plans.find((p) => p.selectable);
        if (offer) this.form.controls.plan.setValue(offer.code);
        this.planValue.set(this.form.controls.plan.value);
      },
      error: (e) => this.catalogError.set(toApiError(e).message),
    });
  }

  protected price(p: PlanOffer): string {
    return formatPlanPrice(p.listPriceCents);
  }

  protected consumers(p: PlanOffer): string {
    return p.maxActiveConsumers === null ? 'clientes ilimitados' : `até ${p.maxActiveConsumers} clientes`;
  }

  protected programsLabel(p: PlanOffer): string {
    return limitLabel(p.maxPrograms, 'programa', 'programas').replace('Até', 'até');
  }

  protected bad(name: keyof typeof this.form.controls): boolean {
    const c = this.form.controls[name];
    return c.invalid && (c.touched || this.submitted());
  }

  protected mismatch(): boolean {
    const { password, passwordConfirmation } = this.form.controls;
    return (passwordConfirmation.touched || this.submitted()) && passwordConfirmation.value !== password.value;
  }

  protected fe(field: string): string | undefined {
    return this.error()?.fieldErrors[field];
  }

  protected submit(): void {
    if (this.sending()) return; // evita envio duplo
    this.submitted.set(true);
    this.form.markAllAsTouched();
    if (this.form.invalid || this.mismatch()) return;
    this.sending.set(true);
    this.error.set(null);
    const v = this.form.getRawValue();
    this.api
      .signup({
        plan: v.plan,
        establishmentName: v.establishmentName.trim(),
        contactPhone: v.contactPhone.trim() || null,
        contactEmail: v.contactEmail.trim() || null,
        ownerName: v.ownerName.trim(),
        email: v.email.trim(),
        password: v.password,
        passwordConfirmation: v.passwordConfirmation,
        termsAccepted: v.termsAccepted,
        website: v.website,
      })
      .subscribe({
        next: (r) => {
          this.clearDraft();
          this.auth.adoptSession(r.me);
          void this.router.navigate(['/e', r.establishmentId, 'plano'], { queryParams: { bemvindo: 1 }, replaceUrl: true });
        },
        error: (e) => {
          this.sending.set(false);
          this.error.set(toApiError(e));
        },
      });
  }

  /** Rascunho só nesta aba (sessionStorage), nunca com as senhas. */
  private saveDraft(v: Partial<Record<string, unknown>>): void {
    try {
      const { password: _p, passwordConfirmation: _c, website: _w, ...rest } = v;
      sessionStorage.setItem(DRAFT_KEY, JSON.stringify(rest));
    } catch {
      /* armazenamento indisponível: segue sem rascunho */
    }
  }

  private restoreDraft(): void {
    try {
      const raw = sessionStorage.getItem(DRAFT_KEY);
      if (!raw) return;
      const d = JSON.parse(raw) as Record<string, unknown>;
      for (const key of ['plan', 'establishmentName', 'contactPhone', 'contactEmail', 'ownerName', 'email'] as const) {
        if (typeof d[key] === 'string') this.form.controls[key].setValue(d[key] as never, { emitEvent: false });
      }
      if (typeof d['termsAccepted'] === 'boolean') this.form.controls.termsAccepted.setValue(d['termsAccepted'], { emitEvent: false });
      this.planValue.set(this.form.controls.plan.value);
    } catch {
      /* rascunho inválido: ignora */
    }
  }

  private clearDraft(): void {
    try {
      sessionStorage.removeItem(DRAFT_KEY);
    } catch {
      /* nada a limpar */
    }
  }
}
