import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { vi } from 'vitest';
import { PlanCatalog } from '../../core/api/plan-api.service';
import { BusinessSignupPage } from './business-signup.page';

const CATALOG: PlanCatalog = {
  trialFree: true, selfSignupEnabled: true,
  trialMessage: 'Fase de testes: o uso é gratuito e nenhuma cobrança é feita.',
  plans: [
    { code: 'FREE', name: 'Free', listPriceCents: 0, maxActiveConsumers: 10, maxPrograms: 1, maxProgramTypes: 1, selectable: true },
    { code: 'GROWTH', name: 'Growth', listPriceCents: 5900, maxActiveConsumers: 150, maxPrograms: 2, maxProgramTypes: 2, selectable: true },
    { code: 'PRO', name: 'Pro', listPriceCents: 12900, maxActiveConsumers: null, maxPrograms: null, maxProgramTypes: 4, selectable: true },
  ],
};

describe('BusinessSignupPage', () => {
  beforeEach(() => sessionStorage.clear());

  async function setup(plano = 'growth', catalog: PlanCatalog = CATALOG) {
    await TestBed.configureTestingModule({
      imports: [BusinessSignupPage],
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([])],
    }).compileComponents();
    const fixture = TestBed.createComponent(BusinessSignupPage);
    fixture.componentRef.setInput('plano', plano);
    await fixture.whenStable();
    const http = TestBed.inject(HttpTestingController);
    http.expectOne('/api/public/plans').flush(catalog);
    await fixture.whenStable();
    return { fixture, el: fixture.nativeElement as HTMLElement, http };
  }

  /** Plano marcado (o valor do rádio fica no controle do Angular, não no atributo do DOM). */
  const checkedPlan = (el: HTMLElement) =>
    CATALOG.plans[[...el.querySelectorAll<HTMLInputElement>('input[type=radio]')].findIndex((r) => r.checked)].code;

  const fill = (el: HTMLElement, id: string, value: string) => {
    const input = el.querySelector<HTMLInputElement>('#' + id)!;
    input.value = value;
    input.dispatchEvent(new Event('input'));
  };

  function fillValid(el: HTMLElement) {
    fill(el, 'establishmentName', 'Café Teste');
    fill(el, 'ownerName', 'Ana Souza');
    fill(el, 'email', 'ana@cafe.test');
    fill(el, 'password', 'Senha-forte-2026');
    fill(el, 'passwordConfirmation', 'Senha-forte-2026');
    el.querySelector<HTMLInputElement>('input[formControlName=termsAccepted]')!.click();
  }

  it('mostra o plano vindo da landing, os preços previstos e a gratuidade da fase de testes', async () => {
    const { el } = await setup('pro');
    expect(checkedPlan(el)).toBe('PRO');
    expect(el.textContent).toContain('nenhuma cobrança');
    expect(el.textContent).toContain('R$ 129/mês · grátis nos testes');
    expect(el.textContent).toContain('clientes ilimitados');
    expect(el.textContent).not.toMatch(/cartão de crédito:|número do cartão/i);
    expect(el.querySelector('input[name*=card], input[autocomplete^=cc-]')).toBeNull();
  });

  it('valida no navegador antes de enviar e não envia duas vezes', async () => {
    const { fixture, el, http } = await setup();
    el.querySelector<HTMLButtonElement>('button[type=submit]')!.click();
    await fixture.whenStable();
    http.expectNone('/api/public/establishment-signup');
    expect(el.textContent).toContain('Informe o nome do estabelecimento.');
    expect(el.textContent).toContain('Aceite os termos para continuar.');

    fillValid(el);
    fill(el, 'passwordConfirmation', 'Outra-senha-2026');
    await fixture.whenStable();
    el.querySelector<HTMLButtonElement>('button[type=submit]')!.click();
    await fixture.whenStable();
    http.expectNone('/api/public/establishment-signup');
    expect(el.textContent).toContain('As senhas não conferem.');
  });

  it('cria a conta, adota a sessão aberta pelo servidor e abre o painel no plano', async () => {
    const { fixture, el, http } = await setup('growth');
    const navigate = vi.spyOn(TestBed.inject(Router), 'navigate').mockResolvedValue(true);
    fillValid(el);
    await fixture.whenStable();
    expect(sessionStorage.getItem('stp.cadastro-empresa')).toContain('Café Teste');
    expect(sessionStorage.getItem('stp.cadastro-empresa')).not.toContain('Senha-forte');
    el.querySelector<HTMLButtonElement>('button[type=submit]')!.click();
    el.querySelector<HTMLButtonElement>('button[type=submit]')!.click();
    const req = http.expectOne('/api/public/establishment-signup');
    expect(req.request.body.plan).toBe('GROWTH');
    expect(Object.keys(req.request.body)).not.toContain('platformRole');
    expect(Object.keys(req.request.body)).not.toContain('role');
    await fixture.whenStable();
    expect(el.querySelector<HTMLButtonElement>('button[type=submit]')!.disabled).toBe(true);
    req.flush({ establishmentId: 7, plan: 'GROWTH', trialFree: true,
      me: { id: 1, email: 'ana@cafe.test', fullName: 'Ana', platformRole: null, passwordChangeRequired: false, memberships: [] } });
    await fixture.whenStable();
    expect(navigate).toHaveBeenCalledWith(['/e', 7, 'plano'], { queryParams: { bemvindo: 1 }, replaceUrl: true });
    expect(sessionStorage.getItem('stp.cadastro-empresa')).toBeNull();
  });

  it('mostra o erro do servidor no campo (ex.: e-mail indisponível) e libera o botão', async () => {
    const { fixture, el, http } = await setup();
    fillValid(el);
    el.querySelector<HTMLButtonElement>('button[type=submit]')!.click();
    http.expectOne('/api/public/establishment-signup').flush(
      { code: 'CONFLICT', detail: 'Não foi possível criar a conta com este e-mail.', errors: [{ field: 'email', message: 'Não foi possível criar a conta com este e-mail.' }] },
      { status: 409, statusText: 'Conflict' });
    await fixture.whenStable();
    expect(el.textContent).toContain('Não foi possível criar a conta com este e-mail.');
    expect(el.querySelector<HTMLButtonElement>('button[type=submit]')!.disabled).toBe(false);
  });

  it('fora da fase de testes os planos pagos aparecem indisponíveis', async () => {
    const off: PlanCatalog = { ...CATALOG, trialFree: false, trialMessage: null,
      plans: CATALOG.plans.map((p) => ({ ...p, selectable: p.code === 'FREE' })) };
    const { el } = await setup('pro', off);
    expect(checkedPlan(el)).toBe('FREE');
    expect(el.querySelectorAll('input[type=radio]:disabled').length).toBe(2);
    expect(el.textContent).not.toContain('grátis nos testes');
  });
});
