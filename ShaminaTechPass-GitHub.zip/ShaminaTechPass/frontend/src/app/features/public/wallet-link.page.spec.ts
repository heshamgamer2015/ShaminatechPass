import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { DEVICE, DeviceInfo, detectDevice } from '../../shared/device';
import { WalletLinkPage } from './wallet-link.page';

const TOKEN = 'a'.repeat(32);
const BOTH = {
  establishmentName: 'Café', programName: 'Cartão Café', programType: 'POINTS', consumerFirstName: 'Ana',
  status: 'READY', message: null, saveUrl: 'https://pay.google.com/gp/v/save/abc', linkExpiresAt: '2026-11-09T00:00:00Z',
  google: { status: 'READY', url: 'https://pay.google.com/gp/v/save/abc' },
  apple: { status: 'READY', url: `/api/public/wallet-links/${TOKEN}/apple` },
};
const UA = {
  android: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
  iphone: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',
  instagram: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Instagram 350.0',
  windows: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
};

describe('WalletLinkPage', () => {
  async function setup(body: object, device: DeviceInfo = detectDevice({ userAgent: '' }), status = 200) {
    await TestBed.configureTestingModule({
      imports: [WalletLinkPage],
      providers: [provideHttpClient(), provideHttpClientTesting(), { provide: DEVICE, useValue: device }],
    }).compileComponents();
    const fixture = TestBed.createComponent(WalletLinkPage);
    fixture.componentRef.setInput('token', TOKEN);
    await fixture.whenStable();
    const http = TestBed.inject(HttpTestingController);
    const req = http.expectOne(`/api/public/wallet-links/${TOKEN}`);
    if (status === 200) req.flush(body);
    else req.flush(body, { status, statusText: 'x' });
    await fixture.whenStable();
    return { fixture, el: fixture.nativeElement as HTMLElement };
  }

  const click = async (el: HTMLElement, fixture: { whenStable(): Promise<unknown> }, text: string) => {
    [...el.querySelectorAll<HTMLButtonElement>('button')].find((b) => b.textContent?.includes(text))!.click();
    await fixture.whenStable();
  };

  it('mostra o botão oficial de salvar só quando o cartão está pronto (formato da Etapa 3)', async () => {
    const { el } = await setup({ ...BOTH, google: undefined, apple: undefined });
    const link = el.querySelector<HTMLAnchorElement>('a.wallet-button')!;
    expect(link.href).toBe('https://pay.google.com/gp/v/save/abc');
    expect(link.rel).toContain('noreferrer');
    expect(el.textContent).toContain('Olá, Ana!');
  });

  it('aparelho não identificado vê as duas carteiras, sem bloqueio', async () => {
    const { el } = await setup(BOTH);
    expect(el.querySelector<HTMLAnchorElement>('a.wallet-button')!.href).toBe('https://pay.google.com/gp/v/save/abc');
    const apple = el.querySelector<HTMLAnchorElement>('a.apple-wallet')!;
    expect(apple.getAttribute('href')).toBe(`/api/public/wallet-links/${TOKEN}/apple`);
    expect(apple.getAttribute('aria-label')).toBe('Adicionar à Carteira da Apple');
  });

  it('no Android destaca o Google Wallet e mantém a escolha manual', async () => {
    const { fixture, el } = await setup(BOTH, detectDevice({ userAgent: UA.android }));
    expect(el.textContent).toContain('Recomendado para o seu celular Android: Google Wallet');
    expect(el.querySelector('a.wallet-button')).not.toBeNull();
    expect(el.querySelector('a.apple-wallet')).toBeNull();
    await click(el, fixture, 'Usar outra carteira');
    // A Apple não é apresentada como instalável no Android: orienta abrir no iPhone.
    expect(el.querySelector('a.apple-wallet')).toBeNull();
    expect(el.textContent).toContain('funciona só no iPhone');
  });

  it('no iPhone destaca a Carteira da Apple e o Google fica como alternativa', async () => {
    const { fixture, el } = await setup(BOTH, detectDevice({ userAgent: UA.iphone, maxTouchPoints: 5 }));
    expect(el.textContent).toContain('Recomendado para o seu iPhone: Carteira da Apple');
    expect(el.querySelector('a.apple-wallet')).not.toBeNull();
    expect(el.querySelector('a.wallet-button')).toBeNull();
    await click(el, fixture, 'Usar outra carteira');
    expect(el.querySelector('a.wallet-button')).not.toBeNull();
    expect(el.textContent).toContain('não tem aplicativo para iPhone');
  });

  it('no navegador interno do Instagram orienta abrir no Safari', async () => {
    const { el } = await setup(BOTH, detectDevice({ userAgent: UA.instagram, maxTouchPoints: 5 }));
    expect(el.textContent).toContain('navegador do Instagram');
    expect(el.textContent).toContain('Abrir no Safari');
    expect(el.querySelector('a.apple-wallet')).not.toBeNull(); // continua podendo tentar
  });

  it('no computador mostra o QR Code para abrir no celular', async () => {
    const { fixture, el } = await setup(BOTH, detectDevice({ userAgent: UA.windows }));
    expect(el.textContent).toContain('Abra no seu celular');
    expect(el.querySelector<HTMLImageElement>('.phone img')!.getAttribute('src')).toBe(`/api/public/wallet-links/${TOKEN}/qr`);
    expect(el.querySelector('a.wallet-button')).toBeNull();
    await click(el, fixture, 'Continuar neste aparelho');
    expect(el.querySelector('a.wallet-button')).not.toBeNull();
    expect(el.querySelector('a.apple-wallet')).toBeNull();
  });

  it('a Carteira da Apple pronta não espera o Google terminar de preparar', async () => {
    const { el } = await setup({ ...BOTH, status: 'PREPARING', message: 'Preparando…', google: { status: 'PREPARING', url: null } },
      detectDevice({ userAgent: UA.iphone, maxTouchPoints: 5 }));
    expect(el.querySelector('a.apple-wallet')).not.toBeNull();
    expect(el.textContent).toContain('Google Wallet: o cartão está sendo preparado.');
  });

  it('mostra só o Apple Wallet quando o Google não está disponível', async () => {
    const { el } = await setup({ ...BOTH, saveUrl: null, google: null });
    expect(el.querySelector('a.wallet-button')).toBeNull();
    expect(el.querySelector('a.apple-wallet')).not.toBeNull();
  });

  it('informa link inválido sem detalhes', async () => {
    const { el } = await setup(
      { code: 'WALLET_LINK_INVALID', detail: 'Este link é inválido ou expirou. Peça um novo link ao estabelecimento.' }, undefined, 404);
    expect(el.textContent).toContain('Link indisponível');
    expect(el.querySelector('a.wallet-button')).toBeNull();
  });
});
