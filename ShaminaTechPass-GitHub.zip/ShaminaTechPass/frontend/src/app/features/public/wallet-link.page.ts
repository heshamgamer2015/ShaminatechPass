import { NgTemplateOutlet } from '@angular/common';
import { ChangeDetectionStrategy, Component, OnDestroy, computed, effect, inject, input, signal } from '@angular/core';
import { toApiError } from '../../core/api/api-error';
import { WalletApi } from '../../core/api/wallet-api.service';
import { PublicWalletPass } from '../../core/loyalty-models';
import { NotificationService } from '../../core/notifications/notification.service';
import { DEVICE, PLATFORM_LABELS, WalletKind } from '../../shared/device';
import { PROGRAM_TYPE_LABELS, label } from '../../shared/labels';

/**
 * Página pública (sem login) que o consumidor abre no celular para adicionar o cartão ao Google Wallet (Android) ou
 * à Carteira da Apple (iPhone — sem instalar aplicativo). O aparelho é identificado só para destacar a carteira
 * recomendada: a outra continua disponível em "Usar outra carteira", e nada é redirecionado automaticamente.
 * Computador e iPad (que não guardam cartões) veem um QR Code para abrir este mesmo link no celular.
 * Mostra só estabelecimento, programa e primeiro nome. O token do link nunca é guardado no navegador.
 */
@Component({
  selector: 'app-wallet-link-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [NgTemplateOutlet],
  template: `
    <main class="page">
      <section class="panel">
        <span class="brand" aria-hidden="true">P</span>
        @if (error()) {
          <h1>Link indisponível</h1>
          <p>{{ error() }}</p>
        } @else if (data(); as d) {
          <p class="muted">{{ d.establishmentName }}</p>
          <h1>{{ d.programName }}</h1>
          @if (cadastro()) {
            <!-- Vindo do cadastro pelo QR Code: mostra em que etapa o cartão está, sem afirmar que já foi adicionado. -->
            <ol class="steps" aria-label="Situação do cadastro">
              <li class="done">Cadastro concluído</li>
              <li class="done">Cartão preparado</li>
              @if (usable(d)) {
                <li class="next">Adicione o cartão à carteira do seu celular</li>
              } @else if (d.status === 'PREPARING') {
                <li class="pending">Emissão na carteira digital pendente — aguarde alguns instantes</li>
              } @else {
                <li class="pending">Carteira digital temporariamente indisponível</li>
              }
            </ol>
          }
          <p>Olá, {{ d.consumerFirstName }}! Seu cartão de {{ typeLabel(d.programType) }} pode ficar no seu celular.</p>

          @if (usable(d)) {
            @if (device.openOnPhone) {
              <div class="phone">
                <p><strong>Abra no seu celular.</strong> Este {{ platformLabel }} não guarda cartões de fidelidade: aponte a câmera
                  do celular para o QR Code.</p>
                <img [src]="qrUrl()" alt="QR Code para abrir este cartão no celular" width="200" height="200" />
              </div>
            } @else if (recommendedLabel(d); as rec) {
              <p class="recommended">Recomendado para o seu {{ platformLabel }}: <strong>{{ rec }}</strong></p>
            }

            @if (device.inAppBrowser && primary(d).includes('APPLE_WALLET')) {
              <div class="warn" role="note">
                <p>Você está no navegador do {{ device.inAppBrowser }}, que pode não abrir o cartão da Apple. Toque em
                  <strong>•••</strong> e escolha <strong>Abrir no Safari</strong>.</p>
                <button class="retry" type="button" (click)="copyLink()">Copiar o link</button>
              </div>
            }

            <div class="options">
              @for (kind of primary(d); track kind) {
                <ng-container *ngTemplateOutlet="option; context: { $implicit: kind, d: d }" />
              }
            </div>

            @if (others(d).length > 0) {
              @if (!showOthers()) {
                <button class="link-button" type="button" (click)="showOthers.set(true)">
                  {{ primary(d).length > 0 ? 'Usar outra carteira' : 'Continuar neste aparelho' }}
                </button>
              } @else {
                <div class="options others">
                  @for (kind of others(d); track kind) {
                    <ng-container *ngTemplateOutlet="option; context: { $implicit: kind, d: d }" />
                  }
                </div>
              }
            }
            @if (d.google?.status === 'PREPARING') {
              <p class="hint">Google Wallet: o cartão está sendo preparado.</p>
            }
            <p class="hint">O cartão é pessoal: depois de salvo, fica vinculado à sua conta.</p>
          } @else if (d.status === 'PREPARING') {
            <p class="info">{{ d.message }}</p>
            <button class="retry" type="button" (click)="load()">Tentar novamente</button>
          } @else {
            <p class="info">{{ d.message }}</p>
          }

          <ng-template #option let-kind let-d="d">
            @if (kind === 'GOOGLE_WALLET') {
              <div class="option google">
                <a class="wallet-button" [href]="googleUrl(d)" rel="noopener noreferrer">Adicionar ao Google Wallet</a>
                <p class="hint">{{ googleHint() }}</p>
              </div>
            } @else if (device.canInstall.APPLE_WALLET) {
              <div class="option apple">
                <!-- Selo oficial da Apple (public/wallet/add-to-apple-wallet-pt-br.svg, baixado do Apple Developer);
                     sem o arquivo, mostra o texto. -->
                <a class="apple-wallet" [href]="d.apple.url" rel="noopener noreferrer" aria-label="Adicionar à Carteira da Apple">
                  @if (!appleBadgeMissing()) {
                    <img src="/wallet/add-to-apple-wallet-pt-br.svg" alt="Adicionar à Carteira da Apple" height="48"
                         (error)="appleBadgeMissing.set(true)" />
                  } @else {
                    <span class="wallet-button apple-text">Adicionar à Carteira da Apple</span>
                  }
                </a>
                <p class="hint">iPhone: toque no botão e depois em “Adicionar”.</p>
              </div>
            } @else {
              <p class="info option apple">A Carteira da Apple funciona só no iPhone: abra este mesmo link no iPhone.</p>
            }
          </ng-template>
        } @else {
          <p>Carregando…</p>
        }
        <footer>ShaminaTech Pass</footer>
      </section>
    </main>
  `,
  styles: `
    .page {
      min-height: 100vh;
      display: grid;
      place-items: center;
      padding: 1rem;
      background: linear-gradient(160deg, var(--primary-soft), var(--bg) 60%);
    }
    .panel {
      width: 100%;
      max-width: 420px;
      display: grid;
      gap: 0.75rem;
      text-align: center;
      padding: 2rem 1.25rem;
      border-radius: 18px;
      background: var(--surface);
      box-shadow: var(--shadow);
    }
    .brand {
      justify-self: center;
      display: grid;
      place-items: center;
      width: 48px;
      height: 48px;
      border-radius: 12px;
      background: var(--primary);
      color: #fff;
      font-weight: 800;
      font-size: 1.4rem;
    }
    h1 {
      font-size: 1.4rem;
      margin: 0;
    }
    p {
      margin: 0;
    }
    .wallet-button {
      display: block;
      padding: 0.95rem 1rem;
      border-radius: 999px;
      background: #000;
      color: #fff;
      font-weight: 700;
      text-decoration: none;
      font-size: 1.05rem;
    }
    .options {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    .others {
      padding-top: 0.75rem;
      border-top: 1px solid var(--border);
    }
    .steps {
      list-style: none;
      padding: 0;
      margin: 0.25rem 0;
      display: grid;
      gap: 0.3rem;
      text-align: left;
    }
    .steps li {
      position: relative;
      padding-left: 1.75rem;
    }
    .steps li::before {
      content: '';
      position: absolute;
      left: 0;
      top: 0.2rem;
      width: 16px;
      height: 16px;
      border-radius: 50%;
      border: 2px solid var(--border-strong);
    }
    .steps li.done::before {
      border-color: var(--success);
      background: var(--success) var(--icon-check) center / 10px no-repeat;
    }
    .steps li.next {
      font-weight: 600;
    }
    .steps li.next::before {
      border-color: var(--primary);
    }
    .steps li.pending {
      color: var(--text-muted);
    }
    .recommended {
      font-size: 0.92rem;
    }
    .phone {
      display: grid;
      gap: 0.6rem;
      justify-items: center;
      padding: 1rem;
      border-radius: var(--radius-sm);
      background: var(--bg);
    }
    .phone img {
      width: 200px;
      height: 200px;
      padding: 6px;
      border-radius: 8px;
      background: #fff;
    }
    .option {
      display: grid;
      gap: 0.4rem;
    }
    .apple-wallet {
      justify-self: center;
      display: inline-flex;
      min-height: 44px;
      text-decoration: none;
    }
    .apple-wallet img {
      height: 48px;
      width: auto;
    }
    .apple-text {
      background: #000;
    }
    .hint,
    footer {
      font-size: 0.82rem;
      color: var(--text-muted);
    }
    .info {
      padding: 0.75rem;
      border-radius: var(--radius-sm);
      background: var(--info-soft);
      color: var(--info);
    }
    .warn {
      display: grid;
      gap: 0.5rem;
      padding: 0.75rem;
      border-radius: var(--radius-sm);
      background: var(--warning-soft);
      color: var(--warning);
      font-size: 0.9rem;
    }
    .retry {
      justify-self: center;
      min-height: 44px;
      padding: 0 1.25rem;
      border-radius: var(--radius-sm);
      border: 1px solid var(--border);
      background: var(--surface);
      font: inherit;
    }
    .link-button {
      justify-self: center;
      min-height: 44px;
      padding: 0 1rem;
      border: 0;
      background: none;
      color: var(--primary);
      font: inherit;
      font-weight: 600;
      text-decoration: underline;
      text-underline-offset: 3px;
      cursor: pointer;
    }
  `,
})
export class WalletLinkPage implements OnDestroy {
  private readonly api = inject(WalletApi);
  private readonly notifications = inject(NotificationService);
  /** Aparelho identificado: só destaca a carteira; a escolha manual continua disponível. */
  protected readonly device = inject(DEVICE);
  protected readonly platformLabel = PLATFORM_LABELS[this.device.platform];

  /** :token da rota /carteira/:token. */
  readonly token = input.required<string>();
  /** ?cadastro=1: chegou aqui logo após o cadastro pelo QR Code. */
  readonly cadastro = input<string>();

  protected readonly data = signal<PublicWalletPass | null>(null);
  protected readonly error = signal<string | null>(null);
  protected readonly appleBadgeMissing = signal(false);
  protected readonly showOthers = signal(false);
  protected readonly qrUrl = computed(() => `/api/public/wallet-links/${this.token()}/qr`);
  private timer: ReturnType<typeof setTimeout> | null = null;

  constructor() {
    effect(() => {
      this.token();
      this.load();
    });
  }

  ngOnDestroy(): void {
    if (this.timer) clearTimeout(this.timer);
  }

  protected load(): void {
    this.api.openPublic(this.token()).subscribe({
      next: (d) => {
        this.data.set(d);
        if (d.status === 'PREPARING' && !this.timer) {
          this.timer = setTimeout(() => {
            this.timer = null;
            this.load();
          }, 4000);
        }
      },
      error: (e) => this.error.set(toApiError(e).message),
    });
  }

  /** Carteiras prontas para este cartão. */
  protected available(d: PublicWalletPass): WalletKind[] {
    const list: WalletKind[] = [];
    if (this.googleUrl(d)) list.push('GOOGLE_WALLET');
    if (d.apple?.status === 'READY' && d.apple.url) list.push('APPLE_WALLET');
    return list;
  }

  /** Há carteira pronta? (A Apple pode estar pronta enquanto o Google ainda prepara o cartão.) */
  protected usable(d: PublicWalletPass): boolean {
    return this.available(d).length > 0;
  }

  /** Em destaque: a carteira do aparelho; aparelho desconhecido vê as duas; computador e iPad, nenhuma. */
  protected primary(d: PublicWalletPass): WalletKind[] {
    if (this.device.openOnPhone) return [];
    const available = this.available(d);
    const rec = this.device.recommended;
    if (rec && available.includes(rec)) return [rec];
    return available.filter((k) => this.device.canInstall[k]);
  }

  protected others(d: PublicWalletPass): WalletKind[] {
    const primary = this.primary(d);
    return this.available(d).filter((k) => !primary.includes(k));
  }

  protected recommendedLabel(d: PublicWalletPass): string | null {
    const rec = this.device.recommended;
    if (!rec || !this.available(d).includes(rec)) return null;
    return rec === 'GOOGLE_WALLET' ? 'Google Wallet' : 'Carteira da Apple';
  }

  protected googleHint(): string {
    switch (this.device.platform) {
      case 'android':
        return 'Use a conta Google em que deseja guardar o cartão.';
      case 'ios':
        return 'O Google Wallet não tem aplicativo para iPhone: o cartão fica na sua conta Google para usar em um Android.';
      case 'unknown':
        return 'Celular Android: use a conta Google em que deseja guardar o cartão.';
      default:
        return 'O cartão fica salvo na sua conta Google e aparece no seu celular Android.';
    }
  }

  /** Endereço do Google Wallet (formato novo em google.url; saveUrl mantido da Etapa 3). */
  protected googleUrl(d: PublicWalletPass): string | null {
    if (d.google) return d.google.status === 'READY' ? d.google.url : null;
    return d.saveUrl;
  }

  /** Copia o link para colar no Safari (navegadores internos de aplicativos não abrem o .pkpass). */
  protected copyLink(): void {
    const url = window.location.href.split('?')[0];
    const manual = () => this.notifications.info('Copie o endereço na barra do navegador e cole no Safari.');
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(url).then(() => this.notifications.success('Link copiado. Cole no Safari.'), manual);
    } else {
      manual();
    }
  }

  protected typeLabel(t: string): string {
    return label(PROGRAM_TYPE_LABELS, t).toLowerCase();
  }
}
