import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { vi } from 'vitest';
import { NotificationOverview } from '../../core/loyalty-models';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { EstablishmentContext } from './establishment-context.service';
import { NotificationsPage } from './notifications.page';

function overview(over: Partial<NotificationOverview> = {}): NotificationOverview {
  return {
    settings: {
      nearRewardEnabled: false, nearRewardStamps: 1, nearRewardPointsPercent: 10, expiryEnabled: false, expiryDaysBefore: 3,
      inactivityEnabled: false, inactivityDays: 60, minIntervalDays: 7, proximityEnabled: false, proximityText: null,
    },
    locations: [],
    maxLocations: 10,
    integration: { googleConfigured: true, googleMissing: [], appleConfigured: false },
    capabilities: [
      { key: 'GOOGLE_MESSAGES', title: 'Avisos no Google Wallet', available: true, detail: 'O Google não informa se o aviso apareceu.' },
      { key: 'APPLE_PROXIMITY', title: 'Proximidade no Apple Wallet', available: false, detail: 'Depende da conta Apple Developer.' },
    ],
    last30Days: {},
    recentFailures: [],
    notes: ['"Aceito" significa que o Google gravou a mensagem no cartão.'],
    ...over,
  };
}

describe('NotificationsPage', () => {
  const dialogs = { confirm: vi.fn().mockResolvedValue(true) };

  async function setup(data = overview()) {
    const ctx = { id: signal(1), base: signal('/e/1'), panel: signal({ id: 1, name: 'Café', policy: { timeZone: 'America/Sao_Paulo' } }),
      can: () => true };
    await TestBed.configureTestingModule({
      imports: [NotificationsPage],
      providers: [provideHttpClient(), provideHttpClientTesting(), { provide: EstablishmentContext, useValue: ctx },
        { provide: ConfirmService, useValue: dialogs }],
    }).compileComponents();
    const fixture = TestBed.createComponent(NotificationsPage);
    await fixture.whenStable();
    const http = TestBed.inject(HttpTestingController);
    http.expectOne('/api/establishments/1/notifications').flush(data);
    http.expectOne((r) => r.url === '/api/establishments/1/notifications/history').flush({ content: [], page: 0, size: 20, totalElements: 0, totalPages: 0 });
    await fixture.whenStable();
    return { fixture, el: fixture.nativeElement as HTMLElement, http };
  }

  it('mostra recursos disponíveis e indisponíveis sem números de entrega', async () => {
    const { el } = await setup();
    expect(el.textContent).toContain('Avisos no Google Wallet');
    expect(el.textContent).toContain('Indisponível');
    expect(el.textContent).toContain('Nenhum pedido de aviso no período.');
    expect(el.textContent).not.toMatch(/entregues|abertos|visualiza/i);
  });

  it('pede confirmação ao ativar lembretes e envia as configurações', async () => {
    const { fixture, el, http } = await setup();
    el.querySelector<HTMLInputElement>('input[formcontrolname=nearRewardEnabled]')!.click();
    await fixture.whenStable();
    el.querySelector<HTMLButtonElement>('form button[type=submit]')!.click();
    await fixture.whenStable();
    expect(dialogs.confirm).toHaveBeenCalledWith(expect.objectContaining({ title: 'Ativar lembretes?' }));
    const req = http.expectOne((r) => r.method === 'PUT');
    expect(req.request.body).toMatchObject({ nearRewardEnabled: true, nearRewardStamps: 1, minIntervalDays: 7, proximityText: null });
  });

  it('não envia localização com coordenadas que não são números', async () => {
    const { fixture, el, http } = await setup();
    const set = (id: string, v: string) => {
      const i = el.querySelector<HTMLInputElement>('#' + id)!;
      i.value = v;
      i.dispatchEvent(new Event('input'));
    };
    set('locName', 'Loja');
    set('locAddress', 'Av. Paulista, 1000');
    set('locCity', 'São Paulo');
    set('locState', 'SP');
    set('locCep', '01310-100');
    set('locLat', 'abc');
    set('locLon', '-46.6');
    await fixture.whenStable();
    el.querySelector<HTMLFormElement>('.loc-form')!.dispatchEvent(new Event('submit'));
    await fixture.whenStable();
    http.expectNone((r) => r.url.includes('/locations'));
    expect(el.textContent).toContain('Latitude e longitude devem ser números.');
  });
});
