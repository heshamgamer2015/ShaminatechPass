import { ChangeDetectionStrategy, Component, ElementRef, OnDestroy, computed, effect, inject, signal, viewChild } from '@angular/core';
import { FormsModule, NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { Observable, concat, defer, lastValueFrom, toArray } from 'rxjs';
import { ApiError, toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import {
  Design,
  ExpiredBalancePolicy,
  ProgramPayload,
  ProgramType,
  ReversalPolicy,
  Rounding,
  StampCriterion,
  ValidityMode,
} from '../../core/loyalty-models';
import { NotificationService } from '../../core/notifications/notification.service';
import { contrastRatio } from '../../shared/color';
import {
  EXPIRED_BALANCE_LABELS,
  PROGRAM_TYPE_HINTS,
  PROGRAM_TYPE_LABELS,
  REVERSAL_LABELS,
  ROUNDING_LABELS,
  STAMP_CRITERION_LABELS,
  VALIDITY_MODE_LABELS,
  label,
  parseMoney,
} from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { CardPreviewComponent } from '../../shared/ui/card-preview.component';
import { FieldErrorComponent } from '../../shared/ui/field-error.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { EstablishmentContext } from './establishment-context.service';

const TYPES: ProgramType[] = ['STAMPS', 'POINTS', 'CASHBACK', 'VIP'];
const STEPS = ['Tipo', 'Regras', 'Recompensas e validade', 'Personalização', 'Revisão'] as const;
const STEP_TITLES = [
  'Qual tipo de fidelidade?',
  'Como o cliente acumula',
  'Recompensas e validade',
  'Aparência do cartão',
  'Revise antes de ativar',
];
const STEP_HELP = [
  'Escolha como o cliente será recompensado. Só aparecem habilitados os tipos liberados para o seu estabelecimento.',
  'Dê um nome ao programa e defina a regra de acúmulo. Use exemplos reais do seu balcão.',
  'Defina o que o cliente ganha e por quanto tempo o cartão vale sem movimentação.',
  'Cores, textos e imagens que o cliente verá no cartão e na página de cadastro.',
  'Confira tudo. Você pode voltar a qualquer etapa sem perder o que preencheu.',
];
const TYPE_ICONS: Record<ProgramType, string> = { STAMPS: 'check-circle', POINTS: 'star', CASHBACK: 'wallet', VIP: 'shield' };
const MAX_IMAGE_BYTES = 1024 * 1024;
const MONEY = /^\s*\d{1,10}([.,]\d{1,2})?\s*$/;

interface DraftReward {
  name: string;
  cost: number;
  description: string;
}

interface DraftTier {
  name: string;
  rankOrder: number;
  minSpend: number | null;
  benefits: string;
}

/**
 * Assistente de criação de programa (5 etapas). Usa só regras que o backend já suporta (mesmo contrato da edição).
 * Tudo fica no formulário até a revisão: voltar não perde dados. Ao confirmar, cria o programa e, em seguida,
 * personalização, imagens, recompensas e níveis — se algum desses passos falhar, o programa já criado é mantido e a
 * página indica o que concluir na edição.
 */
@Component({
  selector: 'app-program-wizard-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, ReactiveFormsModule, RouterLink, AlertComponent, CardPreviewComponent, FieldErrorComponent, IconComponent, PageHeaderComponent],
  template: `
    <app-page-header title="Novo programa" subtitle="Siga as etapas; você pode voltar a qualquer momento sem perder o que preencheu">
      <a class="btn" [routerLink]="ctx.base() + '/programas'">Cancelar</a>
    </app-page-header>

    <nav class="wizard-progress" aria-label="Etapas do assistente">
      <p class="progress-text">Etapa {{ step() + 1 }} de {{ steps.length }} · <strong>{{ steps[step()] }}</strong></p>
      <div class="meter" aria-hidden="true"><span [style.width.%]="((step() + 1) / steps.length) * 100"></span></div>
      <ol class="stepper">
        @for (s of steps; track s; let i = $index) {
          <li [class.current]="step() === i" [class.done]="i < step()" [attr.aria-current]="step() === i ? 'step' : null">
            <button type="button" (click)="goTo(i)" [disabled]="i > maxReached() || creating()"
                    [attr.aria-label]="'Etapa ' + (i + 1) + ': ' + s + (i < step() ? ' (concluída)' : '')">
              <span class="num">
                @if (i < step()) {
                  <app-icon name="check" [size]="14" />
                } @else {
                  {{ i + 1 }}
                }
              </span>
              <span class="name">{{ s }}</span>
            </button>
          </li>
        }
      </ol>
    </nav>

    <div class="wizard" [class.with-side]="showSide()">
    <form #wizardForm class="card form wizard-form" [formGroup]="form" (ngSubmit)="next()" novalidate>
      <header class="step-head">
        <h2 id="step-title" tabindex="-1">{{ stepTitles[step()] }}</h2>
        <p class="muted">{{ stepHelp[step()] }}</p>
      </header>
      @if (serverError(); as e) {
        <app-alert kind="error">{{ e.message }}</app-alert>
      }
      @if (stepInvalid()) {
        <app-alert kind="error">Revise os campos destacados abaixo antes de continuar.</app-alert>
      }

      @switch (step()) {
        @case (0) {
          <fieldset>
            <legend class="sr-only">Qual tipo de fidelidade?</legend>
            <div class="types">
              @for (t of types; track t) {
                <label class="type" [class.selected]="form.controls.type.value === t" [class.disabled]="!allowed(t)">
                  <input type="radio" formControlName="type" [value]="t" [attr.disabled]="allowed(t) ? null : true" />
                  <span class="type-top">
                    <span class="type-icon"><app-icon [name]="typeIcon(t)" [size]="20" /></span>
                    @if (form.controls.type.value === t) {
                      <span class="type-check"><app-icon name="check" [size]="14" /></span>
                    }
                  </span>
                  <strong>{{ typeLabel(t) }}</strong>
                  <small>{{ hint(t) }}</small>
                  @if (!allowed(t)) { <small class="warn">Não habilitado para o seu estabelecimento.</small> }
                  @if (t === 'VIP' && allowed(t)) {
                    <small class="muted">Nesta versão: cadastro de níveis e benefícios, sem emissão de cartões nem progressão automática.</small>
                  }
                </label>
              }
            </div>
            @if (noTypeAllowed()) {
              <app-alert kind="warning">Nenhum tipo de fidelidade está habilitado para o seu estabelecimento. Fale com a ShaminaTech.</app-alert>
            }
          </fieldset>
        }

        @case (1) {
          <div class="field">
            <label for="name">Nome do programa</label>
            <input id="name" class="input" formControlName="name" maxlength="80" placeholder="Ex.: Cartão Fidelidade Café" />
            <app-field-error [server]="fe('name')" [local]="err('name')" />
          </div>
          <div class="field">
            <label for="description">Descrição <span class="muted">(opcional, aparece na página de cadastro)</span></label>
            <textarea id="description" class="input" rows="2" formControlName="description" maxlength="500"></textarea>
          </div>
          @switch (type()) {
            @case ('STAMPS') {
              <div class="form-row">
                <div class="field">
                  <label for="stampsRequired">Carimbos para completar</label>
                  <input id="stampsRequired" class="input" type="number" min="2" max="100" formControlName="stampsRequired" />
                  <app-field-error [server]="fe('stampsRequired')" [local]="err('stampsRequired')" />
                </div>
                <div class="field">
                  <label for="stampCriterion">Quando o cliente ganha um carimbo</label>
                  <select id="stampCriterion" class="select" formControlName="stampCriterion">
                    @for (c of criteria; track c) { <option [value]="c">{{ criterionLabel(c) }}</option> }
                  </select>
                </div>
              </div>
              @if (form.controls.stampCriterion.value === 'PURCHASE') {
                <div class="field">
                  <label for="minPurchaseAmount">Valor mínimo da compra (R$) <span class="muted">(opcional)</span></label>
                  <input id="minPurchaseAmount" class="input" inputmode="decimal" formControlName="minPurchaseAmount" />
                  <app-field-error [server]="fe('minPurchaseAmount')" [local]="err('minPurchaseAmount')" />
                </div>
              }
            }
            @case ('POINTS') {
              <div class="form-row">
                <div class="field">
                  <label for="pointsPerUnit">Pontos concedidos</label>
                  <input id="pointsPerUnit" class="input" type="number" min="1" formControlName="pointsPerUnit" />
                  <app-field-error [server]="fe('pointsPerUnit')" [local]="err('pointsPerUnit')" />
                </div>
                <div class="field">
                  <label for="spendUnit">A cada (R$)</label>
                  <input id="spendUnit" class="input" inputmode="decimal" formControlName="spendUnit" />
                  <app-field-error [server]="fe('spendUnit')" [local]="err('spendUnit')" />
                </div>
                <div class="field">
                  <label for="rounding">Arredondamento</label>
                  <select id="rounding" class="select" formControlName="rounding">
                    @for (r of roundings; track r) { <option [value]="r">{{ roundingLabel(r) }}</option> }
                  </select>
                </div>
              </div>
              <div class="field">
                <label for="minPurchaseAmount">Valor mínimo para pontuar (R$) <span class="muted">(opcional)</span></label>
                <input id="minPurchaseAmount" class="input" inputmode="decimal" formControlName="minPurchaseAmount" />
                <app-field-error [server]="fe('minPurchaseAmount')" [local]="err('minPurchaseAmount')" />
              </div>
              <p class="muted">Exemplo: {{ form.controls.pointsPerUnit.value || 1 }} ponto(s) a cada R$ {{ form.controls.spendUnit.value || '1,00' }}.</p>
            }
            @case ('CASHBACK') {
              <app-alert kind="info">Cashback é um saldo promocional para usar no seu estabelecimento. Não há saque nem transferência de dinheiro.</app-alert>
              <div class="form-row">
                <div class="field">
                  <label for="cashbackPercent">Percentual (%)</label>
                  <input id="cashbackPercent" class="input" inputmode="decimal" formControlName="cashbackPercent" />
                  <app-field-error [server]="fe('cashbackPercent')" [local]="err('cashbackPercent')" />
                </div>
                <div class="field">
                  <label for="minPurchaseAmount">Compra mínima (R$) <span class="muted">(opcional)</span></label>
                  <input id="minPurchaseAmount" class="input" inputmode="decimal" formControlName="minPurchaseAmount" />
                  <app-field-error [server]="fe('minPurchaseAmount')" [local]="err('minPurchaseAmount')" />
                </div>
                <div class="field">
                  <label for="maxCreditPerPurchase">Crédito máximo por compra (R$) <span class="muted">(opcional)</span></label>
                  <input id="maxCreditPerPurchase" class="input" inputmode="decimal" formControlName="maxCreditPerPurchase" />
                  <app-field-error [server]="fe('maxCreditPerPurchase')" [local]="err('maxCreditPerPurchase')" />
                </div>
              </div>
              <div class="form-row">
                <div class="field">
                  <label for="minRedeemBalance">Saldo mínimo para usar (R$) <span class="muted">(opcional)</span></label>
                  <input id="minRedeemBalance" class="input" inputmode="decimal" formControlName="minRedeemBalance" />
                  <app-field-error [server]="fe('minRedeemBalance')" [local]="err('minRedeemBalance')" />
                </div>
                <div class="field">
                  <label for="maxRedeemPercent">Máximo da compra pago com cashback (%) <span class="muted">(opcional)</span></label>
                  <input id="maxRedeemPercent" class="input" inputmode="decimal" formControlName="maxRedeemPercent" />
                  <app-field-error [server]="fe('maxRedeemPercent')" [local]="err('maxRedeemPercent')" />
                </div>
                <div class="field">
                  <label for="rounding">Arredondamento dos centavos</label>
                  <select id="rounding" class="select" formControlName="rounding">
                    @for (r of roundings; track r) { <option [value]="r">{{ roundingLabel(r) }}</option> }
                  </select>
                </div>
              </div>
            }
            @case ('VIP') {
              <app-alert kind="info">Os níveis VIP são cadastrados na próxima etapa. Nesta versão não há emissão de cartões VIP.</app-alert>
            }
          }
        }

        @case (2) {
          @if (type() === 'STAMPS') {
            <fieldset class="form">
              <legend>Recompensa</legend>
              <div class="field">
                <label for="stampReward">Recompensa do cartão completo</label>
                <input id="stampReward" class="input" formControlName="stampReward" maxlength="200" placeholder="Ex.: Um café grátis" />
                <app-field-error [server]="fe('stampReward')" [local]="err('stampReward')" />
              </div>
              <label><input type="checkbox" formControlName="restartAfterRedeem" /> Recomeçar o cartão após o resgate</label>
            </fieldset>
          }
          @if (type() === 'POINTS') {
            <fieldset class="form">
              <legend>Recompensas por pontos</legend>
              @for (r of rewards(); track $index; let i = $index) {
                <div class="item">
                  <span><strong>{{ r.name }}</strong> — {{ r.cost }} pontos @if (r.description) { <span class="muted">· {{ r.description }}</span> }</span>
                  <button class="btn btn-sm" type="button" (click)="removeReward(i)">Remover</button>
                </div>
              } @empty {
                <p class="muted">Nenhuma recompensa ainda. Você também pode cadastrá-las depois, na página do programa.</p>
              }
              <div class="form-row add">
                <input class="input" [ngModelOptions]="{ standalone: true }" [(ngModel)]="rewardName" placeholder="Nome da recompensa" maxlength="80" aria-label="Nome da recompensa" />
                <input class="input" [ngModelOptions]="{ standalone: true }" [(ngModel)]="rewardCost" type="number" min="1" placeholder="Custo em pontos" aria-label="Custo em pontos" />
                <input class="input" [ngModelOptions]="{ standalone: true }" [(ngModel)]="rewardDescription" placeholder="Descrição (opcional)" maxlength="300" aria-label="Descrição da recompensa" />
                <button class="btn" type="button" (click)="addReward()">Adicionar</button>
              </div>
              @if (rewardError()) { <span class="field-error-text">{{ rewardError() }}</span> }
            </fieldset>
          }
          @if (type() === 'VIP') {
            <fieldset class="form">
              <legend>Níveis VIP</legend>
              @for (t of tiers(); track $index; let i = $index) {
                <div class="item">
                  <span><strong>{{ t.rankOrder }}. {{ t.name }}</strong>
                    @if (t.minSpend) { — R$ {{ t.minSpend }} gastos } @if (t.benefits) { <span class="muted">· {{ t.benefits }}</span> }</span>
                  <button class="btn btn-sm" type="button" (click)="removeTier(i)">Remover</button>
                </div>
              } @empty {
                <p class="muted">Nenhum nível ainda.</p>
              }
              <div class="form-row add">
                <input class="input" [ngModelOptions]="{ standalone: true }" [(ngModel)]="tierName" placeholder="Nome do nível" maxlength="40" aria-label="Nome do nível" />
                <input class="input" [ngModelOptions]="{ standalone: true }" [(ngModel)]="tierRank" type="number" min="1" max="20" placeholder="Ordem" aria-label="Ordem" />
                <input class="input" [ngModelOptions]="{ standalone: true }" [(ngModel)]="tierSpend" type="number" min="0" placeholder="Gasto mínimo (R$)" aria-label="Gasto mínimo" />
                <input class="input" [ngModelOptions]="{ standalone: true }" [(ngModel)]="tierBenefits" placeholder="Benefícios" maxlength="500" aria-label="Benefícios" />
                <button class="btn" type="button" (click)="addTier()">Adicionar</button>
              </div>
              @if (rewardError()) { <span class="field-error-text">{{ rewardError() }}</span> }
            </fieldset>
          }
          <fieldset class="form">
            <legend>Validade</legend>
            <div class="form-row">
              <div class="field">
                <label for="inactivityDays">Cartão expira após quantos dias sem movimentação</label>
                <input id="inactivityDays" class="input" type="number" min="1" max="3650" formControlName="inactivityDays" />
                <span class="hint">Só compras ou resgates confirmados renovam o prazo. Abrir, baixar ou consultar o cartão não renova.</span>
                <app-field-error [server]="fe('inactivityDays')" [local]="err('inactivityDays')" />
              </div>
              <div class="field">
                <label for="validityMode">Até quando vale no último dia</label>
                <select id="validityMode" class="select" formControlName="validityMode">
                  @for (v of validityModes; track v) { <option [value]="v">{{ validityLabel(v) }}</option> }
                </select>
                <span class="hint">Fuso do estabelecimento: {{ ctx.panel()?.policy?.timeZone }}</span>
              </div>
            </div>
            @if (type() !== 'VIP') {
              <div class="form-row">
                <div class="field">
                  <label for="expiredBalancePolicy">Quando o cartão expira, o saldo…</label>
                  <select id="expiredBalancePolicy" class="select" formControlName="expiredBalancePolicy">
                    @for (v of balancePolicies; track v) { <option [value]="v">{{ balanceLabel(v) }}</option> }
                  </select>
                </div>
                <div class="field">
                  <label for="reversalPolicy">Estorno de compra já usada pelo cliente</label>
                  <select id="reversalPolicy" class="select" formControlName="reversalPolicy">
                    @for (v of reversalPolicies; track v) { <option [value]="v">{{ reversalLabel(v) }}</option> }
                  </select>
                </div>
                <div class="field">
                  <label for="benefitValidityDays">Validade de cada benefício (dias) <span class="muted">(opcional)</span></label>
                  <input id="benefitValidityDays" class="input" type="number" min="1" max="3650" formControlName="benefitValidityDays" />
                  <span class="hint">Independe da validade do cartão. Vazio = sem vencimento próprio.</span>
                  <app-field-error [server]="fe('benefitValidityDays')" [local]="err('benefitValidityDays')" />
                </div>
              </div>
            }
          </fieldset>
        }

        @case (3) {
          <div class="design">
            <div class="form">
              <div class="form-row">
                <div class="field">
                  <label for="brandColor">Cor principal</label>
                  <div class="color"><input type="color" formControlName="brandColor" aria-label="Escolher cor principal" />
                    <input id="brandColor" class="input mono" formControlName="brandColor" maxlength="7" /></div>
                  <app-field-error [server]="fe('brandColor')" [local]="err('brandColor')" />
                </div>
                <div class="field">
                  <label for="textColor">Cor do texto</label>
                  <div class="color"><input type="color" formControlName="textColor" aria-label="Escolher cor do texto" />
                    <input id="textColor" class="input mono" formControlName="textColor" maxlength="7" /></div>
                  <app-field-error [server]="fe('textColor')" [local]="err('textColor')" />
                </div>
              </div>
              @if (lowContrast()) {
                <app-alert kind="warning">Contraste baixo entre a cor principal e a do texto ({{ contrast() }}:1). Para boa leitura, use 4,5:1 ou mais.
                  Na página de cadastro o Pass troca automaticamente para preto ou branco.</app-alert>
              }
              <div class="field">
                <label for="cardMessage">Mensagem do cartão <span class="muted">(opcional)</span></label>
                <input id="cardMessage" class="input" formControlName="cardMessage" maxlength="200" />
              </div>
              <div class="field">
                <label for="rewardInfo">Informação sobre recompensas <span class="muted">(opcional)</span></label>
                <input id="rewardInfo" class="input" formControlName="rewardInfo" maxlength="300" />
              </div>
              <div class="form-row">
                <div class="field">
                  <label for="logo">Logotipo <span class="muted">(PNG ou JPEG, até 1 MB; quadrado de 660 px recomendado)</span></label>
                  <input id="logo" type="file" accept="image/png,image/jpeg" (change)="pick('logo', $event)" />
                  @if (logo()) { <button class="btn btn-sm" type="button" (click)="clearImage('logo')">Remover logotipo</button> }
                </div>
                <div class="field">
                  <label for="hero">Imagem de destaque <span class="muted">(PNG ou JPEG, até 1 MB; 1032 × 812 px)</span></label>
                  <input id="hero" type="file" accept="image/png,image/jpeg" (change)="pick('hero', $event)" />
                  @if (hero()) { <button class="btn btn-sm" type="button" (click)="clearImage('hero')">Remover imagem</button> }
                </div>
              </div>
              @if (imageError()) { <app-alert kind="error">{{ imageError() }}</app-alert> }
            </div>
            <div class="preview">
              <app-card-preview [design]="previewDesign()" [programName]="form.controls.name.value || 'Seu programa'"
                                [establishmentName]="ctx.panel()?.name ?? ''" [type]="type()" [balance]="0"
                                [stampsRequired]="type() === 'STAMPS' ? form.controls.stampsRequired.value : null"
                                code="XXXX-XXXX-XXXX-XXXX" holder="Cliente" />
            </div>
          </div>
        }

        @case (4) {
          <dl class="details review">
            <dt>Tipo</dt><dd>{{ typeLabel(type()) }}</dd>
            <dt>Nome</dt><dd>{{ form.controls.name.value }}</dd>
            @if (form.controls.description.value) { <dt>Descrição</dt><dd>{{ form.controls.description.value }}</dd> }
            @for (r of summaryRules(); track r.label) { <dt>{{ r.label }}</dt><dd>{{ r.value }}</dd> }
            <dt>Validade do cartão</dt><dd>{{ form.controls.inactivityDays.value }} dias sem movimentação ({{ validityLabel(form.controls.validityMode.value) }})</dd>
            @if (type() !== 'VIP') {
              <dt>Saldo na expiração</dt><dd>{{ balanceLabel(form.controls.expiredBalancePolicy.value) }}</dd>
              <dt>Estorno</dt><dd>{{ reversalLabel(form.controls.reversalPolicy.value) }}</dd>
              <dt>Validade de cada benefício</dt><dd>{{ form.controls.benefitValidityDays.value ? form.controls.benefitValidityDays.value + ' dias' : 'sem vencimento próprio' }}</dd>
            }
            <dt>Cores</dt><dd><span class="swatch" [style.background]="form.controls.brandColor.value"></span> {{ form.controls.brandColor.value }}
              · texto {{ form.controls.textColor.value }}</dd>
            <dt>Imagens</dt><dd>{{ logo() ? 'logotipo' : 'sem logotipo' }} · {{ hero() ? 'imagem de destaque' : 'sem imagem de destaque' }}</dd>
          </dl>
          <p class="muted">Ao confirmar, o programa é criado já ativo: passa a aceitar emissões de cartões e movimentações.
            Mudanças de regra depois valem só para as próximas movimentações.</p>
          @if (partial(); as msg) {
            <app-alert kind="warning">{{ msg }}</app-alert>
          }
        }
      }

      <div class="form-footer split nav">
        @if (step() > 0) {
          <button class="btn" type="button" (click)="back()" [disabled]="creating()"><app-icon name="chevron-left" [size]="16" />Voltar</button>
        } @else {
          <span></span>
        }
        @if (step() < steps.length - 1) {
          <button class="btn btn-primary" type="submit" [disabled]="noTypeAllowed()">Continuar <app-icon name="chevron-right" [size]="16" /></button>
        } @else if (createdId(); as id) {
          <a class="btn btn-primary" [routerLink]="[ctx.base() + '/programas', id]">Abrir o programa</a>
        } @else {
          <button class="btn btn-primary" type="submit" [disabled]="creating() || !canManage()">
            {{ creating() ? 'Criando…' : 'Criar e ativar programa' }}</button>
        }
      </div>
    </form>

    @if (showSide()) {
      <aside class="side" aria-label="Prévia do cartão">
        <app-card-preview [design]="previewDesign()" [programName]="form.controls.name.value || 'Seu programa'"
                          [establishmentName]="ctx.panel()?.name ?? ''" [type]="type()" [balance]="0"
                          [stampsRequired]="type() === 'STAMPS' ? form.controls.stampsRequired.value : null"
                          code="XXXX-XXXX-XXXX-XXXX" holder="Cliente" />
        <p class="muted small">Prévia aproximada. A aparência final depende da carteira (Google ou Apple) e do celular do cliente.</p>
      </aside>
    }
    </div>
  `,
  styles: `
    .wizard-progress {
      margin-bottom: 1rem;
    }
    .progress-text {
      display: none;
      margin: 0 0 0.4rem;
      font-size: var(--text-sm);
      color: var(--text-muted);
    }
    .wizard-progress .meter {
      display: none;
    }
    .stepper {
      list-style: none;
      display: flex;
      gap: 0;
      padding: 0;
      margin: 0;
      counter-reset: step;
    }
    .stepper li {
      flex: 1;
      display: flex;
      align-items: center;
      min-width: 0;
    }
    .stepper li + li::before {
      content: '';
      flex: 0 0 24px;
      height: 2px;
      margin: 0 0.35rem;
      border-radius: 2px;
      background: var(--border-strong);
    }
    .stepper li.done + li::before,
    .stepper li.current::before {
      background: var(--primary);
    }
    .stepper button {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      min-height: 40px;
      min-width: 0;
      padding: 0 0.25rem;
      border: 0;
      background: none;
      font: inherit;
      font-size: var(--text-sm);
      font-weight: 600;
      color: var(--text-muted);
      cursor: pointer;
      border-radius: var(--radius-sm);
    }
    .stepper button:disabled {
      cursor: default;
      color: var(--text-subtle);
    }
    .stepper .name {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .stepper .num {
      display: grid;
      place-items: center;
      width: 26px;
      height: 26px;
      flex: none;
      border-radius: 50%;
      border: 2px solid var(--border-strong);
      background: var(--surface);
      font-weight: 700;
      font-size: var(--text-xs);
    }
    .stepper .current button {
      color: var(--text);
    }
    .stepper .current .num {
      border-color: var(--primary);
      background: var(--primary);
      color: #fff;
    }
    .stepper .done .num {
      border-color: var(--primary);
      background: var(--primary-soft);
      color: var(--primary-ink);
    }
    @media (max-width: 900px) {
      .progress-text,
      .wizard-progress .meter {
        display: block;
      }
      .wizard-progress .meter {
        margin-bottom: 0.6rem;
      }
      .stepper .name {
        display: none;
      }
      .stepper li {
        flex: 0 0 auto;
      }
    }
    .wizard {
      display: grid;
      gap: 1.25rem;
      align-items: start;
    }
    .wizard.with-side {
      grid-template-columns: minmax(0, 1fr) 320px;
    }
    .side {
      position: sticky;
      top: calc(60px + 1.5rem);
      display: grid;
      gap: 0.6rem;
      justify-items: center;
      text-align: center;
    }
    @media (max-width: 1100px) {
      .wizard.with-side {
        grid-template-columns: 1fr;
      }
      .side {
        display: none;
      }
    }
    .step-head {
      padding-bottom: 0.85rem;
      border-bottom: 1px solid var(--border);
    }
    .step-head h2 {
      margin: 0;
      font-size: var(--text-lg);
    }
    .step-head h2:focus {
      outline: none;
    }
    .step-head p {
      margin: 0.25rem 0 0;
    }
    .types {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(min(100%, 210px), 1fr));
      gap: 0.75rem;
    }
    .type {
      position: relative;
      display: grid;
      align-content: start;
      gap: 0.35rem;
      padding: 1rem;
      border: 1.5px solid var(--border);
      border-radius: var(--radius);
      background: var(--surface);
      cursor: pointer;
    }
    .type:hover:not(.disabled) {
      border-color: var(--border-strong);
    }
    .type input {
      position: absolute;
      opacity: 0;
      pointer-events: none;
    }
    .type:has(input:focus-visible) {
      box-shadow: var(--focus-ring);
    }
    .type-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0.25rem;
    }
    .type-icon {
      display: grid;
      place-items: center;
      width: 38px;
      height: 38px;
      border-radius: 10px;
      background: var(--surface-muted);
      color: var(--text-muted);
    }
    .type-check {
      display: grid;
      place-items: center;
      width: 22px;
      height: 22px;
      border-radius: 50%;
      background: var(--primary);
      color: #fff;
    }
    .type small {
      color: var(--text-muted);
      line-height: 1.4;
    }
    .type.selected {
      border-color: var(--primary);
      background: var(--primary-soft);
    }
    .type.selected .type-icon {
      background: var(--primary);
      color: #fff;
    }
    .type.disabled {
      opacity: 0.6;
      cursor: not-allowed;
      background: var(--surface-muted);
    }
    .review {
      padding: 1rem;
      border-radius: var(--radius-sm);
      background: var(--surface-muted);
    }
    .warn {
      color: var(--warning);
    }
    .item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 0.75rem;
      padding: 0.5rem 0.75rem;
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
    }
    .add {
      align-items: center;
    }
    .design {
      display: grid;
      grid-template-columns: minmax(0, 1.3fr) minmax(0, 1fr);
      gap: 1.25rem;
      align-items: start;
    }
    @media (max-width: 900px) {
      .design {
        grid-template-columns: 1fr;
      }
    }
    .preview {
      display: grid;
      justify-items: center;
    }
    @media (max-width: 720px) {
      .nav {
        position: sticky;
        bottom: 0;
        z-index: 5;
        box-shadow: 0 -4px 12px rgb(17 24 39 / 6%);
      }
      .nav .btn {
        flex: 1;
      }
    }
  `,
})
export class ProgramWizardPage implements OnDestroy {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(LoyaltyApi);
  private readonly router = inject(Router);
  private readonly notifications = inject(NotificationService);

  protected readonly steps = STEPS;
  protected readonly stepTitles = STEP_TITLES;
  protected readonly stepHelp = STEP_HELP;
  /** Verdadeiro depois de uma tentativa de avançar com campos inválidos (some ao corrigir e avançar). */
  protected readonly stepInvalid = signal(false);
  /** Prévia lateral nas etapas de regras, recompensas e revisão (a etapa de aparência já mostra a prévia ao lado). */
  protected readonly showSide = computed(() => [1, 2, 4].includes(this.step()));
  private readonly wizardForm = viewChild<ElementRef<HTMLFormElement>>('wizardForm');
  protected readonly types = TYPES;
  protected readonly criteria: StampCriterion[] = ['VISIT', 'PURCHASE', 'PRODUCT'];
  protected readonly roundings: Rounding[] = ['DOWN', 'HALF_UP', 'UP'];
  protected readonly validityModes: ValidityMode[] = ['END_OF_DAY', 'EXACT_TIME'];
  protected readonly balancePolicies: ExpiredBalancePolicy[] = ['KEEP', 'FORFEIT'];
  protected readonly reversalPolicies: ReversalPolicy[] = ['REQUIRE_BALANCE', 'ALLOW_NEGATIVE'];

  protected readonly step = signal(0);
  protected readonly maxReached = signal(0);
  protected readonly serverError = signal<ApiError | null>(null);
  protected readonly creating = signal(false);
  protected readonly createdId = signal<number | null>(null);
  protected readonly partial = signal<string | null>(null);
  protected readonly rewards = signal<DraftReward[]>([]);
  protected readonly tiers = signal<DraftTier[]>([]);
  protected readonly rewardError = signal<string | null>(null);
  protected readonly imageError = signal<string | null>(null);
  protected readonly logo = signal<File | null>(null);
  protected readonly hero = signal<File | null>(null);
  private readonly logoPreview = signal<string | null>(null);
  private readonly heroPreview = signal<string | null>(null);
  protected rewardName = '';
  protected rewardCost: number | null = null;
  protected rewardDescription = '';
  protected tierName = '';
  protected tierRank: number | null = null;
  protected tierSpend: number | null = null;
  protected tierBenefits = '';

  protected readonly form = inject(NonNullableFormBuilder).group({
    type: ['STAMPS' as ProgramType, Validators.required],
    name: ['', [Validators.required, Validators.maxLength(80)]],
    description: ['', Validators.maxLength(500)],
    inactivityDays: [90 as number | null, [Validators.required, Validators.min(1), Validators.max(3650)]],
    validityMode: ['END_OF_DAY' as ValidityMode],
    expiredBalancePolicy: ['KEEP' as ExpiredBalancePolicy],
    reversalPolicy: ['REQUIRE_BALANCE' as ReversalPolicy],
    benefitValidityDays: [null as number | null, [Validators.min(1), Validators.max(3650)]],
    minPurchaseAmount: ['', Validators.pattern(MONEY)],
    rounding: ['DOWN' as Rounding],
    pointsPerUnit: [1 as number | null, [Validators.min(1), Validators.max(100000)]],
    spendUnit: ['1,00', Validators.pattern(MONEY)],
    cashbackPercent: ['5', Validators.pattern(MONEY)],
    maxCreditPerPurchase: ['', Validators.pattern(MONEY)],
    minRedeemBalance: ['', Validators.pattern(MONEY)],
    maxRedeemPercent: ['', Validators.pattern(MONEY)],
    stampsRequired: [10 as number | null, [Validators.min(2), Validators.max(100)]],
    stampCriterion: ['VISIT' as StampCriterion],
    stampReward: ['', Validators.maxLength(200)],
    restartAfterRedeem: [true],
    brandColor: ['#F43F5E', [Validators.required, Validators.pattern(/^#[0-9A-Fa-f]{6}$/)]],
    textColor: ['#FFFFFF', [Validators.required, Validators.pattern(/^#[0-9A-Fa-f]{6}$/)]],
    cardMessage: ['', Validators.maxLength(200)],
    rewardInfo: ['', Validators.maxLength(300)],
  });

  private readonly typeValue = signal<ProgramType>('STAMPS');
  protected readonly type = computed(() => this.typeValue());
  private readonly colors = signal({ brand: '#F43F5E', text: '#FFFFFF' });
  protected readonly contrast = computed(() => {
    const r = contrastRatio(this.colors().brand, this.colors().text);
    return r === null ? null : Math.round(r * 10) / 10;
  });
  protected readonly lowContrast = computed(() => (this.contrast() ?? 21) < 4.5);
  protected readonly noTypeAllowed = computed(() => !TYPES.some((t) => this.allowed(t)));
  protected readonly previewDesign = computed<Design>(() => ({
    brandColor: this.colors().brand,
    textColor: this.colors().text,
    cardMessage: null,
    rewardInfo: null,
    logoUrl: this.logoPreview(),
    heroUrl: this.heroPreview(),
    walletNotes: [],
  }));

  /** Campos validados em cada etapa (os demais não bloqueiam o avanço). */
  private fieldsOf(step: number): (keyof typeof this.form.controls)[] {
    const t = this.type();
    if (step === 0) return ['type'];
    if (step === 1) {
      const common: (keyof typeof this.form.controls)[] = ['name', 'description'];
      if (t === 'STAMPS') return [...common, 'stampsRequired', 'minPurchaseAmount'];
      if (t === 'POINTS') return [...common, 'pointsPerUnit', 'spendUnit', 'minPurchaseAmount'];
      if (t === 'CASHBACK') return [...common, 'cashbackPercent', 'minPurchaseAmount', 'maxCreditPerPurchase', 'minRedeemBalance', 'maxRedeemPercent'];
      return common;
    }
    if (step === 2) return ['inactivityDays', 'benefitValidityDays', 'stampReward'];
    if (step === 3) return ['brandColor', 'textColor', 'cardMessage', 'rewardInfo'];
    return [];
  }

  constructor() {
    this.form.controls.type.valueChanges.subscribe((t) => this.typeValue.set(t));
    this.form.controls.brandColor.valueChanges.subscribe((brand) => this.colors.update((c) => ({ ...c, brand })));
    this.form.controls.textColor.valueChanges.subscribe((text) => this.colors.update((c) => ({ ...c, text })));
    effect(() => {
      const panel = this.ctx.panel();
      if (!panel || this.form.dirty) return;
      this.form.controls.inactivityDays.setValue(panel.policy.defaultInactivityDays);
      const first = TYPES.find((t) => panel.policy.allowedProgramTypes.includes(t));
      if (first) this.form.controls.type.setValue(first);
    });
  }

  ngOnDestroy(): void {
    for (const url of [this.logoPreview(), this.heroPreview()]) if (url) URL.revokeObjectURL(url);
  }

  protected canManage(): boolean {
    return this.ctx.can('PROGRAMS_MANAGE');
  }

  protected allowed(t: ProgramType): boolean {
    return this.ctx.panel()?.policy.allowedProgramTypes.includes(t) ?? false;
  }

  protected fe(field: string): string | undefined {
    return this.serverError()?.fieldErrors?.[field];
  }

  /** Mensagem local do campo (só depois de tocado/validado). */
  protected err(name: keyof typeof this.form.controls): string | null {
    const c = this.form.controls[name];
    if (!c.touched || c.valid) return null;
    const e = c.errors ?? {};
    if (e['required']) return name === 'name' ? 'Informe o nome.' : 'Campo obrigatório.';
    if (e['pattern']) return name === 'brandColor' || name === 'textColor' ? 'Use o formato #RRGGBB.' : 'Valor inválido (use vírgula para centavos, ex.: 10,50).';
    if (e['min']) return `Mínimo: ${e['min'].min}.`;
    if (e['max']) return `Máximo: ${e['max'].max}.`;
    if (e['maxlength']) return `Máximo de ${e['maxlength'].requiredLength} caracteres.`;
    if (e['custom']) return e['custom'];
    return 'Valor inválido.';
  }

  /** Validações que dependem do tipo (campos obrigatórios só em um dos tipos). */
  private validateStep(step: number): boolean {
    const fields = this.fieldsOf(step);
    fields.forEach((f) => this.form.controls[f].markAsTouched());
    const t = this.type();
    const requireField = (name: keyof typeof this.form.controls) => {
      const c = this.form.controls[name];
      const v = c.value;
      if (v === null || v === '' || (typeof v === 'number' && Number.isNaN(v))) c.setErrors({ ...(c.errors ?? {}), required: true });
    };
    if (step === 0 && !this.allowed(t)) return false;
    if (step === 1) {
      if (t === 'STAMPS') requireField('stampsRequired');
      if (t === 'POINTS') {
        requireField('pointsPerUnit');
        requireField('spendUnit');
      }
      if (t === 'CASHBACK') requireField('cashbackPercent');
    }
    return fields.every((f) => this.form.controls[f].valid);
  }

  protected next(): void {
    const current = this.step();
    if (current === STEPS.length - 1) {
      void this.create();
      return;
    }
    if (!this.validateStep(current)) {
      this.stepInvalid.set(true);
      this.focusFirstInvalid();
      return;
    }
    this.stepInvalid.set(false);
    this.serverError.set(null);
    this.step.set(current + 1);
    this.maxReached.update((m) => Math.max(m, current + 1));
    this.afterStepChange();
  }

  protected back(): void {
    this.stepInvalid.set(false);
    this.step.update((s) => Math.max(0, s - 1));
    this.afterStepChange();
  }

  protected goTo(i: number): void {
    if (i <= this.maxReached()) {
      this.stepInvalid.set(false);
      this.step.set(i);
      this.afterStepChange();
    }
  }

  protected typeIcon(t: ProgramType): string {
    return TYPE_ICONS[t];
  }

  /** Leva o foco ao título da nova etapa (leitores de tela anunciam a mudança) e volta ao topo da página. */
  private afterStepChange(): void {
    setTimeout(() => {
      this.wizardForm()?.nativeElement.querySelector<HTMLElement>('#step-title')?.focus({ preventScroll: true });
      if (typeof window.scrollTo === 'function') {
        try {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } catch {
          /* ambiente sem rolagem (testes) */
        }
      }
    });
  }

  /** Coloca o cursor no primeiro campo com erro, para a correção ser imediata. */
  private focusFirstInvalid(): void {
    setTimeout(() => {
      const el = this.wizardForm()?.nativeElement.querySelector<HTMLElement>(
        'input.ng-invalid, select.ng-invalid, textarea.ng-invalid',
      );
      el?.focus();
    });
  }

  protected addReward(): void {
    const name = this.rewardName.trim();
    if (!name || !this.rewardCost || this.rewardCost < 1) {
      this.rewardError.set('Informe o nome e o custo (1 ponto ou mais).');
      return;
    }
    this.rewardError.set(null);
    this.rewards.update((list) => [...list, { name, cost: Math.trunc(this.rewardCost!), description: this.rewardDescription.trim() }]);
    this.rewardName = '';
    this.rewardCost = null;
    this.rewardDescription = '';
  }

  protected removeReward(i: number): void {
    this.rewards.update((list) => list.filter((_, idx) => idx !== i));
  }

  protected addTier(): void {
    const name = this.tierName.trim();
    if (!name || !this.tierRank || this.tierRank < 1 || this.tierRank > 20) {
      this.rewardError.set('Informe o nome e a ordem (1 a 20) do nível.');
      return;
    }
    this.rewardError.set(null);
    this.tiers.update((list) =>
      [...list, { name, rankOrder: this.tierRank!, minSpend: this.tierSpend, benefits: this.tierBenefits.trim() }].sort(
        (a, b) => a.rankOrder - b.rankOrder,
      ),
    );
    this.tierName = '';
    this.tierRank = null;
    this.tierSpend = null;
    this.tierBenefits = '';
  }

  protected removeTier(i: number): void {
    this.tiers.update((list) => list.filter((_, idx) => idx !== i));
  }

  protected pick(slot: 'logo' | 'hero', event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;
    this.imageError.set(null);
    if (!file) return;
    if (!['image/png', 'image/jpeg'].includes(file.type)) {
      this.imageError.set('Envie uma imagem PNG ou JPEG.');
      input.value = '';
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      this.imageError.set('A imagem deve ter no máximo 1 MB.');
      input.value = '';
      return;
    }
    this.setImage(slot, file);
  }

  protected clearImage(slot: 'logo' | 'hero'): void {
    this.setImage(slot, null);
  }

  private setImage(slot: 'logo' | 'hero', file: File | null): void {
    const preview = slot === 'logo' ? this.logoPreview : this.heroPreview;
    const old = preview();
    if (old) URL.revokeObjectURL(old);
    preview.set(file ? URL.createObjectURL(file) : null);
    (slot === 'logo' ? this.logo : this.hero).set(file);
  }

  protected summaryRules(): { label: string; value: string }[] {
    const v = this.form.getRawValue();
    switch (this.type()) {
      case 'STAMPS':
        return [
          { label: 'Carimbos para completar', value: `${v.stampsRequired} (${this.criterionLabel(v.stampCriterion).toLowerCase()})` },
          ...(v.stampCriterion === 'PURCHASE' && v.minPurchaseAmount ? [{ label: 'Compra mínima', value: `R$ ${v.minPurchaseAmount}` }] : []),
          { label: 'Recompensa', value: v.stampReward || 'não informada' },
          { label: 'Após o resgate', value: v.restartAfterRedeem ? 'o cartão recomeça' : 'o cartão é concluído' },
        ];
      case 'POINTS':
        return [
          { label: 'Regra', value: `${v.pointsPerUnit} ponto(s) a cada R$ ${v.spendUnit} (${this.roundingLabel(v.rounding).toLowerCase()})` },
          ...(v.minPurchaseAmount ? [{ label: 'Compra mínima', value: `R$ ${v.minPurchaseAmount}` }] : []),
          { label: 'Recompensas', value: this.rewards().length ? this.rewards().map((r) => `${r.name} (${r.cost} pts)`).join(', ') : 'nenhuma ainda' },
        ];
      case 'CASHBACK':
        return [
          { label: 'Cashback', value: `${v.cashbackPercent}% do valor da compra` },
          ...(v.minPurchaseAmount ? [{ label: 'Compra mínima', value: `R$ ${v.minPurchaseAmount}` }] : []),
          ...(v.maxCreditPerPurchase ? [{ label: 'Crédito máximo por compra', value: `R$ ${v.maxCreditPerPurchase}` }] : []),
          ...(v.minRedeemBalance ? [{ label: 'Saldo mínimo para usar', value: `R$ ${v.minRedeemBalance}` }] : []),
          ...(v.maxRedeemPercent ? [{ label: 'Máximo pago com cashback', value: `${v.maxRedeemPercent}% da compra` }] : []),
        ];
      default:
        return [{ label: 'Níveis', value: this.tiers().length ? this.tiers().map((t) => t.name).join(', ') : 'nenhum ainda' }];
    }
  }

  private payload(): ProgramPayload {
    const v = this.form.getRawValue();
    const money = (s: string) => parseMoney(s);
    return {
      type: this.type(),
      name: v.name.trim(),
      description: v.description.trim() || null,
      inactivityDays: v.inactivityDays ?? 0,
      validityMode: v.validityMode,
      expiredBalancePolicy: v.expiredBalancePolicy,
      reversalPolicy: v.reversalPolicy,
      benefitValidityDays: v.benefitValidityDays || null,
      minPurchaseAmount: money(v.minPurchaseAmount),
      rounding: v.rounding,
      pointsPerUnit: v.pointsPerUnit,
      spendUnit: money(v.spendUnit),
      cashbackPercent: money(v.cashbackPercent),
      maxCreditPerPurchase: money(v.maxCreditPerPurchase),
      minRedeemBalance: money(v.minRedeemBalance),
      maxRedeemPercent: money(v.maxRedeemPercent),
      stampsRequired: v.stampsRequired,
      stampCriterion: v.stampCriterion,
      stampReward: v.stampReward.trim() || null,
      restartAfterRedeem: v.restartAfterRedeem,
    };
  }

  /** Etapa em que cada campo é preenchido (para levar o usuário ao erro devolvido pelo servidor). */
  private stepOfField(field: string): number {
    for (let i = 0; i < STEPS.length; i++) {
      if ((this.fieldsOf(i) as string[]).includes(field)) return i;
    }
    return this.step();
  }

  private async create(): Promise<void> {
    const eid = this.ctx.id();
    if (eid === null || this.creating() || this.createdId()) return;
    this.creating.set(true);
    this.serverError.set(null);
    let programId: number;
    try {
      programId = (await lastValueFrom(this.api.createProgram(eid, this.payload()))).id;
    } catch (e) {
      const err = toApiError(e);
      this.serverError.set(err);
      this.creating.set(false);
      const field = Object.keys(err.fieldErrors ?? {})[0];
      if (field) this.step.set(this.stepOfField(field));
      return;
    }
    this.createdId.set(programId);
    const v = this.form.getRawValue();
    const followUps: Observable<unknown>[] = [
      defer(() => this.api.updateDesign(eid, programId, {
        brandColor: v.brandColor.toUpperCase(),
        textColor: v.textColor.toUpperCase(),
        cardMessage: v.cardMessage.trim() || null,
        rewardInfo: v.rewardInfo.trim() || null,
      })),
    ];
    if (this.logo()) followUps.push(defer(() => this.api.uploadImage(eid, programId, 'logo', this.logo()!)));
    if (this.hero()) followUps.push(defer(() => this.api.uploadImage(eid, programId, 'hero', this.hero()!)));
    for (const r of this.type() === 'POINTS' ? this.rewards() : []) {
      followUps.push(defer(() => this.api.createReward(eid, programId, { name: r.name, description: r.description || null, cost: r.cost, active: true })));
    }
    for (const t of this.type() === 'VIP' ? this.tiers() : []) {
      followUps.push(defer(() => this.api.saveTier(eid, programId, {
        name: t.name, rankOrder: t.rankOrder, minSpend: t.minSpend, minVisits: null, periodDays: null, benefits: t.benefits || null,
      })));
    }
    try {
      await lastValueFrom(concat(...followUps).pipe(toArray()));
      this.notifications.success('Programa criado e ativo.');
      void this.router.navigate([this.ctx.base() + '/programas', programId]);
    } catch (e) {
      this.partial.set(
        `O programa foi criado, mas parte da configuração não foi salva (${toApiError(e).message}). ` +
          'Abra o programa para conferir personalização, imagens e recompensas.',
      );
    } finally {
      this.creating.set(false);
    }
  }

  protected typeLabel(t: string): string {
    return label(PROGRAM_TYPE_LABELS, t);
  }
  protected hint(t: string): string {
    return label(PROGRAM_TYPE_HINTS, t);
  }
  protected criterionLabel(c: string): string {
    return label(STAMP_CRITERION_LABELS, c);
  }
  protected roundingLabel(r: string): string {
    return label(ROUNDING_LABELS, r);
  }
  protected validityLabel(v: string): string {
    return label(VALIDITY_MODE_LABELS, v);
  }
  protected balanceLabel(v: string): string {
    return label(EXPIRED_BALANCE_LABELS, v);
  }
  protected reversalLabel(v: string): string {
    return label(REVERSAL_LABELS, v);
  }
}
