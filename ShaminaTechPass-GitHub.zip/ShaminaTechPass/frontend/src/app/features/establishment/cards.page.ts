import { ChangeDetectionStrategy, Component, effect, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import { Card, CardStatus, Program } from '../../core/loyalty-models';
import { Page } from '../../core/models';
import { CARD_STATUS_LABELS, formatBalance, formatLocalDateTime, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { EmptyStateComponent } from '../../shared/ui/empty-state.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { PagerComponent } from '../../shared/ui/pager.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';
import { EstablishmentContext } from './establishment-context.service';

@Component({
  selector: 'app-cards-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, RouterLink, AlertComponent, EmptyStateComponent, IconComponent, PageHeaderComponent, PagerComponent, SpinnerComponent, StatusBadgeComponent],
  template: `
    <app-page-header title="Cartões" subtitle="Cartões emitidos, saldos e validade" />
    <form class="toolbar" (ngSubmit)="load(0)">
      <input class="input" type="search" name="q" [(ngModel)]="q" placeholder="Cliente, telefone ou código do cartão" aria-label="Pesquisar" />
      <select class="select" name="status" [(ngModel)]="status" (ngModelChange)="load(0)" aria-label="Situação">
        <option value="">Todas as situações</option>
        @for (s of statuses; track s) { <option [value]="s">{{ statusLabel(s) }}</option> }
      </select>
      <select class="select" name="program" [(ngModel)]="programId" (ngModelChange)="load(0)" aria-label="Programa">
        <option [ngValue]="null">Todos os programas</option>
        @for (p of programs(); track p.id) { <option [ngValue]="p.id">{{ p.name }}</option> }
      </select>
      <button class="btn" type="submit"><app-icon name="search" /> Filtrar</button>
    </form>
    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (page(); as p) {
      @if (p.content.length === 0) {
        @if (q.trim() || status || programId !== null) {
          <app-empty-state icon="search" title="Nenhum cartão encontrado" description="Nenhum cartão corresponde aos filtros. Ajuste a busca." />
        } @else {
          <app-empty-state icon="card" title="Nenhum cartão emitido"
            description="Os cartões aparecem aqui quando o cliente se cadastra pelo QR Code ou quando você emite um na página do cliente." />
        }
      } @else {
        <p class="result-count">{{ p.totalElements }} cartão(ões)</p>
        <div class="table-wrap">
          <table class="table responsive">
            <thead><tr><th>Cliente</th><th>Programa</th><th class="num">Saldo</th><th>Válido até</th><th>Situação</th><th><span class="sr-only">Ações</span></th></tr></thead>
            <tbody>
              @for (c of p.content; track c.id) {
                <tr>
                  <td data-label="Cliente">
                    <a class="person" [routerLink]="[ctx.base() + '/cartoes', c.id]">
                      <span class="initial" aria-hidden="true">{{ c.consumerName.charAt(0) }}</span>
                      <span class="person-text"><strong>{{ c.consumerName }}</strong>
                        <span class="person-sub mono">{{ c.displayCode }}</span></span>
                    </a>
                  </td>
                  <td data-label="Programa">{{ c.programName }}</td>
                  <td data-label="Saldo" class="num"><strong>{{ balance(c) }}</strong></td>
                  <td data-label="Válido até">{{ local(c.validUntil) }}</td>
                  <td data-label="Situação"><app-badge [value]="c.status" [labelText]="statusLabel(c.status)" /></td>
                  <td class="cell-actions"><a class="btn btn-sm" [routerLink]="[ctx.base() + '/cartoes', c.id]"
                    [attr.aria-label]="'Abrir cartão de ' + c.consumerName">Abrir <app-icon name="chevron-right" [size]="16" /></a></td>
                </tr>
              }
            </tbody>
          </table>
        </div>
        <app-pager [page]="p.page" [totalPages]="p.totalPages" (pageChange)="load($event)" />
      }
    } @else {
      <app-spinner />
    }
  `,
})
export class CardsPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(LoyaltyApi);
  protected readonly statuses: CardStatus[] = ['ACTIVE', 'SUSPENDED', 'EXPIRED', 'COMPLETED', 'CANCELLED'];
  protected readonly page = signal<Page<Card> | null>(null);
  protected readonly programs = signal<Program[]>([]);
  protected readonly error = signal<ApiError | null>(null);
  protected q = '';
  protected status: CardStatus | '' = '';
  protected programId: number | null = null;

  constructor() {
    effect(() => {
      const id = this.ctx.id();
      if (id === null) return;
      this.api.programs(id).subscribe((p) => this.programs.set(p));
      this.load(0);
    });
  }

  protected load(page: number): void {
    const id = this.ctx.id();
    if (id === null) return;
    this.api.cards(id, { status: this.status, programId: this.programId, q: this.q }, page).subscribe({
      next: (p) => {
        this.error.set(null);
        this.page.set(p);
      },
      error: (e) => this.error.set(toApiError(e)),
    });
  }

  protected statusLabel(s: string): string {
    return label(CARD_STATUS_LABELS, s);
  }
  protected balance(c: Card): string {
    return formatBalance(c.programType, c.balance);
  }
  protected local(v: string): string {
    return formatLocalDateTime(v);
  }
}
