import { ChangeDetectionStrategy, Component, effect, inject, signal } from '@angular/core';
import { ApiError, toApiError } from '../../core/api/api-error';
import { EstablishmentApi } from '../../core/api/establishment-api.service';
import { AuditEvent, Page } from '../../core/models';
import { AlertComponent } from '../../shared/ui/alert.component';
import { AuditTableComponent } from '../../shared/ui/audit-table.component';
import { EmptyStateComponent } from '../../shared/ui/empty-state.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { PagerComponent } from '../../shared/ui/pager.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { EstablishmentContext } from './establishment-context.service';

@Component({
  selector: 'app-establishment-audit-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [AlertComponent, AuditTableComponent, EmptyStateComponent, PageHeaderComponent, PagerComponent, SpinnerComponent],
  template: `
    <app-page-header title="Auditoria" subtitle="Registro permanente das alterações feitas neste estabelecimento. Somente leitura." />
    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (result(); as r) {
      @if (r.content.length === 0) {
        <app-empty-state icon="shield" title="Nenhum evento registrado ainda" description="Alterações de programas, clientes, cartões e configurações aparecem aqui automaticamente." />
      } @else {
        <app-audit-table [events]="r.content" />
        <app-pager [page]="r.page" [totalPages]="r.totalPages" (pageChange)="load($event)" />
      }
    } @else {
      <app-spinner />
    }
  `,
})
export class EstablishmentAuditPage {
  private readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(EstablishmentApi);
  protected readonly result = signal<Page<AuditEvent> | null>(null);
  protected readonly error = signal<ApiError | null>(null);

  constructor() {
    effect(() => {
      if (this.ctx.id() !== null) this.load(0);
    });
  }

  protected load(page: number): void {
    const id = this.ctx.id();
    if (id === null) return;
    this.api.audit(id, page).subscribe({
      next: (r) => this.result.set(r),
      error: (e) => this.error.set(toApiError(e)),
    });
  }
}
