import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, effect, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { toApiError } from '../../core/api/api-error';
import { WalletApi } from '../../core/api/wallet-api.service';
import { WalletIntegrationStatus, WalletPassView, WalletSyncStatus } from '../../core/loyalty-models';
import { Page } from '../../core/models';
import { NotificationService } from '../../core/notifications/notification.service';
import { WALLET_REMOTE_STATE_LABELS, WALLET_SYNC_LABELS, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { EmptyStateComponent } from '../../shared/ui/empty-state.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { PagerComponent } from '../../shared/ui/pager.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';
import { EstablishmentContext } from './establishment-context.service';

@Component({
  selector: 'app-wallet-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe, FormsModule, RouterLink, AlertComponent, EmptyStateComponent, IconComponent, PageHeaderComponent, PagerComponent, StatusBadgeComponent],
  template: `
    <app-page-header title="Carteiras digitais" subtitle="Google Wallet e Apple Wallet: emissão e atualização dos cartões dos seus clientes" />

    @if (status(); as s) {
      <div class="providers">
        <section class="card provider">
          <header class="prov-head">
            <span class="prov-icon"><app-icon name="wallet" [size]="20" /></span>
            <span class="prov-title"><h2>Google Wallet</h2><span class="muted small">Android e navegador</span></span>
            @if (s.configured) {
              <span class="badge dot tone-success">Ativa</span>
            } @else {
              <span class="badge dot tone-warning">Pendente</span>
            }
          </header>
          @if (!s.configured) {
            <app-alert kind="warning">Ainda não disponível. Nada precisa ser feito por você: a ShaminaTech cuida da configuração.</app-alert>
            @if (s.missing.length > 0) {
              <details class="more"><summary>Pendências técnicas ({{ s.missing.length }})</summary>
                <ul>@for (m of s.missing; track m) { <li>{{ m }}</li> }</ul></details>
            }
          }
          <dl class="pass-counts">
            @for (k of statuses; track k) {
              <div [class.alert-row]="k === 'FAILED' && (s.passes[k] ?? 0) > 0">
                <dt>{{ syncLabel(k) }}</dt><dd class="num">{{ s.passes[k] ?? 0 }}</dd>
              </div>
            }
          </dl>
          @if ((s.passes['FAILED'] ?? 0) > 0) {
            <p class="note warn"><app-icon name="alert" [size]="16" />
              <span>Há cartões com falha no envio. Filtre por “Falha no envio” abaixo e use <strong>Reenviar</strong>; se a falha
                continuar, fale com a ShaminaTech informando o cliente e o horário.</span></p>
          }
          @if (s.notes.length > 0) {
            <details class="more"><summary>Como funciona</summary>
              <ul>@for (n of s.notes; track n) { <li>{{ n }}</li> }</ul></details>
          }
        </section>

        <section class="card provider">
          <header class="prov-head">
            <span class="prov-icon"><app-icon name="phone" [size]="20" /></span>
            <span class="prov-title"><h2>Apple Wallet</h2><span class="muted small">iPhone</span></span>
            @if (s.apple.configured) {
              <span class="badge dot tone-info">Configurada</span>
            } @else {
              <span class="badge dot tone-neutral">Não disponível</span>
            }
          </header>
          @if (s.apple.configured) {
            <app-alert kind="info">Certificados configurados. A distribuição aos clientes depende da homologação com a Apple
              (conta Apple Developer e endereço HTTPS público), conduzida pela ShaminaTech.</app-alert>
          } @else {
            <app-alert kind="warning">Ainda não disponível para os seus clientes. Nada precisa ser feito por você: a ShaminaTech
              cuida da configuração.</app-alert>
            @if (s.apple.missing.length > 0) {
              <details class="more"><summary>Pendências técnicas ({{ s.apple.missing.length }})</summary>
                <ul>@for (m of s.apple.missing; track m) { <li>{{ m }}</li> }</ul></details>
            }
          }
          @if (s.apple.notes.length > 0) {
            <details class="more"><summary>Como funciona</summary>
              <ul>@for (n of s.apple.notes; track n) { <li>{{ n }}</li> }</ul></details>
          }
        </section>
      </div>
    }

    <div class="section-head list-head">
      <h2>Cartões enviados às carteiras</h2>
    </div>
    <div class="toolbar">
      <select class="select" [(ngModel)]="filter" (ngModelChange)="load(0)" aria-label="Situação">
        <option value="">Todos os passes</option>
        @for (k of statuses; track k) { <option [value]="k">{{ syncLabel(k) }}</option> }
      </select>
    </div>

    @if (page(); as p) {
      @if (p.content.length === 0) {
        <app-empty-state icon="wallet" [title]="filter ? 'Nenhum cartão nesta situação' : 'Nenhum cartão nas carteiras ainda'"
          [description]="filter ? 'Escolha outra situação no filtro.' : 'O cliente recebe o link ao se cadastrar pelo QR Code, ou você gera o link na página do cartão.'" />
      } @else {
        <div class="table-wrap">
          <table class="table responsive">
            <thead><tr><th>Cliente</th><th>Carteira</th><th>Programa</th><th>Sincronização</th><th>Na carteira</th><th>Última confirmação</th><th><span class="sr-only">Ações</span></th></tr></thead>
            <tbody>
              @for (w of p.content; track w.id) {
                <tr>
                  <td data-label="Cliente"><a [routerLink]="[ctx.base() + '/cartoes', w.cardId]">{{ w.consumerName }}</a><br /><span class="muted mono">{{ w.cardCode }}</span></td>
                  <td data-label="Carteira">{{ w.provider === 'APPLE_WALLET' ? 'Apple Wallet' : 'Google Wallet' }}</td>
                  <td data-label="Programa">{{ w.programName }}</td>
                  <td data-label="Sincronização"><app-badge [value]="w.status" [labelText]="syncLabel(w.status)" />
                    @if (w.lastError && w.status === 'FAILED') { <br /><span class="error-text small">{{ w.lastError }}</span> }</td>
                  <td data-label="Na carteira">{{ w.remoteState ? remoteLabel(w.remoteState) : '—' }}</td>
                  <td data-label="Última confirmação">{{ w.lastSyncedAt ? (w.lastSyncedAt | date: 'dd/MM/yyyy HH:mm') : '—' }}</td>
                  <td class="cell-actions">
                    @if (w.retryAllowed && ctx.can('CARDS_MANAGE')) {
                      <button class="btn btn-sm" type="button" (click)="retry(w)"><app-icon name="refresh" [size]="16" /> Reenviar</button>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
        <app-pager [page]="p.page" [totalPages]="p.totalPages" (pageChange)="load($event)" />
      }
    }
  `,
  styles: `
    .providers {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(min(100%, 340px), 1fr));
      gap: 1rem;
      align-items: start;
      margin-bottom: 1.5rem;
    }
    .provider {
      display: grid;
      gap: 0.85rem;
    }
    .prov-head {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }
    .prov-head h2 {
      margin: 0;
    }
    .prov-title {
      display: grid;
      flex: 1;
      line-height: 1.3;
    }
    .prov-icon {
      display: grid;
      place-items: center;
      width: 40px;
      height: 40px;
      border-radius: 10px;
      background: var(--surface-muted);
      color: var(--text-muted);
    }
    .pass-counts {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(110px, 1fr));
      gap: 0.5rem;
      margin: 0;
    }
    .pass-counts div {
      padding: 0.6rem 0.75rem;
      border-radius: var(--radius-sm);
      background: var(--surface-muted);
    }
    .pass-counts .alert-row {
      background: var(--danger-soft);
      color: var(--danger);
    }
    .pass-counts dt {
      font-size: var(--text-xs);
      color: inherit;
      opacity: 0.85;
    }
    .pass-counts dd {
      margin: 0;
      font-size: var(--text-lg);
      font-weight: 700;
    }
    .more summary {
      cursor: pointer;
      font-weight: 600;
      font-size: var(--text-sm);
    }
    ul {
      margin: 0.4rem 0 0;
      padding-left: 1.1rem;
    }
    .more li {
      color: var(--text-muted);
      font-size: var(--text-sm);
    }
    .error-text {
      color: var(--danger);
    }
    .list-head {
      margin-top: 0.5rem;
    }
  `,
})
export class WalletPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(WalletApi);
  private readonly notifications = inject(NotificationService);
  protected readonly statuses: WalletSyncStatus[] = ['SYNCED', 'PENDING', 'SYNCING', 'FAILED', 'INVALIDATED'];
  protected readonly status = signal<WalletIntegrationStatus | null>(null);
  protected readonly page = signal<Page<WalletPassView> | null>(null);
  protected filter: WalletSyncStatus | '' = '';

  constructor() {
    effect(() => {
      const id = this.ctx.id();
      if (id === null) return;
      this.api.status(id).subscribe((s) => this.status.set(s));
      this.load(0);
    });
  }

  protected load(page: number): void {
    const id = this.ctx.id();
    if (id === null) return;
    this.api.passes(id, this.filter, page).subscribe((p) => this.page.set(p));
  }

  protected retry(w: WalletPassView): void {
    const id = this.ctx.id();
    if (id === null) return;
    this.api.retry(id, w.id).subscribe({
      next: () => {
        this.notifications.success('Reenvio solicitado.');
        setTimeout(() => this.load(this.page()?.page ?? 0), 2500);
      },
      error: (e) => this.notifications.error(toApiError(e).message),
    });
  }

  protected syncLabel(s: string): string {
    return label(WALLET_SYNC_LABELS, s);
  }

  protected remoteLabel(s: string): string {
    return label(WALLET_REMOTE_STATE_LABELS, s);
  }
}
