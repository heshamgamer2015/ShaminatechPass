import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { EstablishmentPlanView } from '../../core/api/plan-api.service';
import { EstablishmentContext } from './establishment-context.service';
import { PlanPage } from './plan.page';

const GROWTH: EstablishmentPlanView = {
  code: 'GROWTH', name: 'Growth', listPriceCents: 5900, trialFree: true, accessStatus: 'ACTIVE', origin: 'SELF_SIGNUP',
  since: '2026-11-25T12:00:00Z', trialMessage: 'Fase de testes: o uso é gratuito e nenhuma cobrança é feita.',
  limits: { maxActiveConsumers: 150, maxPrograms: 2, maxProgramTypes: 2 },
  usage: { activeConsumers: 12, programs: 1, typesInUse: ['POINTS'] },
  allowedTypes: ['POINTS', 'CASHBACK', 'STAMPS', 'VIP'],
};

describe('PlanPage', () => {
  async function setup(view: EstablishmentPlanView, bemvindo?: string) {
    const ctx = { id: signal(1), base: signal('/e/1'), panel: signal({ id: 1, name: 'Café' }), can: () => true };
    await TestBed.configureTestingModule({
      imports: [PlanPage],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting(), { provide: EstablishmentContext, useValue: ctx }],
    }).compileComponents();
    const fixture = TestBed.createComponent(PlanPage);
    if (bemvindo) fixture.componentRef.setInput('bemvindo', bemvindo);
    await fixture.whenStable();
    TestBed.inject(HttpTestingController).expectOne('/api/establishments/1/plan').flush(view);
    await fixture.whenStable();
    return fixture.nativeElement as HTMLElement;
  }

  it('mostra plano, condição de testes sem cobrança, limites, uso e o próximo passo', async () => {
    const el = await setup(GROWTH, '1');
    expect(el.textContent).toContain('Conta criada!');
    expect(el.textContent).toContain('Growth');
    expect(el.textContent).toContain('R$ 59/mês (preço comercial previsto)');
    expect(el.textContent).toContain('Grátis na fase de testes');
    expect(el.textContent).toContain('nenhuma cobrança');
    expect(el.textContent).toContain('12 / 150');
    expect(el.textContent).toContain('1 / 2');
    expect(el.querySelector('a[href="/e/1/programas/novo"]')).not.toBeNull();
  });

  it('Pro aparece como ilimitado e estabelecimento manual como definido pela ShaminaTech', async () => {
    const pro = await setup({ ...GROWTH, code: 'PRO', name: 'Pro', listPriceCents: 12900,
      limits: { maxActiveConsumers: null, maxPrograms: null, maxProgramTypes: 4 } });
    expect(pro.textContent).toContain('/ ilimitado');
    expect(pro.querySelector('.pl-bar')).toBeNull();
    TestBed.resetTestingModule();
    const manual = await setup({ ...GROWTH, code: null, name: null, listPriceCents: null, trialFree: false, trialMessage: null,
      origin: null, since: null, limits: { maxActiveConsumers: 100, maxPrograms: null, maxProgramTypes: null } });
    expect(manual.textContent).toContain('Personalizado pela ShaminaTech');
    expect(manual.textContent).not.toContain('Grátis na fase de testes');
  });
});
