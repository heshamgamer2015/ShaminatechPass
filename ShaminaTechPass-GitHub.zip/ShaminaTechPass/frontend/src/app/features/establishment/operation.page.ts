import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, ElementRef, OnDestroy, effect, inject, signal, viewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import { Card, CardDetail, Channel, Consumer, OperationResult, Transaction } from '../../core/loyalty-models';
import { NotificationService } from '../../core/notifications/notification.service';
import {
  CARD_STATUS_LABELS,
  PROGRAM_TYPE_LABELS,
  TRANSACTION_LABELS,
  formatBalance,
  formatLocalDateTime,
  formatMoney,
  formatPhone,
  label,
} from '../../shared/labels';
import { CAMERA_PROBLEM_MESSAGES, CameraProblem, QrScanner, classifyScan } from '../../shared/qr-scanner';
import { AlertComponent } from '../../shared/ui/alert.component';
import { CardPreviewComponent } from '../../shared/ui/card-preview.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';
import { CardOperationComponent } from './card-operation.component';
import { EstablishmentContext } from './establishment-context.service';

/**
 * Registro rápido. Dois modos de identificação:
 * - Manual: pesquisar o cliente e escolher o cartão.
 * - Leitura: ler o QR Code/código de barras (leitor USB, digitação ou câmera, quando o navegador suporta).
 * Em ambos os casos o cartão só é identificado; a concessão exige a confirmação da empresa.
 */
@Component({
  selector: 'app-operation-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe, FormsModule, RouterLink, AlertComponent, CardPreviewComponent, IconComponent, PageHeaderComponent, StatusBadgeComponent, CardOperationComponent],
  template: `
    <app-page-header title="Registrar compra" subtitle="Identifique o cliente, confira o cartão e confirme a operação" />

    @if (!selected()) {
      <div class="segmented modes" role="group" aria-label="Como identificar o cliente">
        <button type="button" [attr.aria-pressed]="mode() === 'scan'" (click)="mode.set('scan')">
          <app-icon name="scan" /> Ler código do cartão</button>
        <button type="button" [attr.aria-pressed]="mode() === 'manual'" (click)="setManual()">
          <app-icon name="search" /> Pesquisar cliente</button>
      </div>

      @if (mode() === 'scan') {
        <section class="card">
          <form class="form" (ngSubmit)="lookup()">
            <div class="field">
              <label for="code">Código do cartão</label>
              <input #codeInput id="code" class="input big mono" name="code" [(ngModel)]="code" autocomplete="off"
                     placeholder="XXXX-XXXX-XXXX-XXXX" />
              <span class="hint">Use um leitor de código (ele digita e confirma sozinho) ou digite o código impresso no cartão.</span>
            </div>
            <div class="actions">
              <button class="btn btn-primary" type="submit" [disabled]="!code.trim() || looking()">
                <app-icon name="search" /> {{ looking() ? 'Buscando…' : 'Buscar cartão' }}</button>
              <button class="btn" type="button" (click)="toggleCamera()" [disabled]="starting()">
                <app-icon [name]="scanning() ? 'x' : 'camera'" />
                {{ scanning() ? 'Parar câmera' : (starting() ? 'Abrindo câmera…' : 'Usar câmera') }}</button>
            </div>
          </form>
          <video #video class="camera" [class.hidden]="!scanning()" autoplay playsinline muted aria-label="Imagem da câmera"></video>
          @if (scanning()) {
            <p class="muted small">Aponte para o QR Code do cartão do cliente (na carteira do celular ou impresso).</p>
          }
          @if (cameraProblem(); as m) {
            <app-alert kind="warning">{{ m }}</app-alert>
          }
        </section>
      } @else {
        <section class="card">
          <form class="toolbar" (ngSubmit)="search()">
            <input #searchInput class="input input-lg" type="search" name="q" [(ngModel)]="q" placeholder="Nome ou telefone do cliente"
                   aria-label="Pesquisar cliente" />
            <button class="btn btn-primary btn-lg" type="submit"><app-icon name="search" /> Pesquisar</button>
          </form>
          @for (c of consumers(); track c.id) {
            <button type="button" class="pick" (click)="pickConsumer(c)">
              <strong>{{ c.fullName }}</strong>
              <span class="muted">{{ phone(c.phone) }} · {{ c.activeCards }} cartão(ões) ativo(s)</span>
              <app-icon class="go" name="chevron-right" />
            </button>
          } @empty {
            @if (searched()) {
              <p class="muted">Nenhum cliente encontrado. <a [routerLink]="ctx.base() + '/clientes'" [queryParams]="{ novo: 1 }">Cadastrar cliente</a></p>
            }
          }
          @if (consumerCards(); as cards) {
            <h3>Cartões de {{ pickedName() }}</h3>
            @for (card of cards; track card.id) {
              <button type="button" class="pick" (click)="pickCard(card)">
                <strong>{{ card.programName }}</strong>
                <span class="muted">{{ typeLabel(card.programType) }} · {{ balance(card) }}</span>
                <app-badge [value]="card.status" [labelText]="cardStatus(card.status)" />
              </button>
            } @empty {
              <p class="muted">Este cliente ainda não tem cartões. Emita um na página do cliente.</p>
            }
          }
        </section>
      }
      @if (lookupError()) {
        <app-alert kind="error">{{ lookupError() }}</app-alert>
      }
    } @else {
      @let d = selected()!;
      <div class="grid op">
        <section class="card">
          <div class="who">
            <span class="avatar" aria-hidden="true">{{ d.card.consumerName.charAt(0) }}</span>
            <div class="who-text">
              <h2>{{ d.card.consumerName }}</h2>
              <p class="muted">{{ d.card.programName }} · cartão <span class="mono">{{ d.card.displayCode }}</span></p>
            </div>
            <button class="btn btn-sm" type="button" (click)="reset()"><app-icon name="refresh" [size]="16" /> Trocar cliente</button>
          </div>
          <div class="balance">
            <span class="muted small">Saldo disponível</span>
            <strong class="num">{{ balance(d.card, d.card.availableBalance) }}</strong>
          </div>
          <dl class="details">
            <dt>Situação</dt><dd><app-badge [value]="d.card.status" [labelText]="cardStatus(d.card.status)" /></dd>
            <dt>Válido até</dt><dd>{{ validUntil(d.card) }}</dd>
            <dt>Identificado por</dt><dd>{{ channel() === 'QR_CODE' ? 'Leitura do código' : 'Pesquisa manual' }}</dd>
          </dl>
          <p class="muted small">Identificar o cartão não concede nada: confira os dados e confirme a operação abaixo.</p>
          @if (last(); as r) {
            <app-alert [kind]="r.replayed ? 'info' : 'success'">
              {{ r.replayed ? 'Esta operação já tinha sido registrada; nada foi duplicado.' : 'Operação registrada.' }}
              Novo saldo: {{ balance(r.card, r.card.balance) }}.
            </app-alert>
          }
          <app-card-operation [establishmentId]="ctx.id()!" [detail]="d" [channel]="channel()" (done)="onDone($event)" />
        </section>
        <section class="preview">
          <app-card-preview [design]="d.design" [programName]="d.card.programName" [establishmentName]="ctx.panel()?.name ?? ''"
                            [type]="d.card.programType" [balance]="d.card.availableBalance" [stampsRequired]="d.card.stampsRequired"
                            [code]="d.card.displayCode" [holder]="d.card.consumerName" />
          <section class="card recent">
            <h3>Últimas movimentações</h3>
            @for (t of recent(); track t.id) {
              <div class="tx">
                <span>{{ txLabel(t.type) }}@if (t.reversed) { <span class="muted"> (estornada)</span> }</span>
                <strong [class.neg]="t.amount < 0">{{ t.amount > 0 ? '+' : '' }}{{ balance(d.card, t.amount) }}</strong>
                <small class="muted">{{ t.occurredAt | date: 'dd/MM/yyyy HH:mm' }}@if (t.purchaseAmount) { · compra informada {{ money(t.purchaseAmount) }} }</small>
              </div>
            } @empty {
              <p class="muted small">Nenhuma movimentação ainda.</p>
            }
            <a class="btn btn-sm" [routerLink]="[ctx.base() + '/cartoes', d.card.id]">Ver histórico completo</a>
          </section>
        </section>
      </div>
    }
  `,
  styles: `
    .modes {
      margin-bottom: 1rem;
    }
    .modes button {
      min-height: 40px;
      padding: 0 1rem;
    }
    .big {
      font-size: 1.35rem;
      min-height: 54px;
      letter-spacing: 0.05em;
    }
    .camera {
      width: 100%;
      max-width: 420px;
      margin-top: 1rem;
      border-radius: var(--radius);
      background: #000;
    }
    .hidden {
      display: none;
    }
    .recent {
      width: 100%;
      display: grid;
      gap: 0.4rem;
    }
    .recent h3 {
      margin: 0;
      font-size: 1rem;
    }
    .tx {
      display: grid;
      grid-template-columns: 1fr auto;
      gap: 0 0.75rem;
      padding: 0.4rem 0;
      border-bottom: 1px solid var(--border);
    }
    .tx small {
      grid-column: 1 / -1;
    }
    .neg {
      color: var(--danger);
    }
    .pick {
      display: grid;
      grid-template-columns: 1fr auto;
      gap: 0.15rem 1rem;
      width: 100%;
      text-align: left;
      padding: 0.75rem;
      margin-top: 0.5rem;
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
      background: var(--surface);
      font: inherit;
      cursor: pointer;
    }
    .pick:hover {
      border-color: var(--primary);
      background: var(--primary-soft);
    }
    .pick .muted {
      grid-column: 1;
    }
    .pick .go {
      grid-column: 2;
      grid-row: 1 / span 2;
      align-self: center;
      color: var(--text-subtle);
    }
    .op {
      grid-template-columns: minmax(0, 1.4fr) minmax(0, 1fr);
      align-items: start;
    }
    @media (max-width: 900px) {
      .op {
        grid-template-columns: 1fr;
      }
    }
    .who {
      display: flex;
      gap: 0.85rem;
      align-items: center;
    }
    .who-text {
      flex: 1;
      min-width: 0;
    }
    .who h2 {
      margin: 0;
      font-size: var(--text-lg);
    }
    .who p {
      margin: 0;
    }
    .avatar {
      display: grid;
      place-items: center;
      width: 44px;
      height: 44px;
      flex: none;
      border-radius: 50%;
      background: var(--primary-soft-strong);
      color: var(--primary-ink);
      font-weight: 750;
      font-size: var(--text-lg);
      text-transform: uppercase;
    }
    .balance {
      display: grid;
      margin: 1rem 0 0.75rem;
      padding: 0.85rem 1rem;
      border-radius: var(--radius-sm);
      background: var(--surface-muted);
    }
    .balance strong {
      font-size: var(--text-2xl);
      line-height: 1.2;
      letter-spacing: -0.02em;
    }
    .preview {
      display: grid;
      gap: 0.75rem;
      justify-items: center;
    }
    app-alert {
      display: block;
      margin: 0.75rem 0;
    }
  `,
})
export class OperationPage implements OnDestroy {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(LoyaltyApi);
  private readonly notifications = inject(NotificationService);
  private readonly video = viewChild<ElementRef<HTMLVideoElement>>('video');
  private readonly codeInput = viewChild<ElementRef<HTMLInputElement>>('codeInput');
  private readonly searchInput = viewChild<ElementRef<HTMLInputElement>>('searchInput');

  protected readonly mode = signal<'scan' | 'manual'>('scan');
  protected readonly selected = signal<CardDetail | null>(null);
  protected readonly channel = signal<Channel>('MANUAL');
  protected readonly lookupError = signal<string | null>(null);
  protected readonly consumers = signal<Consumer[]>([]);
  protected readonly searched = signal(false);
  protected readonly consumerCards = signal<Card[] | null>(null);
  protected readonly pickedName = signal('');
  protected readonly last = signal<OperationResult | null>(null);
  protected readonly scanning = signal(false);
  protected readonly starting = signal(false);
  protected readonly looking = signal(false);
  protected readonly cameraProblem = signal<string | null>(null);
  protected readonly recent = signal<Transaction[]>([]);
  protected code = '';
  protected q = '';
  private readonly scanner = new QrScanner();
  private lastScan = { text: '', at: 0 };

  constructor() {
    // Balcão: o cursor vai sempre para o campo do modo escolhido — ao abrir a tela, ao trocar de modo e ao
    // voltar de "Trocar cliente" —, para o leitor de código ou a digitação funcionarem sem clique extra.
    effect(() => {
      if (this.selected()) return;
      const field = this.mode() === 'scan' ? this.codeInput() : this.searchInput();
      field?.nativeElement.focus();
    });
  }

  ngOnDestroy(): void {
    this.stopCamera();
  }

  protected setManual(): void {
    this.stopCamera();
    this.mode.set('manual');
  }

  /** Busca o cartão pelo código lido/digitado. Só identifica: nenhuma concessão acontece aqui. */
  protected lookup(raw = this.code): void {
    const eid = this.ctx.id();
    if (eid === null || !raw.trim() || this.looking()) return;
    const scan = classifyScan(raw);
    if (scan.kind !== 'CARD') {
      this.lookupError.set(
        scan.kind === 'SIGNUP_QR'
          ? 'Este é o QR Code de cadastro do balcão, não o cartão de um cliente. Leia o código do cartão do cliente.'
          : scan.kind === 'WALLET_LINK'
            ? 'Este é o link para adicionar o cartão à carteira. Leia o QR Code exibido no cartão do cliente.'
            : 'O código lido não é de um cartão do ShaminaTech Pass. Confira e tente de novo.',
      );
      return;
    }
    this.lookupError.set(null);
    this.looking.set(true);
    this.api.lookup(eid, scan.code!).subscribe({
      next: (d) => {
        this.looking.set(false);
        this.stopCamera();
        this.channel.set('QR_CODE');
        this.last.set(null);
        this.show(d);
      },
      error: (e) => {
        this.looking.set(false);
        this.lookupError.set(toApiError(e).message);
      },
    });
  }

  private show(d: CardDetail): void {
    this.selected.set(d);
    const eid = this.ctx.id();
    if (eid === null) return;
    this.api.cardHistory(eid, d.card.id, 0).subscribe({
      next: (h) => this.recent.set(h.content.slice(0, 5)),
      error: () => this.recent.set([]),
    });
  }

  protected search(): void {
    const eid = this.ctx.id();
    if (eid === null) return;
    this.consumerCards.set(null);
    this.api.consumers(eid, this.q, 'ACTIVE', 0).subscribe({
      next: (p) => {
        this.consumers.set(p.content);
        this.searched.set(true);
      },
      error: (e) => this.lookupError.set(toApiError(e).message),
    });
  }

  protected pickConsumer(c: Consumer): void {
    const eid = this.ctx.id();
    if (eid === null) return;
    this.pickedName.set(c.fullName);
    this.api.consumer(eid, c.id).subscribe((d) => {
      this.consumerCards.set(d.cards);
      const active = d.cards.filter((card) => card.status === 'ACTIVE');
      if (active.length === 1) this.pickCard(active[0]);
    });
  }

  protected pickCard(card: Card): void {
    const eid = this.ctx.id();
    if (eid === null) return;
    this.api.card(eid, card.id).subscribe((d) => {
      this.channel.set('MANUAL');
      this.last.set(null);
      this.show(d);
    });
  }

  protected onDone(result: OperationResult): void {
    this.last.set(result);
    this.notifications.success(result.replayed ? 'Operação já registrada anteriormente.' : 'Operação registrada.');
    const eid = this.ctx.id();
    if (eid !== null) this.api.card(eid, result.card.id).subscribe((d) => this.show(d));
  }

  protected reset(): void {
    this.selected.set(null);
    this.last.set(null);
    this.recent.set([]);
    this.code = '';
    this.consumerCards.set(null);
  }

  protected async toggleCamera(): Promise<void> {
    if (this.scanning()) {
      this.stopCamera();
      return;
    }
    const el = this.video()?.nativeElement;
    if (!el) return;
    this.cameraProblem.set(null);
    this.lookupError.set(null);
    this.starting.set(true);
    try {
      await this.scanner.start(el, (text) => this.onScan(text));
      this.scanning.set(true);
    } catch (problem) {
      this.cameraProblem.set(CAMERA_PROBLEM_MESSAGES[problem as CameraProblem] ?? CAMERA_PROBLEM_MESSAGES.FAILED);
    } finally {
      this.starting.set(false);
    }
  }

  /** Ignora a mesma leitura repetida por 3 s (a câmera lê o mesmo código várias vezes por segundo). */
  private onScan(text: string): void {
    const now = Date.now();
    if (text === this.lastScan.text && now - this.lastScan.at < 3000) return;
    this.lastScan = { text, at: now };
    this.code = text;
    this.lookup(text);
  }

  private stopCamera(): void {
    this.scanner.stop();
    this.scanning.set(false);
  }

  protected phone(v: string): string {
    return formatPhone(v);
  }
  protected typeLabel(t: string): string {
    return label(PROGRAM_TYPE_LABELS, t);
  }
  protected cardStatus(s: string): string {
    return label(CARD_STATUS_LABELS, s);
  }
  protected balance(card: Card, value = card.balance): string {
    return formatBalance(card.programType, value);
  }
  protected txLabel(t: string): string {
    return label(TRANSACTION_LABELS, t);
  }
  protected money(v: number): string {
    return formatMoney(v);
  }
  protected validUntil(card: Card): string {
    return formatLocalDateTime(card.validUntil);
  }
}
