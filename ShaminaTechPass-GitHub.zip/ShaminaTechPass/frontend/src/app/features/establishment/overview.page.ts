import { ChangeDetectionStrategy, Component, effect, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import { NearReward, Overview } from '../../core/loyalty-models';
import { PROGRAM_TYPE_LABELS, formatBalance, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { TransactionTableComponent } from '../../shared/ui/transaction-table.component';
import { EstablishmentContext } from './establishment-context.service';

/**
 * Página inicial do painel: números reais do estabelecimento, atalhos e estados vazios (nunca dados fictícios).
 * Hierarquia: (1) ação de balcão e atalhos; (2) quatro números principais; (3) situação dos cartões;
 * (4) quem está perto da recompensa e benefícios do período; (5) últimas movimentações.
 */
@Component({
  selector: 'app-overview-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, AlertComponent, IconComponent, PageHeaderComponent, TransactionTableComponent],
  template: `
    <app-page-header [title]="ctx.panel()?.name ?? 'Visão geral'" subtitle="Resumo do seu programa de fidelidade">
      @if (ctx.can('CONSUMERS_MANAGE')) {
        <a class="btn" [routerLink]="ctx.base() + '/clientes'" [queryParams]="{ novo: 1 }">
          <app-icon name="plus" /> Cadastrar cliente
        </a>
      }
      @if (ctx.can('TRANSACTIONS_REGISTER')) {
        <a class="btn btn-primary" [routerLink]="ctx.base() + '/operacao'"><app-icon name="scan" /> Registrar compra</a>
      }
    </app-page-header>

    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (data(); as d) {
      @if (d.limitReached) {
        <app-alert kind="warning" class="gap">
          O limite de {{ d.maxActiveConsumers }} clientes ativos foi atingido. Novos cadastros (no balcão e pelo QR Code) ficam
          bloqueados até liberar vagas (desative clientes sem uso) ou até a ShaminaTech ampliar o limite.
        </app-alert>
      }

      @if (d.totalPrograms === 0) {
        <section class="card start">
          <h2>Comece em três passos</h2>
          <ol class="steps">
            <li>
              <span class="step-n">1</span>
              <span><a [routerLink]="ctx.base() + '/programas/novo'">Crie seu programa de fidelidade</a>
                <span class="muted"> — carimbos, pontos ou cashback.</span></span>
            </li>
            <li>
              <span class="step-n">2</span>
              <span>Gere o <a [routerLink]="ctx.base() + '/qr-cadastro'">QR Code de cadastro</a>
                <span class="muted"> e coloque no balcão.</span></span>
            </li>
            <li>
              <span class="step-n">3</span>
              <span>Registre as compras em <a [routerLink]="ctx.base() + '/operacao'">Registrar compra</a>.</span>
            </li>
          </ol>
        </section>
      }

      <section class="stats" aria-label="Números principais">
        <div class="stat">
          <span class="stat-label">Clientes ativos</span>
          <span class="stat-value">{{ d.activeConsumers }}<span class="of"> / {{ d.maxActiveConsumers }}</span></span>
          <div class="meter" role="meter" [attr.aria-valuenow]="d.limitUsedPercent" aria-valuemin="0" aria-valuemax="100"
               [attr.aria-label]="'Limite utilizado: ' + d.limitUsedPercent + '%'">
            <span [style.width.%]="d.limitUsedPercent" [class.warn]="d.limitUsedPercent >= 80 && !d.limitReached"
                  [class.full]="d.limitReached"></span>
          </div>
          <span class="stat-foot">{{ d.limitUsedPercent }}% do limite · {{ d.totalConsumers }} cadastros no total</span>
        </div>
        <div class="stat">
          <span class="stat-label">Cartões ativos</span>
          <span class="stat-value">{{ d.cards.active }}</span>
          <span class="stat-foot">{{ d.activePrograms }} programa(s) ativo(s)</span>
        </div>
        <div class="stat">
          <span class="stat-label">Recompensas resgatadas</span>
          <span class="stat-value">{{ d.rewardsRedeemed }}</span>
          <span class="stat-foot">nos últimos {{ d.periodDays }} dias</span>
        </div>
        <div class="stat">
          <span class="stat-label">Cadastros pelo QR Code</span>
          <span class="stat-value">{{ d.selfSignups }}</span>
          <span class="stat-foot">nos últimos {{ d.periodDays }} dias · {{ d.activeSignupLinks }} QR Code(s) ativo(s)</span>
        </div>
      </section>

      <section class="card status-strip" aria-label="Situação dos cartões">
        <h2 class="strip-title">Situação dos cartões</h2>
        <ul class="strip">
          <li><span class="badge dot tone-success">Ativos</span> <strong class="num">{{ d.cards.active }}</strong></li>
          <li><span class="badge dot tone-info">Concluídos</span> <strong class="num">{{ d.cards.completed }}</strong></li>
          <li><span class="badge dot tone-warning">Expirados</span> <strong class="num">{{ d.cards.expired }}</strong>
            <span class="muted small">por inatividade</span></li>
          <li><span class="badge dot tone-warning">Bloqueados</span> <strong class="num">{{ d.cards.suspended }}</strong></li>
          <li><span class="badge dot tone-neutral">Cancelados</span> <strong class="num">{{ d.cards.cancelled }}</strong></li>
        </ul>
        @if (ctx.can('CONSUMERS_VIEW')) {
          <a class="strip-link" [routerLink]="ctx.base() + '/cartoes'">Consultar cartões <app-icon name="chevron-right" [size]="16" /></a>
        }
      </section>

      <div class="grid grid-2 main">
        <section class="card">
          <div class="section-head">
            <h2>Perto da recompensa</h2>
            @if (ctx.can('CONSUMERS_VIEW')) {
              <a [routerLink]="ctx.base() + '/cartoes'">Ver cartões</a>
            }
          </div>
          <p class="muted small">Cartões ativos com pelo menos 80% dos carimbos ou dos pontos da recompensa mais barata.</p>
          <div class="rows">
            @for (n of d.nearReward; track n.cardId) {
              <a class="near" [routerLink]="[ctx.base() + '/cartoes', n.cardId]">
                <span class="who">
                  <strong>{{ n.consumerName }}</strong>
                  <span class="muted small">{{ n.programName }}</span>
                </span>
                <span class="right">
                  @if (n.ready) {
                    <span class="badge tone-success">Pode resgatar</span>
                  } @else {
                    <span class="small">faltam {{ remaining(n) }}</span>
                  }
                  <span class="meter bar" aria-hidden="true"><span [style.width.%]="progress(n)"></span></span>
                </span>
              </a>
            } @empty {
              <p class="muted empty-line">Nenhum cliente perto de uma recompensa no momento.</p>
            }
          </div>
        </section>

        <section class="card">
          <div class="section-head">
            <h2>Benefícios concedidos</h2>
            <span class="muted small">últimos {{ d.periodDays }} dias</span>
          </div>
          @if (d.benefitsGranted.length === 0) {
            <p class="muted empty-line">Nenhuma concessão registrada no período.</p>
          } @else {
            <ul class="benefits">
              @for (b of d.benefitsGranted; track b.type) {
                <li>
                  <span class="muted small">{{ typeLabel(b.type) }}</span>
                  <strong>{{ balance(b.type, b.amount) }}</strong>
                  <span class="muted small">em {{ b.operations }} operação(ões)</span>
                </li>
              }
            </ul>
          }
        </section>
      </div>

      <section class="card">
        <div class="section-head">
          <h2>Movimentações recentes</h2>
          @if (ctx.can('CONSUMERS_VIEW')) {
            <a [routerLink]="ctx.base() + '/movimentacoes'">Ver todas</a>
          }
        </div>
        @if (d.recentTransactions.length === 0) {
          <p class="muted empty-line">Nenhuma movimentação registrada ainda.</p>
        } @else {
          <app-transaction-table [items]="d.recentTransactions" [showCustomer]="true" [base]="ctx.base()" />
        }
      </section>
    } @else {
      <div class="stats" aria-busy="true" aria-label="Carregando números">
        @for (i of skeletons; track i) {
          <div class="stat">
            <span class="skeleton w-55"></span>
            <span class="skeleton big"></span>
            <span class="skeleton w-70"></span>
          </div>
        }
      </div>
    }
  `,
  styles: `
    .gap {
      margin-bottom: 1rem;
    }
    .start {
      margin-bottom: 1rem;
      border-color: color-mix(in srgb, var(--primary) 25%, var(--border));
      background: linear-gradient(0deg, var(--surface), var(--primary-soft));
    }
    .steps {
      list-style: none;
      margin: 0.25rem 0 0;
      padding: 0;
      display: grid;
      gap: 0.6rem;
    }
    .steps li {
      display: flex;
      gap: 0.75rem;
      align-items: baseline;
    }
    .step-n {
      display: inline-grid;
      place-items: center;
      width: 24px;
      height: 24px;
      flex: none;
      border-radius: 50%;
      background: var(--primary);
      color: #fff;
      font-size: var(--text-xs);
      font-weight: 700;
    }
    .of {
      font-size: var(--text-md);
      font-weight: 500;
      color: var(--text-muted);
      letter-spacing: 0;
    }
    .stats .meter {
      margin: 0.35rem 0 0.15rem;
    }
    .skeleton.big {
      height: 2rem;
      width: 40%;
      margin: 0.35rem 0;
    }
    .status-strip {
      margin-top: 1rem;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 0.75rem 1.5rem;
      padding: 0.85rem 1.25rem;
    }
    .strip-title {
      margin: 0;
      font-size: var(--text-sm);
      font-weight: 600;
      color: var(--text-muted);
    }
    .strip {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem 1.25rem;
      flex: 1;
    }
    .strip li {
      display: inline-flex;
      align-items: center;
      gap: 0.4rem;
    }
    .strip-link {
      display: inline-flex;
      align-items: center;
      gap: 0.2rem;
      font-size: var(--text-sm);
      font-weight: 600;
      text-decoration: none;
    }
    .main {
      margin-top: 1rem;
    }
    .rows {
      margin-top: 0.5rem;
    }
    .near {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 1rem;
      padding: 0.7rem 0;
      border-bottom: 1px solid var(--border);
      color: inherit;
      text-decoration: none;
    }
    .near:last-child {
      border-bottom: 0;
    }
    .near:hover strong {
      color: var(--primary-ink);
    }
    .who {
      display: grid;
      min-width: 0;
    }
    .who strong {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .right {
      display: grid;
      justify-items: end;
      gap: 0.35rem;
      white-space: nowrap;
    }
    .bar {
      width: 110px;
    }
    .benefits {
      list-style: none;
      padding: 0;
      margin: 0;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 0.75rem;
    }
    .benefits li {
      display: grid;
      gap: 0.1rem;
      padding: 0.85rem 1rem;
      border-radius: var(--radius-sm);
      background: var(--surface-muted);
    }
    .benefits strong {
      font-size: var(--text-lg);
      font-variant-numeric: tabular-nums;
    }
    .empty-line {
      padding: 1rem 0 0.25rem;
      margin: 0;
    }
  `,
})
export class OverviewPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(LoyaltyApi);
  protected readonly data = signal<Overview | null>(null);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly skeletons = [1, 2, 3, 4];

  constructor() {
    effect(() => {
      const id = this.ctx.id();
      if (id === null) return;
      this.api.overview(id).subscribe({
        next: (d) => this.data.set(d),
        error: (e) => this.error.set(toApiError(e)),
      });
    });
  }

  protected progress(n: NearReward): number {
    return n.target > 0 ? Math.min(100, Math.round((n.available / n.target) * 100)) : 0;
  }

  protected remaining(n: NearReward): string {
    if (n.programType === 'STAMPS') {
      const r = Math.ceil(n.remaining);
      return `${r} carimbo${r === 1 ? '' : 's'}`;
    }
    return `${Math.ceil(n.remaining)} pontos` + (n.rewardName ? ` para ${n.rewardName}` : '');
  }

  protected typeLabel(type: string): string {
    return label(PROGRAM_TYPE_LABELS, type);
  }

  protected balance(type: string, value: number): string {
    return formatBalance(type, value);
  }
}
