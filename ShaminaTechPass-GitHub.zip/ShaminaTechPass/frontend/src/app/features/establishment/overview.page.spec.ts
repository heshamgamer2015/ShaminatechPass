import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { Overview } from '../../core/loyalty-models';
import { EstablishmentContext } from './establishment-context.service';
import { OverviewPage } from './overview.page';

function overview(over: Partial<Overview> = {}): Overview {
  return {
    activeConsumers: 85, totalConsumers: 90, maxActiveConsumers: 100, limitUsedPercent: 85, limitReached: false,
    cards: { active: 70, suspended: 1, expired: 4, completed: 9, cancelled: 2 },
    periodDays: 30, benefitsGranted: [], rewardsRedeemed: 5, recentTransactions: [],
    activePrograms: 2, totalPrograms: 2, activeSignupLinks: 1, selfSignups: 12, nearReward: [],
    ...over,
  };
}

describe('OverviewPage', () => {
  async function setup(data: Overview, perms: string[] = ['TRANSACTIONS_REGISTER', 'CONSUMERS_VIEW', 'CONSUMERS_MANAGE']) {
    const ctx = { id: signal(1), base: signal('/e/1'), panel: signal({ id: 1, name: 'Café Aroma' }), can: (p: string) => perms.includes(p) };
    await TestBed.configureTestingModule({
      imports: [OverviewPage],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting(), { provide: EstablishmentContext, useValue: ctx }],
    }).compileComponents();
    const fixture = TestBed.createComponent(OverviewPage);
    await fixture.whenStable();
    TestBed.inject(HttpTestingController).expectOne('/api/establishments/1/overview').flush(data);
    await fixture.whenStable();
    return fixture.nativeElement as HTMLElement;
  }

  it('mostra os quatro números principais, o uso do limite e a situação dos cartões', async () => {
    const el = await setup(overview());
    const stats = el.querySelectorAll('.stats .stat');
    expect(stats.length).toBe(4);
    expect(stats[0].textContent).toContain('85');
    expect(stats[0].textContent).toContain('/ 100');
    const meter = el.querySelector('[role=meter]')!;
    expect(meter.getAttribute('aria-valuenow')).toBe('85');
    // 80% ou mais: barra em tom de atenção, sem o aviso de limite atingido.
    expect(meter.querySelector('span')!.classList).toContain('warn');
    expect(el.textContent).not.toContain('foi atingido');
    expect(el.querySelector('.status-strip')!.textContent).toContain('Expirados');
    expect(el.querySelector('.status-strip')!.textContent).toContain('4');
  });

  it('avisa quando o limite foi atingido e oferece os três passos sem programas', async () => {
    const el = await setup(overview({ limitReached: true, limitUsedPercent: 100, activeConsumers: 100, totalPrograms: 0, activePrograms: 0 }));
    expect(el.textContent).toContain('O limite de 100 clientes ativos foi atingido');
    expect(el.textContent).toContain('Comece em três passos');
    expect(el.querySelector('[role=meter] span')!.classList).toContain('full');
  });

  it('esconde ações sem permissão', async () => {
    const el = await setup(overview(), []);
    expect(el.textContent).not.toContain('Registrar compra');
    expect(el.textContent).not.toContain('Cadastrar cliente');
    expect(el.textContent).not.toContain('Ver todas');
  });
});
