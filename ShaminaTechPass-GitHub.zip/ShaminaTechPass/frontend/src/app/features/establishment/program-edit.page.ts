import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, input, signal } from '@angular/core';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { FormsModule, NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import {
  ExpiredBalancePolicy,
  Program,
  ProgramPayload,
  ProgramStatus,
  ProgramType,
  ReversalPolicy,
  Reward,
  Rounding,
  StampCriterion,
  ValidityMode,
  VipTier,
} from '../../core/loyalty-models';
import { NotificationService } from '../../core/notifications/notification.service';
import {
  EXPIRED_BALANCE_LABELS,
  PROGRAM_TYPE_HINTS,
  PROGRAM_TYPE_LABELS,
  REVERSAL_LABELS,
  ROUNDING_LABELS,
  STAMP_CRITERION_LABELS,
  VALIDITY_MODE_LABELS,
  label,
  parseMoney,
} from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { FieldErrorComponent } from '../../shared/ui/field-error.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';
import { EstablishmentContext } from './establishment-context.service';

const TYPES: ProgramType[] = ['STAMPS', 'POINTS', 'CASHBACK', 'VIP'];

@Component({
  selector: 'app-program-edit-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe, FormsModule, ReactiveFormsModule, RouterLink, AlertComponent, FieldErrorComponent, IconComponent, PageHeaderComponent, StatusBadgeComponent],
  template: `
    <app-page-header [title]="program() ? program()!.name : 'Novo programa'"
                     [subtitle]="program() ? typeLabel(program()!.type) : 'Escolha o tipo e as regras'"
                     [backLink]="ctx.base() + '/programas'" backLabel="Programas">
      @if (program(); as p) {
        @if (canManage()) {
          <a class="btn" [routerLink]="ctx.base() + '/personalizacao'" [queryParams]="{ programa: p.id }">Personalizar cartão</a>
          @if (p.status === 'ACTIVE') {
            <button class="btn" type="button" (click)="setStatus('PAUSED')">Pausar</button>
          } @else if (p.status === 'PAUSED') {
            <button class="btn" type="button" (click)="setStatus('ACTIVE')">Retomar</button>
          }
          @if (p.status !== 'ARCHIVED') {
            <button class="btn btn-danger" type="button" (click)="setStatus('ARCHIVED')">Encerrar</button>
          }
        }
      }
    </app-page-header>

    @if (program(); as p) {
      <section class="stats summary" aria-label="Situação do programa">
        <div class="stat">
          <span class="stat-label">Situação</span>
          <span><app-badge [value]="p.status" /></span>
          <span class="stat-foot">{{ statusHelp(p.status) }}</span>
        </div>
        <div class="stat">
          <span class="stat-label">Tipo de fidelidade</span>
          <strong class="locked"><app-icon name="lock" [size]="15" /> {{ typeLabel(p.type) }}</strong>
          <span class="stat-foot">Não pode ser alterado depois de criado.</span>
        </div>
        <div class="stat">
          <span class="stat-label">Validade do cartão</span>
          <strong>{{ p.inactivityDays }} dias</strong>
          <span class="stat-foot">sem movimentação</span>
        </div>
        <div class="stat">
          <span class="stat-label">Criado em</span>
          <strong>{{ p.createdAt | date: 'dd/MM/yyyy' }}</strong>
        </div>
      </section>
      @if (!p.typeAllowed) {
        <app-alert kind="warning" class="gap">Este tipo de cartão não está mais habilitado pela ShaminaTech: o programa e os cartões foram preservados, mas não aceitam novas movimentações.</app-alert>
      }
      @if (!p.operational) {
        <app-alert kind="info" class="gap">Níveis VIP: nesta versão você cadastra níveis e benefícios, mas a progressão automática dos clientes ainda não funciona e não há emissão de cartões VIP.</app-alert>
      }
    }

    <form class="card form" [formGroup]="form" (ngSubmit)="save()" novalidate>
      @if (program(); as p) {
        <div class="section-head">
          <h2>Regras do programa</h2>
          @if (form.dirty && p.status !== 'ARCHIVED') {
            <span class="badge dot tone-warning">Alterações não salvas</span>
          }
        </div>
        @if (p.status === 'ARCHIVED') {
          <app-alert kind="info">Programa encerrado: as regras ficam apenas para consulta.</app-alert>
        } @else {
          <p class="note info"><app-icon name="info" [size]="16" />
            <span>Mudanças de regra valem só para as <strong>próximas</strong> movimentações. Saldos, cartões emitidos e o histórico já
              registrado não mudam. O tipo de fidelidade é fixo.</span></p>
        }
      }
      @if (error(); as e) {
        <app-alert kind="error">{{ e.message }}</app-alert>
      }

      @if (!program()) {
        <fieldset>
          <legend>Tipo de programa</legend>
          <div class="types">
            @for (t of types; track t) {
              <label class="type" [class.selected]="form.controls.type.value === t" [class.disabled]="!allowed(t)">
                <input type="radio" formControlName="type" [value]="t" [attr.disabled]="allowed(t) ? null : true" />
                <strong>{{ typeLabel(t) }}</strong>
                <small>{{ hint(t) }}</small>
                @if (!allowed(t)) {
                  <small class="warn">Não habilitado para o seu estabelecimento.</small>
                }
              </label>
            }
          </div>
        </fieldset>
      }

      <div class="form-row">
        <div class="field">
          <label for="name">Nome do programa</label>
          <input id="name" class="input" formControlName="name" maxlength="80" placeholder="Ex.: Cartão Fidelidade Café" />
          <app-field-error [server]="fe('name')" [local]="touchedInvalid('name') ? 'Informe o nome.' : null" />
        </div>
      </div>
      <div class="field">
        <label for="description">Descrição <span class="muted">(opcional)</span></label>
        <textarea id="description" class="input" rows="2" formControlName="description" maxlength="500"></textarea>
      </div>

      @switch (type()) {
        @case ('STAMPS') {
          <fieldset class="form">
            <legend>Carimbos</legend>
            <div class="form-row">
              <div class="field">
                <label for="stampsRequired">Carimbos para completar</label>
                <input id="stampsRequired" class="input" type="number" min="2" max="100" formControlName="stampsRequired" />
                <app-field-error [server]="fe('stampsRequired')" />
              </div>
              <div class="field">
                <label for="stampCriterion">Critério</label>
                <select id="stampCriterion" class="select" formControlName="stampCriterion">
                  @for (c of criteria; track c) { <option [value]="c">{{ criterionLabel(c) }}</option> }
                </select>
              </div>
            </div>
            <div class="field">
              <label for="stampReward">Recompensa do cartão completo</label>
              <input id="stampReward" class="input" formControlName="stampReward" maxlength="200" placeholder="Ex.: Um café grátis" />
              <app-field-error [server]="fe('stampReward')" />
            </div>
            <label><input type="checkbox" formControlName="restartAfterRedeem" /> Recomeçar o cartão após o resgate</label>
            @if (form.controls.stampCriterion.value === 'PURCHASE') {
              <div class="field">
                <label for="minPurchaseAmount">Valor mínimo da compra (R$) <span class="muted">(opcional)</span></label>
                <input id="minPurchaseAmount" class="input" inputmode="decimal" formControlName="minPurchaseAmount" />
              </div>
            }
          </fieldset>
        }
        @case ('POINTS') {
          <fieldset class="form">
            <legend>Pontos</legend>
            <div class="form-row">
              <div class="field">
                <label for="pointsPerUnit">Pontos concedidos</label>
                <input id="pointsPerUnit" class="input" type="number" min="1" formControlName="pointsPerUnit" />
              </div>
              <div class="field">
                <label for="spendUnit">A cada (R$)</label>
                <input id="spendUnit" class="input" inputmode="decimal" formControlName="spendUnit" />
                <app-field-error [server]="fe('spendUnit')" />
              </div>
              <div class="field">
                <label for="rounding">Arredondamento</label>
                <select id="rounding" class="select" formControlName="rounding">
                  @for (r of roundings; track r) { <option [value]="r">{{ roundingLabel(r) }}</option> }
                </select>
              </div>
            </div>
            <div class="field">
              <label for="minPurchaseAmount">Valor mínimo para pontuar (R$) <span class="muted">(opcional)</span></label>
              <input id="minPurchaseAmount" class="input" inputmode="decimal" formControlName="minPurchaseAmount" />
            </div>
            <p class="muted">Exemplo: {{ form.controls.pointsPerUnit.value || 1 }} ponto(s) a cada R$ {{ form.controls.spendUnit.value || '1,00' }}.
              As recompensas são cadastradas depois de salvar o programa.</p>
          </fieldset>
        }
        @case ('CASHBACK') {
          <fieldset class="form">
            <legend>Cashback</legend>
            <app-alert kind="info">Cashback é um saldo promocional para usar no seu estabelecimento. Não há saque nem transferência de dinheiro.</app-alert>
            <div class="form-row">
              <div class="field">
                <label for="cashbackPercent">Percentual (%)</label>
                <input id="cashbackPercent" class="input" inputmode="decimal" formControlName="cashbackPercent" />
                <app-field-error [server]="fe('cashbackPercent')" />
              </div>
              <div class="field">
                <label for="minPurchaseAmount">Compra mínima (R$)</label>
                <input id="minPurchaseAmount" class="input" inputmode="decimal" formControlName="minPurchaseAmount" />
              </div>
              <div class="field">
                <label for="maxCreditPerPurchase">Crédito máximo por compra (R$)</label>
                <input id="maxCreditPerPurchase" class="input" inputmode="decimal" formControlName="maxCreditPerPurchase" />
              </div>
            </div>
            <div class="form-row">
              <div class="field">
                <label for="minRedeemBalance">Saldo mínimo para usar (R$)</label>
                <input id="minRedeemBalance" class="input" inputmode="decimal" formControlName="minRedeemBalance" />
              </div>
              <div class="field">
                <label for="maxRedeemPercent">Máximo da compra pago com cashback (%)</label>
                <input id="maxRedeemPercent" class="input" inputmode="decimal" formControlName="maxRedeemPercent" />
              </div>
              <div class="field">
                <label for="rounding">Arredondamento dos centavos</label>
                <select id="rounding" class="select" formControlName="rounding">
                  @for (r of roundings; track r) { <option [value]="r">{{ roundingLabel(r) }}</option> }
                </select>
              </div>
            </div>
          </fieldset>
        }
      }

      <fieldset class="form">
        <legend>Validade e regras</legend>
        <div class="form-row">
          <div class="field">
            <label for="inactivityDays">Cartão expira após quantos dias sem movimentação</label>
            <input id="inactivityDays" class="input" type="number" min="1" max="3650" formControlName="inactivityDays" />
            <span class="hint">Toda compra ou resgate confirmado renova este prazo. Consultas não renovam.</span>
            <app-field-error [server]="fe('inactivityDays')" />
          </div>
          <div class="field">
            <label for="validityMode">Até quando vale no último dia</label>
            <select id="validityMode" class="select" formControlName="validityMode">
              @for (v of validityModes; track v) { <option [value]="v">{{ validityLabel(v) }}</option> }
            </select>
            <span class="hint">Fuso do estabelecimento: {{ ctx.panel()?.policy?.timeZone }}</span>
          </div>
        </div>
        @if (type() !== 'VIP') {
          <div class="form-row">
            <div class="field">
              <label for="expiredBalancePolicy">Quando o cartão expira, o saldo…</label>
              <select id="expiredBalancePolicy" class="select" formControlName="expiredBalancePolicy">
                @for (v of balancePolicies; track v) { <option [value]="v">{{ balanceLabel(v) }}</option> }
              </select>
            </div>
            <div class="field">
              <label for="reversalPolicy">Estorno de compra já usada pelo cliente</label>
              <select id="reversalPolicy" class="select" formControlName="reversalPolicy">
                @for (v of reversalPolicies; track v) { <option [value]="v">{{ reversalLabel(v) }}</option> }
              </select>
            </div>
            <div class="field">
              <label for="benefitValidityDays">Validade de cada benefício (dias) <span class="muted">(opcional)</span></label>
              <input id="benefitValidityDays" class="input" type="number" min="1" max="3650" formControlName="benefitValidityDays" />
              <span class="hint">Independe da validade do cartão. Vazio = benefícios sem vencimento próprio.</span>
            </div>
          </div>
        }
      </fieldset>

      @if (canManage() && program()?.status !== 'ARCHIVED') {
        <div class="form-footer sticky">
          <button class="btn btn-primary" type="submit" [disabled]="saving() || (!!program() && !form.dirty)">
            {{ saving() ? 'Salvando…' : (program() ? 'Salvar alterações' : 'Criar programa') }}</button>
          @if (program() && form.dirty) {
            <button class="btn btn-ghost" type="button" (click)="discard()" [disabled]="saving()">Descartar alterações</button>
          }
        </div>
      }
    </form>

    @if (program()?.type === 'POINTS') {
      <section class="card">
        <h2>Recompensas</h2>
        <div class="table-wrap">
          <table class="table responsive">
            <thead><tr><th>Recompensa</th><th class="num">Custo</th><th>Situação</th><th><span class="sr-only">Ações</span></th></tr></thead>
            <tbody>
              @for (r of rewards(); track r.id) {
                <tr>
                  <td data-label="Recompensa"><strong>{{ r.name }}</strong><br /><span class="muted">{{ r.description }}</span></td>
                  <td data-label="Custo" class="num">{{ r.cost }} pontos</td>
                  <td data-label="Situação"><app-badge [value]="r.active ? 'ACTIVE' : 'DISABLED'" [labelText]="r.active ? 'Disponível' : 'Desativada'" /></td>
                  <td class="cell-actions">
                    @if (canManage()) {
                      <button class="btn btn-sm" type="button" (click)="toggleReward(r)">{{ r.active ? 'Desativar' : 'Ativar' }}</button>
                    }
                  </td>
                </tr>
              } @empty {
                <tr><td colspan="4" class="muted">Nenhuma recompensa cadastrada.</td></tr>
              }
            </tbody>
          </table>
        </div>
        @if (canManage()) {
          <form class="form-row add" (ngSubmit)="addReward()">
            <input class="input" name="rname" [(ngModel)]="rewardName" placeholder="Nome da recompensa" maxlength="80" aria-label="Nome da recompensa" />
            <input class="input" name="rcost" type="number" min="1" [(ngModel)]="rewardCost" placeholder="Custo em pontos" aria-label="Custo em pontos" />
            <input class="input" name="rdesc" [(ngModel)]="rewardDescription" placeholder="Descrição (opcional)" maxlength="300" aria-label="Descrição" />
            <button class="btn btn-primary" type="submit" [disabled]="!rewardName || !rewardCost">Adicionar</button>
          </form>
        }
      </section>
    }

    @if (program()?.type === 'VIP') {
      <section class="card">
        <h2>Níveis VIP <small class="muted">(cadastro — progressão automática em preparação)</small></h2>
        <div class="table-wrap">
          <table class="table responsive">
            <thead><tr><th>Ordem</th><th>Nível</th><th>Critério</th><th>Benefícios</th></tr></thead>
            <tbody>
              @for (t of tiers(); track t.id) {
                <tr>
                  <td data-label="Ordem">{{ t.rankOrder }}</td>
                  <td data-label="Nível"><strong>{{ t.name }}</strong></td>
                  <td data-label="Critério">
                    {{ t.minSpend ? 'R$ ' + t.minSpend + ' gastos' : '' }} {{ t.minVisits ? t.minVisits + ' visitas' : '' }}
                    {{ t.periodDays ? 'em ' + t.periodDays + ' dias' : '' }}
                    @if (!t.minSpend && !t.minVisits) { <span class="muted">não definido</span> }
                  </td>
                  <td data-label="Benefícios">{{ t.benefits ?? '—' }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
        @if (canManage()) {
          <form class="form-row add" (ngSubmit)="addTier()">
            <input class="input" name="tname" [(ngModel)]="tierName" placeholder="Nome do nível" maxlength="40" aria-label="Nome do nível" />
            <input class="input" name="trank" type="number" min="1" max="20" [(ngModel)]="tierRank" placeholder="Ordem" aria-label="Ordem" />
            <input class="input" name="tspend" type="number" min="0" [(ngModel)]="tierSpend" placeholder="Gasto mínimo (R$)" aria-label="Gasto mínimo" />
            <input class="input" name="tbenefits" [(ngModel)]="tierBenefits" placeholder="Benefícios" maxlength="500" aria-label="Benefícios" />
            <button class="btn btn-primary" type="submit" [disabled]="!tierName || !tierRank">Adicionar nível</button>
          </form>
        }
      </section>
    }
  `,
  styles: `
    .summary {
      margin-bottom: 1rem;
    }
    .locked {
      display: inline-flex;
      align-items: center;
      gap: 0.35rem;
    }
    .gap {
      margin-bottom: 1rem;
    }
    .types {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 0.75rem;
    }
    .type {
      display: grid;
      gap: 0.3rem;
      padding: 0.9rem;
      border: 2px solid var(--border);
      border-radius: var(--radius);
      cursor: pointer;
    }
    .type input {
      justify-self: start;
    }
    .type.selected {
      border-color: var(--primary);
      background: var(--primary-soft);
    }
    .type.disabled {
      opacity: 0.55;
      cursor: not-allowed;
    }
    .warn {
      color: var(--warning);
    }
    .status-line {
      display: grid;
      gap: 0.5rem;
      justify-items: start;
    }
    .add {
      margin-top: 1rem;
      align-items: center;
    }
    textarea.input {
      resize: vertical;
    }
  `,
})
export class ProgramEditPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(LoyaltyApi);
  private readonly router = inject(Router);
  private readonly notifications = inject(NotificationService);
  private readonly dialogs = inject(ConfirmService);

  /** :programId (ausente em /programas/novo). */
  readonly programId = input<string>();

  protected readonly types = TYPES;
  protected readonly criteria: StampCriterion[] = ['VISIT', 'PURCHASE', 'PRODUCT'];
  protected readonly roundings: Rounding[] = ['DOWN', 'HALF_UP', 'UP'];
  protected readonly validityModes: ValidityMode[] = ['END_OF_DAY', 'EXACT_TIME'];
  protected readonly balancePolicies: ExpiredBalancePolicy[] = ['KEEP', 'FORFEIT'];
  protected readonly reversalPolicies: ReversalPolicy[] = ['REQUIRE_BALANCE', 'ALLOW_NEGATIVE'];

  protected readonly program = signal<Program | null>(null);
  protected readonly rewards = signal<Reward[]>([]);
  protected readonly tiers = signal<VipTier[]>([]);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly saving = signal(false);
  protected rewardName = '';
  protected rewardCost: number | null = null;
  protected rewardDescription = '';
  protected tierName = '';
  protected tierRank: number | null = null;
  protected tierSpend: number | null = null;
  protected tierBenefits = '';

  protected readonly form = inject(NonNullableFormBuilder).group({
    type: ['STAMPS' as ProgramType, Validators.required],
    name: ['', [Validators.required, Validators.maxLength(80)]],
    description: [''],
    inactivityDays: [90, [Validators.required, Validators.min(1), Validators.max(3650)]],
    validityMode: ['END_OF_DAY' as ValidityMode],
    expiredBalancePolicy: ['KEEP' as ExpiredBalancePolicy],
    reversalPolicy: ['REQUIRE_BALANCE' as ReversalPolicy],
    benefitValidityDays: [null as number | null],
    minPurchaseAmount: [''],
    rounding: ['DOWN' as Rounding],
    pointsPerUnit: [1 as number | null],
    spendUnit: ['1,00'],
    cashbackPercent: ['5'],
    maxCreditPerPurchase: [''],
    minRedeemBalance: [''],
    maxRedeemPercent: [''],
    stampsRequired: [10 as number | null],
    stampCriterion: ['VISIT' as StampCriterion],
    stampReward: [''],
    restartAfterRedeem: [true],
  });
  private readonly typeValue = signal<ProgramType>('STAMPS');
  protected readonly type = computed(() => this.program()?.type ?? this.typeValue());

  constructor() {
    this.form.controls.type.valueChanges.subscribe((t) => this.typeValue.set(t));
    effect(() => {
      const eid = this.ctx.id();
      const panel = this.ctx.panel();
      if (eid === null || !panel) return;
      const pid = this.programId();
      if (!pid) {
        this.form.controls.inactivityDays.setValue(panel.policy.defaultInactivityDays);
        const first = TYPES.find((t) => panel.policy.allowedProgramTypes.includes(t));
        if (first) this.form.controls.type.setValue(first);
        return;
      }
      this.api.program(eid, Number(pid)).subscribe({
        next: (p) => this.fill(p),
        error: (e) => this.error.set(toApiError(e)),
      });
    });
  }

  private fill(p: Program): void {
    this.program.set(p);
    const money = (v: number | null) => (v == null ? '' : String(v).replace('.', ','));
    this.form.reset({
      type: p.type,
      name: p.name,
      description: p.description ?? '',
      inactivityDays: p.inactivityDays,
      validityMode: p.validityMode,
      expiredBalancePolicy: p.expiredBalancePolicy,
      reversalPolicy: p.reversalPolicy,
      benefitValidityDays: p.benefitValidityDays,
      minPurchaseAmount: money(p.minPurchaseAmount),
      rounding: p.rounding ?? 'DOWN',
      pointsPerUnit: p.pointsPerUnit ?? 1,
      spendUnit: money(p.spendUnit) || '1,00',
      cashbackPercent: money(p.cashbackPercent) || '5',
      maxCreditPerPurchase: money(p.maxCreditPerPurchase),
      minRedeemBalance: money(p.minRedeemBalance),
      maxRedeemPercent: money(p.maxRedeemPercent),
      stampsRequired: p.stampsRequired ?? 10,
      stampCriterion: p.stampCriterion ?? 'VISIT',
      stampReward: p.stampReward ?? '',
      restartAfterRedeem: p.restartAfterRedeem ?? true,
    });
    if (!this.canManage() || p.status === 'ARCHIVED') this.form.disable();
    const eid = this.ctx.id()!;
    if (p.type === 'POINTS') this.api.rewards(eid, p.id).subscribe((r) => this.rewards.set(r));
    if (p.type === 'VIP') this.api.tiers(eid, p.id).subscribe((t) => this.tiers.set(t));
  }

  protected canManage(): boolean {
    return this.ctx.can('PROGRAMS_MANAGE');
  }

  protected allowed(t: ProgramType): boolean {
    return this.ctx.panel()?.policy.allowedProgramTypes.includes(t) ?? false;
  }

  protected fe(field: string): string | undefined {
    return this.error()?.fieldErrors?.[field];
  }

  protected touchedInvalid(name: 'name'): boolean {
    const c = this.form.controls[name];
    return c.touched && c.invalid;
  }

  protected async save(): Promise<void> {
    const eid = this.ctx.id();
    if (eid === null || this.saving()) return;
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    if (
      this.program() &&
      !(await this.dialogs.confirm({
        title: 'Salvar as novas regras?',
        message: 'Elas valem para as próximas movimentações. Saldos, cartões emitidos e histórico já registrados não mudam.',
        confirmLabel: 'Salvar alterações',
      }))
    ) {
      return;
    }
    const v = this.form.getRawValue();
    const money = (s: string) => parseMoney(s);
    const payload: ProgramPayload = {
      type: this.type(),
      name: v.name,
      description: v.description || null,
      inactivityDays: v.inactivityDays,
      validityMode: v.validityMode,
      expiredBalancePolicy: v.expiredBalancePolicy,
      reversalPolicy: v.reversalPolicy,
      benefitValidityDays: v.benefitValidityDays || null,
      minPurchaseAmount: money(v.minPurchaseAmount),
      rounding: v.rounding,
      pointsPerUnit: v.pointsPerUnit,
      spendUnit: money(v.spendUnit),
      cashbackPercent: money(v.cashbackPercent),
      maxCreditPerPurchase: money(v.maxCreditPerPurchase),
      minRedeemBalance: money(v.minRedeemBalance),
      maxRedeemPercent: money(v.maxRedeemPercent),
      stampsRequired: v.stampsRequired,
      stampCriterion: v.stampCriterion,
      stampReward: v.stampReward || null,
      restartAfterRedeem: v.restartAfterRedeem,
    };
    if (Object.values(payload).some((x) => typeof x === 'number' && Number.isNaN(x))) {
      this.error.set({ status: 400, code: 'VALIDATION_ERROR', message: 'Verifique os valores numéricos (use vírgula para centavos).', fieldErrors: {} });
      return;
    }
    this.saving.set(true);
    this.error.set(null);
    const current = this.program();
    const request = current ? this.api.updateProgram(eid, current.id, payload) : this.api.createProgram(eid, payload);
    request.subscribe({
      next: (p) => {
        this.saving.set(false);
        this.notifications.success(current ? 'Programa atualizado.' : 'Programa criado.');
        if (current) this.fill(p);
        else void this.router.navigate([this.ctx.base() + '/programas', p.id]);
      },
      error: (e) => {
        this.saving.set(false);
        this.error.set(toApiError(e));
      },
    });
  }

  protected async setStatus(status: ProgramStatus): Promise<void> {
    const eid = this.ctx.id();
    const p = this.program();
    if (eid === null || !p) return;
    const texts: Record<ProgramStatus, { title: string; message?: string; confirmLabel: string; tone?: 'danger' }> = {
      PAUSED: { title: 'Pausar o programa?', message: 'Impede novas emissões e movimentações até ser retomado.', confirmLabel: 'Pausar' },
      ACTIVE: { title: 'Retomar o programa?', confirmLabel: 'Retomar' },
      ARCHIVED: {
        title: 'Encerrar o programa?',
        message: 'Encerrar é definitivo: cartões e histórico são preservados, mas o programa não poderá ser reaberto.',
        confirmLabel: 'Encerrar',
        tone: 'danger',
      },
    };
    if (!(await this.dialogs.confirm(texts[status]))) return;
    this.api.programStatus(eid, p.id, status).subscribe({
      next: (updated) => {
        this.fill(updated);
        this.notifications.success('Situação do programa alterada.');
      },
      error: (e) => this.notifications.error(toApiError(e).message),
    });
  }

  protected addReward(): void {
    const eid = this.ctx.id();
    const p = this.program();
    if (eid === null || !p || !this.rewardCost) return;
    this.api
      .createReward(eid, p.id, { name: this.rewardName, description: this.rewardDescription || null, cost: this.rewardCost, active: true })
      .subscribe({
        next: (r) => {
          this.rewards.update((list) => [...list, r]);
          this.rewardName = '';
          this.rewardCost = null;
          this.rewardDescription = '';
        },
        error: (e) => this.notifications.error(toApiError(e).message),
      });
  }

  /** Volta o formulário aos valores salvos. */
  protected discard(): void {
    const p = this.program();
    if (p) this.fill(p);
  }

  protected statusHelp(status: ProgramStatus): string {
    return { ACTIVE: 'Aceita emissões e movimentações', PAUSED: 'Sem novas emissões ou movimentações', ARCHIVED: 'Encerrado definitivamente' }[status];
  }

  protected async toggleReward(r: Reward): Promise<void> {
    const eid = this.ctx.id();
    if (eid === null) return;
    if (
      r.active &&
      !(await this.dialogs.confirm({
        title: `Desativar "${r.name}"?`,
        message: 'Clientes deixam de poder resgatar esta recompensa. Os pontos continuam no cartão. Você pode reativar depois.',
        confirmLabel: 'Desativar',
        tone: 'danger',
      }))
    ) {
      return;
    }
    this.api.updateReward(eid, r.id, { name: r.name, description: r.description, cost: r.cost, active: !r.active }).subscribe({
      next: (updated) => this.rewards.update((list) => list.map((x) => (x.id === updated.id ? updated : x))),
      error: (e) => this.notifications.error(toApiError(e).message),
    });
  }

  protected addTier(): void {
    const eid = this.ctx.id();
    const p = this.program();
    if (eid === null || !p || !this.tierRank) return;
    this.api
      .saveTier(eid, p.id, {
        name: this.tierName,
        rankOrder: this.tierRank,
        minSpend: this.tierSpend,
        minVisits: null,
        periodDays: null,
        benefits: this.tierBenefits || null,
      })
      .subscribe({
        next: (t) => {
          this.tiers.update((list) => [...list, t].sort((a, b) => a.rankOrder - b.rankOrder));
          this.tierName = '';
          this.tierRank = null;
          this.tierSpend = null;
          this.tierBenefits = '';
        },
        error: (e) => this.notifications.error(toApiError(e).message),
      });
  }

  protected typeLabel(t: string): string {
    return label(PROGRAM_TYPE_LABELS, t);
  }
  protected hint(t: string): string {
    return label(PROGRAM_TYPE_HINTS, t);
  }
  protected criterionLabel(c: string): string {
    return label(STAMP_CRITERION_LABELS, c);
  }
  protected roundingLabel(r: string): string {
    return label(ROUNDING_LABELS, r);
  }
  protected validityLabel(v: string): string {
    return label(VALIDITY_MODE_LABELS, v);
  }
  protected balanceLabel(v: string): string {
    return label(EXPIRED_BALANCE_LABELS, v);
  }
  protected reversalLabel(v: string): string {
    return label(REVERSAL_LABELS, v);
  }
}
