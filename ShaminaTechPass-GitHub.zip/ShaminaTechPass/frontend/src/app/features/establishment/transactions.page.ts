import { ChangeDetectionStrategy, Component, effect, inject, signal } from '@angular/core';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { FormsModule } from '@angular/forms';
import { ApiError, toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import { Transaction, TransactionType } from '../../core/loyalty-models';
import { Page } from '../../core/models';
import { NotificationService } from '../../core/notifications/notification.service';
import { AlertComponent } from '../../shared/ui/alert.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { PagerComponent } from '../../shared/ui/pager.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { TransactionTableComponent } from '../../shared/ui/transaction-table.component';
import { EstablishmentContext } from './establishment-context.service';
import { askReverse } from './reverse-dialog';

const FILTERS: Record<string, TransactionType[]> = {
  movements: ['EARN', 'REDEEM', 'REVERSAL'],
  earn: ['EARN'],
  redeem: ['REDEEM'],
  reversal: ['REVERSAL'],
  expiration: ['BENEFIT_EXPIRED', 'BALANCE_FORFEITED', 'CARD_EXPIRED'],
  all: [],
};

@Component({
  selector: 'app-transactions-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, AlertComponent, PageHeaderComponent, PagerComponent, SpinnerComponent, TransactionTableComponent],
  template: `
    <app-page-header title="Movimentações" subtitle="Histórico imutável: correções são feitas por estorno" />
    <div class="toolbar">
      <select class="select" [(ngModel)]="filter" (ngModelChange)="load(0)" aria-label="Tipo">
        <option value="movements">Concessões, resgates e estornos</option>
        <option value="earn">Somente concessões</option>
        <option value="redeem">Somente resgates</option>
        <option value="reversal">Somente estornos</option>
        <option value="expiration">Vencimentos e expirações</option>
        <option value="all">Tudo (inclui mudanças de cartão)</option>
      </select>
    </div>
    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (page(); as p) {
      <app-transaction-table [items]="p.content" [showCustomer]="true" [base]="ctx.base()"
                             [canReverse]="ctx.can('TRANSACTIONS_REVERSE')" (reverse)="reverse($event)" />
      <app-pager [page]="p.page" [totalPages]="p.totalPages" (pageChange)="load($event)" />
    } @else {
      <app-spinner />
    }
  `,
})
export class TransactionsPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(LoyaltyApi);
  private readonly notifications = inject(NotificationService);
  private readonly dialogs = inject(ConfirmService);
  protected readonly page = signal<Page<Transaction> | null>(null);
  protected readonly error = signal<ApiError | null>(null);
  protected filter = 'movements';

  constructor() {
    effect(() => {
      if (this.ctx.id() !== null) this.load(0);
    });
  }

  protected load(page: number): void {
    const id = this.ctx.id();
    if (id === null) return;
    this.api.transactions(id, FILTERS[this.filter], page).subscribe({
      next: (p) => {
        this.error.set(null);
        this.page.set(p);
      },
      error: (e) => this.error.set(toApiError(e)),
    });
  }

  protected reverse(t: Transaction): void {
    const id = this.ctx.id();
    if (id === null) return;
    askReverse(this.api, id, t, this.notifications, this.dialogs, () => this.load(this.page()?.page ?? 0));
  }
}
