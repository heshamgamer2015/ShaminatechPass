import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, input, signal } from '@angular/core';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { FormsModule, NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import { ConsumerDetail, Program, Transaction } from '../../core/loyalty-models';
import { Page } from '../../core/models';
import { NotificationService } from '../../core/notifications/notification.service';
import { CARD_STATUS_LABELS, PROGRAM_TYPE_LABELS, formatBalance, formatPhone, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { FieldErrorComponent } from '../../shared/ui/field-error.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { PagerComponent } from '../../shared/ui/pager.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';
import { TransactionTableComponent } from '../../shared/ui/transaction-table.component';
import { EstablishmentContext } from './establishment-context.service';

@Component({
  selector: 'app-consumer-detail-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    DatePipe,
    FormsModule,
    ReactiveFormsModule,
    RouterLink,
    AlertComponent,
    FieldErrorComponent,
    PageHeaderComponent,
    PagerComponent,
    SpinnerComponent,
    StatusBadgeComponent,
    TransactionTableComponent,
  ],
  template: `
    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
      <p><a [routerLink]="ctx.base() + '/clientes'">Voltar para clientes</a></p>
    } @else if (detail(); as d) {
      <app-page-header [title]="d.consumer.fullName" [subtitle]="'Cliente #' + d.consumer.id"
                       [backLink]="ctx.base() + '/clientes'" backLabel="Clientes">
        @if (canManage()) {
          @if (d.consumer.status === 'ACTIVE') {
            <button class="btn btn-danger" type="button" (click)="toggleStatus()">Desativar cadastro</button>
          } @else {
            <button class="btn" type="button" (click)="toggleStatus()">Reativar cadastro</button>
          }
        }
      </app-page-header>

      <div class="grid">
        <section class="card">
          <h2>Cadastro</h2>
          @if (!editing()) {
            <dl class="details">
              <dt>Situação</dt><dd><app-badge [value]="d.consumer.status" /></dd>
              <dt>Telefone</dt><dd>{{ phone(d.consumer.phone) }}</dd>
              <dt>E-mail</dt><dd>{{ d.consumer.email ?? '—' }}</dd>
              <dt>Código interno</dt><dd>{{ d.consumer.externalRef ?? '—' }}</dd>
              <dt>Comunicações</dt><dd>{{ d.consumer.marketingOptIn ? 'Aceita' : 'Não aceita' }}</dd>
              <dt>Ciência LGPD</dt><dd>{{ d.consumer.privacyAcknowledgedAt | date: 'dd/MM/yyyy HH:mm' }}</dd>
              <dt>Cadastrado em</dt><dd>{{ d.consumer.createdAt | date: 'dd/MM/yyyy' }}</dd>
            </dl>
            @if (canManage()) {
              <button class="btn btn-sm" type="button" (click)="startEdit()">Editar dados</button>
            }
          } @else {
            <form class="form" [formGroup]="form" (ngSubmit)="save()" novalidate>
              @if (formError(); as e) {
                <app-alert kind="error">{{ e.message }}</app-alert>
              }
              <div class="field">
                <label for="fullName">Nome</label>
                <input id="fullName" class="input" formControlName="fullName" maxlength="150" />
                <app-field-error [server]="formError()?.fieldErrors?.['fullName']" />
              </div>
              <div class="field">
                <label for="phone">Telefone</label>
                <input id="phone" class="input" type="tel" formControlName="phone" maxlength="25" />
                <app-field-error [server]="formError()?.fieldErrors?.['phone']" />
              </div>
              <div class="field">
                <label for="email">E-mail</label>
                <input id="email" class="input" type="email" formControlName="email" />
                <app-field-error [server]="formError()?.fieldErrors?.['email']" />
              </div>
              <div class="field">
                <label for="externalRef">Código interno</label>
                <input id="externalRef" class="input" formControlName="externalRef" maxlength="40" />
                <app-field-error [server]="formError()?.fieldErrors?.['externalRef']" />
              </div>
              <label><input type="checkbox" formControlName="marketingOptIn" /> Aceita comunicações promocionais</label>
              <div class="actions">
                <button class="btn btn-primary" type="submit">Salvar</button>
                <button class="btn" type="button" (click)="editing.set(false)">Cancelar</button>
              </div>
            </form>
          }
        </section>

        <section class="card">
          <h2>Cartões</h2>
          @if (d.cards.length === 0) {
            <p class="muted">Nenhum cartão emitido.</p>
          }
          <ul class="cards">
            @for (c of d.cards; track c.id) {
              <li>
                <a [routerLink]="[ctx.base() + '/cartoes', c.id]">
                  <strong>{{ c.programName }}</strong>
                  <span class="muted">{{ typeLabel(c.programType) }} · {{ c.displayCode }}</span>
                </a>
                <span>{{ balance(c.programType, c.balance) }}</span>
                <app-badge [value]="c.status" [labelText]="cardStatus(c.status)" />
              </li>
            }
          </ul>
          @if (canIssue() && d.consumer.status === 'ACTIVE') {
            <form class="issue" (ngSubmit)="issue()">
              <label for="program">Emitir cartão</label>
              <div class="input-group">
                <select id="program" class="select" name="program" [(ngModel)]="programId">
                  <option [ngValue]="null">Escolha o programa…</option>
                  @for (p of issuablePrograms(); track p.id) {
                    <option [ngValue]="p.id">{{ p.name }} ({{ typeLabel(p.type) }})</option>
                  }
                </select>
                <button class="btn btn-primary" type="submit" [disabled]="!programId || saving()">Emitir</button>
              </div>
              @if (issuablePrograms().length === 0) {
                <small class="muted">Nenhum programa ativo disponível. Crie um em “Programas de fidelidade”.</small>
              }
            </form>
          }
        </section>
      </div>

      <section class="card">
        <h2>Histórico de fidelidade</h2>
        @if (history(); as h) {
          <app-transaction-table [items]="h.content" />
          <app-pager [page]="h.page" [totalPages]="h.totalPages" (pageChange)="loadHistory($event)" />
        }
      </section>
    } @else {
      <app-spinner />
    }
  `,
  styles: `
    .cards {
      list-style: none;
      padding: 0;
      margin: 0 0 1rem;
      display: grid;
      gap: 0.5rem;
    }
    .cards li {
      display: grid;
      grid-template-columns: 1fr auto auto;
      gap: 0.75rem;
      align-items: center;
      padding: 0.6rem 0.75rem;
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
    }
    .cards a {
      display: grid;
      text-decoration: none;
      color: inherit;
    }
    .issue {
      display: grid;
      gap: 0.35rem;
    }
    .issue label {
      font-weight: 600;
    }
  `,
})
export class ConsumerDetailPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(LoyaltyApi);
  private readonly notifications = inject(NotificationService);
  private readonly dialogs = inject(ConfirmService);

  readonly consumerId = input.required<string>();

  protected readonly detail = signal<ConsumerDetail | null>(null);
  protected readonly history = signal<Page<Transaction> | null>(null);
  protected readonly programs = signal<Program[]>([]);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly formError = signal<ApiError | null>(null);
  protected readonly editing = signal(false);
  protected readonly saving = signal(false);
  protected programId: number | null = null;
  protected readonly issuablePrograms = computed(() =>
    this.programs().filter((p) => p.status === 'ACTIVE' && p.typeAllowed && p.operational),
  );
  protected readonly form = inject(NonNullableFormBuilder).group({
    fullName: ['', Validators.required],
    phone: ['', Validators.required],
    email: [''],
    externalRef: [''],
    marketingOptIn: [false],
  });

  constructor() {
    effect(() => {
      const eid = this.ctx.id();
      const cid = Number(this.consumerId());
      if (eid === null) return;
      this.load(eid, cid);
      this.api.programs(eid).subscribe((p) => this.programs.set(p));
    });
  }

  protected canManage(): boolean {
    return this.ctx.can('CONSUMERS_MANAGE');
  }

  protected canIssue(): boolean {
    return this.ctx.can('CARDS_MANAGE');
  }

  private load(eid: number, cid: number): void {
    this.api.consumer(eid, cid).subscribe({
      next: (d) => this.detail.set(d),
      error: (e) => this.error.set(toApiError(e)),
    });
    this.loadHistory(0);
  }

  protected loadHistory(page: number): void {
    const eid = this.ctx.id();
    if (eid === null) return;
    this.api.consumerHistory(eid, Number(this.consumerId()), page).subscribe((h) => this.history.set(h));
  }

  protected startEdit(): void {
    const c = this.detail()?.consumer;
    if (!c) return;
    this.form.reset({ fullName: c.fullName, phone: c.phone, email: c.email ?? '', externalRef: c.externalRef ?? '', marketingOptIn: c.marketingOptIn });
    this.formError.set(null);
    this.editing.set(true);
  }

  protected save(): void {
    const eid = this.ctx.id();
    const d = this.detail();
    if (eid === null || !d) return;
    const v = this.form.getRawValue();
    this.api
      .updateConsumer(eid, d.consumer.id, { ...v, email: v.email || null, externalRef: v.externalRef || null })
      .subscribe({
        next: (c) => {
          this.detail.set({ ...d, consumer: c });
          this.editing.set(false);
          this.notifications.success('Cadastro atualizado.');
        },
        error: (e) => this.formError.set(toApiError(e)),
      });
  }

  protected async toggleStatus(): Promise<void> {
    const eid = this.ctx.id();
    const d = this.detail();
    if (eid === null || !d) return;
    const next = d.consumer.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    const ok = await this.dialogs.confirm(
      next === 'INACTIVE'
        ? {
            title: 'Desativar o cadastro?',
            message: 'Libera uma vaga do limite. Os cartões ficam sem movimentação enquanto o cadastro estiver inativo.',
            confirmLabel: 'Desativar',
            tone: 'danger',
          }
        : { title: 'Reativar o cadastro?', message: 'Ocupa uma vaga do limite de clientes ativos.', confirmLabel: 'Reativar' },
    );
    if (!ok) return;
    this.api.consumerStatus(eid, d.consumer.id, next).subscribe({
      next: (c) => {
        this.detail.set({ ...d, consumer: c });
        this.notifications.success(next === 'ACTIVE' ? 'Cadastro reativado.' : 'Cadastro desativado.');
      },
      error: (e) => this.notifications.error(toApiError(e).message),
    });
  }

  protected issue(): void {
    const eid = this.ctx.id();
    const d = this.detail();
    if (eid === null || !d || !this.programId) return;
    this.saving.set(true);
    this.api.issueCard(eid, d.consumer.id, this.programId, null).subscribe({
      next: () => {
        this.saving.set(false);
        this.programId = null;
        this.notifications.success('Cartão emitido.');
        this.load(eid, d.consumer.id);
      },
      error: (e) => {
        this.saving.set(false);
        this.notifications.error(toApiError(e).message);
      },
    });
  }

  protected phone(v: string): string {
    return formatPhone(v);
  }

  protected typeLabel(t: string): string {
    return label(PROGRAM_TYPE_LABELS, t);
  }

  protected cardStatus(s: string): string {
    return label(CARD_STATUS_LABELS, s);
  }

  protected balance(t: string, v: number): string {
    return formatBalance(t, v);
  }
}
