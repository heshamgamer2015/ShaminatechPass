import { ChangeDetectionStrategy, Component, computed, effect, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import { Program } from '../../core/loyalty-models';
import { readableTextColor } from '../../shared/color';
import { PROGRAM_TYPE_LABELS, formatMoney, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { EmptyStateComponent } from '../../shared/ui/empty-state.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';
import { EstablishmentContext } from './establishment-context.service';

const TYPE_ICONS: Record<string, string> = { STAMPS: 'check-circle', POINTS: 'star', CASHBACK: 'wallet', VIP: 'shield' };
const STATUS_ORDER: Record<string, number> = { ACTIVE: 0, PAUSED: 1, ARCHIVED: 2 };

/** Lista de programas: tipo, situação e a regra principal visíveis sem abrir cada um. */
@Component({
  selector: 'app-programs-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, AlertComponent, EmptyStateComponent, IconComponent, PageHeaderComponent, StatusBadgeComponent],
  template: `
    <app-page-header title="Programas de fidelidade" subtitle="Defina como seus clientes acumulam e usam benefícios">
      @if (ctx.can('PROGRAMS_MANAGE')) {
        <a class="btn btn-primary" [routerLink]="ctx.base() + '/programas/novo'"><app-icon name="plus" /> Novo programa</a>
      }
    </app-page-header>

    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (sorted(); as list) {
      @if (list.length === 0) {
        <app-empty-state icon="star" title="Nenhum programa ainda" description="Crie seu primeiro programa: carimbos, pontos ou cashback.">
          @if (ctx.can('PROGRAMS_MANAGE')) {
            <a class="btn btn-primary" [routerLink]="ctx.base() + '/programas/novo'"><app-icon name="plus" /> Criar programa</a>
          }
        </app-empty-state>
      } @else {
        <div class="grid programs">
          @for (p of list; track p.id) {
            <a class="card card-flush program" [class.dim]="p.status !== 'ACTIVE'" [routerLink]="[ctx.base() + '/programas', p.id]">
              <span class="band" [style.background]="p.design.brandColor" [style.color]="ink(p)">
                <app-icon [name]="typeIcon(p.type)" [size]="20" />
                <span class="type">{{ typeLabel(p.type) }}</span>
              </span>
              <span class="body">
                <strong class="name">{{ p.name }}</strong>
                <span class="rule">{{ rule(p) }}</span>
                <span class="muted small">Vence após {{ p.inactivityDays }} dias sem movimentação</span>
                <span class="badges">
                  <app-badge [value]="p.status" />
                  @if (!p.typeAllowed) {
                    <app-badge value="SUSPENDED" labelText="Tipo não habilitado" />
                  }
                  @if (!p.operational) {
                    <app-badge value="DISABLED" labelText="Em preparação" />
                  }
                </span>
              </span>
            </a>
          }
        </div>
      }
    } @else {
      <div class="grid programs" aria-busy="true">
        @for (i of [1, 2, 3]; track i) {
          <div class="card"><span class="skeleton w-60"></span><br /><span class="skeleton"></span></div>
        }
      </div>
    }
  `,
  styles: `
    .programs {
      grid-template-columns: repeat(auto-fill, minmax(min(100%, 280px), 1fr));
    }
    .program {
      display: grid;
      grid-template-rows: auto 1fr;
      text-decoration: none;
      color: inherit;
      transition: border-color 0.15s, box-shadow 0.15s;
    }
    .program:hover {
      border-color: var(--border-strong);
      box-shadow: var(--shadow-sm);
      color: inherit;
    }
    .program.dim .band {
      filter: grayscale(0.6);
      opacity: 0.8;
    }
    .band {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.7rem 1rem;
      font-size: var(--text-sm);
      font-weight: 650;
    }
    .body {
      display: grid;
      align-content: start;
      gap: 0.3rem;
      padding: 1rem 1.1rem 1.1rem;
    }
    .name {
      font-size: var(--text-md);
      overflow-wrap: anywhere;
    }
    .rule {
      font-weight: 500;
    }
    .badges {
      display: flex;
      gap: 0.35rem;
      flex-wrap: wrap;
      margin-top: 0.35rem;
    }
  `,
})
export class ProgramsPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(LoyaltyApi);
  protected readonly programs = signal<Program[] | null>(null);
  protected readonly error = signal<ApiError | null>(null);
  /** Ativos primeiro, depois pausados e encerrados; dentro de cada grupo, por nome. */
  protected readonly sorted = computed(() => {
    const list = this.programs();
    if (!list) return null;
    return [...list].sort((a, b) => (STATUS_ORDER[a.status] ?? 9) - (STATUS_ORDER[b.status] ?? 9) || a.name.localeCompare(b.name));
  });

  constructor() {
    effect(() => {
      const id = this.ctx.id();
      if (id === null) return;
      this.api.programs(id).subscribe({ next: (p) => this.programs.set(p), error: (e) => this.error.set(toApiError(e)) });
    });
  }

  protected typeLabel(t: string): string {
    return label(PROGRAM_TYPE_LABELS, t);
  }

  protected typeIcon(t: string): string {
    return TYPE_ICONS[t] ?? 'star';
  }

  protected ink(p: Program): string {
    return readableTextColor(p.design.brandColor, p.design.textColor);
  }

  /** Regra principal em uma linha, só com dados cadastrados. */
  protected rule(p: Program): string {
    switch (p.type) {
      case 'STAMPS':
        return p.stampsRequired ? `${p.stampsRequired} carimbos${p.stampReward ? ' → ' + p.stampReward : ''}` : 'Carimbos';
      case 'POINTS':
        return p.pointsPerUnit && p.spendUnit ? `${p.pointsPerUnit} ponto(s) a cada ${formatMoney(p.spendUnit)}` : 'Pontos por compra';
      case 'CASHBACK':
        return p.cashbackPercent != null ? `${p.cashbackPercent}% de volta em crédito` : 'Cashback';
      default:
        return 'Níveis com benefícios';
    }
  }
}
