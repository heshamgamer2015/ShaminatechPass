import { ChangeDetectionStrategy, Component, effect, inject, input, signal } from '@angular/core';
import { FormsModule, NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import { Consumer, ConsumerStatus } from '../../core/loyalty-models';
import { Page } from '../../core/models';
import { NotificationService } from '../../core/notifications/notification.service';
import { formatPhone } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { EmptyStateComponent } from '../../shared/ui/empty-state.component';
import { FieldErrorComponent } from '../../shared/ui/field-error.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { PagerComponent } from '../../shared/ui/pager.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';
import { EstablishmentContext } from './establishment-context.service';

@Component({
  selector: 'app-consumers-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    RouterLink,
    AlertComponent,
    EmptyStateComponent,
    FieldErrorComponent,
    IconComponent,
    PageHeaderComponent,
    PagerComponent,
    SpinnerComponent,
    StatusBadgeComponent,
  ],
  template: `
    <app-page-header title="Clientes" subtitle="Pesquise por nome, telefone, código do cliente ou código do cartão">
      @if (canManage() && !creating()) {
        <button class="btn btn-primary" type="button" (click)="openForm()"><app-icon name="plus" /> Novo cliente</button>
      }
    </app-page-header>

    @if (creating()) {
      <form class="card form" [formGroup]="form" (ngSubmit)="create()" novalidate>
        <h2>Novo cliente</h2>
        @if (formError(); as e) {
          <app-alert kind="error">{{ e.message }}</app-alert>
        }
        <div class="form-row">
          <div class="field">
            <label for="fullName">Nome</label>
            <input id="fullName" class="input" formControlName="fullName" maxlength="150" autocomplete="off" />
            <app-field-error [server]="fe('fullName')" [local]="invalid('fullName') ? 'Informe o nome.' : null" />
          </div>
          <div class="field">
            <label for="phone">Telefone (com DDD)</label>
            <input id="phone" class="input" type="tel" formControlName="phone" maxlength="25" placeholder="(11) 99999-0000" />
            <app-field-error [server]="fe('phone')" [local]="invalid('phone') ? 'Informe o telefone.' : null" />
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label for="email">E-mail <span class="muted">(opcional)</span></label>
            <input id="email" class="input" type="email" formControlName="email" />
            <app-field-error [server]="fe('email')" [local]="invalid('email') ? 'E-mail inválido.' : null" />
          </div>
          <div class="field">
            <label for="externalRef">Código interno <span class="muted">(opcional)</span></label>
            <input id="externalRef" class="input" formControlName="externalRef" maxlength="40" />
            <app-field-error [server]="fe('externalRef')" />
          </div>
        </div>
        <label class="check">
          <input type="checkbox" formControlName="marketingOptIn" />
          O cliente aceita receber comunicações promocionais.
        </label>
        <label class="check">
          <input type="checkbox" formControlName="privacyAcknowledged" />
          <span>Informei o cliente sobre o programa de fidelidade e sobre o uso dos dados (nome e telefone) para identificá-lo
            no programa. <strong>Obrigatório.</strong></span>
        </label>
        <app-field-error [server]="fe('privacyAcknowledged')"
                         [local]="form.controls.privacyAcknowledged.touched && !form.controls.privacyAcknowledged.value ? 'Confirmação obrigatória.' : null" />
        <div class="actions">
          <button class="btn btn-primary" type="submit" [disabled]="saving()">{{ saving() ? 'Salvando…' : 'Cadastrar' }}</button>
          <button class="btn" type="button" (click)="creating.set(false)">Cancelar</button>
        </div>
      </form>
    }

    <form class="toolbar" (ngSubmit)="search(0)">
      <input class="input" type="search" name="q" [(ngModel)]="q" placeholder="Nome, telefone, #código ou código do cartão"
             aria-label="Pesquisar clientes" />
      <select class="select" name="status" [(ngModel)]="status" (ngModelChange)="search(0)" aria-label="Situação">
        <option value="">Todas as situações</option>
        <option value="ACTIVE">Ativos</option>
        <option value="INACTIVE">Inativos</option>
      </select>
      <button class="btn" type="submit"><app-icon name="search" /> Pesquisar</button>
    </form>

    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (page(); as p) {
      @if (p.content.length === 0) {
        @if (q.trim() || status) {
          <app-empty-state icon="search" title="Nenhum cliente encontrado" description="Confira a grafia, o telefone com DDD ou o código e tente de novo." />
        } @else {
          <app-empty-state icon="users" title="Nenhum cliente ainda"
            description="Cadastre o primeiro cliente aqui ou coloque o QR Code de cadastro no balcão para os clientes se cadastrarem sozinhos." />
        }
      } @else {
        <p class="result-count">{{ p.totalElements }} cliente(s)</p>
        <div class="table-wrap">
          <table class="table responsive">
            <thead><tr><th>Cliente</th><th>Telefone</th><th class="num">Cartões ativos</th><th>Situação</th><th><span class="sr-only">Ações</span></th></tr></thead>
            <tbody>
              @for (c of p.content; track c.id) {
                <tr>
                  <td data-label="Cliente">
                    <a class="person" [routerLink]="[ctx.base() + '/clientes', c.id]">
                      <span class="initial" aria-hidden="true">{{ c.fullName.charAt(0) }}</span>
                      <span class="person-text"><strong>{{ c.fullName }}</strong>
                        <span class="person-sub">#{{ c.id }}{{ c.externalRef ? ' · ' + c.externalRef : '' }}</span></span>
                    </a>
                  </td>
                  <td data-label="Telefone" class="num">{{ phone(c.phone) }}</td>
                  <td data-label="Cartões ativos" class="num">{{ c.activeCards }}</td>
                  <td data-label="Situação"><app-badge [value]="c.status" /></td>
                  <td class="cell-actions"><a class="btn btn-sm" [routerLink]="[ctx.base() + '/clientes', c.id]"
                    [attr.aria-label]="'Abrir ' + c.fullName">Abrir <app-icon name="chevron-right" [size]="16" /></a></td>
                </tr>
              }
            </tbody>
          </table>
        </div>
        <app-pager [page]="p.page" [totalPages]="p.totalPages" (pageChange)="search($event)" />
      }
    } @else {
      <app-spinner />
    }
  `,
  styles: `
    form.card {
      margin-bottom: 1rem;
    }
  `,
})
export class ConsumersPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(LoyaltyApi);
  private readonly router = inject(Router);
  private readonly notifications = inject(NotificationService);

  /** ?novo=1 abre o formulário. */
  readonly novo = input<string>();

  protected q = '';
  protected status: ConsumerStatus | '' = '';
  protected readonly page = signal<Page<Consumer> | null>(null);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly creating = signal(false);
  protected readonly saving = signal(false);
  protected readonly formError = signal<ApiError | null>(null);
  protected readonly form = inject(NonNullableFormBuilder).group({
    fullName: ['', [Validators.required, Validators.maxLength(150)]],
    phone: ['', [Validators.required]],
    email: ['', Validators.email],
    externalRef: [''],
    marketingOptIn: [false],
    privacyAcknowledged: [false, Validators.requiredTrue],
  });

  constructor() {
    effect(() => {
      if (this.ctx.id() !== null) this.search(0);
    });
    effect(() => {
      if (this.novo()) this.openForm();
    });
  }

  protected canManage(): boolean {
    return this.ctx.can('CONSUMERS_MANAGE');
  }

  protected openForm(): void {
    this.form.reset();
    this.formError.set(null);
    this.creating.set(true);
  }

  protected search(page: number): void {
    const id = this.ctx.id();
    if (id === null) return;
    this.api.consumers(id, this.q, this.status, page).subscribe({
      next: (p) => {
        this.error.set(null);
        this.page.set(p);
      },
      error: (e) => this.error.set(toApiError(e)),
    });
  }

  protected fe(field: string): string | undefined {
    return this.formError()?.fieldErrors?.[field];
  }

  protected invalid(name: 'fullName' | 'phone' | 'email'): boolean {
    const c = this.form.controls[name];
    return c.touched && c.invalid;
  }

  protected phone(value: string): string {
    return formatPhone(value);
  }

  protected create(): void {
    const id = this.ctx.id();
    if (id === null) return;
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    this.saving.set(true);
    this.formError.set(null);
    this.api
      .createConsumer(id, {
        fullName: v.fullName,
        phone: v.phone,
        email: v.email || null,
        externalRef: v.externalRef || null,
        marketingOptIn: v.marketingOptIn,
        privacyAcknowledged: v.privacyAcknowledged,
      })
      .subscribe({
        next: (c) => {
          this.saving.set(false);
          this.notifications.success('Cliente cadastrado.');
          void this.router.navigate([this.ctx.base() + '/clientes', c.id]);
        },
        error: (e) => {
          this.saving.set(false);
          this.formError.set(toApiError(e));
        },
      });
  }
}
