import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, effect, inject, signal } from '@angular/core';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { RouterLink } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { SignupApi } from '../../core/api/signup-api.service';
import { ProgramSignup, SignupOverview } from '../../core/loyalty-models';
import { NotificationService } from '../../core/notifications/notification.service';
import { PROGRAM_TYPE_LABELS, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';
import { EstablishmentContext } from './establishment-context.service';

/**
 * QR Code público de cadastro (um por programa): gerar, visualizar, baixar, imprimir, ativar/desativar e trocar.
 * Diferente do código do cartão: este QR Code é o mesmo para todos os consumidores e só abre a página de cadastro.
 */
@Component({
  selector: 'app-signup-qr-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe, RouterLink, AlertComponent, PageHeaderComponent, SpinnerComponent, StatusBadgeComponent],
  template: `
    <app-page-header title="QR Code do programa"
                     subtitle="Um QR Code por programa, para Android e iPhone: o cliente escaneia, se cadastra e guarda o cartão no celular" />

    <app-alert kind="info">
      <strong>Um único QR Code para todos os celulares.</strong> A página identifica o aparelho e destaca o Google Wallet (Android)
      ou a Carteira da Apple (iPhone) — o cliente também pode escolher. O QR Code é permanente: não expira e não muda quando
      você altera o programa ou o logotipo (só muda se você usar “Gerar novo código”). Ele serve para o cadastro e não
      identifica ninguém: para registrar compras, leia o código do cartão em <a [routerLink]="ctx.base() + '/operacao'">Registrar compra</a>.
      Cliente que já participa ou trocou de celular: abra o cartão dele e use “Gerar novo link para o cliente”.
    </app-alert>

    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (data(); as d) {
      @if (d.full) {
        <app-alert kind="warning">
          O limite de {{ d.maxActiveConsumers }} clientes ativos foi atingido. A página de cadastro informa que as inscrições estão
          temporariamente esgotadas (sem mostrar números). Desative clientes sem uso ou fale com a ShaminaTech.
        </app-alert>
      }
      @for (p of d.programs; track p.programId) {
        <section class="card program">
          <div class="head">
            <div>
              <h2>{{ p.programName }}</h2>
              <p class="muted">{{ typeLabel(p.programType) }} · <app-badge [value]="p.programStatus" /></p>
            </div>
            @if (p.link; as l) {
              <app-badge [value]="l.active ? 'ACTIVE' : 'DISABLED'" [labelText]="l.active ? 'QR Code ativo' : 'QR Code desativado'" />
            }
          </div>

          @if (p.issue) {
            <app-alert [kind]="p.eligible ? 'warning' : 'info'">{{ p.issue }}</app-alert>
          }

          @if (p.link; as l) {
            <div class="body">
              <figure class="qr">
                <img [src]="qrSrc(p, 'svg')" [alt]="'QR Code de cadastro do programa ' + p.programName" width="220" height="220" />
              </figure>
              <div class="info">
                <label class="muted small" [attr.for]="'url-' + p.programId">Endereço do cadastro</label>
                <div class="url">
                  <input class="input mono" [id]="'url-' + p.programId" [value]="l.url" readonly (focus)="select($event)" />
                  <button class="btn btn-sm" type="button" (click)="copy(l.url)">Copiar</button>
                </div>
                <dl class="details">
                  <dt>Cadastros por este QR Code</dt><dd>{{ l.signups }}</dd>
                  <dt>Último cadastro</dt><dd>{{ l.lastSignupAt ? (l.lastSignupAt | date: 'dd/MM/yyyy HH:mm') : '—' }}</dd>
                  <dt>Código gerado em</dt><dd>{{ l.tokenCreatedAt | date: 'dd/MM/yyyy HH:mm' }}</dd>
                </dl>
                <div class="actions">
                  <button class="btn btn-primary" type="button" (click)="print(p)">Imprimir</button>
                  <a class="btn" [href]="qrSrc(p, 'png', true)" download>Baixar PNG (impressão)</a>
                  <a class="btn" [href]="qrSrc(p, 'svg', true)" download>Baixar SVG</a>
                  <a class="btn btn-ghost" [href]="l.url" target="_blank" rel="noopener">Prévia da página do cliente</a>
                  @if (canManage()) {
                    <button class="btn" type="button" [disabled]="busy() === p.programId" (click)="toggle(p)">
                      {{ l.active ? 'Desativar' : 'Ativar' }}
                    </button>
                    <button class="btn btn-danger" type="button" [disabled]="busy() === p.programId" (click)="regenerate(p)">Gerar novo código</button>
                  }
                </div>
              </div>
            </div>
          } @else if (p.eligible && canManage()) {
            <button class="btn btn-primary" type="button" [disabled]="busy() === p.programId" (click)="create(p)">
              {{ busy() === p.programId ? 'Gerando…' : 'Gerar QR Code de cadastro' }}
            </button>
          }
        </section>
      } @empty {
        <section class="card">
          <p class="muted">Nenhum programa disponível.
            <a [routerLink]="ctx.base() + '/programas/novo'">Crie um programa de fidelidade</a> para gerar o QR Code.</p>
        </section>
      }
    } @else {
      <app-spinner />
    }
  `,
  styles: `
    .program {
      display: grid;
      gap: 0.75rem;
    }
    .head {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 1rem;
    }
    .head h2 {
      margin: 0;
    }
    .head p {
      margin: 0.2rem 0 0;
    }
    .body {
      display: grid;
      grid-template-columns: auto minmax(0, 1fr);
      gap: 1.25rem;
      align-items: start;
    }
    @media (max-width: 700px) {
      .body {
        grid-template-columns: 1fr;
        justify-items: center;
      }
    }
    .qr {
      margin: 0;
      padding: 0.5rem;
      border: 1px solid var(--border);
      border-radius: var(--radius);
      background: #fff;
    }
    .qr img {
      display: block;
      width: 220px;
      height: 220px;
    }
    .info {
      display: grid;
      gap: 0.6rem;
      width: 100%;
    }
    .url {
      display: flex;
      gap: 0.5rem;
    }
    .url .input {
      flex: 1;
      min-width: 0;
      font-size: 0.85rem;
    }
    .actions {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
    }
  `,
})
export class SignupQrPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(SignupApi);
  private readonly notifications = inject(NotificationService);
  private readonly dialogs = inject(ConfirmService);

  protected readonly data = signal<SignupOverview | null>(null);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly busy = signal<number | null>(null);

  constructor() {
    effect(() => {
      if (this.ctx.id() !== null) this.load();
    });
  }

  private load(): void {
    this.api.overview(this.ctx.id()!).subscribe({
      next: (d) => this.data.set(d),
      error: (e) => this.error.set(toApiError(e)),
    });
  }

  protected canManage(): boolean {
    return this.ctx.can('CONSUMERS_MANAGE');
  }

  protected qrSrc(p: ProgramSignup, format: 'svg' | 'png', download = false): string {
    return this.api.qrUrl(this.ctx.id()!, p.link!.id, format, download, p.link!.tokenCreatedAt);
  }

  protected create(p: ProgramSignup): void {
    this.run(p, this.api.create(this.ctx.id()!, p.programId), 'QR Code gerado.');
  }

  protected async toggle(p: ProgramSignup): Promise<void> {
    const l = p.link!;
    if (
      l.active &&
      !(await this.dialogs.confirm({
        title: 'Desativar o QR Code?',
        message: 'Quem escanear verá que o cadastro está indisponível. Os cadastros já feitos não mudam.',
        confirmLabel: 'Desativar',
        tone: 'danger',
      }))
    ) {
      return;
    }
    this.run(p, this.api.setActive(this.ctx.id()!, l.id, !l.active), l.active ? 'QR Code desativado.' : 'QR Code ativado.');
  }

  protected async regenerate(p: ProgramSignup): Promise<void> {
    if (
      !(await this.dialogs.confirm({
        title: 'Gerar um novo código?',
        message: 'O QR Code impresso atual deixará de funcionar e precisará ser substituído no balcão.',
        confirmLabel: 'Gerar novo código',
        tone: 'danger',
      }))
    ) {
      return;
    }
    this.run(p, this.api.regenerate(this.ctx.id()!, p.link!.id), 'Novo código gerado. Imprima o QR Code novamente.');
  }

  private run(p: ProgramSignup, request: ReturnType<SignupApi['create']>, message: string): void {
    this.busy.set(p.programId);
    request.subscribe({
      next: () => {
        this.busy.set(null);
        this.notifications.success(message);
        this.load();
      },
      error: (e) => {
        this.busy.set(null);
        this.notifications.error(toApiError(e).message);
      },
    });
  }

  protected select(event: Event): void {
    (event.target as HTMLInputElement).select();
  }

  protected copy(url: string): void {
    navigator.clipboard?.writeText(url).then(
      () => this.notifications.success('Endereço copiado.'),
      () => this.notifications.error('Não foi possível copiar; selecione o endereço e copie manualmente.'),
    );
  }

  /** Abre um cartaz simples (nome, instrução e QR Code) e chama a impressão do navegador. */
  protected print(p: ProgramSignup): void {
    const win = window.open('', '_blank', 'width=720,height=900');
    if (!win) {
      this.notifications.error('O navegador bloqueou a janela de impressão. Permita pop-ups ou use "Baixar PNG".');
      return;
    }
    const esc = (v: string) => v.replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
    const establishment = esc(this.ctx.panel()?.name ?? '');
    const program = esc(p.programName);
    const src = esc(new URL(this.qrSrc(p, 'svg'), window.location.origin).toString());
    win.document.write(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>QR Code de cadastro</title>
      <style>
        body{font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;margin:0;color:#0f172a;text-align:center}
        .poster{max-width:560px;margin:32px auto;padding:32px;border:3px solid #F43F5E;border-radius:24px}
        h1{margin:0 0 4px;font-size:28px} h2{margin:0 0 24px;font-weight:500;color:#475569;font-size:20px}
        img{width:340px;height:340px} p{font-size:18px;margin:20px 0 0}
        small{display:block;margin-top:16px;color:#64748b;font-size:12px}
        @media print{.poster{margin:0 auto;border-width:2px}}
      </style></head><body><div class="poster"><h1>${establishment}</h1><h2>${program}</h2>
      <img src="${src}" alt="QR Code de cadastro" />
      <p><strong>Aponte a câmera do celular</strong> e participe do nosso programa de fidelidade.</p>
      <small>Cadastro gratuito, sem baixar aplicativo · Google Wallet e Carteira da Apple · ShaminaTech Pass</small></div></body></html>`);
    win.document.close();
    const img = win.document.querySelector('img');
    const go = () => {
      win.focus();
      win.print();
    };
    if (img && !img.complete) img.addEventListener('load', go, { once: true });
    else go();
  }

  protected typeLabel(t: string): string {
    return label(PROGRAM_TYPE_LABELS, t);
  }
}
