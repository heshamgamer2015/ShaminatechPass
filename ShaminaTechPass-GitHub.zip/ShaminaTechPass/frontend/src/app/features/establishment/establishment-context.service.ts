import { Injectable, computed, inject, signal } from '@angular/core';
import { ApiError, toApiError } from '../../core/api/api-error';
import { EstablishmentApi } from '../../core/api/establishment-api.service';
import { EstablishmentPanel, Permission } from '../../core/models';

/**
 * Estabelecimento aberto no painel e as permissões do usuário nele (vindas do backend).
 * Fornecido na rota /e/:establishmentId e compartilhado pelas páginas filhas.
 * As permissões só controlam o que a interface exibe; o backend revalida cada requisição.
 */
@Injectable()
export class EstablishmentContext {
  private readonly api = inject(EstablishmentApi);

  readonly panel = signal<EstablishmentPanel | null>(null);
  readonly error = signal<ApiError | null>(null);
  readonly id = computed(() => this.panel()?.id ?? null);
  /** Caminho base do painel (ex.: /e/1). */
  readonly base = computed(() => `/e/${this.panel()?.id ?? ''}`);

  load(id: number): void {
    if (this.panel()?.id === id) return;
    this.panel.set(null);
    this.error.set(null);
    this.api.panel(id).subscribe({
      next: (p) => this.panel.set(p),
      error: (e) => this.error.set(toApiError(e)),
    });
  }

  update(panel: EstablishmentPanel): void {
    this.panel.set(panel);
  }

  can(permission: Permission): boolean {
    return this.panel()?.permissions.includes(permission) ?? false;
  }
}
