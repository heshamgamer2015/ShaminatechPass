import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiError, toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import { BenefitTotals, Indicators, Program } from '../../core/loyalty-models';
import { PROGRAM_TYPE_LABELS, formatBalance, formatMoney, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { EstablishmentContext } from './establishment-context.service';

/**
 * Relatórios de fidelização. Só dados registrados no Pass: nada de estimativas, lucro ou receita incremental.
 * Resultados baixos ou zerados são mostrados como são.
 */
@Component({
  selector: 'app-indicators-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe, FormsModule, AlertComponent, PageHeaderComponent, SpinnerComponent],
  template: `
    <app-page-header title="Relatórios de fidelização" subtitle="Seus clientes estão voltando? Somente dados registrados no Pass — sem estimativas">
      <div class="filters">
        <select class="select" [(ngModel)]="days" (ngModelChange)="load()" aria-label="Período">
          <option [ngValue]="30">Últimos 30 dias</option>
          <option [ngValue]="90">Últimos 90 dias</option>
          <option [ngValue]="180">Últimos 180 dias</option>
          <option [ngValue]="365">Últimos 365 dias</option>
        </select>
        <select class="select" [(ngModel)]="programId" (ngModelChange)="load()" aria-label="Programa">
          <option [ngValue]="null">Todos os programas</option>
          @for (p of programs(); track p.id) { <option [ngValue]="p.id">{{ p.name }}</option> }
        </select>
      </div>
    </app-page-header>

    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (data(); as d) {
      @if (!d.sufficientData) {
        <app-alert kind="warning">{{ d.notes[0] }}</app-alert>
      }
      <p class="muted">Período: {{ d.from | date: 'dd/MM/yyyy' }} a {{ d.to | date: 'dd/MM/yyyy' }}
        @if (selectedProgram(); as p) { · programa {{ p.name }} }</p>

      <h2 class="group">Clientes</h2>
      <div class="grid kpis">
        @if (d.newConsumers !== null) {
          <section class="card kpi"><span class="muted">Novos cadastros</span><strong>{{ d.newConsumers }}</strong>
            <small class="muted">{{ d.selfSignups }} pelo QR Code de cadastro</small></section>
        } @else {
          <section class="card kpi"><span class="muted">Cartões emitidos</span><strong>{{ d.cardsIssued }}</strong>
            <small class="muted">{{ d.selfSignups }} pelo QR Code de cadastro</small></section>
        }
        <section class="card kpi"><span class="muted">Clientes com compras</span><strong>{{ d.consumersWithVisits }}</strong>
          <small class="muted">ao menos uma visita registrada</small></section>
        <section class="card kpi"><span class="muted">Clientes que voltaram</span><strong>{{ d.returningConsumers }}</strong>
          <small class="muted">{{ d.returnRatePercent !== null ? d.returnRatePercent + '% dos clientes com compras' : 'taxa: dados insuficientes' }}</small></section>
        <section class="card kpi"><span class="muted">Clientes recorrentes</span><strong>{{ d.recurringConsumers }}</strong>
          <small class="muted">2 ou mais visitas no período</small></section>
        <section class="card kpi"><span class="muted">Clientes recuperados</span><strong>{{ d.recoveredConsumers }}</strong>
          <small class="muted">voltaram após 60+ dias sem visita</small></section>
        <section class="card kpi"><span class="muted">Clientes inativos</span><strong>{{ d.inactiveConsumers }}</strong>
          <small class="muted">sem visitas há 60+ dias (hoje)</small></section>
      </div>

      <h2 class="group">Frequência e compras</h2>
      <div class="grid kpis">
        <section class="card kpi"><span class="muted">Movimentações (visitas)</span><strong>{{ d.visits }}</strong>
          <small class="muted">concessões não estornadas</small></section>
        <section class="card kpi"><span class="muted">Visitas por cliente</span><strong>{{ d.visitsPerConsumer ?? '—' }}</strong>
          @if (d.visitsPerConsumer === null) { <small class="muted">dados insuficientes</small> }</section>
        <section class="card kpi"><span class="muted">Tempo médio entre compras</span>
          <strong>{{ d.averageDaysBetweenVisits !== null ? d.averageDaysBetweenVisits + ' dias' : '—' }}</strong>
          @if (d.averageDaysBetweenVisits === null) { <small class="muted">dados insuficientes</small> }</section>
        <section class="card kpi"><span class="muted">Compras com valor informado</span><strong>{{ d.purchases }}</strong></section>
        <section class="card kpi"><span class="muted">Valor das compras registradas</span><strong>{{ money(d.totalPurchaseAmount) }}</strong>
          <small class="muted">digitado pela empresa; faturamento informado, não é lucro</small></section>
      </div>

      <section class="card">
        <h2>Visitas por semana</h2>
        @if (d.visits === 0) {
          <p class="muted">Nenhuma visita registrada no período.</p>
        } @else {
          <div class="chart" role="img" [attr.aria-label]="chartLabel()">
            @for (w of d.weekly; track w.start) {
              <div class="col" [title]="(w.start | date: 'dd/MM') + ': ' + w.visits + ' visita(s), ' + w.consumers + ' cliente(s)'">
                <span class="value">{{ w.visits || '' }}</span>
                <span class="bar" [style.height.%]="barHeight(w.visits)"></span>
                <span class="tick">{{ w.start | date: 'dd/MM' }}</span>
              </div>
            }
          </div>
          <p class="muted small">Cada barra soma as visitas de 7 dias a partir da data indicada.</p>
        }
      </section>

      <div class="grid two">
        <section class="card">
          <h2>Benefícios concedidos</h2>
          @for (b of d.benefitsGranted; track b.type) {
            <p><strong>{{ typeLabel(b.type) }}:</strong> {{ balance(b) }} em {{ b.operations }} operação(ões)</p>
          } @empty {
            <p class="muted">Nenhuma concessão no período.</p>
          }
        </section>
        <section class="card">
          <h2>Recompensas resgatadas</h2>
          <p><strong>{{ d.rewardsRedeemed }}</strong> resgate(s) no período</p>
          @for (b of d.benefitsRedeemed; track b.type) {
            <p class="muted">{{ typeLabel(b.type) }}: {{ balance(b) }} usados em {{ b.operations }} resgate(s)</p>
          }
        </section>
      </div>

      <section class="card">
        <h2>Como ler estes números</h2>
        <ul>
          @for (n of d.notes; track n) { <li>{{ n }}</li> }
        </ul>
      </section>
    } @else {
      <app-spinner />
    }
  `,
  styles: `
    .filters {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
    }
    .group {
      font-size: 1.05rem;
      margin: 1.25rem 0 0.5rem;
    }
    .kpis {
      grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
    }
    .two {
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      align-items: start;
      margin-top: 1rem;
    }
    .kpi {
      display: grid;
      gap: 0.25rem;
    }
    .kpi strong {
      font-size: 1.7rem;
    }
    .chart {
      display: flex;
      align-items: flex-end;
      gap: 4px;
      height: 180px;
      padding-top: 1rem;
      overflow-x: auto;
    }
    .col {
      flex: 1 0 22px;
      display: grid;
      grid-template-rows: auto 1fr auto;
      align-items: end;
      justify-items: center;
      height: 100%;
    }
    .bar {
      width: 70%;
      min-height: 2px;
      border-radius: 4px 4px 0 0;
      background: var(--primary);
    }
    .value {
      font-size: 0.72rem;
      color: var(--text-muted);
    }
    .tick {
      font-size: 0.68rem;
      color: var(--text-muted);
      margin-top: 0.25rem;
      white-space: nowrap;
    }
    p {
      margin: 0.25rem 0;
    }
    app-alert {
      display: block;
      margin-bottom: 1rem;
    }
  `,
})
export class IndicatorsPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(LoyaltyApi);
  protected readonly data = signal<Indicators | null>(null);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly programs = signal<Program[]>([]);
  protected days = 90;
  protected programId: number | null = null;
  private readonly maxWeek = computed(() => Math.max(1, ...(this.data()?.weekly ?? []).map((w) => w.visits)));
  protected readonly selectedProgram = computed(() => {
    const d = this.data();
    return d?.programId ? (this.programs().find((p) => p.id === d.programId) ?? null) : null;
  });

  constructor() {
    effect(() => {
      const id = this.ctx.id();
      if (id === null) return;
      this.api.programs(id).subscribe((list) => this.programs.set(list.filter((p) => p.type !== 'VIP')));
      this.load();
    });
  }

  protected load(): void {
    const id = this.ctx.id();
    if (id === null) return;
    this.api.indicators(id, this.days, this.programId).subscribe({
      next: (d) => {
        this.error.set(null);
        this.data.set(d);
      },
      error: (e) => this.error.set(toApiError(e)),
    });
  }

  protected barHeight(v: number): number {
    return Math.round((v / this.maxWeek()) * 100);
  }

  protected chartLabel(): string {
    const w = this.data()?.weekly ?? [];
    return 'Visitas por semana: ' + w.map((p) => p.visits).join(', ');
  }

  protected balance(b: BenefitTotals): string {
    return formatBalance(b.type, b.amount);
  }

  protected typeLabel(t: string): string {
    return label(PROGRAM_TYPE_LABELS, t);
  }

  protected money(v: number): string {
    return formatMoney(v);
  }
}
