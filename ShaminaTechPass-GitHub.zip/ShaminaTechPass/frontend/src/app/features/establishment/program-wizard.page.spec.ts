import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { vi } from 'vitest';
import { EstablishmentContext } from './establishment-context.service';
import { ProgramWizardPage } from './program-wizard.page';

describe('ProgramWizardPage', () => {
  async function setup(allowed = ['STAMPS', 'POINTS']) {
    const ctx = {
      id: signal(1),
      base: signal('/e/1'),
      panel: signal({ id: 1, name: 'Café Aroma', policy: { allowedProgramTypes: allowed, defaultInactivityDays: 60, timeZone: 'America/Sao_Paulo', maxActiveConsumers: 100 } }),
      can: () => true,
    };
    await TestBed.configureTestingModule({
      imports: [ProgramWizardPage],
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([]), { provide: EstablishmentContext, useValue: ctx }],
    }).compileComponents();
    const fixture = TestBed.createComponent(ProgramWizardPage);
    await fixture.whenStable();
    return { fixture, el: fixture.nativeElement as HTMLElement, http: TestBed.inject(HttpTestingController) };
  }

  const next = (el: HTMLElement) => el.querySelector<HTMLButtonElement>('button[type=submit]')!.click();
  const back = (el: HTMLElement) => [...el.querySelectorAll<HTMLButtonElement>('button')].find((b) => b.textContent?.trim() === 'Voltar')!.click();
  function fill(el: HTMLElement, id: string, value: string) {
    const input = el.querySelector<HTMLInputElement>('#' + id)!;
    input.value = value;
    input.dispatchEvent(new Event('input'));
  }

  it('só oferece os tipos habilitados e usa o prazo padrão do estabelecimento', async () => {
    const { fixture, el } = await setup(['POINTS']);
    const enabled = [...el.querySelectorAll<HTMLLabelElement>('label.type:not(.disabled)')];
    expect(enabled.map((l) => l.querySelector('strong')!.textContent!.trim())).toEqual(['Pontos']);
    expect(el.querySelector<HTMLLabelElement>('label.type.selected strong')!.textContent).toContain('Pontos');
    next(el);
    await fixture.whenStable();
    next(el); // sem nome: não avança
    await fixture.whenStable();
    expect(el.textContent).toContain('Informe o nome.');
  });

  it('valida cada etapa e preserva os dados ao voltar', async () => {
    const { fixture, el } = await setup();
    next(el);
    await fixture.whenStable();
    fill(el, 'name', 'Cartão Café');
    fill(el, 'stampsRequired', '1');
    await fixture.whenStable();
    next(el);
    await fixture.whenStable();
    expect(el.textContent).toContain('Mínimo: 2.');
    fill(el, 'stampsRequired', '8');
    next(el);
    await fixture.whenStable();
    expect(el.querySelector<HTMLInputElement>('#inactivityDays')!.value).toBe('60');
    back(el);
    await fixture.whenStable();
    expect(el.querySelector<HTMLInputElement>('#name')!.value).toBe('Cartão Café');
    expect(el.querySelector<HTMLInputElement>('#stampsRequired')!.value).toBe('8');
  });

  it('cria o programa só na revisão e depois grava a personalização', async () => {
    const { fixture, el, http } = await setup();
    const navigate = vi.spyOn(TestBed.inject(Router), 'navigate').mockResolvedValue(true);
    next(el);
    await fixture.whenStable();
    fill(el, 'name', 'Cartão Café');
    next(el);
    await fixture.whenStable();
    fill(el, 'stampReward', 'Um café grátis');
    next(el);
    await fixture.whenStable();
    next(el);
    await fixture.whenStable();
    http.expectNone('/api/establishments/1/programs');
    expect(el.textContent).toContain('Revise antes de ativar');
    expect(el.textContent).toContain('Um café grátis');
    next(el);
    await fixture.whenStable();
    const create = http.expectOne((r) => r.method === 'POST' && r.url === '/api/establishments/1/programs');
    expect(create.request.body).toMatchObject({ type: 'STAMPS', name: 'Cartão Café', stampsRequired: 10, stampReward: 'Um café grátis', inactivityDays: 60 });
    create.flush({ id: 42 });
    await fixture.whenStable();
    const design = http.expectOne((r) => r.method === 'PUT' && r.url === '/api/establishments/1/programs/42/design');
    expect(design.request.body.brandColor).toBe('#F43F5E');
    design.flush({ id: 42 });
    await fixture.whenStable();
    expect(navigate).toHaveBeenCalledWith(['/e/1/programas', 42]);
  });
});
