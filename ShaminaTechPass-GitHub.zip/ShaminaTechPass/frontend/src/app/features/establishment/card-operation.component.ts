import { ChangeDetectionStrategy, Component, computed, inject, input, output, signal } from '@angular/core';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { FormsModule } from '@angular/forms';
import { toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import { CardDetail, Channel, OperationResult } from '../../core/loyalty-models';
import { STAMP_CRITERION_LABELS, formatBalance, label, parseMoney } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';

/**
 * Formulário de concessão/resgate para um cartão já identificado. Nada é gravado até o clique em
 * "Confirmar". A chave de idempotência é gerada uma vez por operação e reaproveitada se a mesma
 * operação for reenviada (ex.: falha de rede), evitando crédito em dobro.
 */
@Component({
  selector: 'app-card-operation',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, AlertComponent],
  template: `
    @let c = detail().card;
    @if (c.status !== 'ACTIVE') {
      <app-alert kind="warning">Este cartão está {{ statusText() }} e não aceita movimentações.</app-alert>
    } @else {
      <div class="modes" role="tablist">
        <button type="button" role="tab" class="btn" [class.btn-primary]="mode() === 'earn'" [attr.aria-selected]="mode() === 'earn'"
                (click)="setMode('earn')">Conceder benefício</button>
        <button type="button" role="tab" class="btn" [class.btn-primary]="mode() === 'redeem'" [attr.aria-selected]="mode() === 'redeem'"
                (click)="setMode('redeem')">Resgatar</button>
      </div>

      <form class="form" (ngSubmit)="confirm()">
        @if (mode() === 'earn') {
          @if (c.programType === 'STAMPS') {
            <div class="field">
              <label for="qty">Carimbos a conceder</label>
              <input id="qty" class="input" type="number" min="1" max="50" name="qty" [(ngModel)]="quantity" (ngModelChange)="changed()" />
              <span class="hint">Faltam {{ missing() }} para completar.</span>
            </div>
          }
          @if (needsPurchase()) {
            <div class="field">
              <label for="purchase">Valor da compra (R$)</label>
              <input id="purchase" class="input big" inputmode="decimal" name="purchase" [(ngModel)]="purchase" (ngModelChange)="changed()"
                     placeholder="0,00" autocomplete="off" />
            </div>
          } @else if (c.programType === 'STAMPS') {
            <div class="field">
              <label for="purchase">Valor da compra (R$) <span class="muted">(opcional, para os indicadores)</span></label>
              <input id="purchase" class="input" inputmode="decimal" name="purchase" [(ngModel)]="purchase" (ngModelChange)="changed()" placeholder="0,00" />
            </div>
          }
        } @else {
          @switch (c.programType) {
            @case ('POINTS') {
              <div class="field">
                <label for="reward">Recompensa</label>
                <select id="reward" class="select" name="reward" [(ngModel)]="rewardId" (ngModelChange)="changed()">
                  <option [ngValue]="null">Escolha…</option>
                  @for (r of detail().rewards; track r.id) {
                    <option [ngValue]="r.id" [disabled]="r.cost > c.availableBalance">{{ r.name }} — {{ r.cost }} pontos</option>
                  }
                </select>
                @if (detail().rewards.length === 0) {
                  <span class="hint">Nenhuma recompensa ativa neste programa.</span>
                }
              </div>
            }
            @case ('CASHBACK') {
              <div class="form-row">
                <div class="field">
                  <label for="amount">Valor do cashback a usar (R$)</label>
                  <input id="amount" class="input big" inputmode="decimal" name="amount" [(ngModel)]="amount" (ngModelChange)="changed()" />
                </div>
                <div class="field">
                  <label for="purchase2">Valor da compra (R$)</label>
                  <input id="purchase2" class="input" inputmode="decimal" name="purchase2" [(ngModel)]="purchase" (ngModelChange)="changed()" />
                </div>
              </div>
            }
            @case ('STAMPS') {
              @if (c.rewardAvailable) {
                <p>Cartão completo! Recompensa: <strong>{{ detail().design.rewardInfo || 'recompensa do programa' }}</strong></p>
              } @else {
                <p class="muted">O cartão ainda não está completo ({{ c.availableBalance }} de {{ c.stampsRequired }}).</p>
              }
            }
          }
        }
        <div class="field">
          <label for="note">Observação <span class="muted">(opcional)</span></label>
          <input id="note" class="input" name="note" maxlength="200" [(ngModel)]="note" (ngModelChange)="changed()" />
        </div>

        @if (error()) {
          <app-alert kind="error">{{ error() }}</app-alert>
        }
        <div class="actions">
          <button class="btn btn-primary btn-lg" type="submit" [disabled]="busy() || !canSubmit()">
            {{ busy() ? 'Registrando…' : (mode() === 'earn' ? 'Confirmar concessão' : 'Confirmar resgate') }}
          </button>
        </div>
      </form>
    }
  `,
  styles: `
    .modes {
      display: flex;
      gap: 0.5rem;
      margin-bottom: 1rem;
      flex-wrap: wrap;
    }
    .big {
      font-size: 1.4rem;
      min-height: 52px;
    }
    .btn-lg {
      min-height: 50px;
      padding: 0 1.5rem;
      font-size: 1.05rem;
    }
  `,
})
export class CardOperationComponent {
  private readonly api = inject(LoyaltyApi);
  private readonly dialogs = inject(ConfirmService);

  readonly establishmentId = input.required<number>();
  readonly detail = input.required<CardDetail>();
  readonly channel = input<Channel>('MANUAL');
  readonly done = output<OperationResult>();

  protected readonly mode = signal<'earn' | 'redeem'>('earn');
  protected readonly busy = signal(false);
  protected readonly error = signal<string | null>(null);
  protected quantity = 1;
  protected purchase = '';
  protected amount = '';
  protected rewardId: number | null = null;
  protected note = '';
  private key: string | null = null;

  protected readonly missing = computed(() => {
    const c = this.detail().card;
    return Math.max(0, (c.stampsRequired ?? 0) - c.availableBalance);
  });

  protected readonly statusText = computed(() => {
    const map: Record<string, string> = { SUSPENDED: 'desativado', EXPIRED: 'expirado', COMPLETED: 'concluído', CANCELLED: 'cancelado' };
    return map[this.detail().card.status] ?? this.detail().card.status;
  });

  protected needsPurchase(): boolean {
    const c = this.detail().card;
    return c.programType === 'POINTS' || c.programType === 'CASHBACK';
  }

  protected canSubmit(): boolean {
    const c = this.detail().card;
    if (this.mode() === 'earn') return !this.needsPurchase() || !!this.purchase;
    if (c.programType === 'POINTS') return this.rewardId !== null;
    if (c.programType === 'CASHBACK') return !!this.amount;
    return c.rewardAvailable;
  }

  protected setMode(mode: 'earn' | 'redeem'): void {
    this.mode.set(mode);
    this.changed();
  }

  /** Qualquer alteração nos dados vira uma nova operação (nova chave). */
  protected changed(): void {
    this.key = null;
    this.error.set(null);
  }

  protected async confirm(): Promise<void> {
    if (this.busy()) return;
    const c = this.detail().card;
    const purchase = parseMoney(this.purchase);
    const amount = parseMoney(this.amount);
    if (Number.isNaN(purchase) || Number.isNaN(amount)) {
      this.error.set('Valor inválido. Use vírgula para os centavos, ex.: 25,90.');
      return;
    }
    const summary =
      this.mode() === 'earn'
        ? `Conceder benefício a ${c.consumerName}${purchase ? ` (compra de ${purchase.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })})` : ''}?`
        : `Registrar resgate de ${c.consumerName}?`;
    const earn = this.mode() === 'earn';
    const ok = await this.dialogs.confirm({
      title: earn ? 'Confirmar concessão' : 'Confirmar resgate',
      message: summary,
      confirmLabel: earn ? 'Conceder' : 'Registrar resgate',
    });
    if (!ok || this.busy()) return;
    this.key ??= LoyaltyApi.newKey();
    this.busy.set(true);
    this.error.set(null);
    const request =
      this.mode() === 'earn'
        ? this.api.earn(this.establishmentId(), c.id, {
            purchaseAmount: purchase,
            quantity: c.programType === 'STAMPS' ? this.quantity : null,
            channel: this.channel(),
            note: this.note || null,
          }, this.key)
        : this.api.redeem(this.establishmentId(), c.id, {
            rewardId: this.rewardId,
            amount,
            purchaseAmount: purchase,
            channel: this.channel(),
            note: this.note || null,
          }, this.key);
    request.subscribe({
      next: (result) => {
        this.busy.set(false);
        this.key = null;
        this.purchase = '';
        this.amount = '';
        this.rewardId = null;
        this.note = '';
        this.quantity = 1;
        this.done.emit(result);
      },
      error: (e) => {
        this.busy.set(false);
        const err = toApiError(e);
        // Erro de rede: mantém a chave para que um novo clique não gere crédito duplicado.
        if (err.status !== 0) this.key = null;
        this.error.set(err.message);
      },
    });
  }

  protected balance(v: number): string {
    return formatBalance(this.detail().card.programType, v);
  }

  protected criterion(c: string | null): string {
    return label(STAMP_CRITERION_LABELS, c);
  }
}
