import { ChangeDetectionStrategy, Component, computed, effect, inject, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NavAction, NavItem, ShellComponent } from '../../layout/shell.component';
import { AlertComponent } from '../../shared/ui/alert.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { EstablishmentContext } from './establishment-context.service';

@Component({
  selector: 'app-establishment-layout',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, ShellComponent, AlertComponent, SpinnerComponent],
  template: `
    @if (ctx.panel(); as panel) {
      <app-shell area="Painel do estabelecimento" [context]="panel.name" [nav]="nav()" [primaryAction]="primaryAction()" />
    } @else if (ctx.error(); as e) {
      <div class="blocked">
        <app-alert kind="error">{{ e.message }}</app-alert>
        <a class="btn" routerLink="/">Voltar ao início</a>
      </div>
    } @else {
      <app-spinner />
    }
  `,
  styles: `
    .blocked {
      max-width: 520px;
      margin: 4rem auto;
      padding: 0 1rem;
      display: grid;
      gap: 1rem;
      justify-items: start;
    }
  `,
})
export class EstablishmentLayoutComponent {
  protected readonly ctx = inject(EstablishmentContext);

  /** Parâmetro de rota :establishmentId. */
  readonly establishmentId = input.required<string>();

  /** Menu montado a partir das permissões reais do usuário neste estabelecimento. */
  /** Ação de balcão sempre visível no topo do menu (um clique, como antes). */
  protected readonly primaryAction = computed<NavAction | null>(() =>
    this.ctx.can('TRANSACTIONS_REGISTER')
      ? { label: 'Registrar compra', link: `/e/${this.establishmentId()}/operacao`, icon: 'scan' }
      : null,
  );

  /** Menu montado a partir das permissões reais do usuário, agrupado pela tarefa do dia a dia. */
  protected readonly nav = computed<NavItem[]>(() => {
    const base = `/e/${this.establishmentId()}`;
    const items: NavItem[] = [{ label: 'Visão geral', link: base, exact: true, icon: 'home' }];
    if (this.ctx.can('CONSUMERS_VIEW')) {
      const s = 'Clientes';
      items.push({ section: s, label: 'Clientes', link: `${base}/clientes`, icon: 'users' });
      items.push({ section: s, label: 'Cartões', link: `${base}/cartoes`, icon: 'card' });
      items.push({ section: s, label: 'Movimentações', link: `${base}/movimentacoes`, icon: 'list' });
      items.push({ section: s, label: 'QR Code do programa', link: `${base}/qr-cadastro`, icon: 'qr' });
    }
    const p = 'Programa';
    items.push({ section: p, label: 'Programas de fidelidade', link: `${base}/programas`, icon: 'star' });
    items.push({ section: p, label: 'Recompensas', link: `${base}/recompensas`, icon: 'gift' });
    if (this.ctx.can('PROGRAMS_MANAGE')) items.push({ section: p, label: 'Personalização', link: `${base}/personalizacao`, icon: 'palette' });
    if (this.ctx.can('CONSUMERS_VIEW')) {
      items.push({ section: p, label: 'Carteiras digitais', link: `${base}/carteiras`, icon: 'wallet' });
      items.push({ section: p, label: 'Notificações e proximidade', link: `${base}/notificacoes`, icon: 'bell' });
    }
    const g = 'Gestão';
    if (this.ctx.can('REPORTS_VIEW')) items.push({ section: g, label: 'Relatórios', link: `${base}/indicadores`, icon: 'chart' });
    items.push({ section: g, label: 'Plano', link: `${base}/plano`, icon: 'sliders' });
    items.push({ section: g, label: 'Configurações', link: `${base}/configuracoes`, icon: 'settings' });
    if (this.ctx.can('AUDIT_VIEW')) items.push({ section: g, label: 'Auditoria', link: `${base}/auditoria`, icon: 'shield' });
    return items;
  });

  constructor() {
    effect(() => this.ctx.load(Number(this.establishmentId())));
  }
}
