import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, effect, inject, signal } from '@angular/core';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { FormsModule, NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiError, toApiError } from '../../core/api/api-error';
import { NotificationApi } from '../../core/api/notification-api.service';
import { EstablishmentLocationData, NotificationOverview, ReminderStatus, ReminderView } from '../../core/loyalty-models';
import { Page } from '../../core/models';
import { NotificationService } from '../../core/notifications/notification.service';
import { REMINDER_CATEGORY_LABELS, REMINDER_STATUS_LABELS, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { FieldErrorComponent } from '../../shared/ui/field-error.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { PagerComponent } from '../../shared/ui/pager.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';
import { EstablishmentContext } from './establishment-context.service';

const STATUSES: ReminderStatus[] = ['PENDING', 'ACCEPTED', 'FAILED', 'REJECTED', 'QUOTA_EXCEEDED', 'CANCELLED'];

/**
 * Notificações e Proximidade: lembretes enviados como mensagens ao Google Wallet, localização da loja publicada nas
 * carteiras e histórico de pedidos. Nenhum número de entrega/abertura: o Google não fornece essa informação.
 */
@Component({
  selector: 'app-notifications-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe, FormsModule, ReactiveFormsModule, AlertComponent, FieldErrorComponent, PageHeaderComponent, PagerComponent,
    SpinnerComponent, StatusBadgeComponent],
  template: `
    <app-page-header title="Notificações e Proximidade"
                     subtitle="Lembretes no Google Wallet e localização da loja — sem rastrear clientes" />

    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (data(); as d) {
      <section class="card">
        <h2>Situação das carteiras</h2>
        @if (d.integration.googleConfigured) {
          <app-alert kind="success">Google Wallet configurado: os lembretes podem ser enviados.</app-alert>
        } @else {
          <app-alert kind="warning">Google Wallet não configurado — nenhum lembrete será enviado. Pendências (ShaminaTech):
            <ul>@for (m of d.integration.googleMissing; track m) { <li>{{ m }}</li> }</ul>
          </app-alert>
        }
        <ul class="caps">
          @for (c of d.capabilities; track c.key) {
            <li>
              <span class="cap-head"><strong>{{ c.title }}</strong>
                <app-badge [value]="c.available ? 'ACTIVE' : 'DISABLED'" [labelText]="c.available ? 'Disponível' : 'Indisponível'" /></span>
              <span class="muted small">{{ c.detail }}</span>
            </li>
          }
        </ul>
      </section>

      <form class="card form" [formGroup]="form" (ngSubmit)="save()" novalidate>
        <h2>Lembretes</h2>
        <p class="muted small">Tudo vem desligado. Cada aviso usa só dados reais do cartão, sai entre 9h e 20h e respeita o
          intervalo mínimo. Lembretes não renovam a validade do cartão.</p>
        @if (saveError(); as e) { <app-alert kind="error">{{ e.message }}</app-alert> }

        <fieldset class="option">
          <label class="switch"><input type="checkbox" role="switch" formControlName="nearRewardEnabled" /> <strong>Recompensa próxima</strong></label>
          <p class="muted small">Ex.: “Falta apenas 1 carimbo para completar seu cartão e ganhar: Um café grátis!”</p>
          <div class="form-row">
            <div class="field">
              <label for="nearRewardStamps">Carimbos: avisar quando faltarem até</label>
              <select id="nearRewardStamps" class="select" formControlName="nearRewardStamps">
                @for (n of [1, 2, 3]; track n) { <option [ngValue]="n">{{ n }} carimbo{{ n > 1 ? 's' : '' }}</option> }
              </select>
            </div>
            <div class="field">
              <label for="nearRewardPointsPercent">Pontos: avisar quando faltarem até</label>
              <select id="nearRewardPointsPercent" class="select" formControlName="nearRewardPointsPercent">
                @for (n of [5, 10, 20]; track n) { <option [ngValue]="n">{{ n }}% da recompensa mais barata</option> }
              </select>
            </div>
          </div>
          <span class="hint">Cashback e níveis VIP não têm “próxima recompensa” definida e não recebem este aviso.</span>
        </fieldset>

        <fieldset class="option">
          <label class="switch"><input type="checkbox" role="switch" formControlName="expiryEnabled" /> <strong>Cartão perto de vencer</strong></label>
          <p class="muted small">Ex.: “Seu cartão Café vence em 3 dias (05/12). Uma compra registrada renova a validade.”</p>
          <div class="field narrow">
            <label for="expiryDaysBefore">Avisar quando faltarem</label>
            <select id="expiryDaysBefore" class="select" formControlName="expiryDaysBefore">
              @for (n of [2, 3, 5, 7]; track n) { <option [ngValue]="n">{{ n }} dias</option> }
            </select>
            <span class="hint">Contado pela validade real do cartão, no fuso {{ ctx.panel()?.policy?.timeZone }}.</span>
          </div>
        </fieldset>

        <fieldset class="option">
          <label class="switch"><input type="checkbox" role="switch" formControlName="inactivityEnabled" /> <strong>Lembrete de inatividade</strong></label>
          <p class="muted small">Convite para voltar. Vai <strong>só</strong> para clientes que aceitaram receber comunicações do
            estabelecimento (o aceite da privacidade não vale como consentimento).</p>
          <div class="field narrow">
            <label for="inactivityDays">Sem movimentações há pelo menos (dias)</label>
            <input id="inactivityDays" class="input" type="number" min="15" max="365" formControlName="inactivityDays" />
            <app-field-error [server]="fe('inactivityDays')" [local]="invalid('inactivityDays') ? 'Entre 15 e 365 dias.' : null" />
          </div>
        </fieldset>

        <fieldset class="option">
          <legend><strong>Frequência</strong></legend>
          <div class="field narrow">
            <label for="minIntervalDays">Intervalo mínimo entre avisos da mesma categoria, por cartão (dias)</label>
            <input id="minIntervalDays" class="input" type="number" min="3" max="90" formControlName="minIntervalDays" />
            <app-field-error [server]="fe('minIntervalDays')" [local]="invalid('minIntervalDays') ? 'Entre 3 e 90 dias.' : null" />
            <span class="hint">Além disso: no máximo 1 aviso por cartão a cada 24 h (o Google aceita até 3 e pode limitar quem envia demais).
              A mesma situação nunca é avisada duas vezes.</span>
          </div>
        </fieldset>

        <fieldset class="option">
          <label class="switch"><input type="checkbox" role="switch" formControlName="proximityEnabled" /> <strong>Proximidade da loja</strong></label>
          <p class="muted small">Publica as localizações abaixo no cartão. O Google Wallet (e o iPhone, quando a Apple Wallet estiver
            ativa) pode sugerir o cartão quando o cliente estiver perto. A distância, o momento e o texto do aviso são decididos
            pelo Google/Apple no celular do cliente; o Pass não recebe a localização de ninguém.</p>
          <div class="field">
            <label for="proximityText">Texto na tela de bloqueio do iPhone <span class="muted">(opcional)</span></label>
            <input id="proximityText" class="input" formControlName="proximityText" maxlength="80" placeholder="Ex.: Passe aqui e ganhe seu carimbo" />
          </div>
          @if (d.locations.length === 0) {
            <span class="hint">Cadastre ao menos uma localização para ativar.</span>
          }
          <app-field-error [server]="fe('proximityEnabled')" />
        </fieldset>

        @if (canManage()) {
          <div class="actions">
            <button class="btn btn-primary" type="submit" [disabled]="saving()">{{ saving() ? 'Salvando…' : 'Salvar configurações' }}</button>
          </div>
        }
      </form>

      <section class="card">
        <div class="section-head">
          <h2>Localização da loja</h2>
          <span class="muted small">{{ d.locations.length }} de {{ d.maxLocations }}</span>
        </div>
        @for (l of d.locations; track l.id) {
          <div class="loc">
            <div>
              <strong>{{ l.name }}</strong><br />
              <span>{{ l.addressLine }} — {{ l.city }}/{{ l.state }} · CEP {{ cep(l.postalCode) }}</span><br />
              <span class="muted small mono">{{ l.latitude }}, {{ l.longitude }}</span>
              <a class="small" [href]="mapUrl(l)" target="_blank" rel="noopener noreferrer">conferir no mapa</a>
            </div>
            @if (canEditLocation()) {
              <div class="loc-actions">
                <button class="btn btn-sm" type="button" (click)="edit(l)">Editar</button>
                <button class="btn btn-sm btn-danger" type="button" (click)="remove(l)">Remover</button>
              </div>
            }
          </div>
        } @empty {
          <p class="muted">Nenhuma localização cadastrada. A ShaminaTech também pode cadastrar para você.</p>
        }

        @if (canEditLocation() && (editingId() !== null || d.locations.length < d.maxLocations)) {
          <form class="form loc-form" [formGroup]="locForm" (ngSubmit)="saveLocation()" novalidate>
            <h3>{{ editingId() ? 'Editar localização' : 'Nova localização' }}</h3>
            @if (locError(); as e) { <app-alert kind="error">{{ e.message }}</app-alert> }
            <div class="form-row">
              <div class="field"><label for="locName">Nome</label>
                <input id="locName" class="input" formControlName="name" maxlength="60" placeholder="Ex.: Loja Centro" />
                <app-field-error [server]="lfe('name')" /></div>
              <div class="field"><label for="locAddress">Endereço</label>
                <input id="locAddress" class="input" formControlName="addressLine" maxlength="200" placeholder="Rua, número" />
                <app-field-error [server]="lfe('addressLine')" /></div>
            </div>
            <div class="form-row">
              <div class="field"><label for="locCity">Cidade</label>
                <input id="locCity" class="input" formControlName="city" maxlength="80" />
                <app-field-error [server]="lfe('city')" /></div>
              <div class="field small-field"><label for="locState">UF</label>
                <input id="locState" class="input" formControlName="state" maxlength="2" />
                <app-field-error [server]="lfe('state')" /></div>
              <div class="field small-field"><label for="locCep">CEP</label>
                <input id="locCep" class="input" formControlName="postalCode" maxlength="9" inputmode="numeric" />
                <app-field-error [server]="lfe('postalCode')" /></div>
            </div>
            <div class="form-row">
              <div class="field"><label for="locLat">Latitude</label>
                <input id="locLat" class="input mono" formControlName="latitude" inputmode="decimal" placeholder="-23.561414" />
                <app-field-error [server]="lfe('latitude')" /></div>
              <div class="field"><label for="locLon">Longitude</label>
                <input id="locLon" class="input mono" formControlName="longitude" inputmode="decimal" placeholder="-46.655881" />
                <app-field-error [server]="lfe('longitude')" /></div>
            </div>
            <span class="hint">Copie as coordenadas do Google Maps (clique com o botão direito no ponto da loja). Use ponto como separador decimal.</span>
            <div class="actions">
              <button class="btn btn-primary" type="submit" [disabled]="savingLoc()">{{ savingLoc() ? 'Salvando…' : 'Salvar localização' }}</button>
              @if (editingId()) { <button class="btn" type="button" (click)="cancelEdit()">Cancelar</button> }
            </div>
          </form>
        }
      </section>

      <section class="card">
        <h2>Pedidos de aviso nos últimos 30 dias</h2>
        <p class="muted small">Contagem do que o Pass pediu e do que o Google respondeu. Entrega e leitura não são informadas pelo Google.</p>
        @if (total(d) === 0) {
          <p class="muted">Nenhum pedido de aviso no período.</p>
        } @else {
          <div class="counts">
            @for (s of statuses; track s) {
              @if (d.last30Days[s]) { <span><app-badge [value]="tone(s)" [labelText]="statusLabel(s)" /> {{ d.last30Days[s] }}</span> }
            }
          </div>
        }
        @if (d.recentFailures.length > 0) {
          <h3>Últimas falhas</h3>
          @for (f of d.recentFailures; track f.id) {
            <p class="small"><app-badge [value]="tone(f.status)" [labelText]="statusLabel(f.status)" />
              {{ f.consumerFirstName }} · {{ categoryLabel(f.category) }} · {{ f.lastAttemptAt | date: 'dd/MM HH:mm' }}
              <span class="muted">{{ f.lastError ?? f.closedReason }}</span></p>
          }
        }
      </section>

      <section class="card">
        <div class="section-head">
          <h2>Histórico de pedidos</h2>
          <select class="select" [(ngModel)]="filter" (ngModelChange)="loadHistory(0)" aria-label="Situação">
            <option value="">Todas as situações</option>
            @for (s of statuses; track s) { <option [value]="s">{{ statusLabel(s) }}</option> }
          </select>
        </div>
        @if (history(); as h) {
          @if (h.content.length === 0) {
            <p class="muted">Nenhum pedido registrado.</p>
          } @else {
            <div class="table-wrap">
              <table class="table responsive">
                <thead><tr><th>Planejado</th><th>Cliente</th><th>Tipo</th><th>Mensagem</th><th>Situação</th></tr></thead>
                <tbody>
                  @for (r of h.content; track r.id) {
                    <tr>
                      <td data-label="Planejado">{{ r.plannedAt | date: 'dd/MM/yyyy HH:mm' }}</td>
                      <td data-label="Cliente">{{ r.consumerFirstName ?? '—' }}<br /><span class="muted small">{{ r.programName }}</span></td>
                      <td data-label="Tipo">{{ categoryLabel(r.category) }}</td>
                      <td data-label="Mensagem">{{ r.body }}</td>
                      <td data-label="Situação"><app-badge [value]="tone(r.status)" [labelText]="statusLabel(r.status)" />
                        @if (r.withdrawnAt) { <br /><span class="muted small">retirada do cartão (situação mudou)</span> }
                        @if (r.status === 'FAILED' && r.nextAttemptAt) { <br /><span class="muted small">nova tentativa {{ r.nextAttemptAt | date: 'dd/MM HH:mm' }}</span> }
                        @if (r.closedReason && r.status !== 'ACCEPTED') { <br /><span class="muted small">{{ r.closedReason }}</span> }</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
            <app-pager [page]="h.page" [totalPages]="h.totalPages" (pageChange)="loadHistory($event)" />
          }
        } @else {
          <app-spinner />
        }
      </section>

      <section class="card">
        <h2>Limitações das carteiras</h2>
        <ul>@for (n of d.notes; track n) { <li>{{ n }}</li> }</ul>
      </section>
    } @else {
      <app-spinner />
    }
  `,
  styles: `
    .caps {
      list-style: none;
      padding: 0;
      margin: 0.75rem 0 0;
      display: grid;
    }
    .caps li {
      display: grid;
      grid-template-columns: 1fr auto;
      gap: 0.15rem 1rem;
      padding: 0.75rem 0;
      border-bottom: 1px solid var(--border);
    }
    .caps li:last-child {
      border-bottom: 0;
      padding-bottom: 0;
    }
    .caps .muted {
      grid-column: 1;
    }
    .cap-head {
      display: contents;
    }
    .cap-head app-badge {
      grid-column: 2;
      grid-row: 1 / span 2;
      align-self: center;
    }
    .option {
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 0.85rem 1rem;
      display: grid;
      gap: 0.4rem;
    }
    .narrow {
      max-width: 420px;
    }
    .small-field {
      max-width: 140px;
    }
    .section-head {
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      gap: 1rem;
      flex-wrap: wrap;
    }
    .loc {
      display: flex;
      justify-content: space-between;
      gap: 1rem;
      padding: 0.75rem 0;
      border-bottom: 1px solid var(--border);
      flex-wrap: wrap;
    }
    .loc a {
      margin-left: 0.5rem;
    }
    .loc-actions {
      display: flex;
      gap: 0.4rem;
      align-items: flex-start;
    }
    .loc-form {
      margin-top: 1rem;
    }
    .counts {
      display: flex;
      flex-wrap: wrap;
      gap: 1rem;
    }
    p {
      margin: 0;
    }
    app-alert {
      display: block;
      margin-bottom: 0.75rem;
    }
  `,
})
export class NotificationsPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(NotificationApi);
  private readonly notifications = inject(NotificationService);
  private readonly dialogs = inject(ConfirmService);
  private readonly fb = inject(NonNullableFormBuilder);

  protected readonly statuses = STATUSES;
  protected readonly data = signal<NotificationOverview | null>(null);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly saveError = signal<ApiError | null>(null);
  protected readonly locError = signal<ApiError | null>(null);
  protected readonly saving = signal(false);
  protected readonly savingLoc = signal(false);
  protected readonly editingId = signal<number | null>(null);
  protected readonly history = signal<Page<ReminderView> | null>(null);
  protected filter: ReminderStatus | '' = '';

  protected readonly form = this.fb.group({
    nearRewardEnabled: [false],
    nearRewardStamps: [1],
    nearRewardPointsPercent: [10],
    expiryEnabled: [false],
    expiryDaysBefore: [3],
    inactivityEnabled: [false],
    inactivityDays: [60, [Validators.required, Validators.min(15), Validators.max(365)]],
    minIntervalDays: [7, [Validators.required, Validators.min(3), Validators.max(90)]],
    proximityEnabled: [false],
    proximityText: ['', Validators.maxLength(80)],
  });

  protected readonly locForm = this.fb.group({
    name: ['', Validators.required],
    addressLine: ['', Validators.required],
    city: ['', Validators.required],
    state: ['', Validators.required],
    postalCode: ['', Validators.required],
    latitude: ['', Validators.required],
    longitude: ['', Validators.required],
  });

  constructor() {
    effect(() => {
      if (this.ctx.id() === null) return;
      this.load();
      this.loadHistory(0);
    });
  }

  private load(): void {
    this.api.overview(this.ctx.id()!).subscribe({
      next: (d) => {
        this.data.set(d);
        this.form.reset({ ...d.settings, proximityText: d.settings.proximityText ?? '' });
        if (!this.canManage()) this.form.disable();
      },
      error: (e) => this.error.set(toApiError(e)),
    });
  }

  protected loadHistory(page: number): void {
    const eid = this.ctx.id();
    if (eid === null) return;
    this.api.history(eid, this.filter, page).subscribe((h) => this.history.set(h));
  }

  protected canManage(): boolean {
    return this.ctx.can('PROGRAMS_MANAGE');
  }

  protected canEditLocation(): boolean {
    return this.ctx.can('ESTABLISHMENT_EDIT');
  }

  protected invalid(name: 'inactivityDays' | 'minIntervalDays'): boolean {
    const c = this.form.controls[name];
    return c.touched && c.invalid;
  }

  protected fe(field: string): string | undefined {
    return this.saveError()?.fieldErrors?.[field];
  }

  protected lfe(field: string): string | undefined {
    return this.locError()?.fieldErrors?.[field];
  }

  protected async save(): Promise<void> {
    const eid = this.ctx.id();
    const current = this.data();
    if (eid === null || !current) return;
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    const turningOn =
      (v.nearRewardEnabled && !current.settings.nearRewardEnabled) ||
      (v.expiryEnabled && !current.settings.expiryEnabled) ||
      (v.inactivityEnabled && !current.settings.inactivityEnabled);
    if (
      turningOn &&
      !(await this.dialogs.confirm({
        title: 'Ativar lembretes?',
        message: 'Clientes com o cartão no Google Wallet poderão receber avisos no celular (entre 9h e 20h).',
        confirmLabel: 'Ativar lembretes',
      }))
    ) {
      return;
    }
    this.saving.set(true);
    this.saveError.set(null);
    this.api.saveSettings(eid, { ...v, proximityText: v.proximityText.trim() || null }).subscribe({
      next: () => {
        this.saving.set(false);
        this.notifications.success('Configurações salvas.');
        this.load();
      },
      error: (e) => {
        this.saving.set(false);
        this.saveError.set(toApiError(e));
      },
    });
  }

  protected edit(l: EstablishmentLocationData): void {
    this.editingId.set(l.id);
    this.locError.set(null);
    this.locForm.reset({ ...l, latitude: String(l.latitude), longitude: String(l.longitude), postalCode: this.cep(l.postalCode) });
  }

  protected cancelEdit(): void {
    this.editingId.set(null);
    this.locForm.reset();
  }

  protected saveLocation(): void {
    const eid = this.ctx.id();
    if (eid === null) return;
    if (this.locForm.invalid) {
      this.locForm.markAllAsTouched();
      this.locError.set({ status: 400, code: 'VALIDATION_ERROR', message: 'Preencha todos os campos da localização.', fieldErrors: {} });
      return;
    }
    const v = this.locForm.getRawValue();
    const latitude = Number(v.latitude.replace(',', '.'));
    const longitude = Number(v.longitude.replace(',', '.'));
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
      this.locError.set({ status: 400, code: 'VALIDATION_ERROR', message: 'Latitude e longitude devem ser números.', fieldErrors: {} });
      return;
    }
    this.savingLoc.set(true);
    this.locError.set(null);
    this.api.saveLocation(eid, this.editingId(), { ...v, state: v.state.trim(), latitude, longitude }).subscribe({
      next: () => {
        this.savingLoc.set(false);
        this.notifications.success('Localização salva.');
        this.cancelEdit();
        this.load();
      },
      error: (e) => {
        this.savingLoc.set(false);
        this.locError.set(toApiError(e));
      },
    });
  }

  protected async remove(l: EstablishmentLocationData): Promise<void> {
    const eid = this.ctx.id();
    if (eid === null) return;
    const ok = await this.dialogs.confirm({
      title: `Remover a localização "${l.name}"?`,
      message: 'Ela deixará de ser publicada nos cartões.',
      confirmLabel: 'Remover',
      tone: 'danger',
    });
    if (!ok) return;
    this.api.deleteLocation(eid, l.id).subscribe({
      next: () => {
        this.notifications.success('Localização removida.');
        this.load();
      },
      error: (e) => this.notifications.error(toApiError(e).message),
    });
  }

  protected total(d: NotificationOverview): number {
    return Object.values(d.last30Days).reduce((a, b) => a + (b ?? 0), 0);
  }

  /** "Descartado" é neutro (não é erro); os demais usam as cores padrão. */
  protected tone(s: ReminderStatus): string {
    return s === 'CANCELLED' ? 'DISABLED' : s;
  }

  protected statusLabel(s: string): string {
    return label(REMINDER_STATUS_LABELS, s);
  }

  protected categoryLabel(c: string): string {
    return label(REMINDER_CATEGORY_LABELS, c);
  }

  protected cep(v: string): string {
    return v.length === 8 ? `${v.slice(0, 5)}-${v.slice(5)}` : v;
  }

  protected mapUrl(l: EstablishmentLocationData): string {
    return `https://www.openstreetmap.org/?mlat=${l.latitude}&mlon=${l.longitude}#map=18/${l.latitude}/${l.longitude}`;
  }
}
