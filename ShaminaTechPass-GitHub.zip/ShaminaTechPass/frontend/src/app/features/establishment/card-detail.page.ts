import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, effect, inject, input, signal } from '@angular/core';
import { IconComponent } from '../../shared/ui/icon.component';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { RouterLink } from '@angular/router';
import { ApiError, toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import { CardDetail, OperationResult, Transaction } from '../../core/loyalty-models';
import { Page } from '../../core/models';
import { NotificationService } from '../../core/notifications/notification.service';
import { CARD_STATUS_LABELS, formatBalance, formatLocalDateTime, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { ApplePassPreviewComponent } from '../../shared/ui/apple-pass-preview.component';
import { CardPreviewComponent } from '../../shared/ui/card-preview.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { PagerComponent } from '../../shared/ui/pager.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';
import { TransactionTableComponent } from '../../shared/ui/transaction-table.component';
import { CardOperationComponent } from './card-operation.component';
import { CardWalletComponent } from './card-wallet.component';
import { EstablishmentContext } from './establishment-context.service';
import { askReverse } from './reverse-dialog';

const LOT_LABELS: Record<string, string> = { OPEN: 'Disponível', CONSUMED: 'Utilizado', EXPIRED: 'Vencido', FORFEITED: 'Zerado na expiração' };

@Component({
  selector: 'app-card-detail-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent, 
    DatePipe,
    RouterLink,
    AlertComponent,
    CardPreviewComponent,
    ApplePassPreviewComponent,
    PageHeaderComponent,
    PagerComponent,
    SpinnerComponent,
    StatusBadgeComponent,
    TransactionTableComponent,
    CardOperationComponent,
    CardWalletComponent,
  ],
  template: `
    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (detail(); as d) {
      <app-page-header [title]="d.card.programName" [subtitle]="d.card.consumerName + ' · ' + d.card.displayCode"
                       [backLink]="ctx.base() + '/cartoes'" backLabel="Cartões">
        <a class="btn" [routerLink]="[ctx.base() + '/clientes', d.card.consumerId]"><app-icon name="user" /> Ver cliente</a>
        @if (ctx.can('CARDS_MANAGE')) {
          @if (d.card.status === 'ACTIVE') {
            <button class="btn" type="button" (click)="action('suspend')">Desativar</button>
          }
          @if (d.card.status === 'SUSPENDED' || d.card.status === 'EXPIRED') {
            <button class="btn btn-primary" type="button" (click)="action('reactivate')">Reativar</button>
          }
          @if (d.card.status !== 'CANCELLED') {
            <button class="btn btn-danger" type="button" (click)="action('cancel')">Cancelar cartão</button>
          }
        }
      </app-page-header>

      <div class="grid top">
        <section class="card">
          <h2>Cartão</h2>
          <dl class="details">
            <dt>Situação do cartão</dt><dd><app-badge [value]="d.card.status" [labelText]="statusLabel(d.card.status)" />
              @if (d.card.statusReason) { <span class="muted"> {{ d.card.statusReason }}</span> }</dd>
            <dt>Saldo</dt><dd><strong>{{ balance(d.card.balance) }}</strong></dd>
            <dt>Disponível agora</dt><dd>{{ balance(d.card.availableBalance) }}</dd>
            @if (d.card.nextBenefitExpiry; as n) {
              <dt>Próximo vencimento</dt><dd>{{ balance(n.amount) }} em {{ n.expiresAt | date: 'dd/MM/yyyy HH:mm' }}</dd>
            }
            <dt>Válido até</dt><dd>{{ local(d.card.validUntil) }} <span class="muted">({{ d.card.timeZone }})</span></dd>
            <dt>Regra</dt><dd>vence após {{ d.card.inactivityDays }} dias sem movimentação</dd>
            <dt>Última movimentação</dt><dd>{{ d.card.lastMovementAt ? (d.card.lastMovementAt | date: 'dd/MM/yyyy HH:mm') : '—' }}</dd>
            <dt>Emitido em</dt><dd>{{ d.card.issuedAt | date: 'dd/MM/yyyy' }}</dd>
            @if (d.card.programType === 'STAMPS') {
              <dt>Ciclos concluídos</dt><dd>{{ d.card.completedCycles }}</dd>
            }
          </dl>
          @if (d.card.status === 'EXPIRED') {
            <app-alert kind="warning">Cartão expirado por inatividade. A reativação dá uma nova validade a partir de hoje.</app-alert>
          }
        </section>
        <section class="preview">
          <div class="segmented" role="group" aria-label="Prévia por carteira">
            <button type="button" class="btn btn-sm" [class.btn-primary]="platform() === 'google'" [attr.aria-pressed]="platform() === 'google'"
                    (click)="platform.set('google')">Google Wallet</button>
            <button type="button" class="btn btn-sm" [class.btn-primary]="platform() === 'apple'" [attr.aria-pressed]="platform() === 'apple'"
                    (click)="platform.set('apple')">Apple Wallet</button>
          </div>
          @if (platform() === 'google') {
            <app-card-preview [design]="d.design" [programName]="d.card.programName" [establishmentName]="ctx.panel()?.name ?? ''"
                              [type]="d.card.programType" [balance]="d.card.availableBalance" [stampsRequired]="d.card.stampsRequired"
                              [code]="d.card.displayCode" [holder]="d.card.consumerName" />
          } @else {
            <app-apple-pass-preview [design]="d.design" [programName]="d.card.programName" [establishmentName]="ctx.panel()?.name ?? ''"
                                    [type]="d.card.programType" [balance]="d.card.availableBalance" [stampsRequired]="d.card.stampsRequired"
                                    [code]="d.card.displayCode" [holder]="d.card.consumerName" [status]="d.card.status" />
          }
        </section>
      </div>

      @if (ctx.can('TRANSACTIONS_REGISTER') && d.card.status === 'ACTIVE') {
        <section class="card">
          <h2>Nova movimentação</h2>
          <app-card-operation [establishmentId]="ctx.id()!" [detail]="d" channel="MANUAL" (done)="onDone($event)" />
        </section>
      }

      <section class="card">
        <h2>Carteiras digitais</h2>
        <app-card-wallet [establishmentId]="ctx.id()!" [cardId]="d.card.id" [cardActive]="d.card.status !== 'CANCELLED'"
                         [canManage]="ctx.can('CARDS_MANAGE')" />
      </section>

      @if (d.lots.length > 0) {
        <section class="card">
          <h2>Benefícios <small class="muted">(cada concessão tem validade própria)</small></h2>
          <div class="table-wrap">
            <table class="table responsive">
              <thead><tr><th>Concedido em</th><th>Original</th><th>Restante</th><th>Vence em</th><th>Situação</th></tr></thead>
              <tbody>
                @for (l of d.lots; track l.id) {
                  <tr>
                    <td data-label="Concedido em">{{ l.createdAt | date: 'dd/MM/yyyy' }}</td>
                    <td data-label="Original">{{ balance(l.originalAmount) }}</td>
                    <td data-label="Restante">{{ balance(l.remaining) }}</td>
                    <td data-label="Vence em">{{ l.expiresAt ? (l.expiresAt | date: 'dd/MM/yyyy HH:mm') : 'sem vencimento próprio' }}</td>
                    <td data-label="Situação">{{ lotLabel(l.status) }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>
      }

      <section class="card">
        <h2>Histórico</h2>
        @if (history(); as h) {
          <app-transaction-table [items]="h.content" [canReverse]="ctx.can('TRANSACTIONS_REVERSE') && d.card.status !== 'CANCELLED'"
                                 (reverse)="reverse($event)" />
          <app-pager [page]="h.page" [totalPages]="h.totalPages" (pageChange)="loadHistory($event)" />
        }
      </section>
    } @else {
      <app-spinner />
    }
  `,
  styles: `
    .top {
      grid-template-columns: minmax(0, 1.3fr) minmax(0, 1fr);
      align-items: start;
    }
    @media (max-width: 900px) {
      .top {
        grid-template-columns: 1fr;
      }
    }
    .preview {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.75rem;
    }
    .segmented {
      display: flex;
      gap: 0.25rem;
    }
  `,
})
export class CardDetailPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(LoyaltyApi);
  private readonly notifications = inject(NotificationService);
  private readonly dialogs = inject(ConfirmService);

  readonly cardId = input.required<string>();

  protected readonly detail = signal<CardDetail | null>(null);
  protected readonly history = signal<Page<Transaction> | null>(null);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly platform = signal<'google' | 'apple'>('google');

  constructor() {
    effect(() => {
      if (this.ctx.id() !== null) this.reload();
    });
  }

  private reload(): void {
    const eid = this.ctx.id()!;
    this.api.card(eid, Number(this.cardId())).subscribe({
      next: (d) => this.detail.set(d),
      error: (e) => this.error.set(toApiError(e)),
    });
    this.loadHistory(0);
  }

  protected loadHistory(page: number): void {
    const eid = this.ctx.id();
    if (eid === null) return;
    this.api.cardHistory(eid, Number(this.cardId()), page).subscribe((h) => this.history.set(h));
  }

  protected onDone(result: OperationResult): void {
    this.notifications.success(result.replayed ? 'Operação já registrada anteriormente.' : 'Operação registrada.');
    this.reload();
  }

  protected async action(kind: 'suspend' | 'reactivate' | 'cancel'): Promise<void> {
    const eid = this.ctx.id();
    const d = this.detail();
    if (eid === null || !d) return;
    const texts = {
      suspend: { title: 'Desativar o cartão?', message: 'Ele não aceitará movimentações até ser reativado.', confirmLabel: 'Desativar' },
      reactivate: { title: 'Reativar o cartão?', message: 'O cartão volta a aceitar movimentações.', confirmLabel: 'Reativar' },
      cancel: {
        title: 'Cancelar o cartão?',
        message: 'Cancelar é definitivo: o cartão nunca mais aceitará movimentações. O histórico é preservado.',
        confirmLabel: 'Cancelar cartão',
      },
    };
    const reason = await this.dialogs.ask({
      ...texts[kind],
      cancelLabel: 'Voltar',
      tone: kind === 'reactivate' ? 'primary' : 'danger',
      reason: kind === 'cancel' ? 'required' : 'optional',
    });
    if (reason === null) return;
    this.api.cardAction(eid, d.card.id, kind, reason.trim() || null).subscribe({
      next: () => {
        this.notifications.success('Cartão atualizado.');
        this.reload();
      },
      error: (e) => this.notifications.error(toApiError(e).message),
    });
  }

  protected reverse(t: Transaction): void {
    const eid = this.ctx.id();
    if (eid === null) return;
    askReverse(this.api, eid, t, this.notifications, this.dialogs, () => this.reload());
  }

  protected statusLabel(s: string): string {
    return label(CARD_STATUS_LABELS, s);
  }
  protected balance(v: number): string {
    return formatBalance(this.detail()?.card.programType, v);
  }
  protected local(v: string): string {
    return formatLocalDateTime(v);
  }
  protected lotLabel(s: string): string {
    return label(LOT_LABELS, s);
  }
}
