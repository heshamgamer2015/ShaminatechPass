import { ChangeDetectionStrategy, Component, computed, effect, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { ApiError, toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import { Program, ProgramType, Reward, Transaction } from '../../core/loyalty-models';
import { Page } from '../../core/models';
import { PROGRAM_TYPE_LABELS, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { EmptyStateComponent } from '../../shared/ui/empty-state.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { PagerComponent } from '../../shared/ui/pager.component';
import { TransactionTableComponent } from '../../shared/ui/transaction-table.component';
import { EstablishmentContext } from './establishment-context.service';

/** Uma recompensa como o empresário a entende: o que o cliente ganha, como conquista e se está valendo agora. */
interface RewardView {
  key: string;
  name: string;
  description: string | null;
  criterion: string;
  programId: number;
  programName: string;
  type: ProgramType;
  available: boolean;
  /** Motivo de estar indisponível (só quando não está disponível). */
  reason: string | null;
  /** Recompensas por pontos são gerenciadas uma a uma; as demais vêm da regra do programa. */
  managedIn: 'reward' | 'program';
}

type Filter = 'available' | 'unavailable' | 'all';

/**
 * Recompensas de todos os programas numa só lista (somente dados cadastrados — nada é estimado).
 * Carimbos e cashback têm a recompensa definida na regra do programa; pontos têm recompensas próprias, com custo.
 */
@Component({
  selector: 'app-rewards-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, AlertComponent, EmptyStateComponent, IconComponent, PageHeaderComponent, PagerComponent, TransactionTableComponent],
  template: `
    <app-page-header title="Recompensas" subtitle="O que seus clientes podem conquistar, como conquistam e os resgates já feitos" />

    @if (error(); as e) {
      <app-alert kind="error">{{ e.message }}</app-alert>
    } @else if (loaded()) {
      <div class="bar">
        <div class="segmented" role="group" aria-label="Filtrar recompensas">
          <button type="button" [attr.aria-pressed]="filter() === 'available'" (click)="filter.set('available')">
            Disponíveis <span class="count">{{ counts().available }}</span></button>
          <button type="button" [attr.aria-pressed]="filter() === 'unavailable'" (click)="filter.set('unavailable')">
            Indisponíveis <span class="count">{{ counts().unavailable }}</span></button>
          <button type="button" [attr.aria-pressed]="filter() === 'all'" (click)="filter.set('all')">
            Todas <span class="count">{{ counts().all }}</span></button>
        </div>
      </div>

      @if (visible().length === 0) {
        @if (counts().all === 0) {
          <app-empty-state icon="gift" title="Nenhuma recompensa ainda"
            description="As recompensas nascem dos programas: o prêmio do cartão de carimbos, o percentual do cashback ou as recompensas por pontos.">
            @if (ctx.can('PROGRAMS_MANAGE')) {
              <a class="btn btn-primary" [routerLink]="ctx.base() + '/programas/novo'"><app-icon name="plus" /> Criar programa</a>
            }
          </app-empty-state>
        } @else {
          <app-empty-state icon="gift" [title]="filter() === 'available' ? 'Nenhuma recompensa disponível agora' : 'Nenhuma recompensa indisponível'"
            [description]="filter() === 'available' ? 'Verifique se o programa está ativo e se a recompensa está ativada.' : 'Todas as recompensas cadastradas estão valendo.'" />
        }
      } @else {
        <ul class="rewards">
          @for (r of visible(); track r.key) {
            <li class="card reward" [class.off]="!r.available">
              <span class="head">
                <span class="badge" [class]="'badge type-' + r.type">{{ typeLabel(r.type) }}</span>
                @if (r.available) {
                  <span class="badge dot tone-success">Disponível</span>
                } @else {
                  <span class="badge dot tone-neutral">Indisponível</span>
                }
              </span>
              <strong class="name">{{ r.name }}</strong>
              @if (r.description) {
                <span class="muted small">{{ r.description }}</span>
              }
              <span class="criterion"><app-icon name="star" [size]="15" /> {{ r.criterion }}</span>
              @if (r.reason) {
                <span class="reason small">{{ r.reason }}</span>
              }
              <a class="program small" [routerLink]="[ctx.base() + '/programas', r.programId]">
                {{ r.managedIn === 'reward' ? 'Gerenciar no programa' : 'Regra do programa' }} {{ r.programName }}
                <app-icon name="chevron-right" [size]="14" /></a>
            </li>
          }
        </ul>
      }

      <section class="card history">
        <div class="section-head">
          <h2>Resgates realizados</h2>
          <span class="muted small">mais recentes primeiro</span>
        </div>
        @if (redemptions(); as h) {
          @if (h.content.length === 0) {
            <p class="muted">Nenhum resgate registrado ainda. Os resgates são feitos em “Registrar compra”.</p>
          } @else {
            <app-transaction-table [items]="h.content" [showCustomer]="true" [base]="ctx.base()" />
            <app-pager [page]="h.page" [totalPages]="h.totalPages" (pageChange)="loadRedemptions($event)" />
          }
        } @else {
          <span class="skeleton w-60"></span>
        }
      </section>
    } @else {
      <div class="rewards" aria-busy="true">
        @for (i of [1, 2, 3]; track i) {
          <div class="card"><span class="skeleton w-40"></span><br /><span class="skeleton"></span></div>
        }
      </div>
    }
  `,
  styles: `
    .bar {
      margin-bottom: 1rem;
    }
    .count {
      padding: 0 0.4rem;
      border-radius: 999px;
      background: var(--surface-muted);
      font-size: var(--text-xs);
    }
    .rewards {
      list-style: none;
      margin: 0;
      padding: 0;
      display: grid;
      gap: 1rem;
      grid-template-columns: repeat(auto-fill, minmax(min(100%, 280px), 1fr));
    }
    .reward {
      display: grid;
      align-content: start;
      gap: 0.4rem;
    }
    .reward.off {
      background: var(--surface-muted);
    }
    .reward.off .name {
      color: var(--text-muted);
    }
    .head {
      display: flex;
      justify-content: space-between;
      gap: 0.5rem;
      margin-bottom: 0.25rem;
    }
    .type-STAMPS,
    .type-POINTS,
    .type-CASHBACK,
    .type-VIP {
      background: var(--primary-soft);
      color: var(--primary-ink);
    }
    .name {
      font-size: var(--text-md);
      overflow-wrap: anywhere;
    }
    .criterion {
      display: inline-flex;
      align-items: center;
      gap: 0.35rem;
      font-weight: 500;
    }
    .reason {
      color: var(--warning);
    }
    .program {
      display: inline-flex;
      align-items: center;
      gap: 0.2rem;
      margin-top: 0.35rem;
      font-weight: 600;
      text-decoration: none;
    }
    .history {
      margin-top: 1.5rem;
    }
  `,
})
export class RewardsPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(LoyaltyApi);
  protected readonly rewards = signal<Reward[]>([]);
  protected readonly programs = signal<Program[]>([]);
  protected readonly redemptions = signal<Page<Transaction> | null>(null);
  protected readonly loaded = signal(false);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly filter = signal<Filter>('available');

  protected readonly all = computed<RewardView[]>(() => {
    const byId = new Map(this.programs().map((p) => [p.id, p]));
    const views: RewardView[] = [];
    for (const p of this.programs()) {
      if (p.type === 'STAMPS' && p.stampReward) {
        views.push(this.view(`s${p.id}`, p, p.stampReward, null, `Completar ${p.stampsRequired} carimbos`
          + (p.restartAfterRedeem ? ' (o cartão recomeça)' : ' (o cartão é concluído)'), true, 'program'));
      }
      if (p.type === 'CASHBACK' && p.cashbackPercent != null) {
        views.push(this.view(`c${p.id}`, p, `${p.cashbackPercent}% de volta em crédito`, 'Crédito para usar no estabelecimento; sem saque.',
          'A cada compra registrada', true, 'program'));
      }
    }
    for (const r of this.rewards()) {
      const p = byId.get(r.programId);
      if (!p) continue;
      views.push(this.view(`r${r.id}`, p, r.name, r.description, `${r.cost} pontos`, r.active, 'reward'));
    }
    return views.sort((a, b) => Number(b.available) - Number(a.available) || a.programName.localeCompare(b.programName));
  });

  protected readonly counts = computed(() => {
    const all = this.all();
    const available = all.filter((r) => r.available).length;
    return { all: all.length, available, unavailable: all.length - available };
  });

  protected readonly visible = computed(() => {
    const f = this.filter();
    return this.all().filter((r) => f === 'all' || (f === 'available' ? r.available : !r.available));
  });

  constructor() {
    effect(() => {
      const id = this.ctx.id();
      if (id === null) return;
      forkJoin({ rewards: this.api.rewards(id), programs: this.api.programs(id) }).subscribe({
        next: ({ rewards, programs }) => {
          this.rewards.set(rewards);
          this.programs.set(programs);
          this.loaded.set(true);
        },
        error: (e) => this.error.set(toApiError(e)),
      });
      this.loadRedemptions(0);
    });
  }

  protected loadRedemptions(page: number): void {
    const id = this.ctx.id();
    if (id === null) return;
    this.api.transactions(id, ['REDEEM'], page).subscribe({
      next: (p) => this.redemptions.set(p),
      error: () => this.redemptions.set({ content: [], page: 0, size: 0, totalElements: 0, totalPages: 0 }),
    });
  }

  protected typeLabel(t: string): string {
    return label(PROGRAM_TYPE_LABELS, t);
  }

  /** Disponível só quando a recompensa está ativa e o programa ativo, habilitado e operacional. */
  private view(key: string, p: Program, name: string, description: string | null, criterion: string, rewardActive: boolean,
               managedIn: 'reward' | 'program'): RewardView {
    let reason: string | null = null;
    if (p.status === 'ARCHIVED') reason = 'Programa encerrado.';
    else if (p.status === 'PAUSED') reason = 'Programa pausado.';
    else if (!p.typeAllowed) reason = 'Tipo de fidelidade não habilitado pela ShaminaTech.';
    else if (!rewardActive) reason = 'Recompensa desativada.';
    return {
      key, name, description, criterion, programId: p.id, programName: p.name, type: p.type, available: reason === null, reason, managedIn,
    };
  }
}
