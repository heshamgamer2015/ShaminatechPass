import { ChangeDetectionStrategy, Component, computed, effect, inject, signal } from '@angular/core';
import { IconComponent } from '../../shared/ui/icon.component';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiError, toApiError } from '../../core/api/api-error';
import { EstablishmentApi } from '../../core/api/establishment-api.service';
import { NotificationService } from '../../core/notifications/notification.service';
import { PROGRAM_TYPE_LABELS, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { FieldErrorComponent } from '../../shared/ui/field-error.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';
import { EstablishmentContext } from './establishment-context.service';

@Component({
  selector: 'app-settings-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, AlertComponent, FieldErrorComponent, IconComponent, PageHeaderComponent, StatusBadgeComponent],
  template: `
    @if (ctx.panel(); as p) {
      <app-page-header title="Configurações" subtitle="Dados do estabelecimento e limites definidos pela ShaminaTech" />

      <div class="grid">
        <section class="card">
          <h2>Seu estabelecimento</h2>
          <dl class="details">
            <dt>Situação</dt><dd><app-badge [value]="p.status" /></dd>
            <dt>Identificador</dt><dd class="mono">{{ p.slug }}</dd>
            <dt>Acesso</dt><dd>Conta empresarial única</dd>
          </dl>
        </section>
        <section class="card">
          <h2 class="with-icon"><app-icon name="lock" [size]="16" /> Limites definidos pela ShaminaTech</h2>
          <dl class="details">
            <dt>Clientes ativos</dt><dd>até {{ p.policy.maxActiveConsumers }}</dd>
            <dt>Tipos de cartão</dt><dd>{{ types() || 'nenhum habilitado' }}</dd>
            <dt>Inatividade padrão</dt><dd>{{ p.policy.defaultInactivityDays }} dias</dd>
            <dt>Fuso horário</dt><dd>{{ p.policy.timeZone }}</dd>
          </dl>
          <p class="note"><app-icon name="info" [size]="16" /><span>Somente leitura. Para alterar limites ou tipos de cartão, fale com a ShaminaTech.</span></p>
        </section>
      </div>

      @if (canEdit()) {
        <form class="card form" [formGroup]="form" (ngSubmit)="save()" novalidate>
          <div class="section-head">
            <h2>Dados de contato</h2>
            @if (form.dirty) { <span class="badge dot tone-warning">Alterações não salvas</span> }
          </div>
          @if (error(); as e) {
            <app-alert kind="error">{{ e.message }}</app-alert>
          }
          <div class="field">
            <label for="name">Nome</label>
            <input id="name" class="input" formControlName="name" maxlength="150" />
            <app-field-error [server]="error()?.fieldErrors?.['name']"
                             [local]="form.controls.name.touched && form.controls.name.invalid ? 'Informe o nome.' : null" />
          </div>
          <div class="form-row">
            <div class="field">
              <label for="contactEmail">E-mail de contato</label>
              <input id="contactEmail" class="input" type="email" formControlName="contactEmail" />
              <app-field-error [server]="error()?.fieldErrors?.['contactEmail']"
                               [local]="form.controls.contactEmail.touched && form.controls.contactEmail.invalid ? 'E-mail inválido.' : null" />
            </div>
            <div class="field">
              <label for="contactPhone">Telefone</label>
              <input id="contactPhone" class="input" type="tel" formControlName="contactPhone" maxlength="30" />
              <app-field-error [server]="error()?.fieldErrors?.['contactPhone']" />
            </div>
          </div>
          <div class="form-footer">
            <button class="btn btn-primary" type="submit" [disabled]="saving() || form.pristine">
              {{ saving() ? 'Salvando…' : 'Salvar alterações' }}
            </button>
          </div>
        </form>
      }
    }
  `,
  styles: `
    .with-icon {
      display: flex;
      align-items: center;
      gap: 0.4rem;
    }
  `,
})
export class SettingsPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(EstablishmentApi);
  private readonly notifications = inject(NotificationService);

  protected readonly canEdit = computed(() => this.ctx.panel() !== null && this.ctx.can('ESTABLISHMENT_EDIT'));
  protected readonly types = computed(() =>
    (this.ctx.panel()?.policy.allowedProgramTypes ?? []).map((t) => label(PROGRAM_TYPE_LABELS, t)).join(', '),
  );
  protected readonly saving = signal(false);
  protected readonly error = signal<ApiError | null>(null);
  protected readonly form = inject(NonNullableFormBuilder).group({
    name: ['', [Validators.required, Validators.maxLength(150)]],
    contactEmail: ['', Validators.email],
    contactPhone: [''],
  });

  constructor() {
    effect(() => {
      const p = this.ctx.panel();
      if (p) {
        this.form.reset({ name: p.name, contactEmail: p.contactEmail ?? '', contactPhone: p.contactPhone ?? '' });
      }
    });
  }

  protected save(): void {
    const id = this.ctx.id();
    if (id === null) return;
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    this.saving.set(true);
    this.error.set(null);
    this.api.update(id, { name: v.name, contactEmail: v.contactEmail || null, contactPhone: v.contactPhone || null }).subscribe({
      next: (panel) => {
        this.ctx.update(panel);
        this.saving.set(false);
        this.notifications.success('Dados atualizados.');
      },
      error: (e) => {
        this.error.set(toApiError(e));
        this.saving.set(false);
      },
    });
  }
}
