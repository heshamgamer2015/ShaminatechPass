import { ChangeDetectionStrategy, Component, computed, effect, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import { Design, Program } from '../../core/loyalty-models';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { NotificationService } from '../../core/notifications/notification.service';
import { ApplePassPreviewComponent } from '../../shared/ui/apple-pass-preview.component';
import { CardPreviewComponent } from '../../shared/ui/card-preview.component';
import { EmptyStateComponent } from '../../shared/ui/empty-state.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { EstablishmentContext } from './establishment-context.service';

const MAX_BYTES = 1024 * 1024;
const HEX = /^#[0-9a-fA-F]{6}$/;

/**
 * Personalização do cartão: cores e textos (salvos juntos) e imagens (enviadas na hora, reprocessadas pelo servidor).
 * A prévia é uma representação aproximada — a aparência final depende da carteira e do aparelho do cliente.
 */
@Component({
  selector: 'app-branding-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, CardPreviewComponent, ApplePassPreviewComponent, EmptyStateComponent, IconComponent, PageHeaderComponent],
  template: `
    <app-page-header title="Personalização" subtitle="A identidade visual que seus clientes verão no cartão e na página de cadastro" />

    @if (programs().length === 0) {
      <app-empty-state icon="palette" title="Nenhum programa para personalizar" description="Crie um programa de fidelidade para personalizar o cartão." />
    } @else {
      <div class="toolbar">
        <label class="sr-only" for="program">Programa</label>
        <select id="program" class="select" [ngModel]="selectedId()" (ngModelChange)="choose($event)">
          @for (p of programs(); track p.id) { <option [ngValue]="p.id">{{ p.name }}</option> }
        </select>
      </div>

      @if (program(); as p) {
        <div class="layout">
          <div class="col">
            <form class="card form" (ngSubmit)="save()" novalidate>
              <div class="section-head">
                <h2>Cores e textos</h2>
                @if (dirty()) {
                  <span class="badge dot tone-warning">Alterações não salvas</span>
                }
              </div>
              <div class="form-row">
                <div class="field">
                  <label for="brandColorText">Cor principal</label>
                  <div class="color">
                    <input type="color" [ngModel]="safe(brandColor(), '#F43F5E')" (ngModelChange)="brandColor.set($event)" name="brandColor"
                           aria-label="Escolher cor principal" />
                    <input id="brandColorText" class="input mono" [class.invalid]="!validBrand()" [ngModel]="brandColor()"
                           (ngModelChange)="brandColor.set($event)" name="brandColorText" maxlength="7" aria-describedby="brand-err" />
                  </div>
                  @if (!validBrand()) { <span id="brand-err" class="field-error">Use o formato #RRGGBB, por exemplo #F43F5E.</span> }
                </div>
                <div class="field">
                  <label for="textColorText">Cor do texto</label>
                  <div class="color">
                    <input type="color" [ngModel]="safe(textColor(), '#FFFFFF')" (ngModelChange)="textColor.set($event)" name="textColor"
                           aria-label="Escolher cor do texto" />
                    <input id="textColorText" class="input mono" [class.invalid]="!validText()" [ngModel]="textColor()"
                           (ngModelChange)="textColor.set($event)" name="textColorText" maxlength="7" aria-describedby="text-err" />
                  </div>
                  @if (!validText()) { <span id="text-err" class="field-error">Use o formato #RRGGBB, por exemplo #FFFFFF.</span> }
                </div>
              </div>
              @if (ratio(); as r) {
                <div class="contrast" [class.bad]="r < 4.5">
                  <span class="sample" [style.background]="brandColor()" [style.color]="textColor()" aria-hidden="true">Aa</span>
                  <span>
                    <strong>Contraste {{ r.toFixed(1).replace('.', ',') }}:1</strong>
                    @if (r >= 4.5) {
                      <span class="badge tone-success">Boa leitura</span>
                    } @else if (r >= 3) {
                      <span class="badge tone-warning">Só para textos grandes</span>
                    } @else {
                      <span class="badge tone-danger">Difícil de ler</span>
                    }
                    <br /><span class="muted small">Recomendado 4,5:1 ou mais. Na página de cadastro o Pass troca para preto ou branco quando o contraste for baixo.</span>
                  </span>
                </div>
              }
              <div class="field">
                <label for="cardMessage">Mensagem do cartão <span class="muted">(opcional)</span></label>
                <input id="cardMessage" class="input" [ngModel]="cardMessage()" (ngModelChange)="cardMessage.set($event)" name="cardMessage"
                       maxlength="200" placeholder="Ex.: Obrigado pela preferência!" />
                <span class="hint">{{ cardMessage().length }}/200 · aparece no cartão e na página de cadastro.</span>
              </div>
              <div class="field">
                <label for="rewardInfo">Informações da recompensa <span class="muted">(opcional)</span></label>
                <textarea id="rewardInfo" class="input" rows="2" [ngModel]="rewardInfo()" (ngModelChange)="rewardInfo.set($event)" name="rewardInfo"
                          maxlength="300" placeholder="Ex.: Complete 10 carimbos e ganhe um café."></textarea>
                <span class="hint">{{ rewardInfo().length }}/300</span>
              </div>
              <div class="form-footer">
                <button class="btn btn-primary" type="submit" [disabled]="saving() || !dirty() || !validBrand() || !validText()">
                  {{ saving() ? 'Salvando…' : 'Salvar aparência' }}</button>
                @if (dirty()) {
                  <button class="btn btn-ghost" type="button" (click)="choose(p.id)" [disabled]="saving()">Descartar</button>
                }
              </div>
            </form>

            <section class="card images">
              <h2>Imagens</h2>
              <p class="hint">PNG ou JPEG, até 1 MB, de 64 a 4096 px. Cada imagem é enviada na hora e reprocessada pelo servidor
                (metadados removidos).</p>
              @for (slot of slots; track slot.key) {
                <div class="image-row">
                  <span class="thumb" [class.wide]="slot.key === 'hero'">
                    @if (imageUrl(p, slot.key); as url) {
                      <img [src]="url" [alt]="slot.label + ' atual'" />
                    } @else {
                      <app-icon name="palette" [size]="20" />
                    }
                  </span>
                  <span class="image-text">
                    <strong>{{ slot.label }}</strong>
                    <span class="muted small">{{ slot.hint }}</span>
                    <span class="actions">
                      <label class="btn btn-sm" [class.disabled]="uploading() === slot.key">
                        <app-icon name="download" [size]="16" />
                        {{ uploading() === slot.key ? 'Enviando…' : (imageUrl(p, slot.key) ? 'Trocar' : 'Enviar') }}
                        <input class="sr-only" type="file" accept="image/png,image/jpeg" [attr.aria-label]="'Enviar ' + slot.label"
                               [disabled]="uploading() !== null" (change)="upload(slot.key, $event)" />
                      </label>
                      @if (imageUrl(p, slot.key)) {
                        <button class="btn btn-sm btn-ghost" type="button" (click)="remove(slot.key)">Remover</button>
                      }
                    </span>
                  </span>
                </div>
              }
            </section>
          </div>

          <section class="preview" aria-label="Prévia do cartão">
            <div class="segmented" role="group" aria-label="Prévia por carteira">
              <button type="button" [attr.aria-pressed]="platform() === 'google'" (click)="platform.set('google')">Google Wallet</button>
              <button type="button" [attr.aria-pressed]="platform() === 'apple'" (click)="platform.set('apple')">Apple Wallet</button>
            </div>
            @if (platform() === 'google') {
              <app-card-preview [design]="previewDesign()" [programName]="p.name" [establishmentName]="ctx.panel()?.name ?? ''"
                                [type]="p.type" [balance]="previewBalance(p)" [stampsRequired]="p.stampsRequired" holder="Nome do cliente" />
            } @else {
              <app-apple-pass-preview [design]="previewDesign()" [programName]="p.name" [establishmentName]="ctx.panel()?.name ?? ''"
                                      [type]="p.type" [balance]="previewBalance(p)" [stampsRequired]="p.stampsRequired" holder="Nome do cliente" />
            }
            <p class="approx"><app-icon name="info" [size]="16" />
              <span><strong>Representação aproximada.</strong> O cartão real é desenhado pela carteira do cliente e pode variar
                conforme o aparelho. Saldo e nome são exemplos.</span></p>
            @if (p.design.walletNotes.length > 0) {
              <details class="notes">
                <summary>Como as carteiras exibem o cartão</summary>
                <ul>@for (n of p.design.walletNotes; track n) { <li>{{ n }}</li> }</ul>
              </details>
            }
          </section>
        </div>
      }
    }
  `,
  styles: `
    .layout {
      display: grid;
      grid-template-columns: minmax(0, 1.25fr) minmax(0, 1fr);
      gap: 1.25rem;
      align-items: start;
    }
    .col {
      display: grid;
      gap: 1rem;
      min-width: 0;
    }
    @media (max-width: 960px) {
      .layout {
        grid-template-columns: 1fr;
      }
      .preview {
        order: -1;
      }
    }
    .preview {
      position: sticky;
      top: calc(60px + 1.5rem);
      display: grid;
      gap: 1rem;
      justify-items: center;
    }
    @media (max-width: 960px) {
      .preview {
        position: static;
      }
    }
    .contrast {
      display: flex;
      gap: 0.85rem;
      align-items: center;
      padding: 0.75rem;
      border-radius: var(--radius-sm);
      background: var(--surface-muted);
      font-size: var(--text-sm);
    }
    .contrast.bad {
      background: var(--warning-soft);
    }
    .sample {
      display: grid;
      place-items: center;
      width: 44px;
      height: 44px;
      flex: none;
      border-radius: 10px;
      font-weight: 750;
      font-size: 1.1rem;
      border: 1px solid rgb(0 0 0 / 8%);
    }
    .images {
      display: grid;
      gap: 0.75rem;
    }
    .images h2 {
      margin: 0;
    }
    .image-row {
      display: flex;
      gap: 1rem;
      align-items: center;
      padding-top: 0.75rem;
      border-top: 1px solid var(--border);
    }
    .thumb {
      display: grid;
      place-items: center;
      width: 64px;
      height: 64px;
      flex: none;
      overflow: hidden;
      border-radius: 12px;
      border: 1px dashed var(--border-strong);
      background: var(--surface-muted);
      color: var(--text-subtle);
    }
    .thumb.wide {
      width: 96px;
    }
    .thumb img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .image-text {
      display: grid;
      gap: 0.25rem;
      min-width: 0;
    }
    label.btn.disabled {
      opacity: 0.6;
      pointer-events: none;
    }
    .approx {
      display: flex;
      gap: 0.5rem;
      max-width: 380px;
      margin: 0;
      font-size: var(--text-sm);
      color: var(--text-muted);
    }
    .notes {
      width: 100%;
      max-width: 380px;
      padding: 0.75rem 0.9rem;
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
      background: var(--surface);
      font-size: var(--text-sm);
    }
    .notes summary {
      cursor: pointer;
      font-weight: 600;
    }
    ul {
      margin: 0.4rem 0 0;
      padding-left: 1.1rem;
      color: var(--text-muted);
    }
  `,
})
export class BrandingPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(LoyaltyApi);
  private readonly router = inject(Router);
  private readonly notifications = inject(NotificationService);
  private readonly dialogs = inject(ConfirmService);
  /** ?programa=ID */
  readonly programa = input<string>();
  protected readonly slots = [
    { key: 'logo' as const, label: 'Logotipo', hint: 'Quadrado, mínimo 660 × 660 px.' },
    { key: 'hero' as const, label: 'Imagem de destaque', hint: '1032 × 812 px recomendado.' },
  ];
  protected readonly programs = signal<Program[]>([]);
  protected readonly selectedId = signal<number | null>(null);
  protected readonly program = computed(() => this.programs().find((p) => p.id === this.selectedId()) ?? null);
  protected readonly saving = signal(false);
  protected readonly uploading = signal<'logo' | 'hero' | null>(null);
  protected readonly platform = signal<'google' | 'apple'>('google');
  protected readonly brandColor = signal('#F43F5E');
  protected readonly textColor = signal('#FFFFFF');
  protected readonly cardMessage = signal('');
  protected readonly rewardInfo = signal('');
  protected readonly validBrand = computed(() => HEX.test(this.brandColor()));
  protected readonly validText = computed(() => HEX.test(this.textColor()));
  protected readonly ratio = computed(() => (this.validBrand() && this.validText() ? contrast(this.brandColor(), this.textColor()) : null));
  protected readonly dirty = computed(() => {
    const d = this.program()?.design;
    if (!d) return false;
    return (
      this.brandColor().toLowerCase() !== d.brandColor.toLowerCase() ||
      this.textColor().toLowerCase() !== d.textColor.toLowerCase() ||
      this.cardMessage() !== (d.cardMessage ?? '') ||
      this.rewardInfo() !== (d.rewardInfo ?? '')
    );
  });
  protected readonly previewDesign = computed<Design>(() => {
    const p = this.program();
    return {
      brandColor: this.validBrand() ? this.brandColor() : '#F43F5E',
      textColor: this.validText() ? this.textColor() : '#FFFFFF',
      cardMessage: this.cardMessage() || null,
      rewardInfo: this.rewardInfo() || null,
      logoUrl: p?.design.logoUrl ?? null,
      heroUrl: p?.design.heroUrl ?? null,
      walletNotes: [],
    };
  });

  constructor() {
    effect(() => {
      const id = this.ctx.id();
      if (id === null) return;
      this.api.programs(id).subscribe({
        next: (list) => {
          const active = list.filter((p) => p.status !== 'ARCHIVED');
          this.programs.set(active);
          const wanted = Number(this.programa());
          this.choose(active.some((p) => p.id === wanted) ? wanted : (active[0]?.id ?? null));
        },
        error: (e) => this.notifications.error(toApiError(e).message),
      });
    });
  }

  protected choose(id: number | null): void {
    this.selectedId.set(id);
    const p = this.program();
    if (!p) return;
    this.brandColor.set(p.design.brandColor);
    this.textColor.set(p.design.textColor);
    this.cardMessage.set(p.design.cardMessage ?? '');
    this.rewardInfo.set(p.design.rewardInfo ?? '');
    void this.router.navigate([], { queryParams: { programa: id }, replaceUrl: true });
  }

  private replace(updated: Program): void {
    this.programs.update((list) => list.map((p) => (p.id === updated.id ? updated : p)));
  }

  protected save(): void {
    const eid = this.ctx.id();
    const p = this.program();
    if (eid === null || !p || this.saving() || !this.validBrand() || !this.validText()) return;
    this.saving.set(true);
    this.api
      .updateDesign(eid, p.id, {
        brandColor: this.brandColor(),
        textColor: this.textColor(),
        cardMessage: this.cardMessage() || null,
        rewardInfo: this.rewardInfo() || null,
      })
      .subscribe({
        next: (updated) => {
          this.saving.set(false);
          this.replace(updated);
          this.notifications.success('Aparência salva. Os cartões nas carteiras são atualizados automaticamente.');
        },
        error: (e) => {
          this.saving.set(false);
          this.notifications.error(toApiError(e).message);
        },
      });
  }

  protected upload(slot: 'logo' | 'hero', event: Event): void {
    const eid = this.ctx.id();
    const p = this.program();
    const inputEl = event.target as HTMLInputElement;
    const file = inputEl.files?.[0];
    if (eid === null || !p || !file) return;
    if (!['image/png', 'image/jpeg'].includes(file.type)) {
      this.notifications.error('Envie uma imagem PNG ou JPEG.');
      inputEl.value = '';
      return;
    }
    if (file.size > MAX_BYTES) {
      this.notifications.error('A imagem deve ter no máximo 1 MB.');
      inputEl.value = '';
      return;
    }
    this.uploading.set(slot);
    this.api.uploadImage(eid, p.id, slot, file).subscribe({
      next: (updated) => {
        this.uploading.set(null);
        this.replace(updated);
        inputEl.value = '';
        this.notifications.success('Imagem enviada.');
      },
      error: (e) => {
        this.uploading.set(null);
        inputEl.value = '';
        this.notifications.error(toApiError(e).message);
      },
    });
  }

  protected async remove(slot: 'logo' | 'hero'): Promise<void> {
    const eid = this.ctx.id();
    const p = this.program();
    if (eid === null || !p) return;
    const ok = await this.dialogs.confirm({
      title: slot === 'logo' ? 'Remover o logotipo?' : 'Remover a imagem de destaque?',
      message: 'O cartão volta a usar a aparência sem esta imagem. Você pode enviar outra depois.',
      confirmLabel: 'Remover',
      tone: 'danger',
    });
    if (!ok) return;
    this.api.removeImage(eid, p.id, slot).subscribe({
      next: (updated) => {
        this.replace(updated);
        this.notifications.success('Imagem removida.');
      },
      error: (e) => this.notifications.error(toApiError(e).message),
    });
  }

  protected imageUrl(p: Program, slot: 'logo' | 'hero'): string | null {
    return slot === 'logo' ? p.design.logoUrl : p.design.heroUrl;
  }

  /** O seletor nativo de cor só aceita #RRGGBB válido. */
  protected safe(color: string, fallback: string): string {
    return HEX.test(color) ? color : fallback;
  }

  protected previewBalance(p: Program): number {
    return p.type === 'STAMPS' ? Math.min(3, p.stampsRequired ?? 3) : p.type === 'CASHBACK' ? 12.5 : 120;
  }
}

function luminance(hex: string): number {
  const [r, g, b] = [1, 3, 5].map((i) => {
    const c = parseInt(hex.slice(i, i + 2), 16) / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

function contrast(a: string, b: string): number {
  const [l1, l2] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (l1 + 0.05) / (l2 + 0.05);
}
