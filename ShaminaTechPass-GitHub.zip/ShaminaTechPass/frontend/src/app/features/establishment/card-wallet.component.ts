import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, effect, inject, input, signal } from '@angular/core';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { toApiError } from '../../core/api/api-error';
import { WalletApi } from '../../core/api/wallet-api.service';
import { CardWallet } from '../../core/loyalty-models';
import { NotificationService } from '../../core/notifications/notification.service';
import { WALLET_REMOTE_STATE_LABELS, WALLET_SYNC_LABELS, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { StatusBadgeComponent } from '../../shared/ui/status-badge.component';

/**
 * Carteiras digitais no detalhe do cartão: Google Wallet e Apple Wallet (estado de emissão/atualização e reenvio) e
 * os links de distribuição — um único link, em que o cliente escolhe a carteira do próprio celular.
 */
@Component({
  selector: 'app-card-wallet',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe, AlertComponent, StatusBadgeComponent],
  template: `
    @if (data(); as w) {
      @if (!w.available && !w.appleAvailable) {
        <app-alert kind="info">Nenhuma carteira digital (Google Wallet ou Apple Wallet) está configurada pela ShaminaTech.</app-alert>
      } @else {
        <div class="providers">
          <section class="provider" aria-labelledby="google-title">
            <h3 id="google-title">Google Wallet <small class="muted">Android</small></h3>
            @if (!w.available) {
              <p class="muted">Não configurado pela ShaminaTech.</p>
            } @else if (w.pass; as p) {
              <dl class="details">
                <dt>Sincronização</dt>
                <dd><app-badge [value]="p.status" [labelText]="syncLabel(p.status)" />
                  @if (p.remoteState) { <span class="muted"> · {{ remoteLabel(p.remoteState) }}</span> }</dd>
                <dt>Última confirmação</dt><dd>{{ p.lastSyncedAt ? (p.lastSyncedAt | date: 'dd/MM/yyyy HH:mm:ss') : '—' }}</dd>
                @if (p.status === 'FAILED' || p.status === 'PENDING') {
                  <dt>Tentativas</dt><dd>{{ p.attempts }}{{ p.nextAttemptAt ? ' · próxima ' + (p.nextAttemptAt | date: 'dd/MM HH:mm') : '' }}</dd>
                }
              </dl>
              @if (p.status === 'FAILED') {
                <app-alert kind="error">
                  O Google Wallet não confirmou a última atualização ({{ p.lastError }}). O saldo no Pass está correto; o celular do
                  cliente pode estar mostrando um valor antigo.
                  @if (!p.nextAttemptAt) { Nova tentativa automática não será feita: use “Reenviar”. }
                </app-alert>
              } @else if (p.status === 'PENDING' || p.status === 'SYNCING') {
                <app-alert kind="info">Atualização na fila de envio ao Google Wallet.</app-alert>
              }
              @if (canManage() && p.retryAllowed) {
                <button class="btn btn-sm" type="button" [disabled]="busy()" (click)="retry(p.id)">Reenviar ao Google</button>
              }
            } @else {
              <p class="muted">O cartão ainda não foi enviado ao Google Wallet.</p>
            }
          </section>

          <section class="provider" aria-labelledby="apple-title">
            <h3 id="apple-title">Apple Wallet <small class="muted">iPhone</small></h3>
            @if (w.appleAvailable && w.appleMissing.length > 0) {
              <!-- Modo de homologação local: o backend informa que o cartão Apple não se atualiza sozinho. -->
              <p class="muted small">{{ w.appleMissing[0] }}</p>
            }
            @if (!w.appleAvailable) {
              <p class="muted">Não configurado pela ShaminaTech.</p>
            } @else if (w.apple; as p) {
              <dl class="details">
                <dt>Atualização</dt>
                <dd><app-badge [value]="p.status" [labelText]="syncLabel(p.status)" />
                  @if (p.remoteState) { <span class="muted"> · {{ remoteLabel(p.remoteState) }}</span> }</dd>
                <dt>Aparelhos</dt><dd>{{ w.appleDevices }} {{ w.appleDevices === 1 ? 'iPhone registrado' : 'iPhones registrados' }}</dd>
                <dt>Último aviso</dt><dd>{{ p.lastSyncedAt ? (p.lastSyncedAt | date: 'dd/MM/yyyy HH:mm:ss') : '—' }}</dd>
              </dl>
              @if (p.status === 'FAILED') {
                <app-alert kind="error">
                  A Apple não confirmou o aviso de atualização ({{ p.lastError }}). O saldo no Pass está correto; o iPhone busca a
                  versão nova quando receber o aviso.
                  @if (!p.nextAttemptAt) { Nova tentativa automática não será feita: use “Reenviar”. }
                </app-alert>
              }
              @if (canManage() && p.retryAllowed) {
                <button class="btn btn-sm" type="button" [disabled]="busy()" (click)="retry(p.id)">Reenviar aviso à Apple</button>
              }
            } @else {
              <p class="muted">O cartão ainda não foi preparado para o Apple Wallet.</p>
            }
          </section>
        </div>

        <div class="actions">
          @if (canManage() && cardActive()) {
            <button class="btn btn-primary" type="button" [disabled]="busy()" (click)="create()">
              {{ w.pass || w.apple ? 'Gerar novo link para o cliente' : 'Adicionar à carteira digital (gerar link)' }}
            </button>
          }
          <button class="btn btn-ghost" type="button" (click)="reload()">Atualizar</button>
        </div>

        @if (createdUrl(); as url) {
          <div class="link">
            <app-alert kind="success">Envie este link ao cliente (ele vale até {{ createdExpires() | date: 'dd/MM/yyyy HH:mm' }}). Na
              página do link o cliente escolhe Google Wallet (Android) ou Apple Wallet (iPhone). Ele só aparece agora: se perder,
              gere outro.</app-alert>
            <div class="link-body">
              <figure class="qr">
                <img [src]="linkQr(url)" alt="QR Code do link do cartão" width="180" height="180" />
                <figcaption class="muted small">No balcão (ou na troca de celular): o cliente escaneia com o celular em que
                  quer guardar o cartão. Mesmo cartão, mesmo saldo.</figcaption>
              </figure>
              <div class="input-group">
                <input class="input mono" [value]="url" readonly aria-label="Link para o cliente" (focus)="select($event)" />
                <button class="btn" type="button" (click)="copy(url)">Copiar</button>
              </div>
            </div>
          </div>
        }

        @if (w.links.length > 0) {
          <h3>Links enviados</h3>
          <div class="table-wrap">
            <table class="table responsive">
              <thead><tr><th>Criado</th><th>Expira</th><th>Acessos</th><th>Situação</th><th></th></tr></thead>
              <tbody>
                @for (l of w.links; track l.id) {
                  <tr>
                    <td data-label="Criado">{{ l.createdAt | date: 'dd/MM/yyyy HH:mm' }}</td>
                    <td data-label="Expira">{{ l.expiresAt | date: 'dd/MM/yyyy HH:mm' }}</td>
                    <td data-label="Acessos">{{ l.useCount }}</td>
                    <td data-label="Situação">{{ l.revokedAt ? 'Revogado' : l.usable ? 'Válido' : 'Expirado' }}</td>
                    <td data-label="">
                      @if (l.usable && canManage()) {
                        <button class="btn btn-sm btn-danger" type="button" (click)="revoke(l.id)">Revogar</button>
                      }
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      }
    }
  `,
  styles: `
    .link-body {
      display: grid;
      gap: 0.75rem;
    }
    .qr {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 0.75rem;
      margin: 0;
    }
    .qr img {
      width: 180px;
      height: 180px;
      padding: 6px;
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
      background: #fff;
    }
    .qr figcaption {
      flex: 1;
      min-width: 12rem;
    }
    .providers {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 1rem;
    }
    .provider {
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
      padding: 0.75rem 1rem;
    }
    .provider h3 {
      margin: 0 0 0.5rem;
    }
    .actions {
      margin-top: 1rem;
    }
    .link {
      display: grid;
      gap: 0.5rem;
      margin: 1rem 0;
    }
    h3 {
      margin-top: 1rem;
      font-size: 1rem;
    }
    app-alert {
      display: block;
      margin: 0.5rem 0;
    }
  `,
})
export class CardWalletComponent {
  private readonly api = inject(WalletApi);
  private readonly notifications = inject(NotificationService);
  private readonly dialogs = inject(ConfirmService);

  readonly establishmentId = input.required<number>();
  readonly cardId = input.required<number>();
  readonly cardActive = input(true);
  readonly canManage = input(false);

  protected readonly data = signal<CardWallet | null>(null);
  protected readonly busy = signal(false);
  protected readonly createdUrl = signal<string | null>(null);
  protected readonly createdExpires = signal<string | null>(null);

  constructor() {
    effect(() => {
      this.cardId();
      this.reload();
    });
  }

  reload(): void {
    this.api.cardWallet(this.establishmentId(), this.cardId()).subscribe({
      next: (w) => this.data.set(w),
      error: (e) => this.notifications.error(toApiError(e).message),
    });
  }

  protected create(): void {
    this.busy.set(true);
    this.api.createLink(this.establishmentId(), this.cardId()).subscribe({
      next: (r) => {
        this.busy.set(false);
        this.createdUrl.set(r.url);
        this.createdExpires.set(r.expiresAt);
        this.data.set(r.wallet);
        // A emissão no Google ocorre logo após a resposta: recarrega para mostrar a confirmação.
        setTimeout(() => this.reload(), 2500);
      },
      error: (e) => {
        this.busy.set(false);
        this.notifications.error(toApiError(e).message);
      },
    });
  }

  protected retry(passId: number): void {
    this.busy.set(true);
    this.api.retry(this.establishmentId(), passId).subscribe({
      next: (w) => {
        this.busy.set(false);
        this.data.set(w);
        this.notifications.success('Reenvio solicitado.');
        setTimeout(() => this.reload(), 2500);
      },
      error: (e) => {
        this.busy.set(false);
        this.notifications.error(toApiError(e).message);
      },
    });
  }

  protected async revoke(linkId: number): Promise<void> {
    const ok = await this.dialogs.confirm({
      title: 'Revogar este link?',
      message: 'O cliente não conseguirá mais usá-lo para adicionar o cartão à carteira.',
      confirmLabel: 'Revogar',
      tone: 'danger',
    });
    if (!ok) return;
    this.api.revoke(this.establishmentId(), linkId).subscribe({
      next: (w) => this.data.set(w),
      error: (e) => this.notifications.error(toApiError(e).message),
    });
  }

  /** QR Code do link (o token é o final do endereço; o backend só gera para link válido). */
  protected linkQr(url: string): string {
    return `/api/public/wallet-links/${url.substring(url.lastIndexOf('/') + 1)}/qr`;
  }

  protected async copy(url: string): Promise<void> {
    try {
      await navigator.clipboard.writeText(url);
      this.notifications.success('Link copiado.');
    } catch {
      this.notifications.error('Não foi possível copiar; selecione o texto e copie manualmente.');
    }
  }

  protected select(event: Event): void {
    (event.target as HTMLInputElement).select();
  }

  protected syncLabel(s: string): string {
    return label(WALLET_SYNC_LABELS, s);
  }

  protected remoteLabel(s: string): string {
    return label(WALLET_REMOTE_STATE_LABELS, s);
  }
}
