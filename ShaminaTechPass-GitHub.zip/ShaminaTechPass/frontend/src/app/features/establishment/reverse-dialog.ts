import { toApiError } from '../../core/api/api-error';
import { LoyaltyApi } from '../../core/api/loyalty-api.service';
import { Transaction } from '../../core/loyalty-models';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { NotificationService } from '../../core/notifications/notification.service';
import { TRANSACTION_LABELS, label } from '../../shared/labels';

/**
 * Estorno: pede o motivo, confirma e envia com uma chave de idempotência própria. O estorno é um novo
 * registro compensatório; a movimentação original permanece no histórico.
 */
export async function askReverse(api: LoyaltyApi, establishmentId: number, t: Transaction, notifications: NotificationService,
                                 dialogs: ConfirmService, onDone: () => void): Promise<void> {
  const reason = await dialogs.ask({
    title: `Estornar "${label(TRANSACTION_LABELS, t.type)}"?`,
    message: `Cliente: ${t.consumerName ?? 'cliente'}. O estorno é um novo registro; a operação original continua no histórico.`,
    confirmLabel: 'Estornar',
    cancelLabel: 'Voltar',
    tone: 'danger',
    reason: 'required',
    reasonLabel: 'Motivo do estorno',
  });
  if (reason === null) return;
  api.reverse(establishmentId, t.id, reason, LoyaltyApi.newKey()).subscribe({
    next: (r) => {
      notifications.success(r.notRestored > 0 ? `Estorno registrado. ${r.transaction.description}` : 'Estorno registrado.');
      onDone();
    },
    error: (e) => notifications.error(toApiError(e).message),
  });
}
