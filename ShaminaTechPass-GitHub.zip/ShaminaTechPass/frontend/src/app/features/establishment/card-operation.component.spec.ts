import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { vi } from 'vitest';
import { CardDetail } from '../../core/loyalty-models';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { CardOperationComponent } from './card-operation.component';

function detail(status: 'ACTIVE' | 'CANCELLED' = 'ACTIVE'): CardDetail {
  return {
    card: {
      id: 7, code: 'ABCD', displayCode: 'ABCD-EFGH-JKMN-PQRS', status, storedStatus: status, balance: 10, availableBalance: 10,
      programId: 1, programName: 'Pontos', programType: 'POINTS', consumerId: 3, consumerName: 'Ana', issuedAt: '', lastMovementAt: null,
      expiresAt: '', validUntil: '2026-12-05T23:59:59', timeZone: 'America/Sao_Paulo', inactivityDays: 30, statusReason: null,
      completedCycles: 0, stampsRequired: null, rewardAvailable: true, nextBenefitExpiry: null,
    },
    lots: [],
    rewards: [],
    design: { brandColor: '#F43F5E', textColor: '#FFFFFF', cardMessage: null, rewardInfo: null, logoUrl: null, heroUrl: null, walletNotes: [] },
    programDescription: null,
  };
}

describe('CardOperationComponent', () => {
  async function setup(d = detail(), answer = true) {
    const dialogs = { confirm: vi.fn().mockResolvedValue(answer) };
    await TestBed.configureTestingModule({
      imports: [CardOperationComponent],
      providers: [provideHttpClient(), provideHttpClientTesting(), { provide: ConfirmService, useValue: dialogs }],
    }).compileComponents();
    const fixture = TestBed.createComponent(CardOperationComponent);
    fixture.componentRef.setInput('establishmentId', 1);
    fixture.componentRef.setInput('detail', d);
    fixture.componentRef.setInput('channel', 'QR_CODE');
    await fixture.whenStable();
    return { fixture, el: fixture.nativeElement as HTMLElement, http: TestBed.inject(HttpTestingController), dialogs };
  }

  /** Envia o formulário e espera a confirmação (assíncrona) do diálogo. */
  async function submit(fixture: { whenStable(): Promise<unknown> }, el: HTMLElement) {
    el.querySelector('form')!.dispatchEvent(new Event('submit'));
    await fixture.whenStable();
  }

  async function typePurchase(fixture: { whenStable(): Promise<unknown> }, el: HTMLElement, value: string) {
    const input = el.querySelector<HTMLInputElement>('#purchase')!;
    input.value = value;
    input.dispatchEvent(new Event('input'));
    await fixture.whenStable();
  }

  it('reaproveita a chave de idempotência quando a mesma operação é reenviada após falha de rede', async () => {
    const { fixture, el, http } = await setup();
    await typePurchase(fixture, el, '25,90');
    await submit(fixture, el);
    const first = http.expectOne('/api/establishments/1/cards/7/earn');
    expect(first.request.body).toEqual({ purchaseAmount: 25.9, quantity: null, channel: 'QR_CODE', note: null });
    const key = first.request.headers.get('Idempotency-Key');
    expect(key).toBeTruthy();
    first.error(new ProgressEvent('error'), { status: 0 });
    await fixture.whenStable();

    await submit(fixture, el);
    const retry = http.expectOne('/api/establishments/1/cards/7/earn');
    expect(retry.request.headers.get('Idempotency-Key')).toBe(key);
  });

  it('gera uma nova chave quando os dados da operação mudam', async () => {
    const { fixture, el, http } = await setup();
    await typePurchase(fixture, el, '10,00');
    await submit(fixture, el);
    const first = http.expectOne('/api/establishments/1/cards/7/earn');
    const key = first.request.headers.get('Idempotency-Key');
    first.error(new ProgressEvent('error'), { status: 0 });
    await fixture.whenStable();

    await typePurchase(fixture, el, '11,00');
    await submit(fixture, el);
    expect(http.expectOne('/api/establishments/1/cards/7/earn').request.headers.get('Idempotency-Key')).not.toBe(key);
  });

  it('pede confirmação com o resumo e não envia nada se a pessoa voltar', async () => {
    const { fixture, el, http, dialogs } = await setup(detail(), false);
    await typePurchase(fixture, el, '25,90');
    await submit(fixture, el);
    expect(dialogs.confirm).toHaveBeenCalledWith(expect.objectContaining({ title: 'Confirmar concessão', confirmLabel: 'Conceder' }));
    expect(dialogs.confirm.mock.calls[0][0].message).toContain('Ana');
    http.expectNone('/api/establishments/1/cards/7/earn');
  });

  it('não oferece movimentação para cartão cancelado', async () => {
    const { el } = await setup(detail('CANCELLED'));
    expect(el.querySelector('form')).toBeNull();
    expect(el.textContent).toContain('cancelado');
  });
});
