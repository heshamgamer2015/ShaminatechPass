import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, effect, inject, input, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { toApiError } from '../../core/api/api-error';
import { EstablishmentPlanView, PlanApi, formatPlanPrice } from '../../core/api/plan-api.service';
import { ProgramType } from '../../core/loyalty-models';
import { PROGRAM_TYPE_LABELS, label } from '../../shared/labels';
import { AlertComponent } from '../../shared/ui/alert.component';
import { IconComponent } from '../../shared/ui/icon.component';
import { PageHeaderComponent } from '../../shared/ui/page-header.component';
import { SpinnerComponent } from '../../shared/ui/spinner.component';
import { EstablishmentContext } from './establishment-context.service';

/**
 * Plano do estabelecimento: plano atual, condição da fase de testes (sem cobrança), limites e utilização.
 * Não há troca de plano com cobrança; os limites são aplicados pelo servidor.
 */
@Component({
  selector: 'app-plan-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe, RouterLink, AlertComponent, IconComponent, PageHeaderComponent, SpinnerComponent],
  template: `
    <app-page-header title="Plano" subtitle="Plano atual, limites e quanto você já está usando" />

    @if (bemvindo()) {
      <app-alert kind="success">
        <strong>Conta criada!</strong> Seu estabelecimento já está ativo. Próximo passo: crie o seu programa de fidelidade.
      </app-alert>
    }

    @if (error(); as e) {
      <app-alert kind="error">{{ e }}</app-alert>
    } @else if (plan(); as p) {
      <section class="card plan">
        <div class="head">
          <div>
            <span class="muted small">Plano atual</span>
            <h2>{{ p.name ?? 'Personalizado pela ShaminaTech' }}</h2>
            @if (p.code && p.listPriceCents !== null) {
              <p class="muted">{{ price(p.listPriceCents) }}{{ p.listPriceCents ? '/mês (preço comercial previsto)' : ' para sempre' }}
                @if (p.since) { · desde {{ p.since | date: 'dd/MM/yyyy' }} }</p>
            }
          </div>
          @if (p.trialFree) {
            <span class="pill"><app-icon name="check-circle" [size]="14" />Grátis na fase de testes</span>
          }
        </div>
        @if (p.trialMessage) {
          <p class="note info"><app-icon name="info" [size]="16" /><span>{{ p.trialMessage }}</span></p>
        }
        @if (!p.code) {
          <p class="note info"><app-icon name="info" [size]="16" />
            <span>Os limites deste estabelecimento foram definidos pela equipe ShaminaTech.</span></p>
        }

        <div class="pl-meters">
          <div class="pl-meter">
            <span class="muted small">Clientes ativos</span>
            <strong>{{ p.usage.activeConsumers }} <small class="muted">/ {{ limit(p.limits.maxActiveConsumers) }}</small></strong>
            @if (p.limits.maxActiveConsumers !== null) {
              <span class="pl-bar"><span [class]="'pl-fill ' + width(p.usage.activeConsumers, p.limits.maxActiveConsumers)"></span></span>
            }
          </div>
          <div class="pl-meter">
            <span class="muted small">Programas de fidelidade</span>
            <strong>{{ p.usage.programs }} <small class="muted">/ {{ limit(p.limits.maxPrograms) }}</small></strong>
            @if (p.limits.maxPrograms !== null) {
              <span class="pl-bar"><span [class]="'pl-fill ' + width(p.usage.programs, p.limits.maxPrograms)"></span></span>
            }
          </div>
          <div class="pl-meter">
            <span class="muted small">Tipos de fidelidade</span>
            <strong>{{ p.usage.typesInUse.length }} <small class="muted">/ {{ limit(p.limits.maxProgramTypes) }}</small></strong>
            <span class="muted small">{{ p.usage.typesInUse.length ? typeList(p.usage.typesInUse) : 'nenhum em uso' }}</span>
          </div>
        </div>
        <p class="muted small">Disponíveis para escolher: {{ typeList(p.allowedTypes) }}. Clientes inativos e programas encerrados não
          contam no limite. Mudar de plano nunca apaga programas ou clientes.</p>
      </section>

      <section class="card next">
        <h2>Comece por aqui</h2>
        <ol>
          <li>Crie o programa de fidelidade (pontos, carimbos ou cashback).</li>
          <li>Personalize o cartão com o seu logotipo e as suas cores.</li>
          <li>Coloque o QR Code do programa no balcão: o cliente se cadastra e guarda o cartão no Android ou no iPhone.</li>
        </ol>
        <div class="actions">
          <a class="btn btn-primary" [routerLink]="ctx.base() + '/programas/novo'"><app-icon name="plus" [size]="16" />Criar programa</a>
          <a class="btn" [routerLink]="ctx.base() + '/qr-cadastro'">QR Code do programa</a>
        </div>
        <p class="muted small">Precisa de outro plano? Fale com a ShaminaTech: durante a fase de testes a mudança também é gratuita.</p>
      </section>
    } @else {
      <app-spinner />
    }
  `,
  styles: `
    .card {
      display: grid;
      gap: 0.9rem;
      margin-bottom: 1rem;
    }
    .head {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: flex-start;
      gap: 0.75rem;
    }
    h2,
    .head p {
      margin: 0;
    }
    .pill {
      display: inline-flex;
      align-items: center;
      gap: 0.3rem;
      padding: 0.25rem 0.7rem;
      border-radius: 999px;
      background: var(--success-soft);
      color: var(--success);
      font-size: 0.8rem;
      font-weight: 600;
    }
    .pl-meters {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 0.75rem;
    }
    @media (max-width: 700px) {
      .pl-meters {
        grid-template-columns: 1fr;
      }
    }
    .pl-meter {
      display: grid;
      gap: 0.35rem;
      padding: 0.85rem;
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
    }
    .pl-meter strong {
      font-size: 1.3rem;
    }
    .pl-bar {
      height: 6px;
      border-radius: 999px;
      background: var(--border);
      overflow: hidden;
    }
    .pl-fill {
      display: block;
      height: 100%;
      background: var(--primary);
    }
    .next ol {
      margin: 0;
      padding-left: 1.2rem;
      display: grid;
      gap: 0.3rem;
    }
    .actions {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
    }
  `,
})
export class PlanPage {
  protected readonly ctx = inject(EstablishmentContext);
  private readonly api = inject(PlanApi);

  /** ?bemvindo=1: chegou aqui logo após criar a conta. */
  readonly bemvindo = input<string>();

  protected readonly plan = signal<EstablishmentPlanView | null>(null);
  protected readonly error = signal<string | null>(null);

  constructor() {
    effect(() => {
      const id = this.ctx.id();
      if (id !== null) {
        this.api.plan(id).subscribe({ next: (p) => this.plan.set(p), error: (e) => this.error.set(toApiError(e).message) });
      }
    });
  }

  protected price(cents: number): string {
    return formatPlanPrice(cents);
  }

  protected limit(value: number | null): string {
    return value === null ? 'ilimitado' : String(value);
  }

  /** Largura da barra em classes de 10% (sem estilo inline: a CSP não permite). */
  protected width(used: number, max: number): string {
    const pct = max <= 0 ? 100 : Math.min(100, Math.round((used / max) * 10) * 10);
    return 'w' + pct;
  }

  protected typeList(types: ProgramType[]): string {
    return types.map((t) => label(PROGRAM_TYPE_LABELS, t)).join(', ');
  }
}
