import { ChangeDetectionStrategy, Component, computed, inject, input, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { filter } from 'rxjs';
import { AuthService } from '../core/auth/auth.service';
import { IconComponent } from '../shared/ui/icon.component';

export interface NavItem {
  label: string;
  link: string;
  /** Nome do ícone (ver IconComponent). */
  icon?: string;
  /** Grupo do menu; itens consecutivos do mesmo grupo ficam juntos sob o título. */
  section?: string;
  exact?: boolean;
  /** Item visível mas indisponível (ex.: funcionalidade futura). */
  soon?: boolean;
}

/** Ação principal fixa no topo do menu (ex.: Registrar compra no balcão). */
export interface NavAction {
  label: string;
  link: string;
  icon: string;
}

interface NavGroup {
  title: string;
  items: NavItem[];
}

/** Estrutura das áreas logadas: barra superior, menu lateral (gaveta no celular) e conteúdo. */
@Component({
  selector: 'app-shell',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, RouterLinkActive, RouterOutlet, IconComponent],
  templateUrl: './shell.component.html',
  styleUrl: './shell.component.scss',
  host: { '(document:keydown.escape)': 'closeMenu()' },
})
export class ShellComponent {
  readonly area = input.required<string>();
  readonly context = input('');
  readonly nav = input.required<NavItem[]>();
  readonly primaryAction = input<NavAction | null>(null);

  protected readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  protected readonly menuOpen = signal(false);
  protected readonly canSwitchEstablishment = computed(() => (this.auth.user()?.memberships.length ?? 0) > 1);

  protected readonly groups = computed<NavGroup[]>(() => {
    const groups: NavGroup[] = [];
    for (const item of this.nav()) {
      const title = item.section ?? '';
      const last = groups[groups.length - 1];
      if (last && last.title === title) last.items.push(item);
      else groups.push({ title, items: [item] });
    }
    return groups;
  });

  protected readonly initials = computed(() => {
    const parts = (this.auth.user()?.fullName ?? '').trim().split(/\s+/).filter(Boolean);
    const first = parts[0]?.[0] ?? '';
    const last = parts.length > 1 ? parts[parts.length - 1][0] : '';
    return (first + last).toUpperCase() || '?';
  });

  protected readonly contextInitial = computed(() => this.context().trim().charAt(0).toUpperCase());

  constructor() {
    // Fecha a gaveta ao navegar (inclusive pelo teclado ou pelo botão voltar do navegador).
    this.router.events
      .pipe(
        filter((e) => e instanceof NavigationEnd),
        takeUntilDestroyed(),
      )
      .subscribe(() => this.menuOpen.set(false));
  }

  protected toggleMenu(): void {
    this.menuOpen.update((open) => !open);
  }

  protected closeMenu(): void {
    this.menuOpen.set(false);
  }

  protected async logout(): Promise<void> {
    await this.auth.logout();
    await this.router.navigate(['/login']);
  }
}
