import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { AuthService } from '../core/auth/auth.service';
import { ShellComponent } from './shell.component';

describe('ShellComponent', () => {
  async function setup() {
    const auth = { user: signal({ fullName: 'Dono Demo', email: 'dono@x.local', memberships: [{}] }), logout: async () => undefined };
    await TestBed.configureTestingModule({
      imports: [ShellComponent],
      providers: [provideRouter([]), { provide: AuthService, useValue: auth }],
    }).compileComponents();
    const fixture = TestBed.createComponent(ShellComponent);
    fixture.componentRef.setInput('area', 'Painel');
    fixture.componentRef.setInput('context', 'Loja Demo');
    fixture.componentRef.setInput('primaryAction', { label: 'Registrar compra', link: '/e/1/operacao', icon: 'scan' });
    fixture.componentRef.setInput('nav', [
      { label: 'Visão geral', link: '/e/1', icon: 'home' },
      { section: 'Clientes', label: 'Clientes', link: '/e/1/clientes', icon: 'users' },
      { section: 'Clientes', label: 'Cartões', link: '/e/1/cartoes', icon: 'card' },
      { section: 'Gestão', label: 'Auditoria', link: '/e/1/auditoria', icon: 'shield' },
      { section: 'Gestão', label: 'Planos', link: '/e/1/planos', soon: true },
    ]);
    await fixture.whenStable();
    return { fixture, el: fixture.nativeElement as HTMLElement };
  }

  it('agrupa o menu por seção, mantendo a ação principal no topo', async () => {
    const { el } = await setup();
    const titles = [...el.querySelectorAll('.nav-title')].map((t) => t.textContent?.trim());
    expect(titles).toEqual(['Clientes', 'Gestão']);
    expect(el.querySelectorAll('.nav-group').length).toBe(3);
    const primary = el.querySelector<HTMLAnchorElement>('.primary-action')!;
    expect(primary.textContent).toContain('Registrar compra');
    expect(primary.getAttribute('href')).toBe('/e/1/operacao');
    expect(el.querySelector('.soon')!.getAttribute('aria-disabled')).toBe('true');
    expect(el.querySelector('.avatar')!.textContent).toBe('DD');
  });

  it('abre a gaveta com o botão e fecha com Esc', async () => {
    const { fixture, el } = await setup();
    const toggle = el.querySelector<HTMLButtonElement>('.menu-toggle')!;
    toggle.click();
    await fixture.whenStable();
    expect(el.querySelector('.shell')!.classList).toContain('menu-open');
    expect(toggle.getAttribute('aria-expanded')).toBe('true');
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    await fixture.whenStable();
    expect(el.querySelector('.shell')!.classList).not.toContain('menu-open');
  });

  it('oferece atalho de teclado para pular ao conteúdo', async () => {
    const { el } = await setup();
    const skip = el.querySelector<HTMLAnchorElement>('.skip-link')!;
    expect(skip.getAttribute('href')).toBe('#conteudo');
    expect(el.querySelector('main#conteudo')).not.toBeNull();
  });
});
