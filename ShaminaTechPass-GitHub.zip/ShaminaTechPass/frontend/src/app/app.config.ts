import { registerLocaleData } from '@angular/common';
import { provideHttpClient, withFetch, withInterceptors } from '@angular/common/http';
import localePt from '@angular/common/locales/pt';
import {
  ApplicationConfig,
  LOCALE_ID,
  inject,
  provideAppInitializer,
  provideBrowserGlobalErrorListeners,
} from '@angular/core';
import { provideRouter, withComponentInputBinding, withRouterConfig } from '@angular/router';
import { errorInterceptor } from './core/api/error.interceptor';
import { AuthService } from './core/auth/auth.service';
import { routes } from './app.routes';

registerLocaleData(localePt);

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    { provide: LOCALE_ID, useValue: 'pt-BR' },
    provideRouter(
      routes,
      // Parâmetros/query params/data da rota chegam como inputs; filhos herdam :establishmentId.
      withComponentInputBinding(),
      withRouterConfig({ paramsInheritanceStrategy: 'always' }),
    ),
    // O HttpClient envia o cabeçalho X-XSRF-TOKEN automaticamente a partir do cookie XSRF-TOKEN.
    provideHttpClient(withFetch(), withInterceptors([errorInterceptor])),
    // Recupera a sessão (cookie HttpOnly) antes da primeira navegação.
    provideAppInitializer(() => inject(AuthService).init()),
  ],
};
