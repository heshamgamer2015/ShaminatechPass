// Traduções exibidas na interface.

export const ROLE_LABELS: Record<string, string> = {
  OWNER: 'Conta empresarial',
  MANAGER: 'Gerente',
  STAFF: 'Funcionário',
  PLATFORM_ADMIN: 'Administrador ShaminaTech',
};

export const STATUS_LABELS: Record<string, string> = {
  ACTIVE: 'Ativo',
  SUSPENDED: 'Suspenso',
  CANCELLED: 'Cancelado',
  DISABLED: 'Desativado',
  INACTIVE: 'Inativo',
  EXPIRED: 'Expirado',
  COMPLETED: 'Concluído',
  PAUSED: 'Pausado',
  ARCHIVED: 'Encerrado',
};

export const PROGRAM_TYPE_LABELS: Record<string, string> = {
  STAMPS: 'Carimbos',
  POINTS: 'Pontos',
  CASHBACK: 'Cashback',
  VIP: 'Níveis VIP',
};

export const PROGRAM_TYPE_HINTS: Record<string, string> = {
  STAMPS: 'O cliente junta carimbos por compra, produto ou visita e ganha uma recompensa ao completar o cartão.',
  POINTS: 'Cada real gasto vira pontos, que o cliente troca por recompensas cadastradas por você.',
  CASHBACK: 'Parte do valor da compra volta como crédito promocional para usar no próprio estabelecimento.',
  VIP: 'Níveis (Bronze, Prata, Ouro...) com benefícios. Nesta versão os níveis são cadastrados, mas a progressão automática ainda não funciona.',
};

export const CARD_STATUS_LABELS: Record<string, string> = {
  ACTIVE: 'Ativo',
  SUSPENDED: 'Desativado',
  EXPIRED: 'Expirado',
  COMPLETED: 'Concluído',
  CANCELLED: 'Cancelado',
};

export const TRANSACTION_LABELS: Record<string, string> = {
  EARN: 'Concessão',
  REDEEM: 'Resgate',
  REVERSAL: 'Estorno',
  BENEFIT_EXPIRED: 'Benefícios vencidos',
  BALANCE_FORFEITED: 'Saldo zerado na expiração',
  CARD_ISSUED: 'Cartão emitido',
  CARD_SUSPENDED: 'Cartão desativado',
  CARD_REACTIVATED: 'Cartão reativado',
  CARD_EXPIRED: 'Cartão expirado',
  CARD_CANCELLED: 'Cartão cancelado',
};

export const CHANNEL_LABELS: Record<string, string> = {
  MANUAL: 'Manual',
  QR_CODE: 'QR Code',
  NFC: 'NFC',
  API: 'Integração',
  SYSTEM: 'Automático',
  PUBLIC_SIGNUP: 'Cadastro pelo QR Code',
};

export const STAMP_CRITERION_LABELS: Record<string, string> = {
  PURCHASE: 'Por compra',
  PRODUCT: 'Por produto',
  VISIT: 'Por visita',
};

export const VALIDITY_MODE_LABELS: Record<string, string> = {
  END_OF_DAY: 'Até 23:59 do último dia',
  EXACT_TIME: 'Mesmo horário da última movimentação',
};

export const EXPIRED_BALANCE_LABELS: Record<string, string> = {
  KEEP: 'Fica congelado (volta se o cartão for reativado)',
  FORFEIT: 'É zerado (registrado no histórico)',
};

export const REVERSAL_LABELS: Record<string, string> = {
  REQUIRE_BALANCE: 'Recusar se o saldo não cobrir',
  ALLOW_NEGATIVE: 'Permitir saldo negativo',
};

export const ROUNDING_LABELS: Record<string, string> = {
  DOWN: 'Para baixo',
  HALF_UP: 'Normal (0,5 para cima)',
  UP: 'Para cima',
};

/** Unidade do saldo de um programa. */
export function formatBalance(type: string | null | undefined, value: number | null | undefined): string {
  const v = value ?? 0;
  if (type === 'CASHBACK') return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const n = v.toLocaleString('pt-BR', { maximumFractionDigits: 2 });
  if (type === 'STAMPS') return `${n} carimbo${Math.abs(v) === 1 ? '' : 's'}`;
  if (type === 'POINTS') return `${n} ponto${Math.abs(v) === 1 ? '' : 's'}`;
  return n;
}

export function formatMoney(value: number | null | undefined): string {
  return value == null ? '—' : value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

/** Converte "12,50" ou "12.50" em número (ou null). */
export function parseMoney(text: string | number | null | undefined): number | null {
  if (text == null || text === '') return null;
  if (typeof text === 'number') return text;
  const cleaned = text.trim().replace(/\s/g, '').replace(/^R\$/, '');
  const normalized = cleaned.includes(',') ? cleaned.replace(/\./g, '').replace(',', '.') : cleaned;
  const n = Number(normalized);
  return Number.isFinite(n) ? n : NaN;
}

export function formatPhone(digits: string | null | undefined): string {
  if (!digits) return '—';
  const d = digits.length > 11 && digits.startsWith('55') ? digits.slice(2) : digits;
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return digits;
}

export const AUDIT_LABELS: Record<string, string> = {
  LOGIN_SUCCEEDED: 'Login realizado',
  LOGIN_FAILED: 'Falha de login',
  LOGIN_BLOCKED: 'Login durante bloqueio',
  PASSWORD_CHANGED: 'Senha alterada',
  PLATFORM_ADMIN_BOOTSTRAPPED: 'Administrador inicial criado',
  USER_CREATED: 'Usuário criado',
  USER_STATUS_CHANGED: 'Situação do usuário alterada',
  USER_UNLOCKED: 'Usuário desbloqueado',
  ESTABLISHMENT_CREATED: 'Estabelecimento criado',
  ESTABLISHMENT_SELF_REGISTERED: 'Estabelecimento cadastrado pelo site',
  ESTABLISHMENT_UPDATED: 'Dados do estabelecimento alterados',
  ESTABLISHMENT_STATUS_CHANGED: 'Situação do estabelecimento alterada',
  MEMBER_ADDED: 'Conta vinculada',
  MEMBER_UPDATED: 'Vínculo alterado',
  ESTABLISHMENT_POLICY_CHANGED: 'Limites alterados',
  LOYALTY_DEFAULTS_CHANGED: 'Regras padrão alteradas',
  ACCOUNT_PASSWORD_RESET: 'Senha da conta redefinida',
  CONSUMER_CREATED: 'Cliente cadastrado',
  CONSUMER_UPDATED: 'Cliente alterado',
  CONSUMER_STATUS_CHANGED: 'Situação do cliente alterada',
  PROGRAM_CREATED: 'Programa criado',
  PROGRAM_UPDATED: 'Programa alterado',
  PROGRAM_STATUS_CHANGED: 'Situação do programa alterada',
  REWARD_SAVED: 'Recompensa salva',
  VIP_TIER_SAVED: 'Nível VIP salvo',
  CARD_DESIGN_UPDATED: 'Personalização alterada',
  CARD_IMAGE_UPLOADED: 'Imagem enviada',
  CARD_IMAGE_REMOVED: 'Imagem removida',
  CARD_ISSUED: 'Cartão emitido',
  CARD_STATUS_CHANGED: 'Situação do cartão alterada',
  TRANSACTION_REVERSED: 'Movimentação estornada',
  WALLET_PASS_CREATED: 'Cartão enviado à carteira digital',
  WALLET_LINK_CREATED: 'Link da carteira gerado',
  WALLET_LINK_REVOKED: 'Link da carteira revogado',
  WALLET_SYNC_RETRIED: 'Reenvio à carteira solicitado',
  SIGNUP_LINK_CREATED: 'QR Code de cadastro gerado',
  SIGNUP_LINK_STATUS_CHANGED: 'QR Code de cadastro ativado/desativado',
  SIGNUP_LINK_REGENERATED: 'QR Code de cadastro substituído',
  CONSUMER_SELF_REGISTERED: 'Cliente cadastrado pelo QR Code',
  NOTIFICATION_SETTINGS_CHANGED: 'Configuração de lembretes alterada',
  ESTABLISHMENT_LOCATION_SAVED: 'Localização salva',
  ESTABLISHMENT_LOCATION_REMOVED: 'Localização removida',
  PASSWORD_RESET_REQUESTED: 'Recuperação de senha solicitada',
  PASSWORD_RESET_COMPLETED: 'Senha redefinida por recuperação',
};

export function label(map: Record<string, string>, key: string | null | undefined): string {
  return key ? (map[key] ?? key) : '—';
}

/** Senha temporária aleatória que atende à política do backend (letras + números, 14 caracteres). */
export function generateTemporaryPassword(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  const values = crypto.getRandomValues(new Uint32Array(12));
  const body = Array.from(values, (v) => alphabet[v % alphabet.length]).join('');
  return `Pass-${body.slice(0, 6)}${(values[0] % 8) + 2}${body.slice(6)}`;
}

/** Sugere um identificador (slug) a partir do nome. */
export function slugify(value: string): string {
  return value
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
}

/** Data/hora local do estabelecimento vinda do backend ("2026-12-05T23:59:59") → "05/12/2026 23:59". */
export function formatLocalDateTime(value: string | null | undefined): string {
  if (!value) return '—';
  const [date, time = ''] = value.split('T');
  const [y, m, d] = date.split('-');
  return `${d}/${m}/${y}${time ? ' ' + time.slice(0, 5) : ''}`;
}

export const WALLET_SYNC_LABELS: Record<string, string> = {
  PENDING: 'Envio pendente',
  SYNCING: 'Enviando',
  SYNCED: 'Sincronizado',
  FAILED: 'Falha no envio',
  INVALIDATED: 'Inativado',
};

export const WALLET_REMOTE_STATE_LABELS: Record<string, string> = {
  ACTIVE: 'Ativo na carteira',
  INACTIVE: 'Inativo na carteira',
  EXPIRED: 'Expirado na carteira',
  COMPLETED: 'Concluído na carteira',
  BLOCKED: 'Bloqueado na carteira (visível)',
  VOIDED: 'Anulado na carteira',
};

/** Etapa 6: situação de um pedido de aviso. Nenhuma indica entrega ou leitura (o Google não informa). */
export const REMINDER_STATUS_LABELS: Record<string, string> = {
  PENDING: 'Aguardando envio',
  SENDING: 'Enviando',
  ACCEPTED: 'Aceito pelo Google',
  FAILED: 'Falha (nova tentativa)',
  REJECTED: 'Recusado pelo Google',
  QUOTA_EXCEEDED: 'Limite do Google atingido',
  CANCELLED: 'Descartado (situação mudou)',
};

export const REMINDER_CATEGORY_LABELS: Record<string, string> = {
  NEAR_REWARD: 'Recompensa próxima',
  EXPIRY: 'Vencimento',
  INACTIVITY: 'Inatividade',
};
