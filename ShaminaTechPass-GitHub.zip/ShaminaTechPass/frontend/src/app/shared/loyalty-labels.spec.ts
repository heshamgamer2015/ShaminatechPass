import { formatBalance, formatLocalDateTime, formatPhone, parseMoney } from './labels';

describe('formatação de fidelidade', () => {
  it('lê valores em reais digitados com vírgula ou ponto', () => {
    expect(parseMoney('25,90')).toBe(25.9);
    expect(parseMoney('1.234,56')).toBe(1234.56);
    expect(parseMoney('R$ 10,00')).toBe(10);
    expect(parseMoney('19.99')).toBe(19.99);
    expect(parseMoney('')).toBeNull();
    expect(Number.isNaN(parseMoney('abc'))).toBe(true);
  });

  it('exibe o saldo na unidade do programa', () => {
    expect(formatBalance('STAMPS', 1)).toBe('1 carimbo');
    expect(formatBalance('STAMPS', 4)).toBe('4 carimbos');
    expect(formatBalance('POINTS', 120)).toBe('120 pontos');
    expect(formatBalance('CASHBACK', 5.99).replace(/\s/g, ' ')).toBe('R$ 5,99');
  });

  it('mostra a validade local do estabelecimento sem converter fuso', () => {
    expect(formatLocalDateTime('2026-12-05T23:59:59')).toBe('05/12/2026 23:59');
    expect(formatLocalDateTime(null)).toBe('—');
  });

  it('formata telefones brasileiros', () => {
    expect(formatPhone('11999998888')).toBe('(11) 99999-8888');
    expect(formatPhone('1133334444')).toBe('(11) 3333-4444');
  });
});
