import { InjectionToken } from '@angular/core';

/**
 * Identificação do aparelho para destacar a carteira digital adequada. É só uma <b>sugestão</b>: a página continua
 * mostrando a escolha manual, nunca redireciona sozinha e funciona mesmo quando nada é identificado.
 *
 * Combina vários sinais (não uma única palavra do User-Agent):
 * - User-Agent Client Hints ({@code navigator.userAgentData.platform/mobile}), quando o navegador oferece;
 * - User-Agent clássico (Android, iPhone/iPod, iPad);
 * - iPadOS 13+, que se apresenta como Mac: "Macintosh" + tela sensível ao toque (maxTouchPoints > 1);
 * - navegadores internos de aplicativos (Instagram, Facebook, TikTok…), que costumam não abrir o .pkpass.
 */
export type DevicePlatform = 'android' | 'ios' | 'ipados' | 'mac' | 'desktop' | 'unknown';
export type WalletKind = 'GOOGLE_WALLET' | 'APPLE_WALLET';

export interface DeviceInfo {
  platform: DevicePlatform;
  /** Nome do aplicativo quando a página está aberta no navegador interno dele (ex.: "Instagram"). */
  inAppBrowser: string | null;
  /** Carteira recomendada para este aparelho (null = sem recomendação). */
  recommended: WalletKind | null;
  /** Este aparelho consegue guardar e usar o cartão nesta carteira. */
  canInstall: Record<WalletKind, boolean>;
  /** Aparelho que não guarda cartões (computador, iPad): a página oferece abrir no celular. */
  openOnPhone: boolean;
}

export interface DeviceSignals {
  userAgent: string;
  maxTouchPoints?: number;
  uaPlatform?: string | null;
  uaMobile?: boolean | null;
}

const IN_APP: [RegExp, string][] = [
  [/Instagram/i, 'Instagram'],
  [/FBAN|FBAV|FB_IAB|FBIOS/i, 'Facebook'],
  [/musical_ly|TikTok|BytedanceWebview/i, 'TikTok'],
  [/LinkedInApp/i, 'LinkedIn'],
  [/Snapchat/i, 'Snapchat'],
  [/Twitter|TwitterAndroid/i, 'X (Twitter)'],
  [/\bLine\//i, 'LINE'],
  [/Pinterest/i, 'Pinterest'],
];

export function detectDevice(signals: DeviceSignals): DeviceInfo {
  const ua = signals.userAgent ?? '';
  const hint = (signals.uaPlatform ?? '').toLowerCase();
  const touch = (signals.maxTouchPoints ?? 0) > 1;

  let platform: DevicePlatform = 'unknown';
  if (hint === 'android' || /Android/i.test(ua)) {
    platform = 'android';
  } else if (hint === 'ios' || /iPhone|iPod/i.test(ua)) {
    platform = 'ios';
  } else if (/iPad/i.test(ua) || (/Macintosh/i.test(ua) && touch)) {
    platform = 'ipados';
  } else if (hint === 'macos' || /Macintosh|Mac OS X/i.test(ua)) {
    platform = 'mac';
  } else if (['windows', 'linux', 'chrome os', 'chromeos'].includes(hint) || /Windows NT|X11|CrOS|Linux x86_64/i.test(ua)) {
    platform = signals.uaMobile ? 'unknown' : 'desktop';
  }

  const inAppBrowser = IN_APP.find(([re]) => re.test(ua))?.[1] ?? null;
  const recommended: WalletKind | null = platform === 'android' ? 'GOOGLE_WALLET' : platform === 'ios' ? 'APPLE_WALLET' : null;
  return {
    platform,
    inAppBrowser,
    recommended,
    // Google Wallet: Android (o cartão fica no celular). Apple Wallet: iPhone. Aparelho desconhecido: deixa tentar as duas.
    canInstall: {
      GOOGLE_WALLET: platform === 'android' || platform === 'unknown',
      APPLE_WALLET: platform === 'ios' || platform === 'unknown',
    },
    openOnPhone: platform === 'desktop' || platform === 'mac' || platform === 'ipados',
  };
}

/** Sinais do navegador atual (sem acesso a nada além do que o próprio navegador informa). */
export function currentDevice(): DeviceInfo {
  if (typeof navigator === 'undefined') {
    return detectDevice({ userAgent: '' });
  }
  const data = (navigator as Navigator & { userAgentData?: { platform?: string; mobile?: boolean } }).userAgentData;
  return detectDevice({
    userAgent: navigator.userAgent,
    maxTouchPoints: navigator.maxTouchPoints,
    uaPlatform: data?.platform ?? null,
    uaMobile: data?.mobile ?? null,
  });
}

export const PLATFORM_LABELS: Record<DevicePlatform, string> = {
  android: 'celular Android',
  ios: 'iPhone',
  ipados: 'iPad',
  mac: 'Mac',
  desktop: 'computador',
  unknown: 'aparelho',
};

/** Aparelho atual, injetável (os testes substituem por um aparelho simulado). */
export const DEVICE = new InjectionToken<DeviceInfo>('DEVICE', { providedIn: 'root', factory: currentDevice });
