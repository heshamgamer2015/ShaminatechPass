import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';
import { CardStatus, Design, ProgramType } from '../../core/loyalty-models';
import { formatBalance } from '../labels';

const SITUATION: Record<string, string> = {
  ACTIVE: 'Ativo',
  SUSPENDED: 'Bloqueado',
  EXPIRED: 'Vencido',
  COMPLETED: 'Concluído',
  CANCELLED: 'Cancelado',
};

/**
 * Prévia APROXIMADA do cartão no Apple Wallet (estilo "storeCard"): logotipo e nome no topo, situação no cabeçalho,
 * saldo sobre a faixa (recorte da imagem de destaque), programa e cliente abaixo e o QR Code. Não é a renderização
 * real — essa só é confirmada no iPhone.
 */
@Component({
  selector: 'app-apple-pass-preview',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <figure class="wrap">
      <article class="pass" [style.background]="design().brandColor" [style.color]="design().textColor"
               [attr.aria-label]="'Prévia aproximada do cartão no Apple Wallet: ' + programName()">
        <header>
          @if (design().logoUrl) {
            <img class="logo" [src]="design().logoUrl" alt="" />
          } @else {
            <span class="logo placeholder" aria-hidden="true">{{ initial() }}</span>
          }
          <span class="logo-text">{{ establishmentName() || programName() }}</span>
          <span class="field right">
            <small>SITUAÇÃO</small>
            <b>{{ situation() }}</b>
          </span>
        </header>
        <div class="strip" [class.with-image]="!!design().heroUrl"
             [style.background-image]="design().heroUrl ? 'url(' + design().heroUrl + ')' : null">
          <span class="field primary">
            <small>{{ balanceLabel() }}</small>
            <b>{{ balanceText() }}</b>
          </span>
        </div>
        <div class="row">
          <span class="field"><small>PROGRAMA</small><b>{{ programName() }}</b></span>
          <span class="field"><small>CLIENTE</small><b>{{ firstName() }}</b></span>
        </div>
        <div class="qr" aria-hidden="true">
          <span class="code"></span>
          <small>{{ code() || 'XXXX-XXXX-XXXX-XXXX' }}</small>
        </div>
      </article>
      <figcaption>Prévia aproximada do Apple Wallet. A Apple define a disposição e as fontes; a aparência real só é
        confirmada no iPhone.</figcaption>
    </figure>
  `,
  styles: `
    .wrap {
      margin: 0;
      display: grid;
      gap: 0.5rem;
      justify-items: center;
      width: 100%;
      max-width: 340px;
    }
    .pass {
      width: 100%;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 10px 30px rgb(15 23 42 / 18%);
      font-family: -apple-system, 'SF Pro Text', 'Helvetica Neue', Arial, sans-serif;
    }
    header {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.6rem 0.75rem;
    }
    .logo {
      height: 30px;
      width: 30px;
      object-fit: contain;
    }
    .placeholder {
      display: grid;
      place-items: center;
      font-weight: 700;
      border-radius: 6px;
      background: rgb(255 255 255 / 20%);
    }
    .logo-text {
      font-weight: 600;
      flex: 1;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .field {
      display: grid;
      line-height: 1.15;
      min-width: 0;
    }
    .field small {
      font-size: 0.62rem;
      font-weight: 600;
      letter-spacing: 0.03em;
      opacity: 0.85;
    }
    .field b {
      font-weight: 500;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .right {
      text-align: right;
    }
    .strip {
      aspect-ratio: 375 / 123;
      display: flex;
      align-items: center;
      padding: 0 0.75rem;
      background-size: cover;
      background-position: center;
    }
    .primary b {
      font-size: 1.9rem;
      font-weight: 300;
    }
    .row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.5rem;
      padding: 0.6rem 0.75rem;
    }
    .qr {
      display: grid;
      justify-items: center;
      gap: 0.25rem;
      padding: 0.5rem 0 0.9rem;
    }
    .qr .code {
      width: 104px;
      height: 104px;
      border-radius: 6px;
      background:
        repeating-linear-gradient(90deg, #111 0 6px, #fff 6px 12px),
        #fff;
      border: 8px solid #fff;
      outline: 1px solid rgb(0 0 0 / 10%);
    }
    .qr small {
      font-size: 0.7rem;
      font-family: ui-monospace, Consolas, monospace;
    }
    figcaption {
      font-size: 0.78rem;
      color: var(--text-muted);
      text-align: center;
    }
  `,
})
export class ApplePassPreviewComponent {
  readonly design = input.required<Design>();
  readonly programName = input.required<string>();
  readonly establishmentName = input('');
  readonly type = input<ProgramType>('STAMPS');
  readonly balance = input<number>(0);
  readonly stampsRequired = input<number | null>(null);
  readonly code = input('');
  readonly holder = input('');
  readonly status = input<CardStatus | string>('ACTIVE');

  protected readonly initial = computed(() => (this.establishmentName() || this.programName()).charAt(0).toUpperCase());
  protected readonly situation = computed(() => SITUATION[this.status()] ?? 'Ativo');
  protected readonly firstName = computed(() => this.holder().trim().split(/\s+/)[0] || 'Cliente');
  protected readonly balanceLabel = computed(() => {
    switch (this.type()) {
      case 'POINTS':
        return 'PONTOS';
      case 'CASHBACK':
        return 'CASHBACK';
      case 'STAMPS':
        return 'CARIMBOS';
      default:
        return 'NÍVEL';
    }
  });
  protected readonly balanceText = computed(() =>
    this.type() === 'STAMPS' && this.stampsRequired()
      ? `${Math.trunc(this.balance())} de ${this.stampsRequired()}`
      : formatBalance(this.type(), this.balance()),
  );
}
