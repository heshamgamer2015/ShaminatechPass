import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { IconComponent } from './icon.component';

/** Estado vazio: explica o que falta e, pelo conteúdo projetado, oferece a próxima ação. */
@Component({
  selector: 'app-empty-state',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent],
  template: `
    <div class="empty">
      @if (icon()) {
        <span class="empty-icon"><app-icon [name]="icon()" [size]="22" /></span>
      }
      <strong>{{ title() }}</strong>
      @if (description()) {
        <p class="muted">{{ description() }}</p>
      }
      <div class="empty-actions"><ng-content /></div>
    </div>
  `,
  styles: `
    .empty {
      display: grid;
      justify-items: center;
      gap: 0.35rem;
      text-align: center;
      padding: 2.5rem 1.25rem;
      border: 1px dashed var(--border-strong);
      border-radius: var(--radius);
      background: var(--surface);
    }
    .empty-icon {
      display: grid;
      place-items: center;
      width: 44px;
      height: 44px;
      margin-bottom: 0.35rem;
      border-radius: 50%;
      background: var(--primary-soft);
      color: var(--primary-ink);
    }
    p {
      margin: 0;
      max-width: 46ch;
    }
    .empty-actions:not(:empty) {
      margin-top: 0.75rem;
    }
  `,
})
export class EmptyStateComponent {
  readonly title = input.required<string>();
  readonly description = input('');
  readonly icon = input('');
}
