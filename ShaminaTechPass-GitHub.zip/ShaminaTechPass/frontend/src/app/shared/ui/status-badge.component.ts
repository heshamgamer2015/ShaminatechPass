import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';
import { ROLE_LABELS, STATUS_LABELS } from '../labels';

const TONES: Record<string, string> = {
  ACTIVE: 'success',
  SUSPENDED: 'warning',
  CANCELLED: 'danger',
  DISABLED: 'neutral',
  INACTIVE: 'neutral',
  EXPIRED: 'warning',
  COMPLETED: 'info',
  PAUSED: 'warning',
  PENDING: 'info',
  SYNCING: 'info',
  SYNCED: 'success',
  FAILED: 'danger',
  SENDING: 'info',
  ACCEPTED: 'success',
  REJECTED: 'danger',
  QUOTA_EXCEEDED: 'warning',
  INVALIDATED: 'neutral',
  ARCHIVED: 'neutral',
  LOCKED: 'danger',
  OWNER: 'primary',
  MANAGER: 'info',
  STAFF: 'neutral',
  PLATFORM_ADMIN: 'primary',
};

/** Selo colorido para situações e papéis (estilos globais .badge / .tone-*). */
@Component({
  selector: 'app-badge',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<span [class]="'badge tone-' + tone() + (isRole() ? '' : ' dot')">{{ text() }}</span>`,
})
export class StatusBadgeComponent {
  readonly value = input.required<string>();
  /** Texto opcional; por padrão usa a tradução de papéis/situações. */
  readonly labelText = input<string>('');

  protected readonly isRole = computed(() => !!ROLE_LABELS[this.value()] && !STATUS_LABELS[this.value()]);
  protected readonly tone = computed(() => TONES[this.value()] ?? 'neutral');
  protected readonly text = computed(
    () => this.labelText() || STATUS_LABELS[this.value()] || ROLE_LABELS[this.value()] || this.value(),
  );
}
