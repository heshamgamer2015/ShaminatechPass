import { ChangeDetectionStrategy, Component, input } from '@angular/core';

/**
 * Símbolo da ShaminaTech (o "S" contínuo com o ponto), redesenhado em vetor a partir de wallet-logo/*.png.
 * Para o ShaminaTech Pass muda apenas a cor — #F43F5E por padrão —, preservando o desenho da marca.
 */
@Component({
  selector: 'app-brand-mark',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { 'aria-hidden': 'true' },
  template: `
    <svg [attr.width]="size()" [attr.height]="size()" viewBox="0 0 660 660" focusable="false">
      <path [attr.stroke]="color()"
            d="M222 118 C170 118 145 145 145 171 C145 197 170 224 222 224 H438 C485 224 515 248 515 277 C515 306 485 330 438 330
               H222 C170 330 145 357 145 383 C145 409 170 436 222 436 H438 C485 436 515 460 515 489 C515 518 485 542 438 542 H222"
            fill="none" stroke-width="54" stroke-linecap="round" stroke-linejoin="round" />
      <circle cx="490" cy="172" r="27" [attr.fill]="color()" />
    </svg>
  `,
  styles: `
    :host {
      display: inline-flex;
      line-height: 0;
    }
  `,
})
export class BrandMarkComponent {
  readonly size = input(32);
  readonly color = input('#F43F5E');
}
