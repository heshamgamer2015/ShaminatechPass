import { ChangeDetectionStrategy, Component, ElementRef, computed, effect, inject, signal, viewChild } from '@angular/core';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { IconComponent } from './icon.component';

/**
 * Diálogo modal de confirmação (um por aplicação, no componente raiz).
 * Usa <dialog> nativo: foco preso no diálogo, Esc cancela, o foco volta ao elemento que abriu.
 */
@Component({
  selector: 'app-confirm-host',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent],
  template: `
    <dialog #dialog class="dialog" aria-labelledby="confirm-title" [attr.aria-describedby]="req()?.message ? 'confirm-msg' : null"
            (cancel)="cancel($event)" (close)="closed()">
      @if (req(); as r) {
        <form method="dialog" (submit)="accept($event)">
          <div class="dialog-body">
            <div class="head">
              <span class="mark" [class.danger]="r.tone === 'danger'"><app-icon [name]="r.tone === 'danger' ? 'alert' : 'info'" [size]="20" /></span>
              <h2 id="confirm-title">{{ r.title }}</h2>
            </div>
            @if (r.message) {
              <p id="confirm-msg" class="msg">{{ r.message }}</p>
            }
            @if (r.reason && r.reason !== 'none') {
              <div class="field">
                <label for="confirm-reason">{{ r.reasonLabel ?? 'Motivo' }}
                  @if (r.reason === 'optional') { <span class="muted">(opcional)</span> }</label>
                <textarea #reasonInput id="confirm-reason" class="input" rows="3" maxlength="500"
                          [value]="reason()" (input)="reason.set($any($event.target).value)"
                          [attr.aria-required]="r.reason === 'required'"></textarea>
              </div>
            }
          </div>
          <div class="dialog-actions">
            <button type="button" class="btn" (click)="cancel()">{{ r.cancelLabel ?? 'Cancelar' }}</button>
            <button #okButton type="submit" class="btn" [class.btn-primary]="r.tone !== 'danger'" [class.btn-danger-solid]="r.tone === 'danger'"
                    [disabled]="blocked()">{{ r.confirmLabel ?? 'Confirmar' }}</button>
          </div>
        </form>
      }
    </dialog>
  `,
  styles: `
    .head {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      margin-bottom: 0.5rem;
    }
    h2 {
      margin: 0;
      font-size: var(--text-lg);
    }
    .mark {
      display: grid;
      place-items: center;
      width: 38px;
      height: 38px;
      flex: none;
      border-radius: 50%;
      background: var(--info-soft);
      color: var(--info);
    }
    .mark.danger {
      background: var(--danger-soft);
      color: var(--danger);
    }
    .msg {
      margin: 0 0 0.25rem;
      color: var(--text-muted);
      white-space: pre-line;
    }
    .field {
      margin-top: 1rem;
    }
    .btn-danger-solid {
      background: var(--danger);
      border-color: var(--danger);
      color: #fff;
    }
    .btn-danger-solid:hover:not(:disabled) {
      background: #991b1b;
      border-color: #991b1b;
      color: #fff;
    }
  `,
})
export class ConfirmHostComponent {
  private readonly service = inject(ConfirmService);
  private readonly dialog = viewChild.required<ElementRef<HTMLDialogElement>>('dialog');
  private readonly reasonInput = viewChild<ElementRef<HTMLTextAreaElement>>('reasonInput');
  private readonly okButton = viewChild<ElementRef<HTMLButtonElement>>('okButton');

  protected readonly req = this.service.current;
  protected readonly reason = signal('');
  protected readonly blocked = computed(() => this.req()?.reason === 'required' && !this.reason().trim());

  constructor() {
    effect(() => {
      const r = this.req();
      const el = this.dialog().nativeElement;
      if (r) {
        this.reason.set('');
        if (!el.open) {
          if (typeof el.showModal === 'function') el.showModal();
          else el.setAttribute('open', '');
        }
        // Foco inicial: o campo de motivo, se houver; senão o botão de confirmar (Enter confirma).
        queueMicrotask(() => (this.reasonInput() ?? this.okButton())?.nativeElement.focus());
      } else if (el.open) {
        if (typeof el.close === 'function') el.close();
        else el.removeAttribute('open');
      }
    });
  }

  protected accept(event: Event): void {
    event.preventDefault();
    const r = this.req();
    if (!r || this.blocked()) return;
    r.resolve(this.reason().trim());
  }

  protected cancel(event?: Event): void {
    event?.preventDefault();
    this.req()?.resolve(null);
  }

  /** Fechado por outro meio (ex.: Esc em navegadores que fecham direto): conta como cancelamento. */
  protected closed(): void {
    this.req()?.resolve(null);
  }
}
