import { TestBed } from '@angular/core/testing';
import { ConfirmService } from '../../core/notifications/confirm.service';
import { ConfirmHostComponent } from './confirm-host.component';

describe('ConfirmHostComponent', () => {
  async function setup() {
    await TestBed.configureTestingModule({ imports: [ConfirmHostComponent] }).compileComponents();
    const fixture = TestBed.createComponent(ConfirmHostComponent);
    await fixture.whenStable();
    return { fixture, el: fixture.nativeElement as HTMLElement, service: TestBed.inject(ConfirmService) };
  }

  it('confirma e devolve texto vazio quando não há motivo', async () => {
    const { fixture, el, service } = await setup();
    const answer = service.confirm({ title: 'Desativar o QR Code?', message: 'Quem escanear verá...', tone: 'danger', confirmLabel: 'Desativar' });
    await fixture.whenStable();
    expect(el.querySelector('#confirm-title')!.textContent).toContain('Desativar o QR Code?');
    expect(el.querySelector('dialog')!.hasAttribute('open')).toBe(true);
    el.querySelector<HTMLButtonElement>('button[type=submit]')!.click();
    expect(await answer).toBe(true);
    await fixture.whenStable();
    expect(service.current()).toBeNull();
  });

  it('cancela e devolve null', async () => {
    const { fixture, el, service } = await setup();
    const answer = service.ask({ title: 'Estornar?' });
    await fixture.whenStable();
    el.querySelector<HTMLButtonElement>('button[type=button]')!.click();
    expect(await answer).toBeNull();
  });

  it('só libera o botão com o motivo obrigatório preenchido', async () => {
    const { fixture, el, service } = await setup();
    const answer = service.ask({ title: 'Cancelar o cartão?', reason: 'required', reasonLabel: 'Motivo do cancelamento' });
    await fixture.whenStable();
    const ok = el.querySelector<HTMLButtonElement>('button[type=submit]')!;
    expect(ok.disabled).toBe(true);
    const text = el.querySelector<HTMLTextAreaElement>('#confirm-reason')!;
    text.value = '  cliente pediu  ';
    text.dispatchEvent(new Event('input'));
    await fixture.whenStable();
    expect(ok.disabled).toBe(false);
    ok.click();
    expect(await answer).toBe('cliente pediu');
  });
});
