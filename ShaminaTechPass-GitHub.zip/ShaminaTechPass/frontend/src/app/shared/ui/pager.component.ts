import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

/** Paginação simples (anterior/próxima). `page` começa em 0, como na API. */
@Component({
  selector: 'app-pager',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (totalPages() > 1) {
      <nav class="pager" aria-label="Paginação">
        <button class="btn btn-sm" type="button" [disabled]="page() === 0" (click)="pageChange.emit(page() - 1)">
          Anterior
        </button>
        <span class="muted">Página {{ page() + 1 }} de {{ totalPages() }}</span>
        <button class="btn btn-sm" type="button" [disabled]="page() + 1 >= totalPages()" (click)="pageChange.emit(page() + 1)">
          Próxima
        </button>
      </nav>
    }
  `,
  styles: `
    .pager {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 1rem;
      margin-top: 1rem;
    }
  `,
})
export class PagerComponent {
  readonly page = input.required<number>();
  readonly totalPages = input.required<number>();
  readonly pageChange = output<number>();
}
