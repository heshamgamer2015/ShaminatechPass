import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';
import { Design, ProgramType } from '../../core/loyalty-models';
import { formatBalance } from '../labels';

/**
 * Prévia interna do cartão (não representa fielmente o Google Wallet nem o Apple Wallet).
 * Usada na personalização e no detalhe do cartão.
 */
@Component({
  selector: 'app-card-preview',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <article class="pass" [style.background]="design().brandColor" [style.color]="design().textColor"
             [attr.aria-label]="'Prévia do cartão ' + programName()">
      @if (design().heroUrl) {
        <img class="hero" [src]="design().heroUrl" alt="" />
      }
      <header>
        @if (design().logoUrl) {
          <img class="logo" [src]="design().logoUrl" alt="Logotipo" />
        } @else {
          <span class="logo placeholder" aria-hidden="true">{{ initial() }}</span>
        }
        <div>
          <small>{{ establishmentName() }}</small>
          <strong>{{ programName() }}</strong>
        </div>
      </header>

      @if (type() === 'STAMPS' && stampsRequired()) {
        <div class="stamps" [attr.aria-label]="balanceText()">
          @for (s of stampSlots(); track $index) {
            <span class="stamp" [class.on]="s"></span>
          }
        </div>
      } @else {
        <p class="balance"><small>Saldo</small>{{ balanceText() }}</p>
      }

      @if (design().cardMessage) {
        <p class="message">{{ design().cardMessage }}</p>
      }
      @if (design().rewardInfo) {
        <p class="reward">{{ design().rewardInfo }}</p>
      }
      <footer>
        <span class="code">{{ code() || 'XXXX-XXXX-XXXX-XXXX' }}</span>
        @if (holder()) {
          <span>{{ holder() }}</span>
        }
      </footer>
    </article>
  `,
  styles: `
    .pass {
      position: relative;
      overflow: hidden;
      width: 100%;
      max-width: 360px;
      border-radius: 18px;
      padding: 1rem 1.1rem;
      box-shadow: 0 10px 30px rgb(15 23 42 / 18%);
      display: grid;
      gap: 0.75rem;
    }
    .hero {
      width: calc(100% + 2.2rem);
      margin: -1rem -1.1rem 0;
      aspect-ratio: 1032 / 812;
      max-height: 220px;
      object-fit: cover;
    }
    header {
      display: flex;
      gap: 0.75rem;
      align-items: center;
    }
    header div {
      display: grid;
    }
    header small {
      opacity: 0.8;
    }
    .logo {
      width: 44px;
      height: 44px;
      border-radius: 50%; /* o Google Wallet recorta o logotipo em círculo */
      object-fit: cover;
      background: rgb(255 255 255 / 25%);
    }
    .placeholder {
      display: grid;
      place-items: center;
      font-weight: 800;
      font-size: 1.2rem;
    }
    .balance {
      margin: 0;
      display: grid;
      font-size: 1.6rem;
      font-weight: 800;
    }
    .balance small {
      font-size: 0.8rem;
      font-weight: 500;
      opacity: 0.8;
    }
    .stamps {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 0.4rem;
    }
    .stamp {
      aspect-ratio: 1;
      border-radius: 50%;
      border: 2px dashed currentColor;
      opacity: 0.6;
    }
    .stamp.on {
      background: currentColor;
      opacity: 1;
      border-style: solid;
    }
    .message,
    .reward {
      margin: 0;
      font-size: 0.9rem;
    }
    .reward {
      opacity: 0.85;
    }
    footer {
      display: flex;
      justify-content: space-between;
      gap: 0.5rem;
      font-size: 0.8rem;
      opacity: 0.9;
    }
    .code {
      font-family: ui-monospace, Consolas, monospace;
      letter-spacing: 0.04em;
    }
  `,
})
export class CardPreviewComponent {
  readonly design = input.required<Design>();
  readonly programName = input.required<string>();
  readonly establishmentName = input('');
  readonly type = input<ProgramType>('STAMPS');
  readonly balance = input<number>(0);
  readonly stampsRequired = input<number | null>(null);
  readonly code = input('');
  readonly holder = input('');

  protected readonly initial = computed(() => (this.establishmentName() || this.programName()).charAt(0).toUpperCase());
  protected readonly balanceText = computed(() => formatBalance(this.type(), this.balance()));
  protected readonly stampSlots = computed(() => {
    const total = Math.min(this.stampsRequired() ?? 0, 30);
    return Array.from({ length: total }, (_, i) => i < this.balance());
  });
}
