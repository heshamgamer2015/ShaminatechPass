import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { NotificationService } from '../../core/notifications/notification.service';

@Component({
  selector: 'app-toast-host',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="toasts" aria-live="polite">
      @for (toast of notifications.toasts(); track toast.id) {
        <div class="toast" [class]="'toast toast-' + toast.kind" role="status">
          <span>{{ toast.message }}</span>
          <button type="button" class="close" aria-label="Fechar" (click)="notifications.dismiss(toast.id)">×</button>
        </div>
      }
    </div>
  `,
  styles: `
    .toasts {
      position: fixed;
      right: 1rem;
      bottom: 1rem;
      left: 1rem;
      display: grid;
      justify-items: end;
      gap: 0.5rem;
      z-index: 100;
      pointer-events: none;
    }
    .toast {
      pointer-events: auto;
      display: flex;
      align-items: center;
      gap: 0.75rem;
      max-width: 420px;
      padding: 0.75rem 0.9rem 0.75rem 1rem;
      border-radius: var(--radius-sm);
      color: #fff;
      box-shadow: var(--shadow-lg);
      background: #1f2937;
      font-size: var(--text-base);
    }
    .toast-success { background: var(--success); }
    .toast-error { background: var(--danger); }
    .close {
      display: grid;
      place-items: center;
      min-width: 32px;
      min-height: 32px;
      border-radius: 6px;
      border: 0;
      background: transparent;
      color: inherit;
      font-size: 1.25rem;
      cursor: pointer;
      line-height: 1;
    }
  `,
})
export class ToastHostComponent {
  protected readonly notifications = inject(NotificationService);
}
