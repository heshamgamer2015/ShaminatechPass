import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Transaction } from '../../core/loyalty-models';
import { CHANNEL_LABELS, TRANSACTION_LABELS, formatBalance, formatMoney, label } from '../labels';

/** Histórico de movimentações (imutável). O botão de estorno só aparece quando permitido. */
@Component({
  selector: 'app-transaction-table',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe, RouterLink],
  template: `
    @if (items().length === 0) {
      <p class="muted">Nenhuma movimentação registrada.</p>
    } @else {
      <div class="table-wrap">
        <table class="table responsive">
          <thead>
            <tr>
              <th>Data</th>
              <th>Operação</th>
              @if (showCustomer()) {
                <th>Cliente</th>
              }
              <th>Valor</th>
              <th>Saldo após</th>
              <th>Compra</th>
              <th>Canal</th>
              @if (canReverse()) {
                <th><span class="sr-only">Ações</span></th>
              }
            </tr>
          </thead>
          <tbody>
            @for (t of items(); track t.id) {
              <tr [class.reversed]="t.reversed">
                <td data-label="Data">{{ t.occurredAt | date: 'dd/MM/yyyy HH:mm' }}</td>
                <td data-label="Operação">
                  <strong>{{ typeLabel(t.type) }}</strong>
                  @if (t.description) {
                    <br /><span class="muted">{{ t.description }}</span>
                  }
                  @if (t.note) {
                    <br /><span class="muted">“{{ t.note }}”</span>
                  }
                  @if (t.reversed) {
                    <br /><span class="tag">estornada</span>
                  }
                  @if (t.reversesId) {
                    <br /><span class="muted">estorno da operação nº {{ t.reversesId }}</span>
                  }
                </td>
                @if (showCustomer()) {
                  <td data-label="Cliente">
                    <a [routerLink]="[base() + '/clientes', t.consumerId]">{{ t.consumerName }}</a>
                    <br /><span class="muted">{{ t.programName }}</span>
                  </td>
                }
                <td data-label="Valor" [class.neg]="t.amount < 0" [class.pos]="t.amount > 0">
                  {{ t.amount === 0 ? '—' : (t.amount > 0 ? '+' : '') + balance(t, t.amount) }}
                </td>
                <td data-label="Saldo após">{{ balance(t, t.balanceAfter) }}</td>
                <td data-label="Compra">{{ t.purchaseAmount != null ? money(t.purchaseAmount) : '—' }}</td>
                <td data-label="Canal">{{ channel(t.channel) }}</td>
                @if (canReverse()) {
                  <td data-label="">
                    @if (t.reversible) {
                      <button class="btn btn-sm btn-danger" type="button" (click)="reverse.emit(t)">Estornar</button>
                    }
                  </td>
                }
              </tr>
            }
          </tbody>
        </table>
      </div>
    }
  `,
  styles: `
    .neg { color: var(--danger); font-weight: 600; }
    .pos { color: var(--success); font-weight: 600; }
    .reversed td { opacity: 0.65; }
    .tag {
      font-size: 0.75rem;
      padding: 0 0.4rem;
      border-radius: 4px;
      background: var(--warning-soft);
      color: var(--warning);
    }
    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0 0 0 0);
    }
  `,
})
export class TransactionTableComponent {
  readonly items = input.required<Transaction[]>();
  readonly showCustomer = input(false);
  /** Caminho do painel (ex.: /e/1), para os links de cliente. */
  readonly base = input('');
  readonly canReverse = input(false);
  readonly reverse = output<Transaction>();

  protected typeLabel(type: string): string {
    return label(TRANSACTION_LABELS, type);
  }

  protected channel(c: string): string {
    return label(CHANNEL_LABELS, c);
  }

  protected balance(t: Transaction, value: number): string {
    return formatBalance(t.programType, value);
  }

  protected money(value: number): string {
    return formatMoney(value);
  }
}
