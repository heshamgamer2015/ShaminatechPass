import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';

/**
 * Mensagem de erro de um campo: prioriza a mensagem do servidor; caso contrário,
 * exibe a mensagem de validação local recebida (quando o campo já foi tocado).
 */
@Component({
  selector: 'app-field-error',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (message(); as text) {
      <span class="field-error" role="alert">{{ text }}</span>
    }
  `,
})
export class FieldErrorComponent {
  readonly server = input<string | undefined>(undefined);
  readonly local = input<string | null>(null);

  protected readonly message = computed(() => this.server() || this.local());
}
