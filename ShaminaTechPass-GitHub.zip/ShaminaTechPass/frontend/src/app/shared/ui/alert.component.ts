import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';
import { IconComponent } from './icon.component';

export type AlertKind = 'error' | 'success' | 'info' | 'warning';

const ICONS: Record<AlertKind, string> = { error: 'alert', success: 'check-circle', info: 'info', warning: 'alert' };

/** Mensagem de estado em linha. Erros usam role="alert"; os demais, role="status". */
@Component({
  selector: 'app-alert',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent],
  host: { '[attr.role]': "kind() === 'error' ? 'alert' : 'status'" },
  template: `
    <div [class]="'alert alert-' + kind()">
      <app-icon [name]="icon()" [size]="18" />
      <div class="alert-body"><ng-content /></div>
    </div>
  `,
  styles: `
    .alert {
      display: flex;
      gap: 0.65rem;
      align-items: flex-start;
      padding: 0.75rem 1rem;
      border-radius: var(--radius-sm);
      border: 1px solid transparent;
      font-size: var(--text-base);
      line-height: 1.45;
    }
    app-icon {
      margin-top: 0.1rem;
    }
    .alert-body {
      min-width: 0;
      flex: 1;
    }
    .alert-error {
      background: var(--danger-soft);
      color: var(--danger);
      border-color: color-mix(in srgb, var(--danger) 20%, transparent);
    }
    .alert-success {
      background: var(--success-soft);
      color: var(--success);
      border-color: color-mix(in srgb, var(--success) 18%, transparent);
    }
    .alert-info {
      background: var(--info-soft);
      color: var(--info);
      border-color: color-mix(in srgb, var(--info) 15%, transparent);
    }
    .alert-warning {
      background: var(--warning-soft);
      color: var(--warning);
      border-color: color-mix(in srgb, var(--warning) 20%, transparent);
    }
  `,
})
export class AlertComponent {
  readonly kind = input<AlertKind>('info');
  protected readonly icon = computed(() => ICONS[this.kind()]);
}
