import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { AuditEvent } from '../../core/models';
import { AUDIT_LABELS, label } from '../labels';

/** Tom visual do evento a partir do código da ação (somente apresentação; o registro não é alterado). */
function toneOf(action: string): string {
  if (/BLOCKED|FAILED|LOCK|CANCEL|REVOK|REMOVED|DISABLED|SUSPEND/.test(action)) return 'danger';
  if (/CREATED|ADDED|ISSUED|SAVED|UNLOCK|REACTIVAT/.test(action)) return 'success';
  if (/LOGIN|LOGOUT|PASSWORD/.test(action)) return 'info';
  return 'neutral';
}

/**
 * Tabela de eventos de auditoria (painel ShaminaTech e painel do estabelecimento). Somente leitura: não há edição
 * nem exclusão de registros. Datas no fuso do navegador, com data e hora em linhas separadas.
 */
@Component({
  selector: 'app-audit-table',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe],
  template: `
    <div class="table-wrap">
      <table class="table responsive">
        <thead>
          <tr>
            <th>Quando</th>
            <th>Evento</th>
            <th>Autor</th>
            @if (showEstablishment()) {
              <th>Estab.</th>
            }
            <th>Detalhes</th>
          </tr>
        </thead>
        <tbody>
          @for (event of events(); track event.id) {
            <tr>
              <td data-label="Quando" class="when">
                <time [attr.datetime]="event.occurredAt" [title]="event.occurredAt | date: 'dd/MM/yyyy HH:mm:ss'">
                  <span>{{ event.occurredAt | date: 'dd/MM/yyyy' }}</span>
                  <span class="muted small">{{ event.occurredAt | date: 'HH:mm' }}</span>
                </time>
              </td>
              <td data-label="Evento"><span [class]="'badge dot tone-' + tone(event.action)">{{ actionLabel(event.action) }}</span></td>
              <td data-label="Autor" class="author">
                @if (event.actorEmail) {
                  {{ event.actorEmail }}
                } @else {
                  <span class="muted">Sistema</span>
                }
              </td>
              @if (showEstablishment()) {
                <td data-label="Estab." class="num">{{ event.establishmentId ?? '—' }}</td>
              }
              <td data-label="Detalhes" class="details-cell">{{ event.details ?? '—' }}</td>
            </tr>
          }
        </tbody>
      </table>
    </div>
  `,
  styles: `
    time {
      display: grid;
      line-height: 1.35;
      white-space: nowrap;
    }
    .author {
      overflow-wrap: anywhere;
    }
    .details-cell {
      max-width: 420px;
      font-size: var(--text-sm);
      color: var(--text-muted);
      overflow-wrap: anywhere;
    }
    .badge {
      white-space: normal;
    }
    @media (max-width: 720px) {
      time {
        display: flex;
        gap: 0.4rem;
      }
      .details-cell {
        max-width: none;
      }
    }
  `,
})
export class AuditTableComponent {
  readonly events = input.required<AuditEvent[]>();
  readonly showEstablishment = input(false);

  protected actionLabel(action: string): string {
    return label(AUDIT_LABELS, action);
  }

  protected tone(action: string): string {
    return toneOf(action);
  }
}
