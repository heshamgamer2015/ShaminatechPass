import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { IconComponent } from './icon.component';

/** Cabeçalho de página: link de volta (opcional), título, subtítulo e ações (conteúdo projetado). */
@Component({
  selector: 'app-page-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, IconComponent],
  template: `
    <header class="page-header">
      <div class="titles">
        @if (backLink()) {
          <a class="back" [routerLink]="backLink()"><app-icon name="arrow-left" [size]="16" /> {{ backLabel() }}</a>
        }
        <h1>{{ title() }}</h1>
        @if (subtitle()) {
          <p class="muted">{{ subtitle() }}</p>
        }
      </div>
      <div class="actions"><ng-content /></div>
    </header>
  `,
  styles: `
    .page-header {
      display: flex;
      flex-wrap: wrap;
      gap: 0.75rem 1rem;
      align-items: flex-end;
      justify-content: space-between;
      margin-bottom: 1.5rem;
    }
    .titles {
      min-width: 0;
    }
    h1 {
      margin: 0;
      font-size: var(--text-xl);
    }
    p {
      margin: 0.25rem 0 0;
      max-width: 70ch;
    }
    .back {
      display: inline-flex;
      align-items: center;
      gap: 0.35rem;
      margin-bottom: 0.5rem;
      font-size: var(--text-sm);
      font-weight: 600;
      color: var(--text-muted);
      text-decoration: none;
    }
    .back:hover {
      color: var(--text);
    }
    .actions:empty {
      display: none;
    }
  `,
})
export class PageHeaderComponent {
  readonly title = input.required<string>();
  readonly subtitle = input<string>('');
  readonly backLink = input<string | unknown[] | null>(null);
  readonly backLabel = input('Voltar');
}
