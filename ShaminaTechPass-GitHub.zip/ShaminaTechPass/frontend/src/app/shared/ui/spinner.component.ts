import { ChangeDetectionStrategy, Component, input } from '@angular/core';

@Component({
  selector: 'app-spinner',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="spinner-wrap" role="status" aria-live="polite">
      <span class="spinner" aria-hidden="true"></span>
      <span>{{ text() }}</span>
    </div>
  `,
  styles: `
    .spinner-wrap {
      display: flex;
      align-items: center;
      gap: 0.6rem;
      padding: 1.5rem;
      color: var(--text-muted);
    }
    .spinner {
      width: 18px;
      height: 18px;
      border: 3px solid var(--primary-soft);
      border-top-color: var(--primary);
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
  `,
})
export class SpinnerComponent {
  readonly text = input('Carregando…');
}
