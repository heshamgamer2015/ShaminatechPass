import { generateTemporaryPassword, slugify } from './labels';

describe('utilitários', () => {
  it('slugify gera identificadores válidos para o backend', () => {
    expect(slugify('Café & Padaria São João!')).toBe('cafe-padaria-sao-joao');
    expect(slugify('  --Loja  2--  ')).toBe('loja-2');
    expect(slugify('x'.repeat(120)).length).toBe(80);
  });

  it('senha temporária atende à política (10+ caracteres, letras e números)', () => {
    for (let i = 0; i < 50; i++) {
      const password = generateTemporaryPassword();
      expect(password.length).toBeGreaterThanOrEqual(10);
      expect(password).toMatch(/[A-Za-z]/);
      expect(password).toMatch(/\d/);
    }
  });
});
