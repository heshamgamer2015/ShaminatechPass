import { detectDevice } from './device';

const UA = {
  android: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
  androidReduced: 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
  iphone: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1',
  iphoneChrome: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/131.0 Mobile/15E148 Safari/604.1',
  iphoneInstagram: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Instagram 350.0.0.0',
  ipadOs: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15',
  ipadOld: 'Mozilla/5.0 (iPad; CPU OS 12_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1 Mobile/15E148 Safari/604.1',
  windows: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  androidFacebook: 'Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36 [FBAN/EMA;FBAV/400.0]',
};

describe('detectDevice', () => {
  it('reconhece Android, inclusive com User-Agent reduzido e por Client Hints', () => {
    for (const ua of [UA.android, UA.androidReduced]) {
      const d = detectDevice({ userAgent: ua });
      expect(d.platform).toBe('android');
      expect(d.recommended).toBe('GOOGLE_WALLET');
      expect(d.canInstall.APPLE_WALLET).toBe(false);
    }
    expect(detectDevice({ userAgent: 'Mozilla/5.0', uaPlatform: 'Android', uaMobile: true }).platform).toBe('android');
  });

  it('reconhece iPhone em qualquer navegador do iOS', () => {
    for (const ua of [UA.iphone, UA.iphoneChrome]) {
      const d = detectDevice({ userAgent: ua, maxTouchPoints: 5 });
      expect(d.platform).toBe('ios');
      expect(d.recommended).toBe('APPLE_WALLET');
      expect(d.openOnPhone).toBe(false);
    }
  });

  it('identifica o iPadOS que se apresenta como Mac, sem confundir com um Mac de verdade', () => {
    expect(detectDevice({ userAgent: UA.ipadOs, maxTouchPoints: 5 }).platform).toBe('ipados');
    expect(detectDevice({ userAgent: UA.ipadOld, maxTouchPoints: 5 }).platform).toBe('ipados');
    const mac = detectDevice({ userAgent: UA.ipadOs, maxTouchPoints: 0 });
    expect(mac.platform).toBe('mac');
    expect(mac.openOnPhone).toBe(true);
    expect(mac.recommended).toBeNull();
  });

  it('computador não recebe recomendação e é orientado a abrir no celular', () => {
    const d = detectDevice({ userAgent: UA.windows });
    expect(d.platform).toBe('desktop');
    expect(d.recommended).toBeNull();
    expect(d.openOnPhone).toBe(true);
    expect(d.canInstall).toEqual({ GOOGLE_WALLET: false, APPLE_WALLET: false });
  });

  it('aparelho desconhecido não é bloqueado: as duas carteiras continuam disponíveis', () => {
    for (const ua of ['', 'curl/8.0', 'Mozilla/5.0']) {
      const d = detectDevice({ userAgent: ua });
      expect(d.platform).toBe('unknown');
      expect(d.recommended).toBeNull();
      expect(d.canInstall).toEqual({ GOOGLE_WALLET: true, APPLE_WALLET: true });
      expect(d.openOnPhone).toBe(false);
    }
  });

  it('identifica navegadores internos de aplicativos', () => {
    expect(detectDevice({ userAgent: UA.iphoneInstagram }).inAppBrowser).toBe('Instagram');
    expect(detectDevice({ userAgent: UA.androidFacebook }).inAppBrowser).toBe('Facebook');
    expect(detectDevice({ userAgent: UA.iphone }).inAppBrowser).toBeNull();
  });
});
