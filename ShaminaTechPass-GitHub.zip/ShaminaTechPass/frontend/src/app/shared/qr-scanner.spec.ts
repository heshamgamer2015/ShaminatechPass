import { classifyScan } from './qr-scanner';
import { contrastRatio, readableTextColor } from './color';

describe('classifyScan', () => {
  it('reconhece o código do cartão e normaliza como o backend', () => {
    expect(classifyScan('abcd-efgh-jkmn-pqrs')).toEqual({ kind: 'CARD', code: 'ABCDEFGHJKMNPQRS' });
    expect(classifyScan(' 0123 4567 89ab cdef ')).toEqual({ kind: 'CARD', code: '0123456789ABCDEF' });
    expect(classifyScan('OIL0-0000-0000-0000').code).toBe('0110000000000000');
  });

  it('não confunde o QR Code de cadastro nem o link da carteira com um cartão', () => {
    expect(classifyScan('http://192.168.0.2:4203/cadastro/' + 'a'.repeat(32)).kind).toBe('SIGNUP_QR');
    expect(classifyScan('https://pass.example/carteira/' + '0'.repeat(32)).kind).toBe('WALLET_LINK');
  });

  it('recusa leituras que não são de cartão', () => {
    expect(classifyScan('https://example.com').kind).toBe('UNKNOWN');
    expect(classifyScan('ABC').kind).toBe('UNKNOWN');
    expect(classifyScan('UUUU-UUUU-UUUU-UUUU').kind).toBe('UNKNOWN'); // U não pertence ao alfabeto
  });
});

describe('readableTextColor', () => {
  it('mantém a cor escolhida quando o contraste é suficiente', () => {
    expect(readableTextColor('#000000', '#FFFFFF')).toBe('#FFFFFF');
    expect(contrastRatio('#000000', '#ffffff')).toBeCloseTo(21, 0);
  });

  it('troca por preto ou branco quando o contraste é baixo', () => {
    expect(readableTextColor('#FFE4E6', '#FFFFFF')).toBe('#000000');
    expect(readableTextColor('#1E3A8A', '#1E40AF')).toBe('#ffffff');
    expect(readableTextColor('#F43F5E', null)).toMatch(/^#(000000|ffffff)$/);
  });
});
