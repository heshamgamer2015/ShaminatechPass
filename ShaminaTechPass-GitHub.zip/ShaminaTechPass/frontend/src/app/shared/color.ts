/** Utilitários de cor para respeitar contraste (WCAG) ao usar as cores escolhidas pelo estabelecimento. */

function channel(c: number): number {
  const s = c / 255;
  return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
}

function luminance(hex: string): number | null {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return null;
  const n = parseInt(m[1], 16);
  return 0.2126 * channel((n >> 16) & 255) + 0.7152 * channel((n >> 8) & 255) + 0.0722 * channel(n & 255);
}

/** Razão de contraste entre duas cores #RRGGBB (1 a 21); null se alguma for inválida. */
export function contrastRatio(a: string, b: string): number | null {
  const la = luminance(a);
  const lb = luminance(b);
  if (la === null || lb === null) return null;
  const [hi, lo] = la > lb ? [la, lb] : [lb, la];
  return (hi + 0.05) / (lo + 0.05);
}

/**
 * Cor de texto legível sobre {@code background}: a preferida quando o contraste é de pelo menos 4,5:1 (AA); senão,
 * preto ou branco, o que contrastar mais.
 */
export function readableTextColor(background: string, preferred: string | null | undefined): string {
  if (preferred && (contrastRatio(background, preferred) ?? 0) >= 4.5) return preferred;
  const white = contrastRatio(background, '#ffffff') ?? 21;
  const black = contrastRatio(background, '#000000') ?? 0;
  return white >= black ? '#ffffff' : '#000000';
}
