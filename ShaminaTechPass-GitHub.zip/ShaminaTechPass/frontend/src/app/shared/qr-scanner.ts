/**
 * Leitura de QR Code pela câmera do navegador.
 * - Usa o leitor nativo (BarcodeDetector) quando existe (Chrome/Edge no Android, macOS e ChromeOS);
 * - Senão, decodifica os quadros com jsQR (carregado só quando a câmera é aberta), o que cobre Safari, Firefox e
 *   Chrome no Windows.
 * A câmera exige contexto seguro (HTTPS ou localhost): fora dele o navegador nem oferece a permissão.
 */

export type CameraProblem = 'INSECURE' | 'UNSUPPORTED' | 'DENIED' | 'NO_CAMERA' | 'BUSY' | 'FAILED';

export const CAMERA_PROBLEM_MESSAGES: Record<CameraProblem, string> = {
  INSECURE:
    'A câmera só funciona em conexão segura (HTTPS) ou no próprio computador (localhost). Use um leitor de código ou digite o código.',
  UNSUPPORTED: 'Este navegador não permite usar a câmera. Use um leitor de código ou digite o código.',
  DENIED: 'O acesso à câmera foi negado. Libere a câmera nas configurações do navegador para este site e tente de novo.',
  NO_CAMERA: 'Nenhuma câmera foi encontrada neste aparelho.',
  BUSY: 'A câmera está sendo usada por outro aplicativo. Feche-o e tente de novo.',
  FAILED: 'Não foi possível abrir a câmera. Use um leitor de código ou digite o código.',
};

/** O que foi lido: código de cartão, QR Code de cadastro do balcão, link de carteira ou outra coisa. */
export type ScanKind = 'CARD' | 'SIGNUP_QR' | 'WALLET_LINK' | 'UNKNOWN';

const CARD_CODE = /^[0-9A-HJKMNP-TV-Z]{16}$/;

/** Classifica o conteúdo lido. Para cartão, devolve o código normalizado (como o backend: O→0, I/L→1). */
export function classifyScan(raw: string): { kind: ScanKind; code: string | null } {
  const value = raw.trim();
  if (/\/cadastro\/[0-9a-f]{32}\b/i.test(value)) return { kind: 'SIGNUP_QR', code: null };
  if (/\/carteira\/[0-9a-f]{32}\b/i.test(value)) return { kind: 'WALLET_LINK', code: null };
  const normalized = value.toUpperCase().replace(/[\s-]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1');
  if (CARD_CODE.test(normalized)) return { kind: 'CARD', code: normalized };
  return { kind: 'UNKNOWN', code: null };
}

interface BarcodeDetectorLike {
  detect(source: CanvasImageSource): Promise<{ rawValue: string }[]>;
}

type JsQr = (data: Uint8ClampedArray, width: number, height: number, options?: object) => { data: string } | null;

export class QrScanner {
  private stream: MediaStream | null = null;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private stopped = false;

  /** Abre a câmera traseira e chama {@code onResult} a cada leitura. Lança {@link CameraProblem} em caso de erro. */
  async start(video: HTMLVideoElement, onResult: (text: string) => void): Promise<void> {
    if (typeof window !== 'undefined' && !window.isSecureContext) throw 'INSECURE' as CameraProblem;
    if (!navigator.mediaDevices?.getUserMedia) throw 'UNSUPPORTED' as CameraProblem;
    this.stopped = false;
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
    } catch (e) {
      const name = (e as { name?: string })?.name;
      if (name === 'NotAllowedError' || name === 'SecurityError') throw 'DENIED' as CameraProblem;
      if (name === 'NotFoundError' || name === 'OverconstrainedError') throw 'NO_CAMERA' as CameraProblem;
      if (name === 'NotReadableError' || name === 'AbortError') throw 'BUSY' as CameraProblem;
      throw 'FAILED' as CameraProblem;
    }
    video.srcObject = this.stream;
    video.setAttribute('playsinline', 'true');
    await video.play().catch(() => undefined);

    const native = await this.nativeDetector();
    const jsQr = native ? null : await this.loadJsQr();
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d', { willReadFrequently: true });

    const tick = async () => {
      if (this.stopped) return;
      try {
        if (video.readyState >= 2 && video.videoWidth > 0) {
          let text: string | null = null;
          if (native) {
            const found = await native.detect(video);
            text = found[0]?.rawValue ?? null;
          } else if (jsQr && context) {
            // Reduz o quadro (até 640 px) para decodificar rápido em celulares.
            const scale = Math.min(1, 640 / Math.max(video.videoWidth, video.videoHeight));
            canvas.width = Math.round(video.videoWidth * scale);
            canvas.height = Math.round(video.videoHeight * scale);
            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            const image = context.getImageData(0, 0, canvas.width, canvas.height);
            text = jsQr(image.data, image.width, image.height, { inversionAttempts: 'dontInvert' })?.data ?? null;
          }
          if (text) onResult(text);
        }
      } catch {
        /* quadro ainda indisponível */
      }
      if (!this.stopped) this.timer = setTimeout(tick, 250);
    };
    void tick();
  }

  stop(): void {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
  }

  private async nativeDetector(): Promise<BarcodeDetectorLike | null> {
    const Ctor = (window as unknown as { BarcodeDetector?: { new (o: object): BarcodeDetectorLike; getSupportedFormats?: () => Promise<string[]> } })
      .BarcodeDetector;
    if (!Ctor) return null;
    try {
      const supported = (await Ctor.getSupportedFormats?.()) ?? ['qr_code'];
      if (!supported.includes('qr_code')) return null;
      // QR Code do cartão (carteiras digitais) e códigos de barras de cartões impressos.
      return new Ctor({ formats: ['qr_code', 'code_128', 'code_39'].filter((f) => supported.includes(f)) });
    } catch {
      return null;
    }
  }

  private async loadJsQr(): Promise<JsQr | null> {
    try {
      const mod = (await import('jsqr')) as unknown as { default?: JsQr } & JsQr;
      return (mod.default ?? mod) as JsQr;
    } catch {
      return null;
    }
  }
}
