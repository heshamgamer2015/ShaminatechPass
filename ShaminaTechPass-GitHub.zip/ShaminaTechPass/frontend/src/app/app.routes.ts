import { Routes } from '@angular/router';
import {
  authGuard,
  establishmentGuard,
  guestGuard,
  homeRedirectGuard,
  landingGuard,
  platformAdminGuard,
  sessionGuard,
} from './core/auth/auth.guards';
import { EstablishmentContext } from './features/establishment/establishment-context.service';

const TITLE = 'ShaminaTech Pass';

export const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    title: 'ShaminaTech Pass · Fidelidade digital no Google Wallet e Apple Wallet',
    canActivate: [landingGuard],
    loadComponent: () => import('./features/landing/landing.page').then((m) => m.LandingPage),
  },
  // Atalho para o painel de quem já está logado (antigo comportamento da raiz).
  { path: 'inicio', canActivate: [homeRedirectGuard], children: [] },
  {
    path: 'login',
    title: `Entrar · ${TITLE}`,
    canActivate: [guestGuard],
    loadComponent: () => import('./features/auth/login.page').then((m) => m.LoginPage),
  },
  {
    path: 'alterar-senha',
    title: `Alterar senha · ${TITLE}`,
    canActivate: [sessionGuard],
    loadComponent: () => import('./features/auth/change-password.page').then((m) => m.ChangePasswordPage),
  },
  {
    path: 'estabelecimentos',
    title: `Estabelecimentos · ${TITLE}`,
    canActivate: [authGuard],
    loadComponent: () => import('./features/home/select-establishment.page').then((m) => m.SelectEstablishmentPage),
  },

  // ---------- Painel ShaminaTech ----------
  {
    path: 'admin',
    canActivate: [authGuard, platformAdminGuard],
    loadComponent: () => import('./features/admin/admin-layout.component').then((m) => m.AdminLayoutComponent),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'estabelecimentos' },
      {
        path: 'estabelecimentos',
        title: `Estabelecimentos · ${TITLE}`,
        loadComponent: () => import('./features/admin/establishments-list.page').then((m) => m.EstablishmentsListPage),
      },
      {
        path: 'estabelecimentos/novo',
        title: `Novo estabelecimento · ${TITLE}`,
        loadComponent: () => import('./features/admin/establishment-create.page').then((m) => m.EstablishmentCreatePage),
      },
      {
        path: 'estabelecimentos/:id',
        title: `Estabelecimento · ${TITLE}`,
        loadComponent: () => import('./features/admin/establishment-detail.page').then((m) => m.EstablishmentDetailPage),
      },
      {
        path: 'usuarios',
        title: `Usuários · ${TITLE}`,
        loadComponent: () => import('./features/admin/users.page').then((m) => m.UsersPage),
      },
      {
        path: 'regras-padrao',
        title: `Regras padrão · ${TITLE}`,
        loadComponent: () => import('./features/admin/defaults.page').then((m) => m.DefaultsPage),
      },
      {
        path: 'auditoria',
        title: `Auditoria · ${TITLE}`,
        loadComponent: () => import('./features/admin/admin-audit.page').then((m) => m.AdminAuditPage),
      },
      {
        path: 'homologacao-apple-wallet',
        title: `Apple Wallet — Homologação · ${TITLE}`,
        loadComponent: () => import('./features/admin/apple-homologation.page').then((m) => m.AppleHomologationPage),
      },
    ],
  },

  // ---------- Painel do estabelecimento ----------
  {
    path: 'e/:establishmentId',
    canActivate: [authGuard, establishmentGuard],
    providers: [EstablishmentContext],
    loadComponent: () =>
      import('./features/establishment/establishment-layout.component').then((m) => m.EstablishmentLayoutComponent),
    children: [
      {
        path: '',
        pathMatch: 'full',
        title: `Visão geral · ${TITLE}`,
        loadComponent: () => import('./features/establishment/overview.page').then((m) => m.OverviewPage),
      },
      {
        path: 'plano',
        title: `Plano · ${TITLE}`,
        loadComponent: () => import('./features/establishment/plan.page').then((m) => m.PlanPage),
      },
      {
        path: 'clientes',
        title: `Clientes · ${TITLE}`,
        loadComponent: () => import('./features/establishment/consumers.page').then((m) => m.ConsumersPage),
      },
      {
        path: 'clientes/:consumerId',
        title: `Cliente · ${TITLE}`,
        loadComponent: () => import('./features/establishment/consumer-detail.page').then((m) => m.ConsumerDetailPage),
      },
      {
        path: 'programas',
        title: `Programas de fidelidade · ${TITLE}`,
        loadComponent: () => import('./features/establishment/programs.page').then((m) => m.ProgramsPage),
      },
      {
        path: 'programas/novo',
        title: `Novo programa · ${TITLE}`,
        loadComponent: () => import('./features/establishment/program-wizard.page').then((m) => m.ProgramWizardPage),
      },
      {
        path: 'programas/:programId',
        title: `Programa · ${TITLE}`,
        loadComponent: () => import('./features/establishment/program-edit.page').then((m) => m.ProgramEditPage),
      },
      {
        path: 'cartoes',
        title: `Cartões · ${TITLE}`,
        loadComponent: () => import('./features/establishment/cards.page').then((m) => m.CardsPage),
      },
      {
        path: 'cartoes/:cardId',
        title: `Cartão · ${TITLE}`,
        loadComponent: () => import('./features/establishment/card-detail.page').then((m) => m.CardDetailPage),
      },
      {
        path: 'notificacoes',
        title: `Notificações e proximidade · ${TITLE}`,
        loadComponent: () => import('./features/establishment/notifications.page').then((m) => m.NotificationsPage),
      },
      {
        path: 'qr-cadastro',
        title: `QR Code do programa · ${TITLE}`,
        loadComponent: () => import('./features/establishment/signup-qr.page').then((m) => m.SignupQrPage),
      },
      {
        path: 'operacao',
        title: `Registrar compra · ${TITLE}`,
        loadComponent: () => import('./features/establishment/operation.page').then((m) => m.OperationPage),
      },
      {
        path: 'movimentacoes',
        title: `Movimentações · ${TITLE}`,
        loadComponent: () => import('./features/establishment/transactions.page').then((m) => m.TransactionsPage),
      },
      {
        path: 'recompensas',
        title: `Recompensas · ${TITLE}`,
        loadComponent: () => import('./features/establishment/rewards.page').then((m) => m.RewardsPage),
      },
      {
        path: 'personalizacao',
        title: `Personalização · ${TITLE}`,
        loadComponent: () => import('./features/establishment/branding.page').then((m) => m.BrandingPage),
      },
      {
        path: 'indicadores',
        title: `Indicadores · ${TITLE}`,
        loadComponent: () => import('./features/establishment/indicators.page').then((m) => m.IndicatorsPage),
      },
      {
        path: 'carteiras',
        title: `Carteiras digitais · ${TITLE}`,
        loadComponent: () => import('./features/establishment/wallet.page').then((m) => m.WalletPage),
      },
      {
        path: 'configuracoes',
        title: `Configurações · ${TITLE}`,
        loadComponent: () => import('./features/establishment/settings.page').then((m) => m.SettingsPage),
      },
      {
        path: 'auditoria',
        title: `Auditoria · ${TITLE}`,
        loadComponent: () =>
          import('./features/establishment/establishment-audit.page').then((m) => m.EstablishmentAuditPage),
      },
    ],
  },

  // ---------- Autocadastro do estabelecimento (escolha do plano; sem cobrança na fase de testes) ----------
  {
    path: 'criar-conta',
    title: `Criar conta · ${TITLE}`,
    loadComponent: () => import('./features/public/business-signup.page').then((m) => m.BusinessSignupPage),
  },

  // ---------- Página pública do consumidor (sem login) ----------
  {
    path: 'cadastro/:token',
    title: 'Cadastro no programa de fidelidade',
    loadComponent: () => import('./features/public/signup.page').then((m) => m.SignupPage),
  },
  {
    path: 'carteira/:token',
    title: `Adicionar à carteira · ${TITLE}`,
    loadComponent: () => import('./features/public/wallet-link.page').then((m) => m.WalletLinkPage),
  },

  // ---------- Mensagens ----------
  {
    path: 'acesso-negado',
    title: `Acesso negado · ${TITLE}`,
    data: { heading: 'Acesso negado', message: 'Você não tem permissão para acessar esta área.' },
    loadComponent: () => import('./features/errors/message.page').then((m) => m.MessagePage),
  },
  {
    path: 'sem-acesso',
    title: `Sem acesso · ${TITLE}`,
    canActivate: [authGuard],
    data: {
      heading: 'Nenhum estabelecimento vinculado',
      message: 'Sua conta ainda não está vinculada a um estabelecimento ativo. Fale com o responsável.',
    },
    loadComponent: () => import('./features/errors/message.page').then((m) => m.MessagePage),
  },
  {
    path: '**',
    title: `Página não encontrada · ${TITLE}`,
    loadComponent: () => import('./features/errors/message.page').then((m) => m.MessagePage),
  },
];
