import { PolicyView, ProgramType } from './loyalty-models';

// Tipos espelhando os DTOs da API do backend.

export type PlatformRole = 'PLATFORM_ADMIN';
export type MembershipRole = 'OWNER' | 'MANAGER' | 'STAFF';
export type EstablishmentStatus = 'ACTIVE' | 'SUSPENDED' | 'CANCELLED';
export type UserStatus = 'ACTIVE' | 'DISABLED';
export type MembershipStatus = 'ACTIVE' | 'DISABLED';
export type Permission =
  | 'ESTABLISHMENT_VIEW'
  | 'ESTABLISHMENT_EDIT'
  | 'AUDIT_VIEW'
  | 'CONSUMERS_VIEW'
  | 'CONSUMERS_MANAGE'
  | 'PROGRAMS_MANAGE'
  | 'CARDS_MANAGE'
  | 'TRANSACTIONS_REGISTER'
  | 'TRANSACTIONS_REVERSE'
  | 'REPORTS_VIEW';

export interface MembershipSummary {
  establishmentId: number;
  establishmentName: string;
  establishmentSlug: string;
  establishmentStatus: EstablishmentStatus;
  role: MembershipRole;
}

export interface Me {
  id: number;
  email: string;
  fullName: string;
  platformRole: PlatformRole | null;
  passwordChangeRequired: boolean;
  memberships: MembershipSummary[];
}

export interface Page<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
}

export interface Member {
  membershipId: number;
  userId: number;
  email: string;
  fullName: string;
  role: MembershipRole;
  status: MembershipStatus;
  userStatus: UserStatus;
  createdAt: string;
}

export interface AuditEvent {
  id: number;
  occurredAt: string;
  action: string;
  actorUserId: number | null;
  actorEmail: string | null;
  establishmentId: number | null;
  targetType: string | null;
  targetId: string | null;
  details: string | null;
}

export interface Usage {
  activeConsumers: number;
  totalConsumers: number;
  maxActiveConsumers: number;
  activeCards: number;
  totalCards: number;
}

export interface EstablishmentSummary {
  id: number;
  name: string;
  slug: string;
  status: EstablishmentStatus;
  contactEmail: string | null;
  createdAt: string;
  usage: Usage;
  /** Plano escolhido no autocadastro (null = limites definidos pela ShaminaTech). */
  plan?: { code: 'FREE' | 'GROWTH' | 'PRO'; name: string; selfSignup: boolean; trialFree: boolean } | null;
}

export interface EstablishmentDetail extends EstablishmentSummary {
  contactPhone: string | null;
  updatedAt: string;
  account: Member | null;
  policy: PolicyView;
  programsByType: Partial<Record<ProgramType, number>>;
}

export interface UserSummary {
  id: number;
  email: string;
  fullName: string;
  platformRole: PlatformRole | null;
  status: UserStatus;
  locked: boolean;
  lastLoginAt: string | null;
  createdAt: string;
}

export interface EstablishmentPanel {
  id: number;
  name: string;
  slug: string;
  status: EstablishmentStatus;
  contactEmail: string | null;
  contactPhone: string | null;
  myRole: MembershipRole;
  permissions: Permission[];
  policy: PolicyView;
}
