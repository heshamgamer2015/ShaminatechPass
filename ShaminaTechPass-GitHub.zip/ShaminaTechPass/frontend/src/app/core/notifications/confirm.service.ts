import { Injectable, signal } from '@angular/core';

export interface ConfirmOptions {
  title: string;
  message?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  /** 'danger' para ações destrutivas ou definitivas. */
  tone?: 'primary' | 'danger';
  /** Pede um motivo: opcional ou obrigatório (o botão só libera com texto). */
  reason?: 'none' | 'optional' | 'required';
  reasonLabel?: string;
}

export interface ConfirmRequest extends ConfirmOptions {
  resolve: (reason: string | null) => void;
}

/**
 * Confirmação de ações importantes com o diálogo do próprio produto (no lugar de confirm()/prompt() do navegador).
 * {@link ask} resolve com o motivo digitado ('' quando não há motivo) ou null quando a pessoa cancela.
 * Um pedido novo cancela o anterior que ainda estiver aberto.
 */
@Injectable({ providedIn: 'root' })
export class ConfirmService {
  readonly current = signal<ConfirmRequest | null>(null);

  ask(options: ConfirmOptions): Promise<string | null> {
    this.current()?.resolve(null);
    return new Promise((resolve) => {
      this.current.set({
        ...options,
        resolve: (value) => {
          this.current.set(null);
          resolve(value);
        },
      });
    });
  }

  /** Atalho para confirmação simples (sem motivo). */
  async confirm(options: ConfirmOptions): Promise<boolean> {
    return (await this.ask({ ...options, reason: 'none' })) !== null;
  }
}
