import { HttpErrorResponse } from '@angular/common/http';
import { toApiError } from './api-error';

describe('toApiError', () => {
  it('lê o problem+json do backend com erros por campo', () => {
    const error = new HttpErrorResponse({
      status: 400,
      error: {
        detail: 'Verifique os campos informados.',
        code: 'VALIDATION_ERROR',
        errors: [
          { field: 'slug', message: 'Identificador inválido.' },
          { field: 'slug', message: 'Outra mensagem.' },
          { field: 'owner.email', message: 'E-mail inválido.' },
        ],
      },
    });
    const result = toApiError(error);
    expect(result.status).toBe(400);
    expect(result.code).toBe('VALIDATION_ERROR');
    expect(result.message).toBe('Verifique os campos informados.');
    expect(result.fieldErrors).toEqual({ slug: 'Identificador inválido.', 'owner.email': 'E-mail inválido.' });
  });

  it('trata falha de rede (status 0)', () => {
    const result = toApiError(new HttpErrorResponse({ status: 0 }));
    expect(result.code).toBe('NETWORK');
    expect(result.message).toContain('conectar ao servidor');
  });

  it('usa mensagem padrão quando o corpo não é JSON', () => {
    const result = toApiError(new HttpErrorResponse({ status: 503, error: '<html>' }));
    expect(result.message).toContain('servidor');
    expect(result.fieldErrors).toEqual({});
  });

  it('é idempotente para erros já convertidos', () => {
    const once = toApiError(new HttpErrorResponse({ status: 403 }));
    expect(toApiError(once)).toBe(once);
  });
});
