import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ProgramType } from '../loyalty-models';
import { Me } from '../models';

export type PlanCode = 'FREE' | 'GROWTH' | 'PRO';

export interface PlanOffer {
  code: PlanCode;
  name: string;
  /** Preço comercial previsto, em centavos (informativo: não há cobrança). */
  listPriceCents: number;
  /** null = ilimitado. */
  maxActiveConsumers: number | null;
  maxPrograms: number | null;
  maxProgramTypes: number;
  selectable: boolean;
}

export interface PlanCatalog {
  trialFree: boolean;
  selfSignupEnabled: boolean;
  trialMessage: string | null;
  plans: PlanOffer[];
}

export interface EstablishmentSignupPayload {
  plan: PlanCode;
  establishmentName: string;
  contactEmail: string | null;
  contactPhone: string | null;
  ownerName: string;
  email: string;
  password: string;
  passwordConfirmation: string;
  termsAccepted: boolean;
  website: string;
}

export interface EstablishmentSignupResult {
  establishmentId: number;
  plan: PlanCode;
  trialFree: boolean;
  me: Me;
}

/** Plano do estabelecimento. code nulo = limites definidos individualmente pela ShaminaTech. */
export interface EstablishmentPlanView {
  code: PlanCode | null;
  name: string | null;
  listPriceCents: number | null;
  trialFree: boolean;
  accessStatus: string | null;
  origin: 'SELF_SIGNUP' | 'PLATFORM_ADMIN' | null;
  since: string | null;
  trialMessage: string | null;
  limits: { maxActiveConsumers: number | null; maxPrograms: number | null; maxProgramTypes: number | null };
  usage: { activeConsumers: number; programs: number; typesInUse: ProgramType[] };
  allowedTypes: ProgramType[];
}

/** Planos e autocadastro de estabelecimentos. */
@Injectable({ providedIn: 'root' })
export class PlanApi {
  private readonly http = inject(HttpClient);

  catalog(): Observable<PlanCatalog> {
    return this.http.get<PlanCatalog>('/api/public/plans');
  }

  signup(payload: EstablishmentSignupPayload): Observable<EstablishmentSignupResult> {
    return this.http.post<EstablishmentSignupResult>('/api/public/establishment-signup', payload);
  }

  plan(establishmentId: number): Observable<EstablishmentPlanView> {
    return this.http.get<EstablishmentPlanView>(`/api/establishments/${establishmentId}/plan`);
  }
}

/** "R$ 59" (preço comercial previsto). */
export function formatPlanPrice(cents: number): string {
  return 'R$ ' + (cents / 100).toLocaleString('pt-BR', { minimumFractionDigits: cents % 100 ? 2 : 0 });
}

export function limitLabel(value: number | null, one: string, many: string): string {
  if (value === null) return `${many} ilimitados`;
  return `Até ${value} ${value === 1 ? one : many}`;
}
