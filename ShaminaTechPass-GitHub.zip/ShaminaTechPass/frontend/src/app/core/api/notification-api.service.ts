import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import {
  EstablishmentLocationData,
  LocationPayload,
  NotificationOverview,
  NotificationSettingsData,
  ReminderStatus,
  ReminderView,
} from '../loyalty-models';
import { Page } from '../models';

/** Notificações e proximidade do estabelecimento. */
@Injectable({ providedIn: 'root' })
export class NotificationApi {
  private readonly http = inject(HttpClient);

  overview(eid: number): Observable<NotificationOverview> {
    return this.http.get<NotificationOverview>(`/api/establishments/${eid}/notifications`);
  }

  saveSettings(eid: number, settings: NotificationSettingsData): Observable<NotificationSettingsData> {
    return this.http.put<NotificationSettingsData>(`/api/establishments/${eid}/notifications/settings`, settings);
  }

  history(eid: number, status: ReminderStatus | '', page: number): Observable<Page<ReminderView>> {
    let params = new HttpParams().set('page', page).set('size', 20);
    if (status) params = params.set('status', status);
    return this.http.get<Page<ReminderView>>(`/api/establishments/${eid}/notifications/history`, { params });
  }

  saveLocation(eid: number, id: number | null, body: LocationPayload): Observable<EstablishmentLocationData> {
    return id === null
      ? this.http.post<EstablishmentLocationData>(`/api/establishments/${eid}/locations`, body)
      : this.http.put<EstablishmentLocationData>(`/api/establishments/${eid}/locations/${id}`, body);
  }

  deleteLocation(eid: number, id: number): Observable<void> {
    return this.http.delete<void>(`/api/establishments/${eid}/locations/${id}`);
  }
}
