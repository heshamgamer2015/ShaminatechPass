import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import {
  CardWallet,
  CreatedWalletLink,
  PublicWalletPass,
  WalletIntegrationStatus,
  WalletPassView,
  WalletSyncStatus,
} from '../loyalty-models';
import { Page } from '../models';

/** Carteiras digitais: painel (autenticado) e página pública do consumidor. Nenhuma credencial do Google passa por aqui. */
@Injectable({ providedIn: 'root' })
export class WalletApi {
  private readonly http = inject(HttpClient);

  status(eid: number): Observable<WalletIntegrationStatus> {
    return this.http.get<WalletIntegrationStatus>(`/api/establishments/${eid}/wallet`);
  }

  passes(eid: number, status: WalletSyncStatus | '', page: number): Observable<Page<WalletPassView>> {
    let params = new HttpParams().set('page', page).set('size', 20);
    if (status) params = params.set('status', status);
    return this.http.get<Page<WalletPassView>>(`/api/establishments/${eid}/wallet/passes`, { params });
  }

  cardWallet(eid: number, cardId: number): Observable<CardWallet> {
    return this.http.get<CardWallet>(`/api/establishments/${eid}/cards/${cardId}/wallet`);
  }

  createLink(eid: number, cardId: number): Observable<CreatedWalletLink> {
    // Um link serve para as duas carteiras: o cliente escolhe Google Wallet ou Apple Wallet na página do link.
    return this.http.post<CreatedWalletLink>(`/api/establishments/${eid}/cards/${cardId}/wallet/links`, {});
  }

  retry(eid: number, passId: number): Observable<CardWallet> {
    return this.http.post<CardWallet>(`/api/establishments/${eid}/wallet/passes/${passId}/retry`, {});
  }

  revoke(eid: number, linkId: number): Observable<CardWallet> {
    return this.http.post<CardWallet>(`/api/establishments/${eid}/wallet/links/${linkId}/revoke`, {});
  }

  openPublic(token: string): Observable<PublicWalletPass> {
    return this.http.get<PublicWalletPass>(`/api/public/wallet-links/${encodeURIComponent(token)}`);
  }
}
