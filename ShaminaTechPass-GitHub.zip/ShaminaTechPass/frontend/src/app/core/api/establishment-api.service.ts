import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { AuditEvent, EstablishmentPanel, Page } from '../models';

export interface UpdateEstablishmentPayload {
  name: string;
  contactEmail: string | null;
  contactPhone: string | null;
}

/** Painel do estabelecimento (/api/establishments/{id}). */
@Injectable({ providedIn: 'root' })
export class EstablishmentApi {
  private readonly http = inject(HttpClient);

  panel(id: number): Observable<EstablishmentPanel> {
    return this.http.get<EstablishmentPanel>(`/api/establishments/${id}`);
  }

  update(id: number, payload: UpdateEstablishmentPayload): Observable<EstablishmentPanel> {
    return this.http.put<EstablishmentPanel>(`/api/establishments/${id}`, payload);
  }

  audit(id: number, page: number): Observable<Page<AuditEvent>> {
    return this.http.get<Page<AuditEvent>>(`/api/establishments/${id}/audit`, { params: { page, size: 20 } });
  }
}
