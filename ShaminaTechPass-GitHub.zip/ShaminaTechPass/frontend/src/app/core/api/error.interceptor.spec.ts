import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { vi } from 'vitest';
import { SessionStore } from '../auth/session.store';
import { ApiError } from './api-error';
import { errorInterceptor } from './error.interceptor';

describe('errorInterceptor', () => {
  let http: HttpClient;
  let backend: HttpTestingController;
  let session: SessionStore;
  let navigate: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideRouter([]), provideHttpClient(withInterceptors([errorInterceptor])), provideHttpClientTesting()],
    });
    http = TestBed.inject(HttpClient);
    backend = TestBed.inject(HttpTestingController);
    session = TestBed.inject(SessionStore);
    navigate = vi.spyOn(TestBed.inject(Router), 'navigate').mockResolvedValue(true);
    session.user.set({ id: 1, email: 'a@a', fullName: 'A', platformRole: null, passwordChangeRequired: false, memberships: [] });
  });

  afterEach(() => backend.verify());

  async function failWith(url: string, status: number, body: object): Promise<ApiError> {
    const request = firstValueFrom(http.get(url));
    backend.expectOne(url).flush(body, { status, statusText: 'x' });
    return request.then(
      () => {
        throw new Error('deveria falhar');
      },
      (e: ApiError) => e,
    );
  }

  it('sessão expirada: limpa o estado e leva ao login', async () => {
    const error = await failWith('/api/establishments/1', 401, { code: 'SESSION_REVOKED', detail: 'Sua sessão foi encerrada.' });
    expect(error.code).toBe('SESSION_REVOKED');
    expect(session.user()).toBeNull();
    expect(navigate).toHaveBeenCalledWith(['/login'], { queryParams: { sessao: 'expirada' } });
  });

  it('401 da sondagem /api/auth/me não força redirecionamento', async () => {
    await failWith('/api/auth/me', 401, { code: 'UNAUTHENTICATED' });
    expect(navigate).not.toHaveBeenCalled();
  });

  it('troca de senha pendente leva à tela de troca', async () => {
    await failWith('/api/admin/users', 403, { code: 'PASSWORD_CHANGE_REQUIRED', detail: 'Altere sua senha.' });
    expect(navigate).toHaveBeenCalledWith(['/alterar-senha']);
  });

  it('403 comum é repassado à tela sem redirecionar', async () => {
    const error = await failWith('/api/establishments/2', 403, { code: 'FORBIDDEN', detail: 'Sem acesso.' });
    expect(error.message).toBe('Sem acesso.');
    expect(navigate).not.toHaveBeenCalled();
    expect(session.user()).not.toBeNull();
  });
});
