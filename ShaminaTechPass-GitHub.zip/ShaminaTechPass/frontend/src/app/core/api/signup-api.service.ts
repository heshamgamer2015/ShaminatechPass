import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, switchMap } from 'rxjs';
import { PublicSignupInfo, PublicSignupRequest, PublicSignupResult, SignupLinkView, SignupOverview } from '../loyalty-models';

/** QR Code de cadastro: painel (autenticado) e página pública do consumidor (sem login). */
@Injectable({ providedIn: 'root' })
export class SignupApi {
  private readonly http = inject(HttpClient);

  overview(eid: number): Observable<SignupOverview> {
    return this.http.get<SignupOverview>(`/api/establishments/${eid}/signup-links`);
  }

  create(eid: number, programId: number): Observable<SignupLinkView> {
    return this.http.post<SignupLinkView>(`/api/establishments/${eid}/programs/${programId}/signup-link`, {});
  }

  setActive(eid: number, linkId: number, active: boolean): Observable<SignupLinkView> {
    return this.http.post<SignupLinkView>(`/api/establishments/${eid}/signup-links/${linkId}/status`, { active });
  }

  regenerate(eid: number, linkId: number): Observable<SignupLinkView> {
    return this.http.post<SignupLinkView>(`/api/establishments/${eid}/signup-links/${linkId}/regenerate`, {});
  }

  /** Endereço da imagem do QR Code (servida pela API autenticada, mesma origem). */
  qrUrl(eid: number, linkId: number, format: 'svg' | 'png', download = false, version = ''): string {
    return `/api/establishments/${eid}/signup-links/${linkId}/qr?format=${format}${download ? '&download=true' : ''}${version ? '&v=' + encodeURIComponent(version) : ''}`;
  }

  info(token: string): Observable<PublicSignupInfo> {
    return this.http.get<PublicSignupInfo>(`/api/public/signup/${encodeURIComponent(token)}`);
  }

  /** O envio exige o cookie CSRF: é obtido antes (o consumidor não tem sessão). */
  register(token: string, body: PublicSignupRequest): Observable<PublicSignupResult> {
    return this.http
      .get('/api/auth/csrf')
      .pipe(switchMap(() => this.http.post<PublicSignupResult>(`/api/public/signup/${encodeURIComponent(token)}`, body)));
  }
}
