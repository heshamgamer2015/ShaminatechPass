import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { SessionStore } from '../auth/session.store';
import { toApiError } from './api-error';

/** Endpoints em que 401 é uma resposta esperada (não significa sessão expirada). */
const AUTH_PROBES = ['/api/auth/me', '/api/auth/login', '/api/auth/csrf'];

/**
 * Converte erros HTTP em {@link ApiError} e trata casos globais:
 * sessão expirada/revogada → login; troca de senha pendente → tela de troca.
 */
export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const router = inject(Router);
  const session = inject(SessionStore);

  return next(req).pipe(
    catchError((error: unknown) => {
      const apiError = toApiError(error);
      if (error instanceof HttpErrorResponse) {
        const isProbe = AUTH_PROBES.some((path) => req.url.startsWith(path));
        if (apiError.status === 401 && !isProbe && session.isAuthenticated()) {
          session.clear();
          void router.navigate(['/login'], { queryParams: { sessao: 'expirada' } });
        } else if (apiError.code === 'PASSWORD_CHANGE_REQUIRED') {
          void router.navigate(['/alterar-senha']);
        }
      }
      return throwError(() => apiError);
    }),
  );
};
