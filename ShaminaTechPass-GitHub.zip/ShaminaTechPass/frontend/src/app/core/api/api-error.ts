import { HttpErrorResponse } from '@angular/common/http';

/** Erro normalizado da API (problem+json do backend) para exibição na interface. */
export interface ApiError {
  status: number;
  code: string;
  message: string;
  /** Mensagens por campo do formulário (ex.: { slug: 'Este identificador já está em uso.' }). */
  fieldErrors: Record<string, string>;
}

interface ProblemBody {
  detail?: string;
  code?: string;
  errors?: { field: string; message: string }[];
}

export function toApiError(error: unknown): ApiError {
  if (isApiError(error)) {
    return error;
  }
  if (!(error instanceof HttpErrorResponse)) {
    return { status: -1, code: 'UNKNOWN', message: 'Ocorreu um erro inesperado.', fieldErrors: {} };
  }
  if (error.status === 0) {
    return {
      status: 0,
      code: 'NETWORK',
      message: 'Não foi possível conectar ao servidor. Verifique sua conexão.',
      fieldErrors: {},
    };
  }
  const body = (typeof error.error === 'object' && error.error !== null ? error.error : {}) as ProblemBody;
  const fieldErrors: Record<string, string> = {};
  for (const item of body.errors ?? []) {
    fieldErrors[item.field] ??= item.message;
  }
  return {
    status: error.status,
    code: body.code ?? `HTTP_${error.status}`,
    message: body.detail ?? defaultMessage(error.status),
    fieldErrors,
  };
}

export function isApiError(value: unknown): value is ApiError {
  return typeof value === 'object' && value !== null && 'fieldErrors' in value && 'code' in value;
}

function defaultMessage(status: number): string {
  if (status === 401) return 'Faça login para continuar.';
  if (status === 403) return 'Você não tem permissão para esta ação.';
  if (status === 404) return 'Registro não encontrado.';
  if (status >= 500) return 'O servidor encontrou um erro. Tente novamente em instantes.';
  return 'Não foi possível concluir a operação.';
}
