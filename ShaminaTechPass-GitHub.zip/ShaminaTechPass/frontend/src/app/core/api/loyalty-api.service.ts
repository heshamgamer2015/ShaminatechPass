import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import {
  Card,
  CardDetail,
  CardStatus,
  Channel,
  Consumer,
  ConsumerDetail,
  ConsumerStatus,
  Indicators,
  OperationResult,
  Overview,
  Program,
  ProgramPayload,
  ProgramStatus,
  Reward,
  TransactionType,
  Transaction,
  VipTier,
} from '../loyalty-models';
import { Page } from '../models';

export interface ConsumerPayload {
  fullName: string;
  phone: string;
  email: string | null;
  externalRef: string | null;
  marketingOptIn: boolean;
  privacyAcknowledged?: boolean;
}

export interface EarnPayload {
  purchaseAmount?: number | null;
  quantity?: number | null;
  channel: Channel;
  note?: string | null;
}

export interface RedeemPayload {
  rewardId?: number | null;
  amount?: number | null;
  purchaseAmount?: number | null;
  channel: Channel;
  note?: string | null;
}

/** Fidelidade do painel do estabelecimento (/api/establishments/{id}/...). */
@Injectable({ providedIn: 'root' })
export class LoyaltyApi {
  private readonly http = inject(HttpClient);

  private base(eid: number): string {
    return `/api/establishments/${eid}`;
  }

  /** Chave de idempotência: gerada uma vez por confirmação e reenviada em caso de nova tentativa. */
  static newKey(): string {
    return crypto.randomUUID();
  }

  overview(eid: number): Observable<Overview> {
    return this.http.get<Overview>(`${this.base(eid)}/overview`);
  }

  indicators(eid: number, days: number, programId: number | null = null): Observable<Indicators> {
    const params: Record<string, number> = { days };
    if (programId !== null) params['programId'] = programId;
    return this.http.get<Indicators>(`${this.base(eid)}/indicators`, { params });
  }

  // ---------- Consumidores ----------
  consumers(eid: number, q: string, status: ConsumerStatus | '', page: number): Observable<Page<Consumer>> {
    let params = new HttpParams().set('page', page).set('size', 20);
    if (q.trim()) params = params.set('q', q.trim());
    if (status) params = params.set('status', status);
    return this.http.get<Page<Consumer>>(`${this.base(eid)}/consumers`, { params });
  }

  consumer(eid: number, id: number): Observable<ConsumerDetail> {
    return this.http.get<ConsumerDetail>(`${this.base(eid)}/consumers/${id}`);
  }

  createConsumer(eid: number, payload: ConsumerPayload): Observable<Consumer> {
    return this.http.post<Consumer>(`${this.base(eid)}/consumers`, payload);
  }

  updateConsumer(eid: number, id: number, payload: ConsumerPayload): Observable<Consumer> {
    return this.http.put<Consumer>(`${this.base(eid)}/consumers/${id}`, payload);
  }

  consumerStatus(eid: number, id: number, status: ConsumerStatus): Observable<Consumer> {
    return this.http.patch<Consumer>(`${this.base(eid)}/consumers/${id}/status`, { status });
  }

  consumerHistory(eid: number, id: number, page: number): Observable<Page<Transaction>> {
    return this.http.get<Page<Transaction>>(`${this.base(eid)}/consumers/${id}/transactions`, { params: { page, size: 20 } });
  }

  // ---------- Programas ----------
  programs(eid: number): Observable<Program[]> {
    return this.http.get<Program[]>(`${this.base(eid)}/programs`);
  }

  program(eid: number, id: number): Observable<Program> {
    return this.http.get<Program>(`${this.base(eid)}/programs/${id}`);
  }

  createProgram(eid: number, payload: ProgramPayload): Observable<Program> {
    return this.http.post<Program>(`${this.base(eid)}/programs`, payload);
  }

  updateProgram(eid: number, id: number, payload: ProgramPayload): Observable<Program> {
    return this.http.put<Program>(`${this.base(eid)}/programs/${id}`, payload);
  }

  programStatus(eid: number, id: number, status: ProgramStatus): Observable<Program> {
    return this.http.patch<Program>(`${this.base(eid)}/programs/${id}/status`, { status });
  }

  updateDesign(eid: number, id: number, design: { brandColor: string; textColor: string; cardMessage: string | null; rewardInfo: string | null }): Observable<Program> {
    return this.http.put<Program>(`${this.base(eid)}/programs/${id}/design`, design);
  }

  uploadImage(eid: number, id: number, slot: 'logo' | 'hero', file: File): Observable<Program> {
    const body = new FormData();
    body.append('file', file);
    return this.http.post<Program>(`${this.base(eid)}/programs/${id}/images/${slot}`, body);
  }

  removeImage(eid: number, id: number, slot: 'logo' | 'hero'): Observable<Program> {
    return this.http.delete<Program>(`${this.base(eid)}/programs/${id}/images/${slot}`);
  }

  rewards(eid: number, programId?: number): Observable<Reward[]> {
    const params: Record<string, number> = programId ? { programId } : {};
    return this.http.get<Reward[]>(`${this.base(eid)}/rewards`, { params });
  }

  createReward(eid: number, programId: number, body: { name: string; description: string | null; cost: number; active: boolean }): Observable<Reward> {
    return this.http.post<Reward>(`${this.base(eid)}/programs/${programId}/rewards`, body);
  }

  updateReward(eid: number, id: number, body: { name: string; description: string | null; cost: number; active: boolean }): Observable<Reward> {
    return this.http.put<Reward>(`${this.base(eid)}/rewards/${id}`, body);
  }

  tiers(eid: number, programId: number): Observable<VipTier[]> {
    return this.http.get<VipTier[]>(`${this.base(eid)}/programs/${programId}/tiers`);
  }

  saveTier(eid: number, programId: number, tier: Omit<VipTier, 'id'>, id?: number): Observable<VipTier> {
    const url = `${this.base(eid)}/programs/${programId}/tiers`;
    return id ? this.http.put<VipTier>(`${url}/${id}`, tier) : this.http.post<VipTier>(url, tier);
  }

  // ---------- Cartões ----------
  cards(eid: number, filter: { status?: CardStatus | ''; programId?: number | null; q?: string }, page: number): Observable<Page<Card>> {
    let params = new HttpParams().set('page', page).set('size', 20);
    if (filter.status) params = params.set('status', filter.status);
    if (filter.programId) params = params.set('programId', filter.programId);
    if (filter.q?.trim()) params = params.set('q', filter.q.trim());
    return this.http.get<Page<Card>>(`${this.base(eid)}/cards`, { params });
  }

  card(eid: number, id: number): Observable<CardDetail> {
    return this.http.get<CardDetail>(`${this.base(eid)}/cards/${id}`);
  }

  lookup(eid: number, code: string): Observable<CardDetail> {
    return this.http.get<CardDetail>(`${this.base(eid)}/cards/lookup`, { params: { code } });
  }

  issueCard(eid: number, consumerId: number, programId: number, inactivityDaysOverride: number | null): Observable<Card> {
    return this.http.post<Card>(`${this.base(eid)}/cards`, { consumerId, programId, inactivityDaysOverride });
  }

  cardAction(eid: number, id: number, action: 'suspend' | 'reactivate' | 'cancel', reason: string | null): Observable<Card> {
    return this.http.post<Card>(`${this.base(eid)}/cards/${id}/${action}`, { reason });
  }

  cardHistory(eid: number, id: number, page: number): Observable<Page<Transaction>> {
    return this.http.get<Page<Transaction>>(`${this.base(eid)}/cards/${id}/transactions`, { params: { page, size: 20 } });
  }

  // ---------- Movimentações ----------
  earn(eid: number, cardId: number, payload: EarnPayload, key: string): Observable<OperationResult> {
    return this.http.post<OperationResult>(`${this.base(eid)}/cards/${cardId}/earn`, payload, { headers: { 'Idempotency-Key': key } });
  }

  redeem(eid: number, cardId: number, payload: RedeemPayload, key: string): Observable<OperationResult> {
    return this.http.post<OperationResult>(`${this.base(eid)}/cards/${cardId}/redeem`, payload, { headers: { 'Idempotency-Key': key } });
  }

  reverse(eid: number, transactionId: number, reason: string, key: string): Observable<OperationResult> {
    return this.http.post<OperationResult>(`${this.base(eid)}/transactions/${transactionId}/reverse`, { reason }, {
      headers: { 'Idempotency-Key': key },
    });
  }

  transactions(eid: number, types: TransactionType[], page: number): Observable<Page<Transaction>> {
    let params = new HttpParams().set('page', page).set('size', 20);
    for (const t of types) params = params.append('type', t);
    return this.http.get<Page<Transaction>>(`${this.base(eid)}/transactions`, { params });
  }
}
