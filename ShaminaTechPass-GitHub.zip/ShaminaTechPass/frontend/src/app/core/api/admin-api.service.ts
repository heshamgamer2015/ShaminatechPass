import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import {
  AuditEvent,
  EstablishmentDetail,
  EstablishmentStatus,
  EstablishmentSummary,
  Page,
  UserStatus,
  UserSummary,
} from '../models';
import { PolicyView } from '../loyalty-models';

export interface CreateEstablishmentPayload {
  name: string;
  slug: string;
  contactEmail: string | null;
  contactPhone: string | null;
  owner: { email: string; fullName: string; temporaryPassword: string | null };
}

/** Homologação Apple Wallet (só no backend local). */
export interface AppleHomologationStatus {
  ready: boolean;
  certificate: {
    loaded: boolean;
    passTypeIdentifier: string | null;
    teamIdentifier: string | null;
    subject: string | null;
    issuer: string | null;
    expiresAt: string | null;
    error: string | null;
  };
  missing: string[];
  updatablePassesConfigured: boolean;
  lanAddresses: string[];
  linkTtlMinutes: number;
}

export interface AppleHomologationPass {
  serialNumber: string;
  sha256: string;
  sizeBytes: number;
  token: string;
  installPath: string;
  createdAt: string;
  expiresAt: string;
}

/** Painel ShaminaTech (/api/admin). */
@Injectable({ providedIn: 'root' })
export class AdminApi {
  private readonly http = inject(HttpClient);

  establishments(q: string, status: EstablishmentStatus | '', page: number): Observable<Page<EstablishmentSummary>> {
    let params = new HttpParams().set('page', page).set('size', 20);
    if (q.trim()) params = params.set('q', q.trim());
    if (status) params = params.set('status', status);
    return this.http.get<Page<EstablishmentSummary>>('/api/admin/establishments', { params });
  }

  establishment(id: number): Observable<EstablishmentDetail> {
    return this.http.get<EstablishmentDetail>(`/api/admin/establishments/${id}`);
  }

  createEstablishment(payload: CreateEstablishmentPayload): Observable<EstablishmentDetail> {
    return this.http.post<EstablishmentDetail>('/api/admin/establishments', payload);
  }

  changeEstablishmentStatus(id: number, status: EstablishmentStatus): Observable<EstablishmentDetail> {
    return this.http.patch<EstablishmentDetail>(`/api/admin/establishments/${id}/status`, { status });
  }

  updatePolicy(id: number, policy: PolicyView): Observable<EstablishmentDetail> {
    return this.http.put<EstablishmentDetail>(`/api/admin/establishments/${id}/policy`, policy);
  }

  resetAccountPassword(id: number, temporaryPassword: string): Observable<EstablishmentDetail> {
    return this.http.post<EstablishmentDetail>(`/api/admin/establishments/${id}/account/reset-password`, { temporaryPassword });
  }

  defaults(): Observable<PolicyView> {
    return this.http.get<PolicyView>('/api/admin/loyalty-defaults');
  }

  updateDefaults(policy: PolicyView): Observable<PolicyView> {
    return this.http.put<PolicyView>('/api/admin/loyalty-defaults', policy);
  }

  users(q: string, page: number): Observable<Page<UserSummary>> {
    let params = new HttpParams().set('page', page).set('size', 20);
    if (q.trim()) params = params.set('q', q.trim());
    return this.http.get<Page<UserSummary>>('/api/admin/users', { params });
  }

  changeUserStatus(id: number, status: UserStatus): Observable<UserSummary> {
    return this.http.patch<UserSummary>(`/api/admin/users/${id}/status`, { status });
  }

  unlockUser(id: number): Observable<UserSummary> {
    return this.http.post<UserSummary>(`/api/admin/users/${id}/unlock`, null);
  }

  audit(page: number): Observable<Page<AuditEvent>> {
    return this.http.get<Page<AuditEvent>>('/api/admin/audit', { params: { page, size: 30 } });
  }

  appleHomologation(): Observable<AppleHomologationStatus> {
    return this.http.get<AppleHomologationStatus>('/api/admin/apple-wallet/homologation');
  }

  generateAppleHomologationPass(): Observable<AppleHomologationPass> {
    return this.http.post<AppleHomologationPass>('/api/admin/apple-wallet/homologation/passes', null);
  }

  /** Imagem (SVG) do QR Code do endereço de instalação — o backend só aceita o endereço de um link ativo. */
  appleHomologationQrUrl(installUrl: string): string {
    return `/api/admin/apple-wallet/homologation/qr?url=${encodeURIComponent(installUrl)}`;
  }
}
