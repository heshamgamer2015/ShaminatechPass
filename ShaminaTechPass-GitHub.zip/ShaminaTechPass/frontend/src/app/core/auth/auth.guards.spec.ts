import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot, UrlTree, convertToParamMap, provideRouter } from '@angular/router';
import { Me } from '../models';
import { AuthService } from './auth.service';
import { authGuard, establishmentGuard, guestGuard, landingGuard, platformAdminGuard } from './auth.guards';
import { SessionStore } from './session.store';

function me(overrides: Partial<Me> = {}): Me {
  return {
    id: 1,
    email: 'dono@teste.local',
    fullName: 'Dono',
    platformRole: null,
    passwordChangeRequired: false,
    memberships: [
      { establishmentId: 10, establishmentName: 'Loja A', establishmentSlug: 'loja-a', establishmentStatus: 'ACTIVE', role: 'OWNER' },
    ],
    ...overrides,
  };
}

describe('guards de autenticação', () => {
  let session: SessionStore;
  let router: Router;
  const state = { url: '/e/10/equipe' } as RouterStateSnapshot;

  const run = (guard: typeof authGuard, route = {} as ActivatedRouteSnapshot) =>
    TestBed.runInInjectionContext(() => guard(route, state));
  const asUrl = (result: unknown) => router.serializeUrl(result as UrlTree);

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()] });
    session = TestBed.inject(SessionStore);
    router = TestBed.inject(Router);
  });

  it('authGuard envia visitante para o login preservando o destino', () => {
    expect(asUrl(run(authGuard))).toBe('/login?voltar=%2Fe%2F10%2Fequipe');
  });

  it('authGuard exige a troca de senha pendente antes de qualquer tela', () => {
    session.user.set(me({ passwordChangeRequired: true }));
    expect(asUrl(run(authGuard))).toBe('/alterar-senha');
  });

  it('authGuard libera usuário logado', () => {
    session.user.set(me());
    expect(run(authGuard)).toBe(true);
  });

  it('platformAdminGuard bloqueia quem não é administrador', () => {
    session.user.set(me());
    expect(asUrl(run(platformAdminGuard))).toBe('/acesso-negado');
    session.user.set(me({ platformRole: 'PLATFORM_ADMIN' }));
    expect(run(platformAdminGuard)).toBe(true);
  });

  it('establishmentGuard só libera estabelecimentos vinculados ao usuário', () => {
    session.user.set(me());
    const route = (id: string) => ({ paramMap: convertToParamMap({ establishmentId: id }) }) as ActivatedRouteSnapshot;
    expect(run(establishmentGuard, route('10'))).toBe(true);
    expect(asUrl(run(establishmentGuard, route('99')))).toBe('/acesso-negado');
  });

  it('landingGuard mostra a página comercial ao visitante e leva quem está logado ao painel', () => {
    expect(run(landingGuard)).toBe(true);
    session.user.set(me());
    expect(asUrl(run(landingGuard))).toBe('/e/10');
    session.user.set(me({ platformRole: 'PLATFORM_ADMIN', memberships: [] }));
    expect(asUrl(run(landingGuard))).toBe('/admin');
  });

  it('guestGuard redireciona usuário já logado para a sua área', () => {
    expect(run(guestGuard)).toBe(true);
    session.user.set(me());
    expect(asUrl(run(guestGuard))).toBe('/e/10');
  });

  it('homeUrl escolhe a área conforme o perfil', () => {
    const auth = TestBed.inject(AuthService);
    expect(auth.homeUrl()).toBe('/login');
    session.user.set(me({ platformRole: 'PLATFORM_ADMIN', memberships: [] }));
    expect(auth.homeUrl()).toBe('/admin');
    session.user.set(me({ memberships: [] }));
    expect(auth.homeUrl()).toBe('/sem-acesso');
    const two = me().memberships.concat({ ...me().memberships[0], establishmentId: 11 });
    session.user.set(me({ memberships: two }));
    expect(auth.homeUrl()).toBe('/estabelecimentos');
  });
});
