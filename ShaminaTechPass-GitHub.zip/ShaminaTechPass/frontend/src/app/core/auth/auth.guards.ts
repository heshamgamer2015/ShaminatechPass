import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth.service';

/*
 * Guards de navegação. Servem à experiência de uso (evitar telas que retornariam erro);
 * a autorização real é sempre feita pelo backend em cada requisição.
 */

/** Usuário logado e sem troca de senha pendente. */
export const authGuard: CanActivateFn = (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const user = auth.user();
  if (!user) {
    return router.createUrlTree(['/login'], { queryParams: { voltar: state.url } });
  }
  if (user.passwordChangeRequired) {
    return router.createUrlTree(['/alterar-senha']);
  }
  return true;
};

/** Apenas exige sessão (usado na própria tela de troca de senha). */
export const sessionGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  return auth.user() ? true : inject(Router).createUrlTree(['/login']);
};

/** Tela de login só para quem ainda não entrou. */
export const guestGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  return auth.user() ? inject(Router).parseUrl(auth.homeUrl()) : true;
};

export const platformAdminGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  return auth.isPlatformAdmin() ? true : inject(Router).createUrlTree(['/acesso-negado']);
};

/** O usuário precisa ter vínculo ativo com o estabelecimento da URL. */
export const establishmentGuard: CanActivateFn = (route) => {
  const auth = inject(AuthService);
  const id = Number(route.paramMap.get('establishmentId'));
  const allowed = auth.user()?.memberships.some((m) => m.establishmentId === id) ?? false;
  return allowed ? true : inject(Router).createUrlTree(['/acesso-negado']);
};

/** Rota raiz: encaminha para a área certa do perfil. */
/** Página comercial pública na raiz: visitantes veem a landing page; quem já está logado vai direto ao seu painel. */
export const landingGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  return auth.user() ? inject(Router).parseUrl(auth.homeUrl()) : true;
};

export const homeRedirectGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  return inject(Router).parseUrl(auth.homeUrl());
};
