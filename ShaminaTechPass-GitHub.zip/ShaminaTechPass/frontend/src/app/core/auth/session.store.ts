import { Injectable, computed, signal } from '@angular/core';
import { Me } from '../models';

/**
 * Estado da sessão no navegador. Não guarda tokens: a sessão real é o cookie HttpOnly
 * do backend. Separado do AuthService para que o interceptor HTTP possa usá-lo sem
 * criar dependência circular com o HttpClient.
 */
@Injectable({ providedIn: 'root' })
export class SessionStore {
  readonly user = signal<Me | null>(null);
  readonly isAuthenticated = computed(() => this.user() !== null);
  readonly isPlatformAdmin = computed(() => this.user()?.platformRole === 'PLATFORM_ADMIN');

  clear(): void {
    this.user.set(null);
  }
}
