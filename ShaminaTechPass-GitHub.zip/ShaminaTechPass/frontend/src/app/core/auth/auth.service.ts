import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { Me } from '../models';
import { SessionStore } from './session.store';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly session = inject(SessionStore);

  readonly user = this.session.user;
  readonly isPlatformAdmin = this.session.isPlatformAdmin;

  /** Executado na inicialização do app: prepara o cookie CSRF e recupera a sessão existente. */
  async init(): Promise<void> {
    await this.ensureCsrfCookie();
    await this.refresh();
  }

  async refresh(): Promise<Me | null> {
    try {
      const me = await firstValueFrom(this.http.get<Me>('/api/auth/me'));
      this.session.user.set(me);
      return me;
    } catch {
      this.session.clear();
      return null;
    }
  }

  async login(email: string, password: string): Promise<Me> {
    await this.ensureCsrfCookie();
    const me = await firstValueFrom(this.http.post<Me>('/api/auth/login', { email: email.trim(), password }));
    this.session.user.set(me);
    return me;
  }

  /** Sessão aberta pelo próprio servidor (autocadastro do estabelecimento): só registra o usuário no app. */
  adoptSession(me: Me): void {
    this.session.user.set(me);
  }

  async logout(): Promise<void> {
    try {
      await firstValueFrom(this.http.post('/api/auth/logout', null));
    } finally {
      this.session.clear();
      // O logout invalida o token CSRF; um novo é necessário para o próximo login.
      await this.ensureCsrfCookie();
    }
  }

  async changePassword(currentPassword: string, newPassword: string): Promise<void> {
    await firstValueFrom(this.http.post('/api/auth/change-password', { currentPassword, newPassword }));
    await this.refresh();
  }

  /** Rota inicial adequada ao perfil do usuário. */
  homeUrl(): string {
    const user = this.user();
    if (!user) return '/login';
    if (user.passwordChangeRequired) return '/alterar-senha';
    if (user.platformRole === 'PLATFORM_ADMIN') return '/admin';
    if (user.memberships.length === 1) return `/e/${user.memberships[0].establishmentId}`;
    if (user.memberships.length > 1) return '/estabelecimentos';
    return '/sem-acesso';
  }

  private async ensureCsrfCookie(): Promise<void> {
    try {
      await firstValueFrom(this.http.get('/api/auth/csrf'));
    } catch {
      // Backend indisponível: o erro aparecerá na próxima ação do usuário.
    }
  }
}
