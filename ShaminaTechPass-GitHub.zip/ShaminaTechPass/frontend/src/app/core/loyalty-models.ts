// Tipos espelhando os DTOs de fidelidade do backend (LoyaltyDtos / MetricsService).
// Valores monetários e saldos chegam como número JSON; o cálculo oficial é sempre do backend (BigDecimal).

export type ProgramType = 'POINTS' | 'CASHBACK' | 'STAMPS' | 'VIP';
export type ProgramStatus = 'ACTIVE' | 'PAUSED' | 'ARCHIVED';
export type ValidityMode = 'END_OF_DAY' | 'EXACT_TIME';
export type ExpiredBalancePolicy = 'KEEP' | 'FORFEIT';
export type ReversalPolicy = 'REQUIRE_BALANCE' | 'ALLOW_NEGATIVE';
export type Rounding = 'DOWN' | 'HALF_UP' | 'UP';
export type StampCriterion = 'PURCHASE' | 'PRODUCT' | 'VISIT';
export type CardStatus = 'ACTIVE' | 'SUSPENDED' | 'EXPIRED' | 'COMPLETED' | 'CANCELLED';
export type ConsumerStatus = 'ACTIVE' | 'INACTIVE';
export type Channel = 'MANUAL' | 'QR_CODE' | 'NFC' | 'API' | 'SYSTEM' | 'PUBLIC_SIGNUP';
export type TransactionType =
  | 'EARN'
  | 'REDEEM'
  | 'REVERSAL'
  | 'BENEFIT_EXPIRED'
  | 'BALANCE_FORFEITED'
  | 'CARD_ISSUED'
  | 'CARD_SUSPENDED'
  | 'CARD_REACTIVATED'
  | 'CARD_EXPIRED'
  | 'CARD_CANCELLED';

export interface PolicyView {
  maxActiveConsumers: number;
  allowedProgramTypes: ProgramType[];
  defaultInactivityDays: number;
  timeZone: string;
}

export interface Consumer {
  id: number;
  fullName: string;
  phone: string;
  email: string | null;
  externalRef: string | null;
  status: ConsumerStatus;
  source: 'PANEL' | 'PUBLIC_QR';
  marketingOptIn: boolean;
  privacyAcknowledgedAt: string;
  createdAt: string;
  statusChangedAt: string | null;
  activeCards: number;
}

export interface ConsumerDetail {
  consumer: Consumer;
  cards: Card[];
}

export interface Design {
  brandColor: string;
  textColor: string;
  cardMessage: string | null;
  rewardInfo: string | null;
  logoUrl: string | null;
  heroUrl: string | null;
  walletNotes: string[];
}

export interface Program {
  id: number;
  type: ProgramType;
  typeAllowed: boolean;
  operational: boolean;
  name: string;
  description: string | null;
  status: ProgramStatus;
  inactivityDays: number;
  validityMode: ValidityMode;
  expiredBalancePolicy: ExpiredBalancePolicy;
  reversalPolicy: ReversalPolicy;
  benefitValidityDays: number | null;
  minPurchaseAmount: number | null;
  rounding: Rounding | null;
  pointsPerUnit: number | null;
  spendUnit: number | null;
  cashbackPercent: number | null;
  maxCreditPerPurchase: number | null;
  minRedeemBalance: number | null;
  maxRedeemPercent: number | null;
  stampsRequired: number | null;
  stampCriterion: StampCriterion | null;
  stampReward: string | null;
  restartAfterRedeem: boolean | null;
  design: Design;
  createdAt: string;
}

export type ProgramPayload = Omit<Program, 'id' | 'typeAllowed' | 'operational' | 'status' | 'design' | 'createdAt'>;

export interface Reward {
  id: number;
  programId: number;
  programName: string;
  name: string;
  description: string | null;
  cost: number;
  active: boolean;
}

export interface VipTier {
  id: number;
  name: string;
  rankOrder: number;
  minSpend: number | null;
  minVisits: number | null;
  periodDays: number | null;
  benefits: string | null;
}

export interface Card {
  id: number;
  code: string;
  displayCode: string;
  status: CardStatus;
  storedStatus: CardStatus;
  balance: number;
  availableBalance: number;
  programId: number;
  programName: string;
  programType: ProgramType;
  consumerId: number;
  consumerName: string;
  issuedAt: string;
  lastMovementAt: string | null;
  expiresAt: string;
  validUntil: string;
  timeZone: string;
  inactivityDays: number;
  statusReason: string | null;
  completedCycles: number;
  stampsRequired: number | null;
  rewardAvailable: boolean;
  nextBenefitExpiry: { amount: number; expiresAt: string } | null;
}

export interface Lot {
  id: number;
  originalAmount: number;
  remaining: number;
  expiredAmount: number;
  expiresAt: string | null;
  status: 'OPEN' | 'CONSUMED' | 'EXPIRED' | 'FORFEITED';
  createdAt: string;
}

export interface CardDetail {
  card: Card;
  lots: Lot[];
  rewards: Reward[];
  design: Design;
  programDescription: string | null;
}

export interface Transaction {
  id: number;
  type: TransactionType;
  channel: Channel;
  amount: number;
  balanceAfter: number;
  purchaseAmount: number | null;
  description: string | null;
  note: string | null;
  occurredAt: string;
  reversesId: number | null;
  reversed: boolean;
  reversible: boolean;
  cardId: number;
  cardCode: string;
  consumerId: number;
  consumerName: string | null;
  programId: number;
  programName: string | null;
  programType: ProgramType | null;
  cardStatusAfter: CardStatus;
  cardExpiresAtAfter: string;
}

export interface OperationResult {
  transaction: Transaction;
  card: Card;
  replayed: boolean;
  notRestored: number;
}

export interface Overview {
  activeConsumers: number;
  totalConsumers: number;
  maxActiveConsumers: number;
  limitUsedPercent: number;
  limitReached: boolean;
  cards: { active: number; suspended: number; expired: number; completed: number; cancelled: number };
  periodDays: number;
  benefitsGranted: { type: ProgramType; operations: number; amount: number }[];
  rewardsRedeemed: number;
  recentTransactions: Transaction[];
  activePrograms: number;
  totalPrograms: number;
  activeSignupLinks: number;
  selfSignups: number;
  nearReward: NearReward[];
}

export interface NearReward {
  cardId: number;
  consumerId: number;
  consumerName: string;
  programName: string;
  programType: ProgramType;
  available: number;
  target: number;
  remaining: number;
  ready: boolean;
  rewardName: string | null;
}

export interface BenefitTotals {
  type: ProgramType;
  operations: number;
  amount: number;
}

export interface Indicators {
  periodDays: number;
  from: string;
  to: string;
  visits: number;
  purchases: number;
  totalPurchaseAmount: number;
  consumersWithVisits: number;
  recurringConsumers: number;
  visitsPerConsumer: number | null;
  averageDaysBetweenVisits: number | null;
  recoveredConsumers: number;
  rewardsRedeemed: number;
  sufficientData: boolean;
  notes: string[];
  programId: number | null;
  /** Null quando filtrado por programa (cadastro de cliente não pertence a um programa). */
  newConsumers: number | null;
  selfSignups: number;
  cardsIssued: number;
  returningConsumers: number;
  returnRatePercent: number | null;
  inactiveConsumers: number;
  benefitsGranted: BenefitTotals[];
  benefitsRedeemed: BenefitTotals[];
  weekly: { start: string; visits: number; consumers: number }[];
}

// ---------------- Cadastro público por QR Code (Etapa 5) ----------------

export interface SignupLinkView {
  id: number;
  active: boolean;
  url: string;
  tokenCreatedAt: string;
  statusChangedAt: string | null;
  signups: number;
  lastSignupAt: string | null;
}

export interface ProgramSignup {
  programId: number;
  programName: string;
  programType: ProgramType;
  programStatus: ProgramStatus;
  eligible: boolean;
  issue: string | null;
  link: SignupLinkView | null;
}

export interface SignupOverview {
  programs: ProgramSignup[];
  activeConsumers: number;
  maxActiveConsumers: number;
  full: boolean;
}

export interface PublicSignupInfo {
  status: 'OPEN' | 'FULL' | 'UNAVAILABLE';
  message: string | null;
  establishmentName: string | null;
  programName: string | null;
  programDescription: string | null;
  programType: ProgramType | null;
  rules: string[];
  rewards: { name: string; description: string | null; cost: number }[];
  validity: string[];
  stampsRequired: number | null;
  stampReward: string | null;
  design: {
    brandColor: string;
    textColor: string;
    logoUrl: string | null;
    heroUrl: string | null;
    cardMessage: string | null;
    rewardInfo: string | null;
  } | null;
  formToken: string | null;
  walletAvailable: boolean;
  /** Carteiras disponíveis (GOOGLE_WALLET, APPLE_WALLET); a página destaca a do aparelho. */
  wallets?: string[];
}

export interface PublicSignupRequest {
  fullName: string;
  phone: string;
  email: string | null;
  privacyAccepted: boolean;
  marketingOptIn: boolean;
  requestId: string;
  formToken: string | null;
  website: string;
}

export interface PublicSignupResult {
  status: 'REGISTERED';
  establishmentName: string;
  programName: string;
  programType: ProgramType;
  consumerFirstName: string;
  walletPath: string | null;
  walletStatus: 'LINK_READY' | 'NOT_CONFIGURED';
  message: string;
}

// ---------------- Carteiras digitais (Etapa 3) ----------------

export type WalletSyncStatus = 'PENDING' | 'SYNCING' | 'SYNCED' | 'FAILED' | 'INVALIDATED';

export interface WalletIntegrationStatus {
  provider: 'GOOGLE_WALLET';
  enabled: boolean;
  configured: boolean;
  missing: string[];
  passes: Partial<Record<WalletSyncStatus, number>>;
  notes: string[];
  apple: AppleWalletStatus;
}

export interface AppleWalletStatus {
  enabled: boolean;
  configured: boolean;
  missing: string[];
  notes: string[];
}

export interface WalletPassView {
  id: number;
  cardId: number;
  cardCode: string | null;
  consumerName: string | null;
  programName: string | null;
  provider: 'GOOGLE_WALLET' | 'APPLE_WALLET';
  status: WalletSyncStatus;
  remoteState: string | null;
  attempts: number;
  lastSyncedAt: string | null;
  lastAttemptAt: string | null;
  nextAttemptAt: string | null;
  lastError: string | null;
  lastErrorStatus: number | null;
  retryAllowed: boolean;
}

export interface WalletLinkView {
  id: number;
  createdAt: string;
  expiresAt: string;
  revokedAt: string | null;
  lastUsedAt: string | null;
  useCount: number;
  usable: boolean;
}

/** pass/available/missing: Google Wallet. apple*: Apple Wallet. */
export interface CardWallet {
  pass: WalletPassView | null;
  links: WalletLinkView[];
  available: boolean;
  missing: string[];
  apple: WalletPassView | null;
  appleDevices: number;
  appleAvailable: boolean;
  appleMissing: string[];
}

export interface CreatedWalletLink {
  url: string;
  expiresAt: string;
  wallet: CardWallet;
}

export interface PublicWalletPass {
  establishmentName: string;
  programName: string;
  programType: ProgramType;
  consumerFirstName: string;
  status: 'READY' | 'PREPARING' | 'UNAVAILABLE';
  message: string | null;
  saveUrl: string | null;
  linkExpiresAt: string;
  /** Carteiras oferecidas ao consumidor (null = indisponível). url: Google = endereço de salvamento; Apple = caminho do .pkpass. */
  google: WalletOption | null;
  apple: WalletOption | null;
}

export interface WalletOption {
  status: 'READY' | 'PREPARING';
  url: string | null;
}

// ---------------- Notificações e proximidade (Etapa 6) ----------------

export type ReminderCategory = 'NEAR_REWARD' | 'EXPIRY' | 'INACTIVITY';
export type ReminderStatus = 'PENDING' | 'SENDING' | 'ACCEPTED' | 'FAILED' | 'REJECTED' | 'QUOTA_EXCEEDED' | 'CANCELLED';

export interface NotificationSettingsData {
  nearRewardEnabled: boolean;
  nearRewardStamps: number;
  nearRewardPointsPercent: number;
  expiryEnabled: boolean;
  expiryDaysBefore: number;
  inactivityEnabled: boolean;
  inactivityDays: number;
  minIntervalDays: number;
  proximityEnabled: boolean;
  proximityText: string | null;
}

export interface EstablishmentLocationData {
  id: number;
  name: string;
  addressLine: string;
  city: string;
  state: string;
  postalCode: string;
  latitude: number;
  longitude: number;
}

export type LocationPayload = Omit<EstablishmentLocationData, 'id'>;

export interface WalletCapability {
  key: string;
  title: string;
  available: boolean;
  detail: string;
}

export interface ReminderView {
  id: number;
  category: ReminderCategory;
  status: ReminderStatus;
  header: string;
  body: string;
  cardId: number;
  consumerFirstName: string | null;
  programName: string | null;
  plannedAt: string;
  lastAttemptAt: string | null;
  acceptedAt: string | null;
  withdrawnAt: string | null;
  attempts: number;
  nextAttemptAt: string | null;
  closedReason: string | null;
  lastError: string | null;
  lastErrorStatus: number | null;
}

export interface NotificationOverview {
  settings: NotificationSettingsData;
  locations: EstablishmentLocationData[];
  maxLocations: number;
  integration: { googleConfigured: boolean; googleMissing: string[]; appleConfigured: boolean };
  capabilities: WalletCapability[];
  last30Days: Partial<Record<ReminderStatus, number>>;
  recentFailures: ReminderView[];
  notes: string[];
}
