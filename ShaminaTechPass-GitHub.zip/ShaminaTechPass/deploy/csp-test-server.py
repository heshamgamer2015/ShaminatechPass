"""
Servidor de VERIFICAÇÃO (não é servidor de produção) do build Angular com os mesmos cabeçalhos de segurança
recomendados em deploy/nginx/shaminatech-pass.conf:

  * troca __CSP_NONCE__ por um valor aleatório a cada resposta HTML;
  * envia CSP rígida (sem 'unsafe-inline'), X-Content-Type-Options, Referrer-Policy, Permissions-Policy, frame-ancestors;
  * encaminha /api para o backend local (127.0.0.1:8083), preservando cookies e cabeçalhos;
  * escuta só em 127.0.0.1.

Uso:  python -I deploy/csp-test-server.py  [porta]   (padrão 4300; requer `npx ng build` antes)
"""
import http.client
import http.server
import os
import secrets
import sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend", "dist", "frontend", "browser")
BACKEND = ("127.0.0.1", 8083)
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 4300


def csp(nonce: str) -> str:
    return (
        "default-src 'self'; "
        "script-src 'self' 'nonce-" + nonce + "'; "
        "style-src 'self' 'nonce-" + nonce + "'; "
        "img-src 'self' data: blob:; "
        "font-src 'self'; "
        "connect-src 'self'; "
        "media-src 'self' blob:; "
        "object-src 'none'; "
        "base-uri 'self'; "
        "form-action 'self'; "
        "frame-ancestors 'none'"
    )


SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "camera=(self), geolocation=(), microphone=(), payment=(), usb=()",
    "X-Frame-Options": "DENY",
    "Cross-Origin-Opener-Policy": "same-origin",
}


class Handler(http.server.BaseHTTPRequestHandler):
    def _proxy(self):
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else None
        conn = http.client.HTTPConnection(*BACKEND, timeout=30)
        headers = {k: v for k, v in self.headers.items() if k.lower() not in ("host", "connection")}
        conn.request(self.command, self.path, body=body, headers=headers)
        resp = conn.getresponse()
        data = resp.read()
        self.send_response(resp.status)
        for k, v in resp.getheaders():
            if k.lower() not in ("transfer-encoding", "connection", "content-length"):
                self.send_header(k, v)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _static(self):
        path = self.path.split("?")[0]
        file = os.path.normpath(os.path.join(ROOT, path.lstrip("/")))
        if not file.startswith(os.path.normpath(ROOT)) or not os.path.isfile(file):
            file = os.path.join(ROOT, "index.html")  # rotas do Angular
        with open(file, "rb") as f:
            data = f.read()
        nonce = secrets.token_urlsafe(18)
        is_html = file.endswith(".html")
        if is_html:
            data = data.replace(b"__CSP_NONCE__", nonce.encode())
        types = {".js": "text/javascript", ".css": "text/css", ".html": "text/html; charset=utf-8", ".svg": "image/svg+xml",
                 ".ico": "image/x-icon", ".png": "image/png", ".json": "application/json"}
        self.send_response(200)
        self.send_header("Content-Type", types.get(os.path.splitext(file)[1], "application/octet-stream"))
        self.send_header("Content-Length", str(len(data)))
        for k, v in SECURITY_HEADERS.items():
            self.send_header(k, v)
        if is_html:
            self.send_header("Content-Security-Policy", csp(nonce))
            self.send_header("Cache-Control", "no-store")
        else:
            self.send_header("Cache-Control", "public, max-age=31536000, immutable")
        self.end_headers()
        self.wfile.write(data)

    def _route(self):
        if self.path.startswith("/api/"):
            self._proxy()
        else:
            self._static()

    do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = _route

    def log_message(self, fmt, *args):
        pass


if __name__ == "__main__":
    print(f"Verificação CSP em http://127.0.0.1:{PORT} (build: {os.path.normpath(ROOT)})")
    http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
